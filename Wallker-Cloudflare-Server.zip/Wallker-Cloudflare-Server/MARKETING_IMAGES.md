# Walker Wallet — социальные изображения

Созданы встроенным imagegen с референсом assets/wolf-level-8.png (наш серый волк, янтарные глаза, чёрный костюм, лаймовый галстук). Сохранены в проект; техническое перекодирование JPG/WebP не меняет композицию.

- assets/avatar-telegram.jpg: квадратная аватарка, 1254 × 1254, около 382 КБ.
- assets/avatar-tiktok.jpg: квадратная аватарка, 1254 × 1254, около 403 КБ.
- assets/task-telegram.webp: широкая карточка, волк и значок Telegram.
- assets/task-tiktok.webp: широкая карточка, волк и значок TikTok.

## Промпты

Telegram avatar: Square avatar, 1024x1024. Preserve the exact friendly grey Walker wolf, amber eyes, muzzle and black suit with lime tie from the reference. A confident waist-up portrait holding a small gold WC coin, dark emerald background with elegant cyan halo, face large and recognizable in a circular social profile crop, head and ears fully inside safe central circle. Premium polished 3D game illustration. No text, no platform icon, no watermarks.

TikTok avatar: Square avatar, 1024x1024. Preserve the exact friendly grey Walker wolf, amber eyes, muzzle and black suit with lime tie from the reference. Confident lively waist-up portrait holding a small gold WC coin, dark charcoal emerald background with tasteful cyan and magenta rim lighting, face large and recognizable in a circular TikTok profile crop, head and ears fully inside safe central circle. Premium polished 3D game illustration. No text, no platform icon, no watermarks.

Telegram card: Wide 16:9 task banner, preferably 1280x720, crisp modest-size web illustration. Preserve the exact friendly grey Walker wolf, amber eyes, muzzle, full-body black suit with lime tie from the reference. Wolf walking confidently on the RIGHT half, shoes and ears inside picture, holding a gold WC coin. On LEFT half a prominent clean official Telegram white paper-plane icon on a blue round emblem. Dark emerald studio park backdrop, subtle cyan glow, coherent polished 3D game art. No text, no other logos, no watermarks. Balanced readable composition for a small task card.

TikTok card: Wide 16:9 task banner, preferably 1280x720, crisp modest-size web illustration. Preserve the exact friendly grey Walker wolf, amber eyes, muzzle, full-body black suit with lime tie from the reference. Wolf walking confidently on the RIGHT half, shoes and ears inside picture, holding a gold WC coin. On LEFT half a prominent recognizable official TikTok musical note glyph, white with cyan/magenta accents on a black round emblem. Dark emerald studio backdrop, subtle cyan and magenta glow, coherent polished 3D game art. No text, no other logos, no watermarks. Balanced readable composition for a small task card.
