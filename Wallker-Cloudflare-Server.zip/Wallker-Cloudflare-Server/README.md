# Walker Wallet — собственный Cloudflare сервер

Подготовлено 3 октября 2026. Сервер и интерфейс проверены локально. Публикация в аккаунте владельца, перенос прежних записей, переключение Telegram-бота и Android APK с новым адресом ещё не выполнены. Текущий APK 0.3.1 продолжает обращаться к старому Sites-серверу.

Этот пакет запускает отдельное приложение и отдельную базу данных. Он не проксирует запросы к Sites, не использует ключи платформы Sites и не изменяет её защиту.

## Первый шаг для владельца

1. В своей панели Cloudflare открой D1 SQL database (обычно Storage & databases → D1).
2. Нажми Create Database, назови новую базу `wallker-wallet`, затем Create.
3. Открой базу и скопируй её Database ID. Это идентификатор базы, не API token.
4. В этом экземпляре `wrangler.jsonc` уже указан Database ID новой базы `wallker-wallet`: `6ceddc00-80eb-4abc-a0b5-a03cec5ddf6a`, полученный со скриншота владельца. Перед публикацией проверь совпадение с базой в своей панели.
5. В консоли именно новой базы выполни содержимое `schema.sql`. SQL создаёт три таблицы и индексы; не удаляет существующие данные. Альтернативный способ после авторизации Wrangler: `npm run db:init`.

## Развёртывание через GitHub

Помести исходники пакета в репозиторий GitHub. Если это папка в общем репозитории, укажи её как Root directory в настройках сборки Cloudflare.

В Cloudflare: Workers & Pages → Create application → Import Git repository. Выбери свой репозиторий, Worker name `wallker-wallet`, build command `npm run build`, deploy command `npx wrangler deploy`. Менеджер пакетов установит зависимости из package.json. Перед публикацией проверь D1 Database ID в исходниках.

Локальный вариант для компьютера с Node 22+: `npm install`, `npm run build`, `npx wrangler login`, `npm run db:init`, `npm run deploy`. Платный тариф не требуется для небольшого теста в пределах бесплатных лимитов; этот пакет не включает его автоматически.

## Подключение бота

В Worker Settings → Variables and Secrets добавь как Secret:

- `TELEGRAM_BOT_TOKEN`: токен основного бота из BotFather; его точный username задаётся TELEGRAM_BOT_USERNAME (без @).
- `TELEGRAM_WEBHOOK_SECRET`: отдельная случайная строка длиной не менее 32 символов (буквы, цифры, `_`, `-`).

Секреты не должны быть в исходниках, ZIP, GitHub-файлах, Android APK или сообщениях чата. Публикация не настраивает webhook автоматически. После проверки нового сервера нужно отдельно переключить webhook Telegram на `https://<фактический-адрес-worker>/api/telegram/webhook` с тем же secret_token и обновить кнопку Mini App в BotFather на корень нового Worker. Адрес получаем из панели Cloudflare; он не известен заранее.

Все запросы Telegram к wallet проверяются по подписи initData. ChatGPT-вход и демо-начисления в независимом сервере отсутствуют. При открытии сайта вне Telegram он предлагает открыть Telegram-бота. CORS по умолчанию разрешает только свой адрес; список дополнительных доверенных источников при необходимости задаётся через ALLOWED_ORIGINS, разделитель — запятая.

## Проверка перед переключением

1. `/api/health` должен вернуть JSON с `ok: true` и `botConfigured: true`. Это проверяет наличие таблиц и настройку токена; не подтверждает связь с телефоном.
2. Неверный 48-значный код в `/api/device/pair` должен дать JSON HTTP 401; без токена `/api/device/steps` тоже HTTP 401. Это ожидаемые отказы авторизации.
3. Открой новый адрес как Mini App именно через бота. Создай код и используй APK, собранный с новым адресом.
4. Проверь: привязка, датчик, передача суточной суммы, обновление баланса в Telegram, повторная передача без повторного начисления, отзыв устройства.

Окончательный результат подтверждается на физическом Android. Локальные тесты не доказывают доступность сервера из сети телефона и не проверяют датчик шагов.

## Перенос и эксплуатация

Новая D1 база начинает пустой. История и балансы из Sites пока не перенесены. Не удаляй старый проект или данные. До переключения пользователей согласуй экспорт/импорт; таблицы users/days/pairings имеют совместимые имена и базовые поля, но секреты и доступы переносятся отдельной процедурой. Старые коды привязки не действуют в новой базе без импорта. После переключения создаём свежие коды.

Шаги поступают без полноценной защиты от накрутки. WC — игровые баллы, без денежных выплат, курса, листинга или гарантии дохода. Награда: 10 WC за полную тысячу шагов, максимум 100 WC за день. Синхронизация принимает сегодня и шесть предыдущих дней по фиксированному часовому поясу профиля; повторные суммы объединяются через MAX.

В базе хранятся Telegram ID, имя, часовой пояс, даты/суточные суммы и хеши секретов привязки. Автоматического удаления истории через 90 дней нет: 90 — только лимит отображаемых строк. Отзыв устройства удаляет привязку, не историю. Политику конфиденциальности, удаление аккаунта, мониторинг, резервные копии, ограничение частоты запросов и защиту от накрутки нужно завершить до публичного запуска с большим числом пользователей.

## Состав

- worker.js: API, проверка Telegram, привязка и синхронизация, webhook.
- schema.sql: новая D1 база.
- wrangler.jsonc: привязки D1/статических файлов.
- src/: интерфейс с прежним дизайном.
- public/: уже собранные статические файлы; build пересоздаёт их из src.
- tests/integration.mjs: проверки в локальном Workers runtime с настоящей временной SQLite/D1 базой.

Проверки выполнены: подпись/срок Telegram, однократное потребление кода при двух параллельных запросах, хранение хешей, повторная синхронизация, суточный лимит, окно 7 дней, разделение аккаунтов, отзыв токена, CORS, secret webhook, ограничения тела запроса, JSON-ошибки. Интерфейс успешно собран esbuild.

Официальные инструкции:
- https://developers.cloudflare.com/workers/get-started/dashboard/
- https://developers.cloudflare.com/d1/get-started/
- https://developers.cloudflare.com/workers/ci-cd/builds/git-integration/github-integration/
- https://developers.cloudflare.com/workers/platform/pricing/

## Beta 0.1.2 / Android 0.3.4

The deployed Android application uses this Worker. Same-account pairing preserves the local ledger and merges up to seven server days; preflight never consumes a code. Replacing a device revokes only its old bearer token. Different-account pairing needs Android confirmation. The ledger uses cumulative daily values, and D1 MAX prevents duplicate WC on retransmission.

`BOT_AUTO_SETUP=true` enables one-time deployment-owned Telegram setup when `/api/health` is checked. The target origin is fixed in the source. Setup uses the configured bot token, sets the webhook and default menu, then verifies both via Telegram. An explicit TELEGRAM_WEBHOOK_SECRET is respected; otherwise a domain-specific HMAC secret is derived from the bot token and never returned. A D1 lease and configuration digest prevent repeated setup. No pending updates are dropped. Main App profile launch settings still require BotFather; historic inline buttons remain unchanged.

The test guide is `public/beta-guide.html`, also linked in the Phone screen. Daily rewards: 10 WC per complete 1,000 steps, at most 100 WC/day. Beta data is unverified; no withdrawal, monetary value or token allocation is promised. Use one phone per account in the first test cohort.

Server 0.1.3 adds a sanitized Telegram setup failure stage, HTTP/API code and fixed reason label to /api/health. Bot tokens, webhook secrets and raw Telegram error descriptions are never returned. Failed setup remains configuration_failed until the one-minute retry lease expires. A successful retry clears the diagnostic.

Server 0.1.4 verifies the configured bot username before modifying Telegram. URL comparison uses URL canonicalisation so an implicit root slash is accepted; different origins, paths, credentials, queries or fragments still fail. Webhook, menu type and menu address failures have separate sanitized reasons.


## Developer menu and Volker — 0.2.0
Set the Cloudflare production environment variable `ADMIN_TELEGRAM_ID` to the owner's numeric Telegram user ID. Do not use a username or bot ID. `/id` in the bot or the Mini App Phone section shows the signed-in user's ID. Without this variable, nobody receives developer privileges. Every admin request verifies Telegram initData and the server allowlist. Changing local UI state cannot grant access.

The developer can create/edit drafts, publish or archive campaigns, schedule their dates, review partner submissions and toggle a mascot sponsor. Step challenges use synchronized steps for today, a one-time reward per campaign and account. Partner tasks require manual developer approval; opening a link is not proof. The WC reward is frozen at submission, so edits do not change pending rewards. Sponsor shirt branding is text (first 12 characters) on the lime shirt; full brand logo/image uploads and shirt color variants are not implemented.

New campaign/claim/mascot tables are created additively on first use. Existing users, device pairings and step history are preserved. Rewards from approved claims contribute to balance separately from step rewards. WC remain beta game points.


## Tap game 0.2.1
The main screen occupies one viewport with a tappable Volker, shared WC balance, level and energy. Each tap earns one WC; capacity 1000, regeneration one energy per second. Rewards are bounded and committed with idempotent receipts in D1. Pending client batches persist per Telegram account. Android uses its existing paired bearer token; Telegram uses verified initData. Taps do not change step history or task rewards. Owner access is still controlled by ADMIN_TELEGRAM_ID in the production environment.

## Rewards 0.2.2
Walking keeps 10 WC per 1,000 steps. New tapping earns 0.1 WC per tap, with 1 energy regenerated per minute. Existing tap rewards are preserved through an idempotent per-account baseline. Fractional rewards persist across sessions. Energy capacity is 100.

## Rewards 0.2.3
Daily taps are capped at 200 WC in the profile timezone, enforced atomically with receipts. Walking rewards from 2026-10-11 are 400 WC per 1,000 steps (floor to whole WC), capped at 4,000 WC daily. 7,500 steps earns 3,000 WC. Older walking days retain their old rate; existing tap earnings are preserved.

## Tap cap 0.2.4
Taps are capped at 1,000 WC/day, reward 0.1 WC per tap, energy capacity 100 with one energy regenerated per second. Walking remains capped at 4,000 WC/day. Existing daily usage is retained when raising the cap.

## Owner reward editor 0.2.5
The developer menu edits tap/step rates (two decimals), daily caps, energy capacity and regeneration interval. Campaign rewards remain per task. Signed owner identity and server validation are required; revision checks reject stale edits. New awards use integer hundredths in persistent ledgers. Existing awards retain their value; changing a rate never recalculates prior earnings. Duplicate/parallel sync and tap requests remain idempotent.

## Owner statistics — 0.2.8

Developer menu → Statistics and users provides owner-only totals, exact all-time WC balances split into walking/tapping/approved campaign rewards, name/username/Telegram ID search, deterministic paginated sorting, individual account history and grouped server errors. Access uses the existing signed Telegram identity and ADMIN_TELEGRAM_ID allowlist; no public leaderboard or arbitrary balance editing is added. Existing balances are preserved by the same legacy conversion used by the wallet.

New analytics tables are created additively. Successful wallet loads, taps, campaign interactions, device pairing and step synchronization contribute to UTC daily activity. Admin statistics reads do not count as activity. First positive synchronization is recorded. No historic visits are invented; existing registration times, balances and step history remain visible. D1/D7 retention refers to users registered exactly one/seven days ago who were active today and remains unavailable until a full measurable cohort exists. Today's figures are provisional.

Server errors and 4xx request rejections are aggregated by hour, sanitized route, status, fixed reason code, verified account and verified platform. Raw exceptions, headers, bodies, query strings, OTPs, device tokens and pairing codes are not recorded. Anonymous request failures share fixed buckets. Error aggregates are retained 30 days, daily activity 90 days, with daily cleanup. Aggregate profile timestamps and balances are not deleted by cleanup. Telemetry failure does not fail successful wallet/sync responses. Mobile crashes, offline failures, app versions and exact sensor errors are not collected by this server-only update. The privacy bot reply describes the additional activity tracking.

Tests cover private access, correct balances/legacy preservation, search/pagination/input escaping, details, actual device error attribution, atomic grouped counters, no leaked secrets, activity/retention, cleanup and wallet availability when analytics storage fails. Existing integration checks still run. Phone applications do not need to be reinstalled.

## Walking levels — 0.2.9

The tappable level row now opens the ten-level Walking Wolf catalog. Progress uses cumulative synchronized daily steps, including existing history, rather than tap count or WC balance. Each unlocked level changes the profile portrait/title. Level thresholds: 0, 1,000, 5,000, 15,000, 30,000, 60,000, 100,000, 200,000, 350,000 and 500,000 steps. One-time WC awards for levels 2–10: 50, 150, 300, 600, 1,000, 2,000, 4,000, 7,500 and 12,000. These awards are additional to daily walking rewards and do not consume daily walking/tap caps. WC remain game points.

The shared catalog lives in level-catalog.mjs, server handling in levels.mjs. GET /api/levels and POST /api/levels/claim require verified Telegram identity and an existing account. Eligibility is checked in SQL from stored steps; a unique user/level key prevents duplicate/concurrent rewards. A claimed award is frozen in integer hundredths. Opening the catalog does not automatically issue coins. Already-eligible users can explicitly claim each outstanding reward. Wallet and owner statistics reconcile the additional levelCoins source.

The ten 3D portrait assets use a single 5-column, 2-row atlas at assets/wolf-levels.png, copied to public by the build. Generated using the built-in imagegen tool, with the existing Volker as an identity reference; prompt: same friendly gray wolf and amber eyes, progression from lime tee/backpack/outdoor clothing through silver/gold medals to tailored gold-trimmed suits and an emerald crown, equal square cells, dark background, no text. CSS displays atlas cells without ten separate downloads.

Tests verify every threshold boundary, existing step history, zero/missing eligibility, signed access, tampered reward/user inputs, no tap-based progress, repeated step uploads, simultaneous/replayed claims, independent user awards, maximum level and all balance totals in both wallet and developer statistics.


## 0.2.10 — pacing and developer level selection
Every new title requires another 45,000 synchronized steps (about 4–5 days at 10,000/day). Thresholds: 0, 45k, 90k, 135k, 180k, 225k, 270k, 315k, 360k, 405k. Existing receipts and balances remain unchanged.
Developer → Rewards and tasks → Your developer level lets the signed owner choose levels 1–10 or reset to automatic step progression. The choice applies only to that owner's account and unlocks the selected level and lower rewards, each payable once. Actual step counts stay unchanged; removed administrators cannot use a stored override. Tests cover access control, reset, replay and balance reconciliation.


## 0.2.11 — taps by walking level and Divine Walker
Effective tap rates and daily WC caps follow the current walking level; existing receipts and paid balances are preserved. Defaults: level 1 = 0.1/1000; levels 2–10 = level × 0.1 WC per tap / 1000+(level−1)×500 WC daily. Owner settings contain an editable rate and cap per level, with revision checks. Existing level-1 reward settings remain compatible.
The owner-only Divine Walker (11) is selected manually, uses a crowned portrait with a gold glow, and defaults to 2 WC/tap and 10000 WC/day (editable). It does not invent steps or provide an extra level bonus. Normal users cannot attain or select this rank. Tap receipts freeze each original award; rank/settings changes never reprice existing taps. Energy restrictions remain active.


## 0.2.12 — rank button, friends, manual grants and VK Steps concept
The tap button renders exactly the current rank portrait from the level atlas, including Divine Walker. A prominent full-width “Уровни Волкера” entry shows rank, progress and an explicit all-levels action.
Friends exchange stable random 20-hex invite codes. A request must be explicitly accepted before either side sees balances and ranks. Removing the edge stops sharing. Only the signed account can act on its edges; concurrent inserts enforce 50 total friends/pending requests per participant. Friend balances use the shared ledger query, including grants, with bounded SQL queries.
Owner menu → Rewards/tasks → Issue WC identifies an existing recipient by Telegram ID and explicitly labels the named grant action. Positive amounts 0.01–1,000,000 WC are stored as integer cents in an audited owner/request ledger. Unique receipts freeze recipient/amount and prevent replay; pending UI requests survive reopening through account-scoped local storage. Wallet and owner statistics show manual awards separately.
Owner menu → VK Steps mock shows a full-body blue shirt mascot and interactive local subscription/registration simulation plus an editable example passive WC calculation. It does not publish any campaign, check subscriptions, activate a user skin or award WC. Cooperation and reward terms remain unapproved.
Generated project asset: assets/volker-vk-steps.png (built-in imagegen, identity-preserving edit of assets/volker.png). Final prompt: preserve the gray amber-eyed waving wolf, pose, joggers and sneakers; replace only the lime shirt with VK blue and exact white Cyrillic two-line “ВК / ШАГИ”; full body on charcoal with subtle blue glow, no other words or props.
Five D1/Workers integration suites cover existing rewards/auth plus friends mutual consent/isolation/removal/bounds, owner grants, validation, atomic replay protection and exact balances across wallet/friends/statistics.

## 0.2.13 — compact screens and the final capped tap
Developer reward/task sections now collapse independently; editing a task opens its form. The connection page is renamed “Подключение”; linked accounts see a wolf success banner and collapsed connection management. Tasks have their own illustrated banner. Wallet shows a balance and seven-day earnings chart, with sources and walk history behind a disclosure. Chart dates respect the profile timezone; frozen step/tap ledgers, approved tasks, level bonuses and manual grants all contribute.
Divine Walker has a dedicated white-and-gold robe portrait with a halo, shared by the main tap button and rank cards. Three new illustration sources are in assets/wolf-{divine,connected,tasks}.png. Run npm run build before deployment; this copies all assets into public. Distribution omits these three redundant generated public PNG copies to remain under GitHub's browser upload size limit.
The final tap may award less than its rate, exactly filling the daily WC cap; integer cents, energy and receipt replay remain atomic. Concurrent partial-final awards and timezone-aware earnings are tested.
Developer → “Игра дня · макет” contains “Комбо маршрута”: pick three locations in the hinted order, with changing calendar-day combinations and a 200 WC example reward. Today/tomorrow/day-after previews and solution reveal are owner-only UI. This local prototype neither publishes a real daily game nor changes balances; real launch requires a server puzzle and exactly-once reward ledger.

## 0.2.14 — full-body wolf ranks, rest state and support
All eleven rank images are independent full-body transparent illustrations. The central tap circle uses safe character sizing so ears, shoes, tail, crown and halo stay inside the button. The level entry is visually quieter and both progress bars show remaining steps. The VK shirt preview contains the entire image within its circular clip.
When the daily WC cap is exhausted, the energy display shows zero and a resting message; the underlying energy ledger remains unchanged. An open mini app checks calendar-day rollover every minute and reloads its server snapshot.
User-facing titles, UI, beta guide and bot messages use Walker Wallet. Existing bot username, deployment URL, archive/extraction paths, database, mobile application IDs and stored credential/storage identifiers retain their legacy spelling for compatibility. Android 0.3.9 source project name is corrected locally; installed Android/iOS app display names were already Walker Wallet.
Support is a signed account-specific form with an owner-only inbox. Bodies (10–2000 chars) and receipts are stored in D1, with an atomic 60-second cooldown and three tickets per rolling 24 hours. The submit form explains that name, Telegram ID and message are shared with the developer. Unique user/request receipts prevent duplicate tickets. Telegram delivery uses only SUPPORT_BOT_TOKEN, never the gameplay bot token; destination comes from SUPPORT_CHAT_ID or a single ADMIN_TELEGRAM_ID. Lease-protected sends are retried by a five-minute cron. Telegram outages retain the ticket without recording raw Telegram errors or tokens. An ambiguous network response can produce a repeated notification with the same ticket number; the database ticket remains unique.
### Connect the support bot
Create a separate bot in BotFather, name it Walker Wallet Support and press Start in it from the developer account. Cloudflare Worker Settings → Variables and Secrets: add SUPPORT_BOT_TOKEN as a secret and SUPPORT_CHAT_ID as the developer's Telegram ID (or an explicitly chosen support group ID). Never put the token in source, a commit, a screenshot or chat. The developer inbox shows connection status. Existing queued messages are automatically retried after configuration. Public support does not yet implement developer replies or attachments.
Six integration suites pass, including support authentication, privacy isolation, owner access, input validation, concurrent deduplication, quotas, mock separate-bot delivery, retry and expired-lease recovery. No real user support messages were sent by the tests.
Full-body prompt set (built-in imagegen, identity-preserving references: established Volker mascot and former rank atlas): centered isolated friendly gray/amber-eyed wolf, whole clothed body including feet, ears and tail, transparent background, no name text. Outfits: 1 lime tee/joggers/sneakers; 2 first backpack; 3 cap and sports jacket; 4 orange expedition kit; 5 silver medal tracksuit; 6 gold medal tracksuit; 7 blazer and gold chain; 8 tailored suit/gold watch/lime tie; 9 gold-trim leader suit; 10 emerald royal suit and crown; 11 full-length white/gold god robe, halo and gold sandals. Assets: assets/wolf-level-1.png through assets/wolf-level-11.png, copied to public by build.mjs. The obsolete bust atlas and divine bust are replaced. Distribution includes source images once and rebuilds public image copies via npm run build. Safe tap-circle scale is 82%; inspection of each asset's alpha coordinates confirms its visible pixels fit within the circular boundary.


## 0.2.15 — главный экран, постоянные настройки, магазин и аналитика

Круг тапа теперь рассчитывается по ширине (до 420px), короткий экран прокручивается. Более насыщенная зелёная палитра. Новые project-bound изображения созданы встроенным imagegen: assets/wolf-friends.png — стая из пяти серых волков в разных костюмах, широкой композиции, группа справа, тёмный фон слева, без текста; assets/wolf-wallet.png — волк в костюме с кошельком и золотыми WC, справа, свободное поле слева. Identity references: wolf-level-1.png и wolf-level-8.png.

Новые версии настроек в D1, черновики по аккаунту, восстановление и JSON. Owner-only постраничный экспорт в офлайн HTML с поиском/CSV. Отдельный баланс WC-Донатов, временные усиления, пакеты игровых WC, защита ledger, Stars invoice/webhook/refund. Реальные платежи выключены до подключения поддержки и тестирования; карта/СБП — только основа для будущего отдельного магазина. Подробности и цены: PAYMENTS.md. Повторяющийся текст о недоступности вывода убран, обещания листинга не добавлены.


## 0.2.16 — четыре раздела, поддержка и Stars

Нижняя панель: Волкер (лапа), Кошелёк, Задания, Друзья; владельцу добавлен Разраб. Подключение находится в кошельке, чат поддержки открывается маленьким значком на главном экране и из магазина. Приватная переписка сохраняется в D1, владелец отвечает в выбранный диалог, старые обращения мигрируют. Polling 5 секунд только для видимой страницы, история страницами по 100. Настройка STARS_PAYMENTS_ENABLED=true включена по запросу владельца. Реальных финансовых операций при разработке не выполняли.

Встроенный imagegen исправил assets/volker-vk-steps.png: прежний полный волк в синей футболке с точной надписью ВК/ШАГИ преобразован в квадратный прозрачный PNG, сохранены лицо, одежда, обувь и хвост. Нет прямоугольного фона и светящейся подложки, персонаж встроен в ту же круглую кнопку.

## 0.2.17 — стая, продвижение и московские сутки

Друзья: компактный баннер, одна кнопка приглашения, счётчики приглашённых, выполнивших условия и начисленных бонусов. Код для взаимного доступа к балансам свёрнут отдельно. Ссылка /start ref_<80-bit-code>; атрибуция допускается только из подписанного start_param или защищённого webhook, закрепляется за новым аккаунтом и не меняется. После подключения шагомера и 5 000 переданных шагов с момента приглашения — 500 WC пригласившему, 100 WC новичку, ровно один раз. Это проверка аккаунта и серверного журнала, не доказательство уникальности человека или достоверности сенсоров. Начисления входят в кампании, кошелёк, график, статистику и экспорт; экспорт также содержит referrals.

Разработчик → Быстрый запуск: шаблоны Telegram (200 WC), TikTok (200 WC) и конкурса мемов/скриншотов/роликов (3 победителя × 3 000 WC). Шаблоны не публикуются автоматически. Вставьте реальные ссылки, проверьте правила и опубликуйте. Конкурс принимает одну публичную ссылку на участника до серверного дедлайна; после него владелец выбирает победителей. Число оплаченных призовых мест защищено атомарным UPDATE. После первой заявки параметры проверки, сроки, количество мест и награды нельзя менять; можно архивировать.

Telegram: создайте публичный канал **Walker Wallet** в своём Telegram, поставьте существующую аватарку, добавьте @wallker_wallet_bot администратором. В шаблоне укажите @имя_канала и https://t.me/имя_канала. Публикация проверяет канал и права бота; кнопка «Проверить подписку» запрашивает getChatMember на сервере. Переход по ссылке не начисляет WC. Ошибка Telegram не подтверждает подписку. TikTok: создайте профиль, вставьте https://www.tiktok.com/@имя, заявки с подтверждениями проверяются владельцем. Аккаунты и канал эта сборка не создаёт. Описание канала: «Walker Wallet 🐺 Прогулки, игровые WC, задания и новости стаи. Шагай вместе с Волкером».

Тапы для всех профилей сбрасываются строго в 00:00 Europe/Moscow (+03:00), по часам Workers. Входные day/now/timezone не меняют сутки. При переходе на московский календарь текущие timestamped receipts сохраняют использованный лимит; баланс не переоценивается. Ответ содержит serverNow, tapResetAt и tapTimezone; таймер UI использует performance.now, при возврате из фона обновляет серверное состояние. После увеличения уже исчерпанного лимита сервер однократно восстанавливает запас энергии. Разработчику необходимо менять лимит именно своего текущего уровня. На главном экране уровни расположены над волком, поддержка подписана.

Проверки: npm test (9 изолированных D1/Workers suites), npm run build. Живой канал и TikTok не подключены; членство Telegram проверено имитацией официального API, платёжные операции не выполнялись.

## 0.2.18 — множитель стаи и кланы

Новые приглашения больше не выдают фиксированные 500/100 WC. После первого входа нового аккаунта по подписанной ссылке и подключения шагомера с 5 000 переданных шагов пригласившему закрепляется один активный реферал. Множитель: 1 + N/100, без сложного процента: 1 → ×1,01; 2 → ×1,02; 10 → ×1,10. Каждый приглашённый закреплён навсегда за одним пригласившим. Множитель увеличивает новые тапы, шаги, награды заданий и уровней, а также дневные лимиты WC за тапы/шаги. Запас энергии не меняется. Покупки WC, WC-Донаты и ручные выдачи не умножаются. Старые начисления сохраняются, повторные запросы получают исходную награду. Ранее оплаченные рефералы мигрируют в квалифицированные без повторного начисления. В журнале тапов/шагов сохраняются до четырёх десятичных знаков WC: например, 0,1 × 1,01 = 0,101 WC. Денежные пополнения и цены магазина сохраняют свою прежнюю точность.

Друзья → Кланы: бесплатное создание, вступление из публичного списка или по коду, выход. Один клан на аккаунт, до 100 участников; ограничение защищено атомарной вставкой. Публичны название, описание, количество участников и сумма личных игровых балансов; личные имена/звания/балансы доступны только участникам своего клана. Перед созданием и вступлением интерфейс объясняет эту видимость. Монеты не переводятся в общий фонд. Клан не меняет награды. При выходе главы полномочия получает самый ранний участник; последний выход архивирует пустой клан.

Добавлены аватарки Telegram/TikTok и картинки заданий с платформой и нашим волком. Публичные карточки подписок отображаются даже до настройки ссылок, с отключённой кнопкой и явным статусом ожидания. После публикации настоящего задания карточка работает по прежней серверной проверке. В меню разработчика можно скачать аватарки и выбрать шаблоны подписок. Реальные социальные аккаунты не созданы и не подключены: нужны ссылки владельца. Механика Telegram требует бота-администратора, TikTok проверяет владелец.

Проверки: 10 изолированных Workers/D1 suites, build; дополнительно тестируются 1/2/10 рефералов, точность 0,101, неизменность прошлых начислений и повторов, увеличенные дневные лимиты, последний дробный тап, серверные награды уровней, перенос старых рефералов, бюджеты и приватность кланов, смена главы и параллельное вступление у предела 100.

## 0.2.19 — подготовка переноса на нового бота

Настраиваемые TELEGRAM_BOT_USERNAME и LEGACY_TELEGRAM_BOT_USERNAME вместо жёстких ссылок; динамические приглашения и вход. Поддержка двух подписей Telegram и независимых защищённых webhook endpoints. Платежи закреплены за принявшим их ботом; старые возвраты маршрутизируются прежним токеном. D1, шагомеры и пользовательские ID остаются прежними. Действующий бот не переключён автоматически: владелец создаёт нового и вносит секреты. Пошаговый порядок — BOT_MIGRATION.md.
