package com.wallker.wallet

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity:ComponentActivity(){
    private lateinit var vault:DeviceVault
    private lateinit var store:StepStore
    private lateinit var status:TextView
    private lateinit var counter:TextView
    private lateinit var pending:TextView
    private lateinit var code:EditText
    private lateinit var pair:Button
    private lateinit var tracking:Button
    private lateinit var sync:Button
    private var busy=false
    private val handler=Handler(Looper.getMainLooper())
    private val ticker=object:Runnable{override fun run(){refresh();handler.postDelayed(this,1000)}}
    private val permissionRequest=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){
        if(motionAllowed())startCounter() else {store.setStatus("Разреши физическую активность в настройках телефона.");refresh()}
    }
    private fun motionAllowed()=Build.VERSION.SDK_INT<29 || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)==PackageManager.PERMISSION_GRANTED
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState);vault=DeviceVault(this);store=StepStore(this)
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,64,32,32);setBackgroundColor(Color.rgb(20,23,24))}
        fun text(value:String,size:Float=16f)=TextView(this).apply{text=value;textSize=size;setTextColor(Color.WHITE);setPadding(0,16,0,16)}
        layout.addView(text("Wallker Wallet",28f));layout.addView(text("Шаги сегодня"))
        counter=text("0",52f);layout.addView(counter)
        tracking=Button(this).apply{setOnClickListener{if(store.enabled()){store.setEnabled(false);stopService(Intent(this@MainActivity,StepService::class.java));store.setStatus("Шагомер приостановлен");refresh()}else requestCounter()}};layout.addView(tracking)
        layout.addView(text("Носи телефон с собой. Шаги сохраняются без интернета. На Android работает постоянное уведомление шагомера."))
        code=EditText(this).apply{hint="Код привязки из Telegram";setTextColor(Color.WHITE);setHintTextColor(Color.LTGRAY);inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS};layout.addView(code)
        pair=Button(this).apply{text="Привязать Telegram";setOnClickListener{pairDevice()}};layout.addView(pair)
        pending=text("");layout.addView(pending)
        sync=Button(this).apply{text="Передать сохранённые шаги";setOnClickListener{StepSyncWorker.now(this@MainActivity);store.setStatus("Передадим шаги при доступной связи");refresh()}};layout.addView(sync)
        layout.addView(Button(this).apply{text="Отключить и очистить местные шаги";setOnClickListener{if(!busy){stopService(Intent(this@MainActivity,StepService::class.java));vault.clear();store.clear();store.setStatus("Для отзыва доступа отключи телефон также в Telegram");refresh()}}})
        status=text("");layout.addView(status)
        layout.addView(text("Apple Health и Health Connect не используются. Передаются только дата и число шагов за последние семь дней. WC — игровые монеты бета-версии без вывода. После перезагрузки открой Wallker; остановка приложения системой может привести к пропускам."))
        layout.addView(Button(this).apply{text="Какие данные передаются";setOnClickListener{
            AlertDialog.Builder(this@MainActivity).setTitle("Данные Wallker")
                .setMessage("Шаги считаются датчиком телефона без GPS. Даты и суточные суммы хранятся на телефоне за сегодня и шесть предыдущих дней. После привязки они автоматически передаются по HTTPS на сервер Wallker при доступном интернете.\n\nTelegram передаёт серверу твой ID и имя. Сервер также хранит часовой пояс, историю шагов и привязку устройства. Локальный токен защищён Android Keystore; на сервере сохраняется его хеш.\n\nКнопка очистки удаляет местные шаги и токен. Для отзыва доступа открой раздел «Телефон» в Telegram и отключи устройство. Это не удаляет историю на сервере.\n\nКамера, геолокация, контакты, паспорт, Apple Health и Health Connect не используются. В этой версии нет рекламы, платежей или обмена WC на деньги.")
                .setPositiveButton("Понятно",null).show()
        }})
        setContentView(ScrollView(this).apply{addView(layout)})
        StepSyncWorker.schedule(this);refresh()
    }
    override fun onStart(){super.onStart();handler.post(ticker);if(store.enabled() && motionAllowed())startCounter();StepSyncWorker.now(this)}
    override fun onStop(){handler.removeCallbacks(ticker);super.onStop()}
    private fun refresh(){
        counter.text="%,d".format(store.today());pending.text="Дней ожидают передачи: ${store.pending().days.size}"
        status.text=store.status().ifEmpty{"Включи шагомер и разреши физическую активность"}
        tracking.text=if(store.enabled())"Приостановить шагомер" else "Включить шагомер"
        tracking.isEnabled=!busy;pair.isEnabled=!busy;code.isEnabled=!busy;sync.isEnabled=!busy && vault.token()!=null
        pair.text=if(vault.token()==null)"Привязать Telegram" else "Привязать заново (очистит местные шаги)"
    }
    private fun requestCounter(){
        val sensors=getSystemService(SENSOR_SERVICE) as SensorManager
        if(sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)==null){store.setStatus("В этом телефоне нет датчика шагов");refresh();return}
        val permissions=mutableListOf<String>()
        if(Build.VERSION.SDK_INT>=29 && !motionAllowed())permissions.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if(permissions.isEmpty())startCounter() else permissionRequest.launch(permissions.toTypedArray())
    }
    private fun startCounter(){
        try{store.setEnabled(true);startForegroundService(Intent(this,StepService::class.java))}
        catch(_:Exception){store.setEnabled(false);store.setStatus("Не удалось включить шагомер. Повтори при открытом Wallker.")}
        refresh()
    }
    private fun pairDevice(){
        if(busy)return
        val value=code.text.toString().trim()
        if(!Regex("[a-f0-9]{48}").matches(value)){store.setStatus("Вставь полный код из Telegram");refresh();return}
        lifecycleScope.launch{
            busy=true;refresh()
            try{
                val result=WallkerAPI.post("/api/device/pair",JSONObject().put("code",value).put("platform","android"))
                stopService(Intent(this@MainActivity,StepService::class.java));store.clear()
                vault.save(result.getString("token"),result.getString("timezone"));code.setText("")
                store.setStatus("Telegram привязан. Включи шагомер.")
            }catch(e:Exception){store.setStatus(e.message ?: "Не удалось привязать телефон")}
            finally{busy=false;refresh()}
        }
    }
}
