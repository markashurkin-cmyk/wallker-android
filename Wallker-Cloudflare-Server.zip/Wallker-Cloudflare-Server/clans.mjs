import {CampaignError,isAdmin} from './campaigns.mjs';
import {balancesReady,ensureStatistics,userQuery} from './statistics.mjs';
import {walkingLevel,LEVELS,DIVINE_LEVEL} from './level-catalog.mjs';
export async function ensureClans(db){if(db.schemaReady)return;await db.batch([
 db.prepare('CREATE TABLE IF NOT EXISTS clans(id TEXT PRIMARY KEY,name TEXT NOT NULL,name_key TEXT NOT NULL,description TEXT NOT NULL,owner TEXT NOT NULL,created INTEGER NOT NULL,archived INTEGER NOT NULL DEFAULT 0)'),
 db.prepare('CREATE UNIQUE INDEX IF NOT EXISTS clans_name ON clans(name_key) WHERE archived=0'),
 db.prepare('CREATE TABLE IF NOT EXISTS clan_members(user_id TEXT PRIMARY KEY,clan_id TEXT NOT NULL,joined INTEGER NOT NULL)'),
 db.prepare('CREATE INDEX IF NOT EXISTS clan_members_clan ON clan_members(clan_id,joined)')]);}
export async function clansSnapshot(db,id,url,env={}){
 await ensureClans(db);await ensureStatistics(db);await balancesReady(db);
 const own=await db.prepare('SELECT c.* FROM clans c JOIN clan_members m ON m.clan_id=c.id WHERE m.user_id=? AND c.archived=0').bind(id).first();
 const q=(url.searchParams.get('q')||'').trim().toLocaleLowerCase('ru-RU');if(q.length>32)throw new CampaignError('Поиск: не больше 32 символов');
 const directory=(await db.prepare(`WITH profiles AS (${userQuery}) SELECT c.id,c.name,c.description,COUNT(m.user_id) AS members,ROUND(COALESCE(SUM(p.balance),0),4) AS budget FROM clans c LEFT JOIN clan_members m ON m.clan_id=c.id LEFT JOIN profiles p ON p.id=m.user_id WHERE c.archived=0 AND c.name_key LIKE ? ESCAPE '\\' GROUP BY c.id ORDER BY budget DESC,c.created LIMIT 30`).bind('%'+q.replace(/[\\%_]/g,'\\$&')+'%').all()).results;
 let members=[];
 if(own){members=(await db.prepare(`WITH profiles AS (${userQuery}) SELECT p.id,p.name,p.balance,p.steps,p.rankSteps,m.joined FROM clan_members m JOIN profiles p ON p.id=m.user_id WHERE m.clan_id=? ORDER BY m.joined,p.id LIMIT 100`).bind(own.id).all()).results.map(p=>({...p,level:walkingLevel(p.rankSteps??p.steps).level,levelName:walkingLevel(p.rankSteps??p.steps).name,owner:p.id===own.owner}));const overrides=(await db.prepare('SELECT user_id,level FROM developer_levels WHERE user_id IN (SELECT user_id FROM clan_members WHERE clan_id=?)').bind(own.id).all()).results;for(const member of members){const override=isAdmin({id:member.id},env)?overrides.find(x=>x.user_id===member.id)?.level:null;if(override){const rank=override===11?DIVINE_LEVEL:LEVELS[override-1];member.level=rank.level;member.levelName=rank.name;}}own.budget=Math.round(members.reduce((n,p)=>n+p.balance,0)*10000)/10000;own.count=members.length;own.isOwner=own.owner===id;own.code=own.id;}
 return {clan:own,members,directory,maxMembers:100};
}
export async function clansAction(db,id,data){
 await ensureClans(db);
 if(data.action==='create'){
  const name=typeof data.name==='string'?data.name.trim():'',description=typeof data.description==='string'?data.description.trim():'';
  if(name.length<3||name.length>32||description.length>140||/[\x00-\x1f]/.test(name+description))throw new CampaignError('Название: 3–32 символа, описание: до 140');
  if(typeof data.requestId!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.requestId))throw new CampaignError('Неверный номер создания');
  const existing=await db.prepare('SELECT owner,name,description,archived FROM clans WHERE id=?').bind(data.requestId).first();
  if(existing&&(existing.owner!==id||existing.name!==name||existing.description!==description||existing.archived))throw new CampaignError('Этот номер создания уже использован',409);
  const key=name.toLocaleLowerCase('ru-RU');
  const occupied=await db.prepare('SELECT id FROM clans WHERE name_key=? AND archived=0').bind(key).first();if(occupied&&occupied.id!==data.requestId)throw new CampaignError('Такое название клана уже занято',409);
  await db.batch([
   db.prepare('INSERT OR IGNORE INTO clans(id,name,name_key,description,owner,created) SELECT ?,?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM clan_members WHERE user_id=?)').bind(data.requestId,name,key,description,id,Date.now(),id),
   db.prepare('INSERT OR IGNORE INTO clan_members(user_id,clan_id,joined) SELECT ?,id,? FROM clans WHERE id=? AND owner=? AND archived=0').bind(id,Date.now(),data.requestId,id),
   db.prepare('UPDATE clans SET archived=1 WHERE id=? AND NOT EXISTS(SELECT 1 FROM clan_members WHERE clan_id=?)').bind(data.requestId,data.requestId)
  ]);
  const member=await db.prepare('SELECT clan_id FROM clan_members WHERE user_id=?').bind(id).first();if(member?.clan_id!==data.requestId)throw new CampaignError('Сначала выйди из своего клана или выбери другое название',409);
  return {ok:true};
 }
 if(data.action==='join'){
  if(typeof data.code!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.code))throw new CampaignError('Выбери клан или вставь его код');
  await db.prepare('INSERT OR IGNORE INTO clan_members(user_id,clan_id,joined) SELECT ?,id,? FROM clans WHERE id=? AND archived=0 AND (SELECT COUNT(*) FROM clan_members WHERE clan_id=clans.id)<100').bind(id,Date.now(),data.code).run();
  const member=await db.prepare('SELECT clan_id FROM clan_members WHERE user_id=?').bind(id).first();if(member?.clan_id!==data.code)throw new CampaignError('Клан недоступен, заполнен или ты уже состоишь в другом',409);
  return {ok:true};
 }
 if(data.action==='leave'){
  // Owner exit transfers leadership to the oldest member; the final exit archives it.
  await db.batch([
   db.prepare('UPDATE clans SET owner=COALESCE((SELECT user_id FROM clan_members WHERE clan_id=clans.id AND user_id<>? ORDER BY joined,user_id LIMIT 1),owner),archived=CASE WHEN (SELECT COUNT(*) FROM clan_members WHERE clan_id=clans.id)<=1 THEN 1 ELSE 0 END WHERE owner=? AND id=(SELECT clan_id FROM clan_members WHERE user_id=?)').bind(id,id,id),
   db.prepare('DELETE FROM clan_members WHERE user_id=?').bind(id)
  ]);return {ok:true};
 }
 throw new CampaignError('Выбери действие с кланом');
}
