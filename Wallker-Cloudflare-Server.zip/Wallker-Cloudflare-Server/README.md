# Wallker Wallet — собственный Cloudflare сервер

Подготовлено 3 октября 2026. Сервер и интерфейс проверены локально. Публикация в аккаунте владельца, перенос прежних записей, переключение Telegram-бота и Android APK с новым адресом ещё не выполнены. Текущий APK 0.3.1 продолжает обращаться к старому Sites-серверу.

Этот пакет запускает отдельное приложение и отдельную базу данных. Он не проксирует запросы к Sites, не использует ключи платформы Sites и не изменяет её защиту.

## Первый шаг для владельца

1. В своей панели Cloudflare открой D1 SQL database (обычно Storage & databases → D1).
2. Нажми Create Database, назови новую базу `wallker-wallet`, затем Create.
3. Открой базу и скопируй её Database ID. Это идентификатор базы, не API token.
4. В этом экземпляре `wrangler.jsonc` уже указан Database ID новой базы `wallker-wallet`: `6ceddc00-80eb-4abc-a0b5-a03cec5ddf6a`, полученный со скриншота владельца. Перед публикацией проверь совпадение с базой в своей панели.
5. В консоли именно новой базы выполни содержимое `schema.sql`. SQL создаёт три таблицы и индексы; не удаляет существующие данные. Альтернативный способ после авторизации Wrangler: `npm run db:init`.

## Развёртывание через GitHub

Помести исходники пакета в репозиторий GitHub. Если это папка в общем репозитории, укажи её как Root directory в настройках сборки Cloudflare.

В Cloudflare: Workers & Pages → Create application → Import Git repository. Выбери свой репозиторий, Worker name `wallker-wallet`, build command `npm run build`, deploy command `npx wrangler deploy`. Менеджер пакетов установит зависимости из package.json. Перед публикацией проверь D1 Database ID в исходниках.

Локальный вариант для компьютера с Node 22+: `npm install`, `npm run build`, `npx wrangler login`, `npm run db:init`, `npm run deploy`. Платный тариф не требуется для небольшого теста в пределах бесплатных лимитов; этот пакет не включает его автоматически.

## Подключение бота

В Worker Settings → Variables and Secrets добавь как Secret:

- `TELEGRAM_BOT_TOKEN`: токен именно `wallker_wallet_bot` из BotFather.
- `TELEGRAM_WEBHOOK_SECRET`: отдельная случайная строка длиной не менее 32 символов (буквы, цифры, `_`, `-`).

Секреты не должны быть в исходниках, ZIP, GitHub-файлах, Android APK или сообщениях чата. Публикация не настраивает webhook автоматически. После проверки нового сервера нужно отдельно переключить webhook Telegram на `https://<фактический-адрес-worker>/api/telegram/webhook` с тем же secret_token и обновить кнопку Mini App в BotFather на корень нового Worker. Адрес получаем из панели Cloudflare; он не известен заранее.

Все запросы Telegram к wallet проверяются по подписи initData. ChatGPT-вход и демо-начисления в независимом сервере отсутствуют. При открытии сайта вне Telegram он предлагает открыть Telegram-бота. CORS по умолчанию разрешает только свой адрес; список дополнительных доверенных источников при необходимости задаётся через ALLOWED_ORIGINS, разделитель — запятая.

## Проверка перед переключением

1. `/api/health` должен вернуть JSON с `ok: true` и `botConfigured: true`. Это проверяет наличие таблиц и настройку токена; не подтверждает связь с телефоном.
2. Неверный 48-значный код в `/api/device/pair` должен дать JSON HTTP 401; без токена `/api/device/steps` тоже HTTP 401. Это ожидаемые отказы авторизации.
3. Открой новый адрес как Mini App именно через бота. Создай код и используй APK, собранный с новым адресом.
4. Проверь: привязка, датчик, передача суточной суммы, обновление баланса в Telegram, повторная передача без повторного начисления, отзыв устройства.

Окончательный результат подтверждается на физическом Android. Локальные тесты не доказывают доступность сервера из сети телефона и не проверяют датчик шагов.

## Перенос и эксплуатация

Новая D1 база начинает пустой. История и балансы из Sites пока не перенесены. Не удаляй старый проект или данные. До переключения пользователей согласуй экспорт/импорт; таблицы users/days/pairings имеют совместимые имена и базовые поля, но секреты и доступы переносятся отдельной процедурой. Старые коды привязки не действуют в новой базе без импорта. После переключения создаём свежие коды.

Шаги поступают без полноценной защиты от накрутки. WC — игровые баллы, без денежных выплат, курса, листинга или гарантии дохода. Награда: 10 WC за полную тысячу шагов, максимум 100 WC за день. Синхронизация принимает сегодня и шесть предыдущих дней по фиксированному часовому поясу профиля; повторные суммы объединяются через MAX.

В базе хранятся Telegram ID, имя, часовой пояс, даты/суточные суммы и хеши секретов привязки. Автоматического удаления истории через 90 дней нет: 90 — только лимит отображаемых строк. Отзыв устройства удаляет привязку, не историю. Политику конфиденциальности, удаление аккаунта, мониторинг, резервные копии, ограничение частоты запросов и защиту от накрутки нужно завершить до публичного запуска с большим числом пользователей.

## Состав

- worker.js: API, проверка Telegram, привязка и синхронизация, webhook.
- schema.sql: новая D1 база.
- wrangler.jsonc: привязки D1/статических файлов.
- src/: интерфейс с прежним дизайном.
- public/: уже собранные статические файлы; build пересоздаёт их из src.
- tests/integration.mjs: проверки в локальном Workers runtime с настоящей временной SQLite/D1 базой.

Проверки выполнены: подпись/срок Telegram, однократное потребление кода при двух параллельных запросах, хранение хешей, повторная синхронизация, суточный лимит, окно 7 дней, разделение аккаунтов, отзыв токена, CORS, secret webhook, ограничения тела запроса, JSON-ошибки. Интерфейс успешно собран esbuild.

Официальные инструкции:
- https://developers.cloudflare.com/workers/get-started/dashboard/
- https://developers.cloudflare.com/d1/get-started/
- https://developers.cloudflare.com/workers/ci-cd/builds/git-integration/github-integration/
- https://developers.cloudflare.com/workers/platform/pricing/

## Beta 0.1.2 / Android 0.3.4

The deployed Android application uses this Worker. Same-account pairing preserves the local ledger and merges up to seven server days; preflight never consumes a code. Replacing a device revokes only its old bearer token. Different-account pairing needs Android confirmation. The ledger uses cumulative daily values, and D1 MAX prevents duplicate WC on retransmission.

`BOT_AUTO_SETUP=true` enables one-time deployment-owned Telegram setup when `/api/health` is checked. The target origin is fixed in the source. Setup uses the configured bot token, sets the webhook and default menu, then verifies both via Telegram. An explicit TELEGRAM_WEBHOOK_SECRET is respected; otherwise a domain-specific HMAC secret is derived from the bot token and never returned. A D1 lease and configuration digest prevent repeated setup. No pending updates are dropped. Main App profile launch settings still require BotFather; historic inline buttons remain unchanged.

The test guide is `public/beta-guide.html`, also linked in the Phone screen. Daily rewards: 10 WC per complete 1,000 steps, at most 100 WC/day. Beta data is unverified; no withdrawal, monetary value or token allocation is promised. Use one phone per account in the first test cohort.

Server 0.1.3 adds a sanitized Telegram setup failure stage, HTTP/API code and fixed reason label to /api/health. Bot tokens, webhook secrets and raw Telegram error descriptions are never returned. Failed setup remains configuration_failed until the one-minute retry lease expires. A successful retry clears the diagnostic.

Server 0.1.4 verifies the configured bot username before modifying Telegram. URL comparison uses URL canonicalisation so an implicit root slash is accepted; different origins, paths, credentials, queries or fragments still fail. Webhook, menu type and menu address failures have separate sanitized reasons.


## Developer menu and Volker — 0.2.0
Set the Cloudflare production environment variable `ADMIN_TELEGRAM_ID` to the owner's numeric Telegram user ID. Do not use a username or bot ID. `/id` in the bot or the Mini App Phone section shows the signed-in user's ID. Without this variable, nobody receives developer privileges. Every admin request verifies Telegram initData and the server allowlist. Changing local UI state cannot grant access.

The developer can create/edit drafts, publish or archive campaigns, schedule their dates, review partner submissions and toggle a mascot sponsor. Step challenges use synchronized steps for today, a one-time reward per campaign and account. Partner tasks require manual developer approval; opening a link is not proof. The WC reward is frozen at submission, so edits do not change pending rewards. Sponsor shirt branding is text (first 12 characters) on the lime shirt; full brand logo/image uploads and shirt color variants are not implemented.

New campaign/claim/mascot tables are created additively on first use. Existing users, device pairings and step history are preserved. Rewards from approved claims contribute to balance separately from step rewards. WC remain beta game points.


## Tap game 0.2.1
The main screen occupies one viewport with a tappable Volker, shared WC balance, level and energy. Each tap earns one WC; capacity 1000, regeneration one energy per second. Rewards are bounded and committed with idempotent receipts in D1. Pending client batches persist per Telegram account. Android uses its existing paired bearer token; Telegram uses verified initData. Taps do not change step history or task rewards. Owner access is still controlled by ADMIN_TELEGRAM_ID in the production environment.

## Rewards 0.2.2
Walking keeps 10 WC per 1,000 steps. New tapping earns 0.1 WC per tap, with 1 energy regenerated per minute. Existing tap rewards are preserved through an idempotent per-account baseline. Fractional rewards persist across sessions. Energy capacity is 100.

## Rewards 0.2.3
Daily taps are capped at 200 WC in the profile timezone, enforced atomically with receipts. Walking rewards from 2026-10-11 are 400 WC per 1,000 steps (floor to whole WC), capped at 4,000 WC daily. 7,500 steps earns 3,000 WC. Older walking days retain their old rate; existing tap earnings are preserved.

## Tap cap 0.2.4
Taps are capped at 1,000 WC/day, reward 0.1 WC per tap, energy capacity 100 with one energy regenerated per second. Walking remains capped at 4,000 WC/day. Existing daily usage is retained when raising the cap.

## Owner reward editor 0.2.5
The developer menu edits tap/step rates (two decimals), daily caps, energy capacity and regeneration interval. Campaign rewards remain per task. Signed owner identity and server validation are required; revision checks reject stale edits. New awards use integer hundredths in persistent ledgers. Existing awards retain their value; changing a rate never recalculates prior earnings. Duplicate/parallel sync and tap requests remain idempotent.

## Owner statistics — 0.2.8

Developer menu → Statistics and users provides owner-only totals, exact all-time WC balances split into walking/tapping/approved campaign rewards, name/username/Telegram ID search, deterministic paginated sorting, individual account history and grouped server errors. Access uses the existing signed Telegram identity and ADMIN_TELEGRAM_ID allowlist; no public leaderboard or arbitrary balance editing is added. Existing balances are preserved by the same legacy conversion used by the wallet.

New analytics tables are created additively. Successful wallet loads, taps, campaign interactions, device pairing and step synchronization contribute to UTC daily activity. Admin statistics reads do not count as activity. First positive synchronization is recorded. No historic visits are invented; existing registration times, balances and step history remain visible. D1/D7 retention refers to users registered exactly one/seven days ago who were active today and remains unavailable until a full measurable cohort exists. Today's figures are provisional.

Server errors and 4xx request rejections are aggregated by hour, sanitized route, status, fixed reason code, verified account and verified platform. Raw exceptions, headers, bodies, query strings, OTPs, device tokens and pairing codes are not recorded. Anonymous request failures share fixed buckets. Error aggregates are retained 30 days, daily activity 90 days, with daily cleanup. Aggregate profile timestamps and balances are not deleted by cleanup. Telemetry failure does not fail successful wallet/sync responses. Mobile crashes, offline failures, app versions and exact sensor errors are not collected by this server-only update. The privacy bot reply describes the additional activity tracking.

Tests cover private access, correct balances/legacy preservation, search/pagination/input escaping, details, actual device error attribution, atomic grouped counters, no leaked secrets, activity/retention, cleanup and wallet availability when analytics storage fails. Existing integration checks still run. Phone applications do not need to be reinstalled.

## Walking levels — 0.2.9

The tappable level row now opens the ten-level Walking Wolf catalog. Progress uses cumulative synchronized daily steps, including existing history, rather than tap count or WC balance. Each unlocked level changes the profile portrait/title. Level thresholds: 0, 1,000, 5,000, 15,000, 30,000, 60,000, 100,000, 200,000, 350,000 and 500,000 steps. One-time WC awards for levels 2–10: 50, 150, 300, 600, 1,000, 2,000, 4,000, 7,500 and 12,000. These awards are additional to daily walking rewards and do not consume daily walking/tap caps. WC remain game points.

The shared catalog lives in level-catalog.mjs, server handling in levels.mjs. GET /api/levels and POST /api/levels/claim require verified Telegram identity and an existing account. Eligibility is checked in SQL from stored steps; a unique user/level key prevents duplicate/concurrent rewards. A claimed award is frozen in integer hundredths. Opening the catalog does not automatically issue coins. Already-eligible users can explicitly claim each outstanding reward. Wallet and owner statistics reconcile the additional levelCoins source.

The ten 3D portrait assets use a single 5-column, 2-row atlas at assets/wolf-levels.png, copied to public by the build. Generated using the built-in imagegen tool, with the existing Volker as an identity reference; prompt: same friendly gray wolf and amber eyes, progression from lime tee/backpack/outdoor clothing through silver/gold medals to tailored gold-trimmed suits and an emerald crown, equal square cells, dark background, no text. CSS displays atlas cells without ten separate downloads.

Tests verify every threshold boundary, existing step history, zero/missing eligibility, signed access, tampered reward/user inputs, no tap-based progress, repeated step uploads, simultaneous/replayed claims, independent user awards, maximum level and all balance totals in both wallet and developer statistics.
