export class TapError extends Error {
  constructor(message,status=400){super(message);this.status=status;}
}
const capacity=1000, regenMs=1000;
export async function ensureTaps(db){
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_state(user_id TEXT PRIMARY KEY,total INTEGER NOT NULL DEFAULT 0,energy INTEGER NOT NULL DEFAULT 1000,energy_at INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_receipts(user_id TEXT NOT NULL,request_id TEXT NOT NULL,requested INTEGER NOT NULL,accepted INTEGER NOT NULL,applied INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))').run();
}
export async function tapSnapshot(db,id,now=Date.now()){
  await ensureTaps(db);
  await db.prepare('INSERT OR IGNORE INTO tap_state(user_id,energy_at) VALUES(?,?)').bind(id,now).run();
  const row=await db.prepare('SELECT total,energy,energy_at FROM tap_state WHERE user_id=?').bind(id).first();
  return {tapCoins:row.total,energy:Math.min(capacity,row.energy+Math.max(0,Math.floor((now-row.energy_at)/regenMs))),capacity,regenMs};
}
export async function earnTaps(db,id,data,now=Date.now()){
  if(!Number.isSafeInteger(data.count)||data.count<1||data.count>50)throw new TapError('Можно передать от 1 до 50 нажатий');
  if(typeof data.requestId!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.requestId))throw new TapError('Неверный номер начисления');
  await tapSnapshot(db,id,now);
  // The receipt, energy deduction and balance update commit together. Replayed
  // requests are harmless, including parallel requests from Android and Telegram.
  const available='MIN(1000,energy+MAX(0,CAST((?-energy_at)/1000 AS INTEGER)))';
  await db.batch([
    db.prepare(`INSERT OR IGNORE INTO tap_receipts(user_id,request_id,requested,accepted,created) SELECT user_id,?,?,MIN(?,${available}),? FROM tap_state WHERE user_id=?`).bind(data.requestId,data.count,data.count,now,now,id),
    db.prepare(`UPDATE tap_state SET total=total+(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?),energy=${available}-(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?),energy_at=CASE WHEN ${available}=1000 THEN ? ELSE energy_at+MAX(0,CAST((?-energy_at)/1000 AS INTEGER))*1000 END WHERE user_id=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)`).bind(id,data.requestId,now,id,data.requestId,now,now,now,id,id,data.requestId),
    db.prepare('UPDATE tap_receipts SET applied=1 WHERE user_id=? AND request_id=? AND applied=0').bind(id,data.requestId)
  ]);
  const receipt=await db.prepare('SELECT requested,accepted FROM tap_receipts WHERE user_id=? AND request_id=?').bind(id,data.requestId).first();
  if(receipt.requested!==data.count)throw new TapError('Номер начисления уже использован для другого количества',409);
  return {...await tapSnapshot(db,id,now),accepted:receipt.accepted};
}
