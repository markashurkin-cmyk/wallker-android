import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
// Local test uses the installed Workers runtime and a separate ephemeral SQLite/D1 database.
const {Miniflare} = await import(process.env.WALLKER_MINIFLARE_MODULE || 'miniflare');
const root = fileURLToPath(new URL('../', import.meta.url));
const botToken = '12345:LOCAL_TEST_ONLY_NOT_A_TELEGRAM_TOKEN';
const webhookSecret = 'local-test-webhook-secret';
const mf = new Miniflare({modules:true, scriptPath:root+'worker.js', compatibilityDate:'2026-05-15', d1Databases:['DB'], bindings:{TELEGRAM_BOT_TOKEN:botToken, TELEGRAM_WEBHOOK_SECRET:webhookSecret, ALLOWED_ORIGINS:'https://allowed.example'}});
function initData(id=1001, authDate=Math.floor(Date.now()/1000)) {
  const fields = new URLSearchParams({auth_date:String(authDate), query_id:'local-test-query', user:JSON.stringify({id,first_name:'Тест'})});
  const secret = createHmac('sha256','WebAppData').update(botToken).digest();
  const check = [...fields].sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join('\n');
  fields.set('hash',createHmac('sha256',secret).update(check).digest('hex'));
  return fields.toString();
}
function dayOffset(offset) { const date=new Date(); const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Tomsk',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date); const get=key=>parts.find(p=>p.type===key).value; const d=new Date(`${get('year')}-${get('month')}-${get('day')}T12:00:00Z`); d.setUTCDate(d.getUTCDate()+offset); return d.toISOString().slice(0,10); }
async function api(path, {method='GET',data,init,token,origin,secret}={}) {
  const headers = {'Content-Type':'application/json'};
  if(init) headers['X-Telegram-Init-Data']=init;
  if(token) headers.Authorization=`Bearer ${token}`;
  if(origin) headers.Origin=origin;
  if(secret) headers['X-Telegram-Bot-Api-Secret-Token']=secret;
  const response = await mf.dispatchFetch('http://localhost'+path,{method,headers,...(data!==undefined ? {body:JSON.stringify(data)} : {})});
  const value=response.status===204 ? null : await response.json();
  return {status:response.status,value,headers:response.headers};
}
try {
  const db=await mf.getD1Database('DB');
  const schema=(await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'');
  for(const sql of schema.split(';').map(s=>s.trim()).filter(Boolean)) await db.prepare(sql).run();
  const auth=initData();
  assert.equal((await api('/api/health')).status,200);
  assert.equal((await api('/api/wallet')).status,401);
  assert.equal((await api('/api/wallet',{init:initData(1001,Math.floor(Date.now()/1000)-3601)})).status,401);
  assert.equal((await api('/api/wallet',{init:auth.slice(0,-1)+(auth.endsWith('0')?'1':'0')})).status,401);
  const initial=await api('/api/wallet?timezone=Asia%2FTomsk',{init:auth});
  assert.equal(initial.status,200); assert.equal(initial.value.user.timezone,'Asia/Tomsk');
  const created=await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}});
  assert.equal(created.status,200); assert.match(created.value.code,/^[a-f0-9]{48}$/);
  const wrongCode=await api('/api/device/pair',{method:'POST',data:{code:'0'.repeat(48),platform:'android'}});
  assert.equal(wrongCode.status,401); assert.match(wrongCode.value.error,/Такой код не найден/);
  assert.ok(!wrongCode.value.error.includes('0'.repeat(48)));
  const pairing=(await Promise.all([1,2].map(()=>api('/api/device/pair',{method:'POST',data:{code:created.value.code,platform:'android'}}))));
  assert.deepEqual(pairing.map(p=>p.status).sort(),[200,401]);
  assert.match(pairing.find(p=>p.status===401).value.error,/уже использован/);
  const token=pairing.find(p=>p.status===200).value.token;
  assert.match(token,/^[a-f0-9]{48}$/);
  const stored=await db.prepare('SELECT code_hash,device_hash FROM pairings LIMIT 1').first();
  assert.notEqual(stored.code_hash,created.value.code); assert.notEqual(stored.device_hash,token);
  const sync=(steps,day=dayOffset(0))=>api('/api/device/steps',{method:'POST',token,data:{day,steps}});
  assert.equal((await sync(3500)).status,200);
  assert.equal((await sync(3500)).value.coins,30);
  assert.equal((await sync(2000)).value.steps,3500);
  assert.equal((await sync(12000)).value.coins,100);
  assert.equal((await sync(100001)).status,400);
  assert.equal((await sync(-1)).status,400);
  assert.equal((await sync(1000,dayOffset(1))).status,400);
  assert.equal((await sync(1000,dayOffset(-7))).status,400);
  assert.equal((await sync(1000,dayOffset(-6))).status,200);
  const snapshot=await api('/api/wallet',{init:auth});
  assert.equal(snapshot.value.balance,110); assert.equal(snapshot.value.todayCoins,100);
  const other=await api('/api/wallet',{init:initData(1002)});
  assert.equal(other.value.balance,0); assert.equal(other.value.devices.length,0);
  const rejected=await api('/api/wallet',{method:'POST',init:auth,origin:'https://untrusted.example',data:{action:'pair'}});
  assert.equal(rejected.status,403); assert.equal(rejected.headers.get('Access-Control-Allow-Origin'),null);
  assert.equal((await api('/api/health',{method:'OPTIONS',origin:'https://allowed.example'})).status,204);
  assert.equal((await api('/api/health',{origin:'https://allowed.example'})).headers.get('Access-Control-Allow-Origin'),'https://allowed.example');
  assert.equal((await api('/api/telegram/webhook',{method:'POST',data:{}})).status,401);
  const webhook=await api('/api/telegram/webhook',{method:'POST',secret:webhookSecret,data:{message:{chat:{id:1001,type:'private'},text:'/start'}}});
  assert.equal(webhook.status,200); assert.equal(webhook.value.reply_markup.inline_keyboard[0][0].web_app.url,'http://localhost');
  assert.equal((await api('/api/device/revoke',{method:'POST',init:auth,data:{}})).status,200);
  assert.equal((await sync(4000)).status,401);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,110);
  const expired=await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}});
  await db.prepare('UPDATE pairings SET expires=0 WHERE device_hash IS NULL').run();
  const expiredAttempt=await api('/api/device/pair',{method:'POST',data:{code:expired.value.code,platform:'android'}});
  assert.equal(expiredAttempt.status,401); assert.match(expiredAttempt.value.error,/Срок действия/);
  const huge=await api('/api/device/pair',{method:'POST',data:{padding:'x'.repeat(9000)}});
  assert.equal(huge.status,413);
  assert.equal((await api('/api/device/pair',{method:'GET'})).status,405);
  assert.equal((await api('/api/unknown')).status,404);
  console.log('PASS: real local D1/Workers integration — Telegram signature and expiry, single-use pairing race, hashed credentials, idempotent sync, daily cap, seven-day window, account isolation, revocation, CORS, webhook secret, bounded requests, JSON errors.');
} finally { await mf.dispose(); }
