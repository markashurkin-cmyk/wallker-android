import {recountAffectedActive} from './growth.mjs';
import {CampaignError} from './campaigns.mjs';
import {rewardSettings,stepRewardStatements} from './rewards.mjs';
import {referralRewardBoost,settleReferrals} from './referrals.mjs';
export async function limit(db,bucket,max,seconds=60,now=Date.now()){
 const window=Math.floor(now/(seconds*1000));
 const row=await db.prepare('INSERT INTO request_limits(bucket,window,n) VALUES(?,?,1) ON CONFLICT(bucket) DO UPDATE SET window=excluded.window,n=CASE WHEN request_limits.window=excluded.window THEN request_limits.n+1 ELSE 1 END RETURNING n').bind(bucket,window).first();
 if(row.n>max)throw new CampaignError('Слишком много запросов. Подожди минуту.',429);
}
export async function canEarn(db,id){
 const row=await db.prepare('SELECT frozen,reason FROM abuse_controls WHERE user_id=?').bind(id).first();
 if(row?.frozen)throw new CampaignError('Начисления приостановлены. Обратись в поддержку.',423);
}
export async function reportSteps(db,device,hash,data,now=Date.now()){
 await canEarn(db,device.user_id);await limit(db,'sync:'+device.user_id,30);
 const old=await db.prepare('SELECT steps,approved_steps,state FROM step_reports WHERE user_id=? AND day=?').bind(device.user_id,data.day).first();
 if(old?.state==='approved'&&data.steps<=old.steps)return {steps:old.steps,status:'synced'};
 const reason='sensor_reported';
 await db.batch([
  db.prepare('INSERT INTO device_sessions(device_hash,user_id,started,last_seen) VALUES(?,?,?,?) ON CONFLICT(device_hash) DO UPDATE SET last_seen=excluded.last_seen').bind(hash,device.user_id,now,now),
  db.prepare("INSERT INTO step_reports(user_id,day,steps,approved_steps,state,reason,received) VALUES(?,?,?,COALESCE((SELECT steps FROM days WHERE user_id=? AND day=?),0),'pending',?,?) ON CONFLICT(user_id,day) DO UPDATE SET steps=CASE WHEN step_reports.state='rejected' THEN MAX(step_reports.approved_steps,excluded.steps) ELSE MAX(step_reports.steps,excluded.steps) END,state=CASE WHEN excluded.steps>step_reports.approved_steps THEN 'pending' ELSE step_reports.state END,reason=excluded.reason,received=excluded.received").bind(device.user_id,data.day,data.steps,device.user_id,data.day,reason,now)
 ]);
 await settleSteps(db,{id:'automatic:sensor'},{action:'approve',userId:device.user_id,day:data.day},now);
 const saved=await db.prepare('SELECT steps FROM days WHERE user_id=? AND day=?').bind(device.user_id,data.day).first();
 return {steps:saved?.steps||0,status:'synced'};
}
async function settleSteps(db,admin,data,now=Date.now()){
 const row=await db.prepare('SELECT * FROM step_reports WHERE user_id=? AND day=?').bind(data.userId,data.day).first();
 if(!row)throw new CampaignError('Отчёт не найден',404);
 await canEarn(db,data.userId);
 const settings=await rewardSettings(db),boost=await referralRewardBoost(db,data.userId,'steps'),rate=Math.round(settings.stepReward*boost.multiplier*10000)/100,cap=Math.round(settings.stepDailyLimit*boost.multiplier*100);
 await db.prepare('INSERT OR IGNORE INTO step_rewards(user_id,day,accounted_steps,units) VALUES(?,?,0,0)').bind(data.userId,data.day).run();
 const award=data.day<'2026-10-11'?db.prepare("UPDATE step_rewards SET units=MAX(units,CAST(MIN(?,10000)/1000 AS INTEGER)*1000),accounted_steps=MAX(accounted_steps,?) WHERE user_id=? AND day=? AND EXISTS(SELECT 1 FROM step_reports WHERE user_id=? AND day=? AND state='pending' AND steps=?)").bind(row.steps,row.steps,data.userId,data.day,data.userId,data.day,row.steps):db.prepare("UPDATE step_rewards SET units=ROUND(units+MIN(MAX(0,?-units),MAX(0,?-accounted_steps)*?),2),accounted_steps=MAX(accounted_steps,?) WHERE user_id=? AND day=? AND EXISTS(SELECT 1 FROM step_reports WHERE user_id=? AND day=? AND state='pending' AND steps=?)").bind(cap,row.steps,rate,row.steps,data.userId,data.day,data.userId,data.day,row.steps);
 await db.batch([
  // Report state and previous credited total are tested in the same transaction.
  db.prepare("INSERT INTO trusted_step_totals(user_id,steps) SELECT ?,MAX(0,MIN(?,10000)-MIN(approved_steps,10000)) FROM step_reports WHERE user_id=? AND day=? AND state='pending' AND steps=? ON CONFLICT(user_id) DO UPDATE SET steps=trusted_step_totals.steps+excluded.steps").bind(data.userId,row.steps,data.userId,data.day,row.steps),
  db.prepare("INSERT INTO days(user_id,day,steps,source,updated) SELECT user_id,day,steps,'sensor',? FROM step_reports WHERE user_id=? AND day=? AND state='pending' AND steps=? ON CONFLICT(user_id,day) DO UPDATE SET steps=MAX(days.steps,excluded.steps),source=excluded.source,updated=excluded.updated").bind(now,data.userId,data.day,row.steps),
  award,
  db.prepare("UPDATE step_reports SET approved_steps=steps,state='approved',reviewed=?,reviewer=? WHERE user_id=? AND day=? AND state='pending' AND steps=?").bind(now,admin.id,data.userId,data.day,row.steps)
 ]);
 await settleReferrals(db,data.userId);return {ok:true};
}
export async function securitySnapshot(db,url){
 const page=Math.max(1,Math.min(10000,Number(url.searchParams.get('page'))||1));
 return {reports:(await db.prepare("SELECT s.*,u.name FROM step_reports s JOIN users u ON u.id=s.user_id WHERE s.state='pending' ORDER BY received LIMIT 50 OFFSET ?").bind((page-1)*50).all()).results,controls:(await db.prepare('SELECT * FROM abuse_controls WHERE frozen=1 LIMIT 100').all()).results,deletions:(await db.prepare("SELECT d.user_id,d.created,u.name FROM deletion_requests d JOIN users u ON u.id=d.user_id WHERE d.state='pending' LIMIT 100").all()).results,clientErrors:(await db.prepare('SELECT * FROM client_errors ORDER BY last_at DESC LIMIT 50').all()).results,page};
}
export async function freezeAccount(db,admin,data){
 if(!/^tg:[1-9]\d*$/.test(data.userId||'')||typeof data.frozen!=='boolean'||typeof data.reason!=='string'||data.reason.length>300)throw new CampaignError('Выбери аккаунт и причину');
 await db.prepare('INSERT INTO abuse_controls(user_id,frozen,reason,updated,admin_id) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM users WHERE id=?) ON CONFLICT(user_id) DO UPDATE SET frozen=excluded.frozen,reason=excluded.reason,updated=excluded.updated,admin_id=excluded.admin_id').bind(data.userId,data.frozen?1:0,data.reason,Date.now(),admin.id,data.userId).run();
 await recountAffectedActive(db,data.userId);return {ok:true}; // Growth Total is immutable; freezing affects earning/trust, not attribution history.
}
export async function clientError(db,id,data){
 const allowed=new Set(['network','motion_permission','sensor_unavailable','sync_failed','clock_changed','ui_crash']);
 if(!allowed.has(data.code)||!['telegram','android','ios'].includes(data.platform)||!/^\d+\.\d+\.\d+$/.test(data.version||''))throw new CampaignError('Неверный код диагностики');
 await limit(db,'diagnostics:'+id,10);const now=Date.now(),day=new Date(now).toISOString().slice(0,10);
 await db.prepare('INSERT INTO client_errors(user_id,day,platform,version,code,count,last_at) VALUES(?,?,?,?,?,1,?) ON CONFLICT(user_id,day,platform,version,code) DO UPDATE SET count=MIN(count+1,1000),last_at=excluded.last_at').bind(id,day,data.platform,data.version,data.code,now).run();return {ok:true};
}
