import {balancesReady,ensureStatistics,userQuery} from './statistics.mjs';
import {LEVELS,DIVINE_LEVEL,walkingLevel} from './level-catalog.mjs';
import {CampaignError,isAdmin} from './campaigns.mjs';
export async function ensureFriends(db){await db.batch([
 db.prepare('CREATE TABLE IF NOT EXISTS friend_codes(user_id TEXT PRIMARY KEY,code TEXT UNIQUE NOT NULL)'),
 db.prepare("CREATE TABLE IF NOT EXISTS friendships(a TEXT NOT NULL,b TEXT NOT NULL,requester TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('pending','accepted')),created INTEGER NOT NULL,PRIMARY KEY(a,b))"),
 db.prepare('CREATE INDEX IF NOT EXISTS friendships_b ON friendships(b,state)')]);}
async function ownCode(db,id){
 for(let i=0;i<3;i++){const code=Array.from(crypto.getRandomValues(new Uint8Array(10)),x=>x.toString(16).padStart(2,'0')).join('');await db.prepare('INSERT OR IGNORE INTO friend_codes(user_id,code) VALUES(?,?)').bind(id,code).run();const row=await db.prepare('SELECT code FROM friend_codes WHERE user_id=?').bind(id).first();if(row)return row.code;}
 throw new CampaignError('Не удалось создать код друга',503);
}
export async function friendsSnapshot(db,id,env){
 await ensureFriends(db);const code=await ownCode(db,id);
 const rows=(await db.prepare('SELECT f.*,u.name,CASE WHEN a=? THEN b ELSE a END AS other FROM friendships f JOIN users u ON u.id=CASE WHEN a=? THEN b ELSE a END WHERE a=? OR b=? ORDER BY created DESC LIMIT 50').bind(id,id,id,id).all()).results;
 const accepted=rows.filter(r=>r.state==='accepted'),friends=[];
 if(accepted.length){
  await ensureStatistics(db);await balancesReady(db);
  const ids=accepted.map(r=>r.other),marks=ids.map(()=>'?').join(',');
  const profiles=(await db.prepare(`SELECT id,balance,steps FROM (${userQuery}) WHERE id IN (${marks})`).bind(...ids).all()).results;
  const overrides=(await db.prepare(`SELECT user_id,level FROM developer_levels WHERE user_id IN (${marks})`).bind(...ids).all()).results;
  for(const row of accepted){const p=profiles.find(p=>p.id===row.other),override=isAdmin({id:row.other},env)?overrides.find(o=>o.user_id===row.other)?.level:null;const rank=override===11?DIVINE_LEVEL:override?LEVELS[override-1]:walkingLevel(p.steps);friends.push({id:row.other,name:row.name,balance:p.balance,level:rank.level,levelName:rank.name});}
 }

 return {code,friends,incoming:rows.filter(r=>r.state==='pending'&&r.requester!==id).map(r=>({id:r.other,name:r.name})),outgoing:rows.filter(r=>r.state==='pending'&&r.requester===id).map(r=>({id:r.other,name:r.name}))};
}
export async function friendsAction(db,id,data){
 await ensureFriends(db);
 if(data.action==='request'){
  const code=typeof data.code==='string'?data.code.trim().toLowerCase():'';if(!/^[a-f0-9]{20}$/.test(code))throw new CampaignError('Введи код друга из его мини-приложения');
  const target=await db.prepare('SELECT user_id FROM friend_codes WHERE code=?').bind(code).first();if(!target)throw new CampaignError('Код друга не найден',404);if(target.user_id===id)throw new CampaignError('Это твой собственный код');
  const [a,b]=[id,target.user_id].sort();
  await db.prepare("INSERT OR IGNORE INTO friendships(a,b,requester,state,created) SELECT ?,?,?,'pending',? WHERE (SELECT COUNT(*) FROM friendships WHERE a=? OR b=?)<50 AND (SELECT COUNT(*) FROM friendships WHERE a=? OR b=?)<50").bind(a,b,id,Date.now(),id,id,target.user_id,target.user_id).run();
  const row=await db.prepare('SELECT state,requester FROM friendships WHERE a=? AND b=?').bind(a,b).first();if(!row)throw new CampaignError('Достигнут лимит 50 друзей и заявок',409);
  return {ok:true,state:row.state,incoming:row.requester!==id};
 }
 if(!['accept','remove'].includes(data.action)||typeof data.userId!=='string'||!/^tg:[1-9]\d*$/.test(data.userId)||data.userId===id)throw new CampaignError('Выбери заявку или друга');
 const [a,b]=[id,data.userId].sort();
 if(data.action==='accept'){
  const row=await db.prepare('SELECT requester,state FROM friendships WHERE a=? AND b=?').bind(a,b).first();if(!row||row.requester===id&&row.state==='pending')throw new CampaignError('Нет входящей заявки',403);
  await db.prepare("UPDATE friendships SET state='accepted' WHERE a=? AND b=? AND requester<>?").bind(a,b,id).run();
 }else await db.prepare('DELETE FROM friendships WHERE a=? AND b=?').bind(a,b).run();
 return {ok:true};
}
