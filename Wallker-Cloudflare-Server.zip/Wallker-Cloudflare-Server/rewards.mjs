import {CampaignError} from './campaigns.mjs';
export const defaults={tapReward:0.1,stepReward:0.4,tapDailyLimit:1000,stepDailyLimit:4000,energyCapacity:100,energyRegenSeconds:1};
export async function rewardSettings(db){
 await db.prepare('CREATE TABLE IF NOT EXISTS reward_settings(id INTEGER PRIMARY KEY,value TEXT NOT NULL,revision INTEGER NOT NULL)').run();
 await db.prepare('INSERT OR IGNORE INTO reward_settings(id,value,revision) VALUES(1,?,1)').bind(JSON.stringify(defaults)).run();
 const row=await db.prepare('SELECT value,revision FROM reward_settings WHERE id=1').first();
 return {...JSON.parse(row.value),revision:row.revision};
}
export async function saveRewardSettings(db,data){
 const current=await rewardSettings(db),value={};
 const fields={tapReward:[0.01,100,2],stepReward:[0.01,100,2],tapDailyLimit:[1,1000000,0],stepDailyLimit:[1,1000000,0],energyCapacity:[1,10000,0],energyRegenSeconds:[1,3600,0]};
 for(const [key,[min,max,precision]] of Object.entries(fields)){
  const x=data[key],factor=10**precision;
  if(typeof x!=='number'||!Number.isFinite(x)||x<min||x>max||Math.abs(x*factor-Math.round(x*factor))>1e-7)throw new CampaignError('Проверь значения наград, лимитов и энергии');
  value[key]=x;
 }
 if(data.revision!==current.revision)throw new CampaignError('Настройки уже изменились. Обнови страницу и повтори.',409);
 const result=await db.prepare('UPDATE reward_settings SET value=?,revision=revision+1 WHERE id=1 AND revision=? RETURNING revision').bind(JSON.stringify(value),current.revision).first();
 if(!result)throw new CampaignError('Настройки уже изменились. Обнови страницу и повтори.',409);
 return {...value,revision:result.revision};
}
export async function ensureStepRewards(db){
 await db.prepare('CREATE TABLE IF NOT EXISTS step_rewards(user_id TEXT NOT NULL,day TEXT NOT NULL,accounted_steps INTEGER NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,day))').run();
 // Preserve all existing daily awards at the previous deployed rules.
 await db.prepare(`INSERT OR IGNORE INTO step_rewards(user_id,day,accounted_steps,units) SELECT user_id,day,steps,CASE WHEN day<'2026-10-11' THEN CAST(MIN(steps,10000)/1000 AS INTEGER)*1000 ELSE CAST(MIN(steps,10000)*4/10 AS INTEGER)*100 END FROM days`).run();
}
export async function stepRewardStatements(db,id,day,steps,settings){
 await ensureStepRewards(db);
 await db.prepare('INSERT OR IGNORE INTO step_rewards(user_id,day,accounted_steps,units) VALUES(?,?,0,0)').bind(id,day).run();
 if(day<'2026-10-11')return db.prepare('UPDATE step_rewards SET units=MAX(units,CAST(MIN(?,10000)/1000 AS INTEGER)*1000),accounted_steps=MAX(accounted_steps,?) WHERE user_id=? AND day=?').bind(steps,steps,id,day);
 const rate=Math.round(settings.stepReward*100),cap=settings.stepDailyLimit*100;
 return db.prepare('UPDATE step_rewards SET units=units+MIN(MAX(0,?-units),MAX(0,?-accounted_steps)*?),accounted_steps=MAX(accounted_steps,?) WHERE user_id=? AND day=?').bind(cap,steps,rate,steps,id,day);
}
