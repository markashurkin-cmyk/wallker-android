import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
// Local test uses the installed Workers runtime and a separate ephemeral SQLite/D1 database.
const {Miniflare} = await import(process.env.WALLKER_MINIFLARE_MODULE || 'miniflare');
const {configureBot,TelegramSetupError}=await import('../worker.js');
const root = fileURLToPath(new URL('../', import.meta.url));
const botToken = '12345:LOCAL_TEST_ONLY_NOT_A_TELEGRAM_TOKEN';
const webhookSecret = 'local-test-webhook-secret';
const mf = new Miniflare({modules:true, scriptPath:root+'worker.js', compatibilityDate:'2026-05-15', d1Databases:['DB'], bindings:{TELEGRAM_BOT_TOKEN:botToken, TELEGRAM_WEBHOOK_SECRET:webhookSecret, ALLOWED_ORIGINS:'https://allowed.example'}});
function initData(id=1001, authDate=Math.floor(Date.now()/1000)) {
  const fields = new URLSearchParams({auth_date:String(authDate), query_id:'local-test-query', user:JSON.stringify({id,first_name:'Тест'})});
  const secret = createHmac('sha256','WebAppData').update(botToken).digest();
  const check = [...fields].sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join('\n');
  fields.set('hash',createHmac('sha256',secret).update(check).digest('hex'));
  return fields.toString();
}
function dayOffset(offset) { const date=new Date(); const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Tomsk',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date); const get=key=>parts.find(p=>p.type===key).value; const d=new Date(`${get('year')}-${get('month')}-${get('day')}T12:00:00Z`); d.setUTCDate(d.getUTCDate()+offset); return d.toISOString().slice(0,10); }
async function api(path, {method='GET',data,init,token,origin,secret}={}) {
  const headers = {'Content-Type':'application/json'};
  if(init) headers['X-Telegram-Init-Data']=init;
  if(token) headers.Authorization=`Bearer ${token}`;
  if(origin) headers.Origin=origin;
  if(secret) headers['X-Telegram-Bot-Api-Secret-Token']=secret;
  const response = await mf.dispatchFetch('http://localhost'+path,{method,headers,...(data!==undefined ? {body:JSON.stringify(data)} : {})});
  const value=response.status===204 ? null : await response.json();
  return {status:response.status,value,headers:response.headers};
}
try {
  const db=await mf.getD1Database('DB');
  const schema=(await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'');
  for(const sql of schema.split(';').map(s=>s.trim()).filter(Boolean)) await db.prepare(sql).run();
  const auth=initData();
  assert.equal((await api('/api/health')).status,200);
  assert.equal((await api('/api/wallet')).status,401);
  assert.equal((await api('/api/wallet',{init:initData(1001,Math.floor(Date.now()/1000)-3601)})).status,401);
  assert.equal((await api('/api/wallet',{init:auth.slice(0,-1)+(auth.endsWith('0')?'1':'0')})).status,401);
  const initial=await api('/api/wallet?timezone=Asia%2FTomsk',{init:auth});
  assert.equal(initial.status,200); assert.equal(initial.value.user.timezone,'Asia/Tomsk');
  const created=await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}});
  assert.equal(created.status,200); assert.match(created.value.code,/^[a-f0-9]{48}$/);
  const wrongCode=await api('/api/device/pair',{method:'POST',data:{code:'0'.repeat(48),platform:'android'}});
  assert.equal(wrongCode.status,401); assert.match(wrongCode.value.error,/Такой код не найден/);
  assert.ok(!wrongCode.value.error.includes('0'.repeat(48)));
  const pairing=(await Promise.all([1,2].map(()=>api('/api/device/pair',{method:'POST',data:{code:created.value.code,platform:'android'}}))));
  assert.deepEqual(pairing.map(p=>p.status).sort(),[200,401]);
  assert.match(pairing.find(p=>p.status===401).value.error,/уже использован/);
  const token=pairing.find(p=>p.status===200).value.token;
  assert.match(token,/^[a-f0-9]{48}$/);
  const stored=await db.prepare('SELECT code_hash,device_hash FROM pairings LIMIT 1').first();
  assert.notEqual(stored.code_hash,created.value.code); assert.notEqual(stored.device_hash,token);
  const sync=(steps,day=dayOffset(0))=>api('/api/device/steps',{method:'POST',token,data:{day,steps}});
  assert.equal((await sync(3500)).status,200);
  assert.equal((await sync(3500)).value.coins,30);
  assert.equal((await sync(2000)).value.steps,3500);
  assert.equal((await sync(12000)).value.coins,100);
  assert.equal((await sync(100001)).status,400);
  assert.equal((await sync(-1)).status,400);
  assert.equal((await sync(1000,dayOffset(1))).status,400);
  assert.equal((await sync(1000,dayOffset(-7))).status,400);
  assert.equal((await sync(1000,dayOffset(-6))).status,200);
  const snapshot=await api('/api/wallet',{init:auth});
  assert.equal(snapshot.value.balance,110); assert.equal(snapshot.value.todayCoins,100);
  const repairCode=(await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}})).value.code;
  const check=await api('/api/device/pair',{method:'POST',token,data:{code:repairCode,platform:'android',checkOnly:true}});
  assert.equal(check.status,200); assert.equal(check.value.sameAccount,true);
  assert.match(check.value.accountId,/^[a-f0-9]{64}$/);
  const unchecked=await api('/api/device/pair',{method:'POST',data:{code:repairCode,platform:'android',checkOnly:true}});
  assert.equal(unchecked.value.sameAccount,null);
  const mismatch=await api('/api/device/pair',{method:'POST',token,data:{code:repairCode,platform:'android',expectedAccountId:'incorrect'}});
  assert.equal(mismatch.status,409);
  assert.equal((await sync(12000)).status,200); // Preflight and refusal do not consume the code or revoke the old device.
  const repaired=await api('/api/device/pair',{method:'POST',token,data:{code:repairCode,platform:'android',expectedAccountId:check.value.accountId}});
  assert.equal(repaired.status,200); assert.equal(repaired.value.accountId,check.value.accountId);
  assert.ok(repaired.value.history.some(h=>h.day===dayOffset(0)&&h.steps===12000));
  assert.equal((await sync(12000)).status,401); // Only the replaced device credential is revoked.
  const repairedSync=await api('/api/device/steps',{method:'POST',token:repaired.value.token,data:{day:dayOffset(0),steps:12000}});
  assert.equal(repairedSync.value.coins,100);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,110);
  assert.equal((await api('/api/wallet',{init:auth})).value.devices.length,1);
  const other=await api('/api/wallet',{init:initData(1002)});
  assert.equal(other.value.balance,0); assert.equal(other.value.devices.length,0);
  const otherCode=(await api('/api/wallet',{method:'POST',init:initData(1002),data:{action:'pair'}})).value.code;
  const otherCheck=await api('/api/device/pair',{method:'POST',token:repaired.value.token,data:{code:otherCode,platform:'android',checkOnly:true}});
  assert.equal(otherCheck.value.sameAccount,false); assert.notEqual(otherCheck.value.accountId,check.value.accountId);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,110);
  const calls=[];
  const fakeTelegram=async (_env,method,data)=>{
    calls.push({method,data});
    if(method==='getWebhookInfo')return {url:'https://wallker-wallet.markashurkin.workers.dev/api/telegram/webhook'};
    if(method==='getChatMenuButton')return {type:'web_app',web_app:{url:'https://wallker-wallet.markashurkin.workers.dev'}};
    return true;
  };
  const setupEnv={DB:db,TELEGRAM_BOT_TOKEN:botToken,BOT_AUTO_SETUP:'true'};
  assert.equal(await configureBot(setupEnv,fakeTelegram),'ready');
  assert.deepEqual(calls.map(c=>c.method),['setWebhook','setChatMenuButton','getWebhookInfo','getChatMenuButton']);
  assert.match(calls[0].data.secret_token,/^[a-f0-9]{64}$/);
  assert.equal(calls[0].data.drop_pending_updates,false);
  assert.equal(await configureBot(setupEnv,fakeTelegram),'ready'); assert.equal(calls.length,4);
  await db.prepare("UPDATE bot_setup SET ready=0,lease_until=0 WHERE id='telegram'").run();
  const rejectedTelegram=async (_env,method,data)=>{
    if(method==='setChatMenuButton')throw new TelegramSetupError(400,'telegram_url_rejected');
    return fakeTelegram(_env,method,data);
  };
  assert.equal(await configureBot(setupEnv,rejectedTelegram),'configuration_failed');
  const diagnostic=await db.prepare("SELECT stage,code,reason FROM bot_setup_errors WHERE id='telegram'").first();
  assert.deepEqual(diagnostic,{stage:'setChatMenuButton',code:400,reason:'telegram_url_rejected'});
  assert.ok(!JSON.stringify(diagnostic).includes(botToken));
  assert.equal(await configureBot(setupEnv,fakeTelegram),'configuration_failed'); // A failed attempt is not mislabeled pending during cooldown.
  await db.prepare("UPDATE bot_setup SET lease_until=0 WHERE id='telegram'").run();
  assert.equal(await configureBot(setupEnv,fakeTelegram),'ready');
  assert.equal(await db.prepare("SELECT id FROM bot_setup_errors WHERE id='telegram'").first(),null);
  const storedSetup=await db.prepare('SELECT config_hash FROM bot_setup').first();
  assert.ok(!storedSetup.config_hash.includes(botToken));
  const rejected=await api('/api/wallet',{method:'POST',init:auth,origin:'https://untrusted.example',data:{action:'pair'}});
  assert.equal(rejected.status,403); assert.equal(rejected.headers.get('Access-Control-Allow-Origin'),null);
  assert.equal((await api('/api/health',{method:'OPTIONS',origin:'https://allowed.example'})).status,204);
  assert.equal((await api('/api/health',{origin:'https://allowed.example'})).headers.get('Access-Control-Allow-Origin'),'https://allowed.example');
  assert.equal((await api('/api/telegram/webhook',{method:'POST',data:{}})).status,401);
  const webhook=await api('/api/telegram/webhook',{method:'POST',secret:webhookSecret,data:{message:{chat:{id:1001,type:'private'},text:'/start'}}});
  assert.equal(webhook.status,200); assert.equal(webhook.value.reply_markup.inline_keyboard[0][0].web_app.url,'http://localhost');
  assert.equal((await api('/api/device/revoke',{method:'POST',init:auth,data:{}})).status,200);
  assert.equal((await sync(4000)).status,401);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,110);
  const expired=await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}});
  await db.prepare('UPDATE pairings SET expires=0 WHERE device_hash IS NULL').run();
  const expiredAttempt=await api('/api/device/pair',{method:'POST',data:{code:expired.value.code,platform:'android'}});
  assert.equal(expiredAttempt.status,401); assert.match(expiredAttempt.value.error,/Срок действия/);
  const huge=await api('/api/device/pair',{method:'POST',data:{padding:'x'.repeat(9000)}});
  assert.equal(huge.status,413);
  assert.equal((await api('/api/device/pair',{method:'GET'})).status,405);
  assert.equal((await api('/api/unknown')).status,404);
  console.log('PASS: real local D1/Workers integration — Telegram signature and expiry, single-use pairing race, non-consuming pairing preflight, same-account history recovery, old-device rotation, different-account detection, deployment-owned Telegram configuration, hashed credentials, idempotent sync, daily cap, seven-day window, account isolation, revocation, CORS, webhook secret, bounded requests, JSON errors.');
} finally { await mf.dispose(); }
