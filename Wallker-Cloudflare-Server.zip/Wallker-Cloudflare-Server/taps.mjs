import {levelSnapshot} from './levels.mjs';
import {isAdmin} from './campaigns.mjs';
import {rewardSettings,levelTapSettings} from './rewards.mjs';
export class TapError extends Error {
  constructor(message,status=400){super(message);this.status=status;}
}

export async function ensureTaps(db){
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_state(user_id TEXT PRIMARY KEY,total INTEGER NOT NULL DEFAULT 0,energy INTEGER NOT NULL DEFAULT 100,energy_at INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_paid(user_id TEXT PRIMARY KEY,units INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_daily_paid(user_id TEXT NOT NULL,day TEXT NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,day))').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_awards(user_id TEXT NOT NULL,request_id TEXT NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_daily(user_id TEXT NOT NULL,day TEXT NOT NULL,count INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,day))').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_reward_baseline(user_id TEXT PRIMARY KEY,legacy_total INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_receipts(user_id TEXT NOT NULL,request_id TEXT NOT NULL,requested INTEGER NOT NULL,accepted INTEGER NOT NULL,applied INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))').run();
}
async function tapDay(db,id,now){
 const user=await db.prepare('SELECT timezone FROM users WHERE id=?').bind(id).first();
 return new Intl.DateTimeFormat('sv-SE',{timeZone:user?.timezone||'Europe/Moscow'}).format(new Date(now));
}
export async function tapSnapshot(db,id,now=Date.now(),env={}){
  await ensureTaps(db);
  const settings=await rewardSettings(db),level=(await levelSnapshot(db,id,isAdmin({id},env))).level,tapSettings=levelTapSettings(settings,level),capacity=settings.energyCapacity,regenMs=settings.energyRegenSeconds*1000;
  await db.prepare('INSERT OR IGNORE INTO tap_state(user_id,energy_at,energy) VALUES(?,?,?)').bind(id,now,capacity).run();
  const row=await db.prepare('SELECT total,energy,energy_at FROM tap_state WHERE user_id=?').bind(id).first();
  await db.prepare('INSERT OR IGNORE INTO tap_reward_baseline(user_id,legacy_total) VALUES(?,?)').bind(id,row.total).run();
  const baseline=await db.prepare('SELECT legacy_total FROM tap_reward_baseline WHERE user_id=?').bind(id).first();
  const day=await tapDay(db,id,now);
  await db.prepare('INSERT OR IGNORE INTO tap_daily(user_id,day) VALUES(?,?)').bind(id,day).run();
  const daily=await db.prepare('SELECT count FROM tap_daily WHERE user_id=? AND day=?').bind(id,day).first();
  const newTaps=Math.max(0,row.total-baseline.legacy_total);
  await db.prepare('INSERT OR IGNORE INTO tap_paid(user_id,units) VALUES(?,?)').bind(id,baseline.legacy_total*100+newTaps*10).run();
  await db.prepare('INSERT OR IGNORE INTO tap_daily_paid(user_id,day,units) VALUES(?,?,?)').bind(id,day,daily.count*10).run();
  const paid=await db.prepare('SELECT units FROM tap_paid WHERE user_id=?').bind(id).first();
  const todayPaid=await db.prepare('SELECT units FROM tap_daily_paid WHERE user_id=? AND day=?').bind(id,day).first();
  return {tapDay:day,tapDailyLimit:tapSettings.tapDailyLimit,tapTodayCoins:todayPaid.units/100,tapDailyRemaining:Math.max(0,tapSettings.tapDailyLimit-todayPaid.units/100),tapReward:tapSettings.tapReward,tapCount:row.total,tapsPerCoin:1/tapSettings.tapReward,tapRemainder:0,tapCoins:paid.units/100,energy:Math.min(capacity,row.energy+Math.max(0,Math.floor((now-row.energy_at)/regenMs))),capacity,regenMs};
}
export async function earnTaps(db,id,data,now=Date.now(),env={}){
  if(!Number.isSafeInteger(data.count)||data.count<1||data.count>50)throw new TapError('Можно передать от 1 до 50 нажатий');
  if(typeof data.requestId!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.requestId))throw new TapError('Неверный номер начисления');
  const state=await tapSnapshot(db,id,now,env);
  const day=state.tapDay,rate=Math.round(state.tapReward*100),cap=state.tapDailyLimit*100,capacity=state.capacity,regenMs=state.regenMs;
  // The receipt, energy deduction and balance update commit together. Replayed
  // requests are harmless, including parallel requests from Android and Telegram.
  const available=`MIN(${capacity},energy+MAX(0,CAST((?-energy_at)/${regenMs} AS INTEGER)))`;
  await db.batch([
    db.prepare(`INSERT OR IGNORE INTO tap_receipts(user_id,request_id,requested,accepted,created) SELECT user_id,?,?,MIN(?,${available},MAX(0,CAST((${cap}-(SELECT units FROM tap_daily_paid WHERE user_id=tap_state.user_id AND day=?))/${rate} AS INTEGER))),? FROM tap_state WHERE user_id=?`).bind(data.requestId,data.count,data.count,now,day,now,id),
    db.prepare('INSERT OR IGNORE INTO tap_awards(user_id,request_id,units) SELECT user_id,request_id,accepted*? FROM tap_receipts WHERE user_id=? AND request_id=?').bind(rate,id,data.requestId),
    db.prepare(`UPDATE tap_state SET total=total+(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?),energy=${available}-(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?),energy_at=CASE WHEN ${available}=${capacity} THEN ? ELSE energy_at+MAX(0,CAST((?-energy_at)/${regenMs} AS INTEGER))*${regenMs} END WHERE user_id=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)`).bind(id,data.requestId,now,id,data.requestId,now,now,now,id,id,data.requestId),
    db.prepare('UPDATE tap_daily SET count=count+(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?) WHERE user_id=? AND day=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)').bind(id,data.requestId,id,day,id,data.requestId),
    db.prepare('UPDATE tap_paid SET units=units+(SELECT units FROM tap_awards WHERE user_id=? AND request_id=?) WHERE user_id=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)').bind(id,data.requestId,id,id,data.requestId),
    db.prepare('UPDATE tap_daily_paid SET units=units+(SELECT units FROM tap_awards WHERE user_id=? AND request_id=?) WHERE user_id=? AND day=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)').bind(id,data.requestId,id,day,id,data.requestId),
    db.prepare('UPDATE tap_receipts SET applied=1 WHERE user_id=? AND request_id=? AND applied=0').bind(id,data.requestId)
  ]);
  const receipt=await db.prepare('SELECT requested,accepted FROM tap_receipts WHERE user_id=? AND request_id=?').bind(id,data.requestId).first();
  if(receipt.requested!==data.count)throw new TapError('Номер начисления уже использован для другого количества',409);
  return {...await tapSnapshot(db,id,now,env),accepted:receipt.accepted};
}
