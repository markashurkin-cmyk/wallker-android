import {GrowthError} from './growth-config.mjs';
import {growthOpen,qualifyActive,growthTick} from './growth.mjs';
import {growthRoute} from './growth-routes.mjs';
import {deleteAccount} from './account.mjs';

import {migrate,requestDB,invalidate} from './runtime.mjs';
import {limit,canEarn,reportSteps,securitySnapshot,freezeAccount,clientError} from './security.mjs';
import {botUsername,publicBot,legacyBotEnv} from './bot-config.mjs';
import {clansSnapshot,clansAction} from './clans.mjs';
import {attributeReferral,settleReferrals,referralBoost} from './referrals.mjs';
import {chatSnapshot,chatInbox,sendChat} from './support-chat.mjs';
import {shopSnapshot,buyProduct,createInvoice,creditPayment,paymentPrecheck,refundedPayment,shopBalance,refundOrder,stampPaymentBots,reconcilePayments} from './shop.mjs';
import {analyticsExport} from './analytics-export.mjs';
import {submitSupport,supportStatus,supportInbox,flushSupport} from './support.mjs';
import {walletChart} from './wallet-chart.mjs';
import {grantBalance,grantTokens,grantHistory,revokeGrant} from './grants.mjs';
import {ensureFriends,friendsSnapshot,friendsAction} from './friends.mjs';
import {levelSnapshot,claimLevel,setDeveloperLevel} from './levels.mjs';
import {statisticsRoute,recordStatistics} from './statistics.mjs';
import {rewardSettings,saveRewardSettings,ensureStepRewards,stepRewardStatements} from './rewards.mjs';
import {ensureTaps,TapError,tapSnapshot,earnTaps} from './taps.mjs';
import {CampaignError,isAdmin,campaignSnapshot,bonusBalance,campaignRoute} from './campaigns.mjs';
const encoder = new TextEncoder();
const healthCache=new WeakMap();
class ApiError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const hex = bytes => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
const digest = async value => hex(await crypto.subtle.digest('SHA-256', encoder.encode(value)));
const randomToken = () => hex(crypto.getRandomValues(new Uint8Array(24)));
const APP_ORIGIN = 'https://wallker-wallet.markashurkin.workers.dev';
function sameURL(actual, expected) {
  try {
    if(typeof actual !== 'string') return false;
    // URL canonicalisation handles an implicit root slash and host casing,
    // while preserving the full path, query, fragment and credentials.
    return new URL(actual).href === new URL(expected).href;
  } catch { return false; }
}
export class TelegramSetupError extends Error {
  constructor(code, reason) { super('Telegram setup failed'); this.code=code; this.reason=reason; }
}
function safeTelegramReason(code, description) {
  const text=String(description || '').toLowerCase();
  if(code===401) return 'bot_token_rejected';
  if(code===429) return 'telegram_rate_limit';
  if(text.includes('secret token')) return 'webhook_secret_invalid';
  if(text.includes('resolve host') || text.includes('ip address')) return 'webhook_address_unreachable';
  if(text.includes('certificate') || text.includes('ssl')) return 'webhook_certificate_rejected';
  if(text.includes('url')) return 'telegram_url_rejected';
  return 'telegram_rejected_request';
}
async function webhookSecret(env) {
  return env.TELEGRAM_WEBHOOK_SECRET || hex(await hmac(encoder.encode(env.TELEGRAM_BOT_TOKEN || ''), `wallker-webhook:${APP_ORIGIN}`));
}
async function telegramCall(env, method, data) {
  let body=JSON.stringify(data), headers={'Content-Type':'application/json'};
  if(method==='setMyProfilePhoto') {
    const avatar=await env.ASSETS.fetch(new Request(APP_ORIGIN+'/avatar-telegram.jpg'));
    if(!avatar.ok) throw new TelegramSetupError(0,'bot_avatar_unavailable');
    const form=new FormData();
    form.set('photo',JSON.stringify({type:'static',photo:'attach://avatar'}));
    form.set('avatar',new Blob([await avatar.arrayBuffer()],{type:'image/jpeg'}),'walker-avatar.jpg');
    body=form; headers={};
  }
  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`, {
    method:'POST', headers, body, signal:AbortSignal.timeout(10000)
  });
  const result = await response.json();
  if (!response.ok || result.ok !== true) {
    const code=Number.isInteger(result.error_code) ? result.error_code : response.status;
    throw new TelegramSetupError(code,safeTelegramReason(code,result.description));
  }
  return result.result;
}
// Deployment-owned configuration only: the caller cannot choose a bot, URL or secret.
// A D1 lease prevents concurrent health checks from repeatedly configuring Telegram.
export async function configureBot(env, call = telegramCall) {
  if (env.BOT_AUTO_SETUP !== 'true' || !env.TELEGRAM_BOT_TOKEN) return 'disabled';
  const db=database(env), secret=await webhookSecret(env);
  const key=await digest(`${env.TELEGRAM_BOT_TOKEN}:${secret}:${APP_ORIGIN}:${botUsername(env)}:${env.LEGACY_TELEGRAM_BOT_TOKEN||''}:${env.LEGACY_TELEGRAM_WEBHOOK_SECRET||''}:${botUsername(env,true)}:walker-profile-v4`);
  await db.prepare('CREATE TABLE IF NOT EXISTS bot_setup (id TEXT PRIMARY KEY, config_hash TEXT, ready INTEGER NOT NULL DEFAULT 0, lease_until INTEGER NOT NULL DEFAULT 0)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS bot_setup_errors (id TEXT PRIMARY KEY, stage TEXT, code INTEGER, reason TEXT, at INTEGER)').run();
  await db.prepare("INSERT OR IGNORE INTO bot_setup(id) VALUES('telegram')").run();
  const current=await db.prepare("SELECT config_hash,ready FROM bot_setup WHERE id='telegram'").first();
  if(current.config_hash===key && current.ready===1) return 'ready';
  const lease=await db.prepare("UPDATE bot_setup SET lease_until=? WHERE id='telegram' AND lease_until<=? RETURNING id").bind(Date.now()+180000,Date.now()).first();
  if(!lease) return current.ready===-1 ? 'configuration_failed' : 'pending';
  await db.prepare("UPDATE bot_setup SET config_hash=?,ready=0 WHERE id='telegram'").bind(key).run();
  let stage='getMe';
  try {
    const bot=await call(env,'getMe',{});
    if(String(bot?.username||'').toLowerCase()!==botUsername(env).toLowerCase()) throw new TelegramSetupError(0,'bot_identity_mismatch');
    await stampPaymentBots(db,env);
    if(env.LEGACY_TELEGRAM_BOT_TOKEN&&env.LEGACY_TELEGRAM_BOT_TOKEN!==env.TELEGRAM_BOT_TOKEN){stage='configureLegacyBot';const oldEnv=legacyBotEnv(env),oldBot=await call(oldEnv,'getMe',{}),oldURL=APP_ORIGIN+'/api/telegram/legacy-webhook';if(String(oldBot?.username||'').toLowerCase()!==botUsername(env,true).toLowerCase())throw new TelegramSetupError(0,'legacy_bot_identity_mismatch');await call(oldEnv,'setWebhook',{url:oldURL,secret_token:await webhookSecret(oldEnv),allowed_updates:['message','pre_checkout_query'],drop_pending_updates:false});const check=await call(oldEnv,'getWebhookInfo',{});if(!sameURL(check.url,oldURL))throw new TelegramSetupError(0,'legacy_webhook_address_mismatch');}
    stage='setWebhook';
    const webhookURL=APP_ORIGIN+'/api/telegram/webhook';
    await call(env,'setWebhook',{url:webhookURL,secret_token:secret,allowed_updates:['message','pre_checkout_query'],drop_pending_updates:false});
    stage='setChatMenuButton';
    await call(env,'setChatMenuButton',{menu_button:{type:'web_app',text:'🐾 Открыть Walker',web_app:{url:APP_ORIGIN}}});
    stage='setMyName';
    await call(env,'setMyName',{name:'Walker Wallet'});
    await call(env,'setMyName',{name:'Walker Wallet',language_code:'ru'});
    const description='🐺 Волк готов шагать с тобой!\n\nОткрывай Walker Wallet, подключай шагомер и получай игровые WC за активность. Кошелёк, задания и награды — прямо в Telegram. WC — игровые баллы.';
    stage='setMyDescription';
    await call(env,'setMyDescription',{description});
    await call(env,'setMyDescription',{description,language_code:'ru'});
    stage='setMyShortDescription';
    const short_description='🐺 Шагай с волком: шаги, игровые WC и задания. Открой Walker Wallet и подключи шагомер.';
    await call(env,'setMyShortDescription',{short_description});
    await call(env,'setMyShortDescription',{short_description,language_code:'ru'});
    stage='setMyProfilePhoto';
    await call(env,'setMyProfilePhoto',{});
    stage='getMyName';
    const name=await call(env,'getMyName',{});
    if(name.name!=='Walker Wallet') throw new TelegramSetupError(0,'bot_name_mismatch');
    stage='getUserProfilePhotos';
    const photos=await call(env,'getUserProfilePhotos',{user_id:bot.id,limit:1});
    if(!photos.photos?.length) throw new TelegramSetupError(0,'bot_avatar_missing');
    stage='getWebhookInfo';
    const webhook=await call(env,'getWebhookInfo',{});
    stage='getChatMenuButton';
    const menu=await call(env,'getChatMenuButton',{});
    stage='verifyConfiguration';
    if(Array.isArray(webhook.allowed_updates)&&!webhook.allowed_updates.includes('pre_checkout_query'))throw new TelegramSetupError(0,'telegram_payment_updates_missing');
    if(!sameURL(webhook.url,webhookURL)) throw new TelegramSetupError(0,'telegram_webhook_address_mismatch');
    if(menu.type!=='web_app') throw new TelegramSetupError(0,'telegram_menu_type_mismatch');
    if(!sameURL(menu.web_app?.url,APP_ORIGIN)) throw new TelegramSetupError(0,'telegram_menu_address_mismatch');
    stage='saveConfiguration';
    await db.prepare("UPDATE bot_setup SET config_hash=?,ready=1,lease_until=0 WHERE id='telegram'").bind(key).run();
    await db.prepare("DELETE FROM bot_setup_errors WHERE id='telegram'").run();
    return 'ready';
  } catch(error) {
    // No token, secret or raw Telegram response is exposed or logged.
    const code=error instanceof TelegramSetupError ? error.code : null;
    const reason=error instanceof TelegramSetupError ? error.reason : stage==='saveConfiguration' ? 'database_write_failed' : 'network_or_response_error';
    await db.batch([
      db.prepare("UPDATE bot_setup SET ready=-1 WHERE id='telegram'"),
      db.prepare("INSERT INTO bot_setup_errors(id,stage,code,reason,at) VALUES('telegram',?,?,?,?) ON CONFLICT(id) DO UPDATE SET stage=excluded.stage,code=excluded.code,reason=excluded.reason,at=excluded.at").bind(stage,code,reason,Date.now())
    ]);
    return 'configuration_failed';
  }
}
async function hmac(key, value) {
  const imported = await crypto.subtle.importKey('raw', key, {name:'HMAC', hash:'SHA-256'}, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', imported, encoder.encode(value)));
}
function equal(a, b) {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}
function localDay(timezone, now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {timeZone:timezone, year:'numeric', month:'2-digit', day:'2-digit'}).formatToParts(now);
  const part = name => parts.find(p => p.type === name).value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}
function timezone(value) {
  try { if (typeof value === 'string' && value.length < 80) { new Intl.DateTimeFormat('en', {timeZone:value}); return value; } } catch {}
  return 'Europe/Moscow';
}
function validDay(value, zone) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const day = Date.parse(`${value}T00:00:00Z`);
  if (!Number.isFinite(day) || new Date(day).toISOString().slice(0,10) !== value) return false;
  const today = Date.parse(`${localDay(zone)}T00:00:00Z`);
  return day <= today && day >= today - 6 * 86400000;
}
const coins = (steps,day='2026-10-11') => day<'2026-10-11'?Math.floor(Math.min(10000,Math.max(0,steps))/1000)*10:Math.floor(Math.min(10000,Math.max(0,steps))*0.4);
function database(env) {
  if (!env.DB) throw new ApiError('База сервера ещё не подключена', 503);
  return env.DB;
}
async function body(request, limit = 8192) {
  const reader = request.body?.getReader();
  if (!reader) throw new ApiError('Пустой запрос');
  const chunks = [];
  let length = 0;
  while (true) {
    const {done, value} = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > limit) { await reader.cancel(); throw new ApiError('Слишком большой запрос', 413); }
    chunks.push(value);
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  try {
    const parsed = JSON.parse(new TextDecoder().decode(bytes));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error();
    return parsed;
  } catch { throw new ApiError('Неверный формат запроса'); }
}
async function identity(request, env, context) {
  const raw = request.headers.get('X-Telegram-Init-Data');
  if (!raw) throw new ApiError('Открой Walker через Telegram-бота', 401);
  if (raw.length > 8192) throw new ApiError('Слишком большой запрос входа', 413);
  if (!env.TELEGRAM_BOT_TOKEN) throw new ApiError('Telegram-бот ещё не подключён к серверу', 503);
  const params = new URLSearchParams(raw);
  if (new Set(params.keys()).size !== [...params.keys()].length) throw new ApiError('Повторяющиеся поля входа', 401);
  const supplied = params.get('hash') || '';
  if (!/^[a-f0-9]{64}$/.test(supplied)) throw new ApiError('Неверная подпись Telegram', 401);
  const authDate = Number(params.get('auth_date'));
  const now = Date.now()/1000;
  if (!authDate || !Number.isFinite(authDate) || now-authDate > 3600 || authDate > now+30) throw new ApiError('Открой приложение заново в Telegram', 401);
  params.delete('hash');
  const check = [...params].sort(([a], [b]) => a<b ? -1 : a>b ? 1 : 0).map(([k,v]) => `${k}=${v}`).join('\n');
  const secret = await hmac(encoder.encode('WebAppData'), env.TELEGRAM_BOT_TOKEN);
  const validSignature=equal(hex(await hmac(secret,check)),supplied)||(env.LEGACY_TELEGRAM_BOT_TOKEN&&equal(hex(await hmac(await hmac(encoder.encode('WebAppData'),env.LEGACY_TELEGRAM_BOT_TOKEN),check)),supplied));
  if (!validSignature) throw new ApiError('Неверная подпись Telegram', 401);
  let user;
  try { user = JSON.parse(params.get('user') || 'null'); } catch { throw new ApiError('Неверные данные Telegram', 401); }
  if (!user || !Number.isSafeInteger(user.id) || user.id <= 0) throw new ApiError('Нет пользователя Telegram', 401);
  const verified={id:`tg:${user.id}`, name:String(user.first_name || 'Участник').slice(0,60), username:typeof user.username==='string'&&/^[a-zA-Z0-9_]{1,32}$/.test(user.username)?user.username:'', mode:'beta',startParam:params.get('start_param')||''};
  if(context){context.user=verified;context.platform='telegram';}
  await limit(database(env),'api:'+verified.id,180);
  return verified;
}
async function snapshot(db, id, env) {
  const user = await db.prepare('SELECT name,timezone,mode FROM users WHERE id=?').bind(id).first();
  if (!user) throw new ApiError('Сначала открой кошелёк');
  await ensureStepRewards(db);
  const settings=await rewardSettings(db);
  const history = (await db.prepare('SELECT d.day,d.steps,d.source,d.updated,r.units/100.0 AS coins FROM days d JOIN step_rewards r ON d.user_id=r.user_id AND d.day=r.day WHERE d.user_id=? ORDER BY d.day DESC LIMIT 90').bind(id).all()).results;
  const sum=await db.prepare('SELECT COALESCE(SUM(units),0)/100.0 AS coins FROM step_rewards WHERE user_id=?').bind(id).first();
  const today = localDay(user.timezone);
  const steps = history.find(row => row.day === today)?.steps || 0;
  const devices = (await db.prepare('SELECT platform,substr(device_hash,1,16) AS id,(SELECT last_seen FROM device_sessions WHERE device_sessions.device_hash=pairings.device_hash) AS lastSeen FROM pairings WHERE user_id=? AND device_hash IS NOT NULL').bind(id).all()).results;
  const tap=await tapSnapshot(db,id,Date.now(),env);
  const levels=await levelSnapshot(db,id,isAdmin({id},env));
  await stampPaymentBots(db,env);
  const purchaseCoins=await shopBalance(db,id),bonusCoins=await bonusBalance(db,id),grantCoins=await grantBalance(db,id),earnings=await walletChart(db,id,today,user.timezone);
  const reports=(await db.prepare("SELECT day,steps,approved_steps,state,reason FROM step_reports WHERE user_id=? AND state='pending' ORDER BY day DESC LIMIT 7").bind(id).all()).results;
  return {...tap,pendingSteps:reports,bot:publicBot(env),purchaseCoins,levels,levelCoins:levels.coins,grantCoins,earnings,rewardSettings:{...settings,stepReward:Math.round(settings.stepReward*tap.referralMultiplier*10000)/10000,stepDailyLimit:Math.round(settings.stepDailyLimit*tap.referralMultiplier*100)/100},user, today, steps, todayCoins:history.find(row=>row.day===today)?.coins||0, balance:(sum?.coins || 0)+bonusCoins+tap.tapCoins+levels.coins+grantCoins+purchaseCoins, bonusCoins, history, devices, botConnected:true, ...await campaignSnapshot(db,{id},env)};
}
async function pairingResult(db,id,token,env){
 const user=await db.prepare('SELECT timezone FROM users WHERE id=?').bind(id).first();
 const history=(await db.prepare("SELECT day,MAX(steps) AS steps FROM (SELECT day,steps FROM days WHERE user_id=? UNION ALL SELECT day,steps FROM step_reports WHERE user_id=? AND state<>'rejected') GROUP BY day ORDER BY day DESC LIMIT 7").bind(id,id).all()).results;
 return {token,timezone:user.timezone,accountId:await digest('wallker-account:'+id),history,serverNow:Date.now(),botLink:publicBot(env).link};
}
async function route(request, env, url, context) {
  const path = url.pathname;
  if(path==='/api/daily')throw new ApiError('Мини-игра пока недоступна',410);
  if(['/api/device/state','/api/device/errors'].includes(path)){
 const token=request.headers.get('Authorization')?.replace(/^Bearer /,'')||'';if(!/^[a-f0-9]{48}$/.test(token))throw new ApiError('Привяжи телефон',401);const db=database(env),device=await db.prepare('SELECT p.user_id,p.platform,u.timezone FROM pairings p JOIN users u ON u.id=p.user_id WHERE device_hash=?').bind(await digest(token)).first();if(!device)throw new ApiError('Устройство отключено',401);context.user={id:device.user_id};context.platform=device.platform;
 if(path.endsWith('/errors'))return clientError(db,device.user_id,{...await body(request),platform:device.platform});await limit(db,'device-state:'+device.user_id,30);return {serverNow:Date.now(),timezone:device.timezone,botLink:publicBot(env).link};
 }
 if(path==='/api/device/tap')throw new ApiError('Тапы доступны только внутри Telegram',410);
  if(path==='/api/admin/security'){const user=await identity(request,env,context);if(!isAdmin(user,env))throw new ApiError('Только для владельца',403);const db=database(env);if(request.method==='GET')return securitySnapshot(db,url);const data=await body(request);if(data.action==='delete-account')return deleteAccount(db,user,data);if(data.action==='correction')return grantTokens(db,user,data);if(data.action==='freeze')return freezeAccount(db,user,data);throw new ApiError('Неизвестное действие');}
  if(path==='/api/client/errors'){const user=await identity(request,env,context);return clientError(database(env),user.id,await body(request));}
  if(path==='/api/account/delete'){const user=await identity(request,env,context),db=database(env);const data=await body(request);if(data.confirm!==true)throw new ApiError('Подтверди запрос удаления');await db.batch([db.prepare('INSERT OR IGNORE INTO deletion_requests(user_id,created) VALUES(?,?)').bind(user.id,Date.now()),db.prepare('DELETE FROM pairings WHERE user_id=?').bind(user.id)]);return {ok:true,pending:true};}
  if(path==='/api/bot'&&request.method==='GET')return publicBot(env);
  if (path === '/api/health' && request.method === 'GET') {
    const db=database(env),raw=db.rawDB||db,key=await digest(JSON.stringify([env.TELEGRAM_BOT_TOKEN,env.LEGACY_TELEGRAM_BOT_TOKEN,env.TELEGRAM_BOT_USERNAME,env.LEGACY_TELEGRAM_BOT_USERNAME,env.TELEGRAM_WEBHOOK_SECRET,env.LEGACY_TELEGRAM_WEBHOOK_SECRET,env.BOT_AUTO_SETUP]));
    const cached=healthCache.get(raw);if(cached&&cached.key===key&&cached.until>Date.now())return cached.promise;
    const promise=(async()=>{
    await db.prepare('SELECT id FROM users LIMIT 1').all();
    const botSetup=await configureBot(env);
    const botSetupError=botSetup==='configuration_failed'
      ? await db.prepare("SELECT stage,code,reason FROM bot_setup_errors WHERE id='telegram'").first() : null;
    return {ok:true, version:'0.2.23', botConfigured:Boolean(env.TELEGRAM_BOT_TOKEN), botSetup,...(botSetupError ? {botSetupError} : {})};
    })();healthCache.set(raw,{key,until:Date.now()+60000,promise});try{return await promise}catch(error){healthCache.delete(raw);throw error}
  }
  if(['/api/shop','/api/shop/buy','/api/shop/invoice'].includes(path)){
    const user=await identity(request,env,context),db=database(env);
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new ApiError('Сначала открой кошелёк');
    if(path==='/api/shop'&&request.method==='GET')return shopSnapshot(db,user.id,env);
    if(request.method!=='POST')throw new ApiError('Метод не поддерживается',405);
    const data=await body(request);
    if(path==='/api/shop/invoice'){if(env.STARS_PAYMENTS_ENABLED!=='true')throw new ApiError('Пополнение пока готовится',409);const setup=await configureBot(env);if(setup!=='ready')throw new ApiError('Оплата временно недоступна. Попробуй позже.',503);return createInvoice(db,user.id,data,env,telegramCall);}
    if(path!=='/api/shop/buy')throw new ApiError('Метод не поддерживается',405);
    await buyProduct(db,user.id,data);context.event='shop';return shopSnapshot(db,user.id,env);
  }
  if(path==='/api/admin/shop'&&['GET','POST'].includes(request.method)){
    const user=await identity(request,env,context);if(!isAdmin(user,env))throw new ApiError('Только для владельца',403);
    const db=database(env);await shopSnapshot(db,user.id,env);
    if(request.method==='POST'){const data=await body(request);if(data.action!=='refund'||typeof data.order!=='string'||data.order.length>128)throw new ApiError('Выбери заказ для возврата');return refundOrder(db,data.order,env,telegramCall);}
    return {enabled:env.STARS_PAYMENTS_ENABLED==='true',orders:(await db.prepare('SELECT id,user_id,credits,stars,state,created FROM shop_orders ORDER BY created DESC LIMIT 100').all()).results};
  }
  if(path==='/api/admin/export'&&request.method==='GET'){
    const user=await identity(request,env,context);if(!isAdmin(user,env))throw new ApiError('Экспорт доступен только владельцу',403);
    return analyticsExport(database(env),url);
  }
  if(['/api/support/chat','/api/admin/support/chat','/api/admin/support/chats'].includes(path)){
    const user=await identity(request,env,context),db=database(env),admin=path.startsWith('/api/admin/');
    if(admin&&!isAdmin(user,env))throw new ApiError('Только для владельца',403);
    if(path.endsWith('/chats')&&request.method==='GET')return chatInbox(db,url);
    if(request.method==='GET')return chatSnapshot(db,admin?url.searchParams.get('user'):user.id,admin,url);
    if(request.method==='POST'&&!path.endsWith('/chats'))return sendChat(db,env,user,await body(request),admin);
    throw new ApiError('Метод не поддерживается',405);
  }
  if(path==='/api/support'&&['GET','POST'].includes(request.method)){
    const user=await identity(request,env,context),db=database(env);
    return request.method==='POST'?submitSupport(db,env,user,await body(request)):supportStatus(db,env,user.id);
  }
  if(path==='/api/admin/support'&&request.method==='GET'){
    const user=await identity(request,env,context);if(!isAdmin(user,env))throw new ApiError('Только для разработчика',403);
    return supportInbox(database(env),env);
  }
  if (path === '/api/wallet' && ['GET','POST'].includes(request.method)) {
    const user = await identity(request, env, context);
    const db = database(env);
    if (request.method === 'GET') {
      await db.prepare('INSERT INTO users(id,name,timezone,mode,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').bind(user.id, user.name, timezone(url.searchParams.get('timezone')), user.mode, Date.now()).run();
      await ensureFriends(db);await ensureTaps(db);await attributeReferral(db,user.id,user.startParam,Date.now(),true);await growthOpen(db,user.id);
      await db.prepare('INSERT OR IGNORE INTO trusted_step_totals(user_id,steps) VALUES(?,0)').bind(user.id).run();
      context.event='wallet';
      return snapshot(db, user.id, env);
    }
    const data = await body(request);
    if (!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first()) throw new ApiError('Сначала открой кошелёк');
    if (data.action !== 'pair') throw new ApiError('Неизвестное действие');
    await limit(db,'pair-code:'+user.id,10);const count=(await db.prepare('SELECT COUNT(*) AS n FROM pairings WHERE user_id=? AND device_hash IS NOT NULL').bind(user.id).first()).n;if(count>=5)throw new ApiError('Подключено пять устройств. Сначала отключи ненужные.',409);
    const code = randomToken();
    const expires = Date.now()+600000;
    await db.batch([
      db.prepare('DELETE FROM pairings WHERE user_id=? AND device_hash IS NULL').bind(user.id),
      db.prepare('INSERT INTO pairings(code_hash,user_id,expires) VALUES(?,?,?)').bind(await digest(code), user.id, expires)
    ]);
    return {code, expires};
  }
  if (['/api/tap','/api/device/tap'].includes(path) && request.method==='POST') {
    const db=database(env),data=await body(request);let id;
    if(path==='/api/tap')id=(await identity(request,env,context)).id;
    else {
      const token=request.headers.get('Authorization')?.replace(/^Bearer /,'')||'';
      if(!/^[a-f0-9]{48}$/.test(token))throw new ApiError('Привяжи телефон заново',401);
      const device=await db.prepare('SELECT user_id,platform FROM pairings WHERE device_hash=?').bind(await digest(token)).first();
      if(!device)throw new ApiError('Телефон не привязан',401);id=device.user_id;context.user={id};context.platform=device.platform;
    }
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(id).first())throw new ApiError('Сначала открой кошелёк');
    await canEarn(db,id);await limit(db,'tap:'+id,90);
    const tap=data.action==='state'?await tapSnapshot(db,id,Date.now(),env):await earnTaps(db,id,data,Date.now(),env);
    context.event='tap';
    const balance=await db.prepare("SELECT COALESCE((SELECT SUM(units)/100.0 FROM step_rewards WHERE user_id=?),0)+COALESCE((SELECT SUM(reward) FROM campaign_claims WHERE user_id=? AND state='approved'),0)+COALESCE((SELECT units/100.0 FROM tap_paid WHERE user_id=?),0)+COALESCE((SELECT SUM(units)/100.0 FROM level_claims WHERE user_id=?),0)+COALESCE((SELECT SUM(units)/100.0 FROM admin_grants WHERE user_id=?),0)+COALESCE((SELECT SUM(units)/100.0 FROM shop_game_awards WHERE user_id=? AND NOT EXISTS(SELECT 1 FROM shop_accounts a WHERE a.user_id=shop_game_awards.user_id AND a.credits<0)),0) AS n").bind(id,id,id,id,id,id).first();
    return {...tap,balance:balance.n};
  }
  if(path.startsWith('/api/growth')||path.startsWith('/api/admin/growth')){
   const user=await identity(request,env,context),db=database(env);
   if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new ApiError('Сначала открой кошелёк');
   if(path.startsWith('/api/admin/')&&!isAdmin(user,env))throw new ApiError('Только для владельца',403);
   await limit(db,'growth:'+user.id,30);
   return growthRoute(db,user,env,url,request.method,request.method==='POST'?await body(request):null);
  }
  if(path==='/api/clans'){
    const user=await identity(request,env,context),db=database(env);
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new ApiError('Сначала открой кошелёк');
    if(request.method==='GET')return clansSnapshot(db,user.id,url,env);
    if(request.method==='POST')return clansAction(db,user.id,await body(request));
    throw new ApiError('Метод не поддерживается',405);
  }
  if(path==='/api/friends'){
    const user=await identity(request,env,context),db=database(env);
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new ApiError('Сначала открой кошелёк');
    if(request.method==='GET')return friendsSnapshot(db,user.id,env);
    if(request.method==='POST')return friendsAction(db,user.id,await body(request));
    throw new ApiError('Метод не поддерживается',405);
  }
  if(path==='/api/levels'||path==='/api/levels/claim'){
    const user=await identity(request,env,context),db=database(env);
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new ApiError('Сначала открой кошелёк');
    if(path==='/api/levels'&&request.method==='GET')return {levels:await levelSnapshot(db,user.id,isAdmin(user,env))};
    if(path==='/api/levels/claim'&&request.method==='POST'){await canEarn(db,user.id);
      const result=await claimLevel(db,user.id,await body(request),isAdmin(user,env));context.event='level';
      return {...result,levels:await levelSnapshot(db,user.id,isAdmin(user,env))};
    }
    throw new ApiError('Метод не поддерживается',405);
  }
  if (path.startsWith('/api/admin/') || path === '/api/campaigns' || path === '/api/campaigns/claim') {
    const user=await identity(request,env,context);const db=database(env);
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new ApiError('Сначала открой кошелёк');
    if(path.startsWith('/api/admin/stats')){
      if(!isAdmin(user,env))throw new ApiError('Статистика доступна только владельцу',403);
      if(request.method!=='GET')throw new ApiError('Метод не поддерживается',405);
      return statisticsRoute(db,url,id=>snapshot(db,id,env));
    }
    const payload=request.method==='POST'?await body(request):{page:Number(url.searchParams.get('page')||1)};
    const wallet=path==='/api/campaigns/claim'?await snapshot(db,user.id,env):null;
    if(path==='/api/admin/grants'){
      if(!isAdmin(user,env))throw new ApiError('Выдача WC доступна только владельцу',403);
      if(request.method==='GET')return grantHistory(db,user,url.searchParams.get('userId'));
      if(request.method!=='POST')throw new ApiError('Метод не поддерживается',405);
      const result=payload.action==='revoke'?await revokeGrant(db,user,payload):await grantTokens(db,user,payload);return {...result,balance:(await snapshot(db,result.userId,env)).balance};
    }
    if(path==='/api/admin/levels'){
      if(!isAdmin(user,env))throw new ApiError('Выбор уровня доступен только владельцу',403);
      if(request.method==='GET')return {levels:await levelSnapshot(db,user.id,true)};
      if(request.method==='POST')return {levels:await setDeveloperLevel(db,user.id,payload.level)};
      throw new ApiError('Метод не поддерживается',405);
    }
    if(path==='/api/admin/rewards'){
      if(!isAdmin(user,env))throw new ApiError('Настройки наград доступны только владельцу',403);
      if(request.method==='GET'){const settings=await rewardSettings(db),history=(await db.prepare('SELECT revision,created FROM reward_settings_history ORDER BY revision DESC LIMIT 20').all()).results;return {settings,history};}
      if(request.method==='POST'){if(payload.action==='restore'){if(!Number.isSafeInteger(payload.targetRevision))throw new ApiError('Выбери сохранённую версию');const old=await db.prepare('SELECT value FROM reward_settings_history WHERE revision=?').bind(payload.targetRevision).first();if(!old)throw new ApiError('Версия не найдена',404);return {settings:await saveRewardSettings(db,{...JSON.parse(old.value),revision:payload.revision})};}return {settings:await saveRewardSettings(db,payload)};}
      throw new ApiError('Метод не поддерживается',405);
    }
    if(!path.startsWith('/api/admin/'))context.event='campaign';
    return campaignRoute(path,request.method,payload,db,user,env,wallet?.steps||0);
  }
  if (path === '/api/device/pair' && request.method === 'POST') {
    const data = await body(request);
    if (typeof data.code !== 'string' || !/^[a-f0-9]{48}$/.test(data.code) || !['android','ios'].includes(data.platform)) throw new ApiError('Неверный код привязки');
    const db = database(env);
    if(data.pairNonce!==undefined&&(typeof data.pairNonce!=='string'||!/^[a-f0-9]{48}$/.test(data.pairNonce)))throw new ApiError('Неверный ключ повторной привязки');
    const token=data.pairNonce?(await digest('walker-device:v1:'+data.code+':'+data.pairNonce)).slice(0,48):randomToken();
    const tokenHash=await digest(token);
    const codeHash = await digest(data.code);
    const ip=request.headers.get('CF-Connecting-IP');if(ip)await limit(db,'pair-ip:'+await digest(ip),30);
    const previousToken = request.headers.get('Authorization')?.replace(/^Bearer /,'') || '';
    const previousHash = /^[a-f0-9]{48}$/.test(previousToken) ? await digest(previousToken) : null;
    const candidate = await db.prepare('SELECT user_id,expires,device_hash FROM pairings WHERE code_hash=?').bind(codeHash).first();
    if (candidate && candidate.expires > Date.now() && (candidate.device_hash===null||data.pairNonce&&candidate.device_hash===tokenHash)) {
      context.user={id:candidate.user_id};context.platform=data.platform;
      const accountId = await digest(`wallker-account:${candidate.user_id}`);
      const previous = previousHash ? await db.prepare('SELECT user_id FROM pairings WHERE device_hash=?').bind(previousHash).first() : null;
      const sameAccount = previous ? previous.user_id === candidate.user_id : null;
      if (data.checkOnly === true) return {accountId, sameAccount};
      if (data.expectedAccountId && data.expectedAccountId !== accountId) throw new ApiError('Аккаунт изменился. Проверь привязку заново.', 409);
    } else if (data.checkOnly === true) {
      if (!candidate) throw new ApiError('Такой код не найден на этом сервере. Перенеси текущий код из Telegram целиком.', 401);
      throw new ApiError(candidate.device_hash !== null ? 'Этот код уже использован. Получи новый в Telegram.' : 'Срок действия этого кода истёк. Получи новый в Telegram.', 401);
    }
    if(candidate?.device_hash===tokenHash&&data.pairNonce&&candidate.expires>Date.now())return pairingResult(db,candidate.user_id,token,env);
    const pairing = await db.prepare('UPDATE pairings SET device_hash=?,platform=? WHERE code_hash=? AND expires>? AND device_hash IS NULL RETURNING user_id').bind(await digest(token), data.platform, codeHash, Date.now()).first();
    if (!pairing) {
      const existing = await db.prepare('SELECT user_id,expires,device_hash FROM pairings WHERE code_hash=?').bind(codeHash).first();
      if(existing?.device_hash===tokenHash&&data.pairNonce&&existing.expires>Date.now())return pairingResult(db,existing.user_id,token,env);
      if (!existing) throw new ApiError(`Такой код не найден на этом сервере. Проверка ввода: ${codeHash.slice(0,12)}. Перенеси текущий код из Telegram целиком.`, 401);
      if (existing.device_hash !== null) throw new ApiError('Этот код уже использован. Получи новый в Telegram.', 401);
      if (existing.expires <= Date.now()) throw new ApiError('Срок действия этого кода истёк. Получи новый в Telegram.', 401);
      throw new ApiError('Код найден и действует, но сервер не завершил привязку. Повтори попытку.', 503);
    }
    const user = await db.prepare('SELECT timezone FROM users WHERE id=?').bind(pairing.user_id).first();
    if (previousHash&&previousHash!==tokenHash) await db.prepare('DELETE FROM pairings WHERE device_hash=?').bind(previousHash).run();
    context.user={id:pairing.user_id};context.platform=data.platform;context.event='pair';
    return pairingResult(db,pairing.user_id,token,env);
  }
  if (path === '/api/device/steps' && request.method === 'POST') {
    const token = request.headers.get('Authorization')?.replace(/^Bearer /,'') || '';
    if (!/^[a-f0-9]{48}$/.test(token)) throw new ApiError('Привяжи телефон заново', 401);
    const db = database(env);
    const device = await db.prepare('SELECT p.user_id,p.platform,u.timezone FROM pairings p JOIN users u ON u.id=p.user_id WHERE p.device_hash=?').bind(await digest(token)).first();
    if (!device) throw new ApiError('Телефон не привязан', 401);
    context.user={id:device.user_id};context.platform=device.platform;
    const data = await body(request);
    if (!Number.isSafeInteger(data.steps) || data.steps < 0 || data.steps > 100000) throw new ApiError('Неверное количество шагов');
    if (!validDay(data.day, device.timezone)) throw new ApiError('Можно передать шаги за сегодня и шесть предыдущих дней');
    const result=await reportSteps(db,device,await digest(token),data);await qualifyActive(db,device.user_id);
    const award=await db.prepare('SELECT units/100.0 AS coins FROM step_rewards WHERE user_id=? AND day=?').bind(device.user_id,data.day).first();
    context.event='sync';context.positiveSteps=result.steps>0;
    return {...result,coins:award?.coins||0,serverNow:Date.now()};
  }
  if (path === '/api/device/revoke' && request.method === 'POST') {
    const user = await identity(request, env, context);
    const data=await body(request),db=database(env);if(data.deviceId!==undefined&&!/^[a-f0-9]{16}$/.test(data.deviceId))throw new ApiError('Выбери устройство');if(data.deviceId)await db.prepare('DELETE FROM pairings WHERE user_id=? AND substr(device_hash,1,16)=?').bind(user.id,data.deviceId).run();else await db.prepare('DELETE FROM pairings WHERE user_id=?').bind(user.id).run();
    return {ok:true};
  }
  if (['/api/telegram/webhook','/api/telegram/legacy-webhook'].includes(path) && request.method === 'POST') {
    if(path.endsWith('/legacy-webhook'))env=legacyBotEnv(env);
    const expected = env.TELEGRAM_BOT_TOKEN ? await webhookSecret(env) : env.TELEGRAM_WEBHOOK_SECRET;
    const supplied = request.headers.get('X-Telegram-Bot-Api-Secret-Token') || '';
    if (!expected || !equal(expected, supplied)) throw new ApiError('Unauthorized', 401);
    const update = await body(request, 32768);
    const sender=update.pre_checkout_query?.from||update.message?.from;if(Number.isSafeInteger(sender?.id)&&sender.id>0){context.user={id:'tg:'+sender.id};context.platform='bot';}
    const db=database(env);
    if(update.pre_checkout_query){const q=update.pre_checkout_query,ok=await paymentPrecheck(db,q,env);await telegramCall(env,'answerPreCheckoutQuery',{pre_checkout_query_id:q.id,ok,...(!ok?{error_message:'Заказ недоступен. Вернись в магазин Walker.'}:{})});return {ok:true};}
    const message = update.message;
    if(message?.chat?.type==='private'&&message.from?.id===message.chat.id){
      if(message.successful_payment)return creditPayment(db,message.from.id,message.successful_payment,env);
      if(message.refunded_payment){await refundedPayment(db,message.from.id,message.refunded_payment,env);return {ok:true};}
    }
    if (!message || message.chat?.type !== 'private' || !Number.isSafeInteger(message.chat?.id)) return {ok:true};
    const command = String(message.text || '').split(/\s/)[0].split('@')[0];
    if(message.from?.is_bot) return {ok:true};
    if(command==='/start'&&message.from?.id===message.chat.id){await ensureFriends(db);await ensureTaps(db);await attributeReferral(db,'tg:'+message.chat.id,String(message.text||'').split(/\s+/)[1]);}
    if(command==='/terms')return {method:'sendMessage',chat_id:message.chat.id,text:'Магазин Walker: WC-Донаты — отдельный баланс для усилений и игровых WC. Перед оплатой показана цена в Stars. Усиления действуют 7/30 дней, повторная покупка продлевает срок, процент не складывается. Автоматических списаний нет. Покупки не обещают денежную доходность или будущий листинг. Для вопросов и возврата: /paysupport.'};
    if(command==='/paysupport')return {method:'sendMessage',chat_id:message.chat.id,text:'Помощь с оплатой и возвратом: открой Walker → Поддержка. Укажи дату и пакет покупки. Ответ придёт в чат поддержки приложения. Поддержка Telegram не обслуживает покупки Walker. Не отправляй данные карты или пароли.'};
    const greetings=[
      '🐺 Волк готов шагать с тобой!',
      '🐺 Стая ждёт — пора на прогулку!',
      '🐺 Каждый шаг — маленькая победа. Пойдём вместе!'
    ];
    let sequence=0;
    if(command!=='/id' && command!=='/privacy') {
      if(!Number.isSafeInteger(message.message_id)) return {ok:true};
      const db=database(env), chatHash=await digest(`walker-bot-chat:${message.chat.id}`);
      await db.prepare('CREATE TABLE IF NOT EXISTS bot_card_rotation (chat_hash TEXT PRIMARY KEY, message_id INTEGER NOT NULL, sequence INTEGER NOT NULL)').run();
      // Count incoming messages in this chat, not Telegram's shared incoming/outgoing IDs.
      // Re-delivery of the latest update keeps the same card; an old update cannot rewind it.
      const row=await db.prepare('INSERT INTO bot_card_rotation(chat_hash,message_id,sequence) VALUES(?,?,0) ON CONFLICT(chat_hash) DO UPDATE SET sequence=CASE WHEN excluded.message_id>bot_card_rotation.message_id THEN bot_card_rotation.sequence+1 ELSE bot_card_rotation.sequence END,message_id=MAX(bot_card_rotation.message_id,excluded.message_id) RETURNING sequence').bind(chatHash,message.message_id).first();
      sequence=row.sequence;
    }
    const index=sequence%greetings.length;
    const text = command === '/id' ? `Твой Telegram ID: ${message.chat.id}` : command === '/privacy'
      ? 'Walker Wallet хранит Telegram ID, имя, username, часовой пояс, даты и число шагов для игровых баллов, обращения в поддержку (текст передаётся разработчику через отдельного бота), а также статистику активности и безопасные коды ошибок запросов. Данные пользователей доступны владельцу проекта. GPS и медицинские данные не используются. Телефон можно отключить в разделе «Подключение». Это не удаляет историю на сервере.'
      : command === '/help'
      ? '🐾 Как начать\n\n1. Открой Walker Wallet кнопкой ниже.\n2. В разделе «Подключение» получи код привязки.\n3. Введи его в приложении на Android или iPhone и включи шагомер.\n\nБаланс, тапы и задания — в Telegram. Для iPhone доступна тестовая версия шагомера. WC — игровые баллы.'
      : `${command === '/start' ? greetings[0] : greetings[index]}\n\nПревращай прогулки в игровые WC, выполняй задания и собирай награды в Walker Wallet.\n\nОткрой кошелёк кнопкой ниже и подключи свой шагомер в разделе «Подключение».\n\n🐾 Твой путь начинается с первого шага.\nWC — игровые баллы.`;
    const reply_markup={inline_keyboard:[[{text:'🐾 Открыть Walker Wallet',web_app:{url:APP_ORIGIN}}]]};
    if(command==='/id' || command==='/privacy') return {method:'sendMessage',chat_id:message.chat.id,text,reply_markup};
    const card=sequence%2+1;
    return {method:'sendPhoto',chat_id:message.chat.id,photo:`${APP_ORIGIN}/wolf-walk-${card}.jpg`,caption:text,reply_markup};
  }
  const known = ['/api/health','/api/wallet','/api/device/pair','/api/device/steps','/api/device/revoke','/api/telegram/webhook'];
  throw new ApiError(known.includes(path) ? 'Метод не поддерживается' : 'Не найдено', known.includes(path) ? 405 : 404);
}
export default {
  async scheduled(controller,env,execution){if(env.GROWTH_PREVIEW==='true')return;execution.waitUntil((async()=>{await migrate(database(env));env={...env,DB:requestDB(database(env))};await growthTick(database(env));await flushSupport(database(env),env);await reconcilePayments(database(env),env,telegramCall);await database(env).batch([database(env).prepare('DELETE FROM request_limits WHERE window<?').bind(Math.floor(Date.now()/60000)-1440),database(env).prepare('DELETE FROM client_errors WHERE day<?').bind(new Date(Date.now()-30*86400000).toISOString().slice(0,10))]);})())},
  async fetch(request, env, execution) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) {
      if (!env.ASSETS) return new Response('Walker: интерфейс ещё не загружен', {status:503});
      const original = await env.ASSETS.fetch(request);
      const response = new Response(original.body, original);
      response.headers.set('X-Content-Type-Options', 'nosniff');
      response.headers.set('Referrer-Policy', 'no-referrer');
      response.headers.set('Content-Security-Policy', "default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'");
      return response;
    }
    if(env.GROWTH_PREVIEW==='true'&&url.pathname!=='/api/health')return new Response(JSON.stringify({error:'Isolated visual preview. Real accounts, bots and payments are disabled.'}),{status:503,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
    const origin = request.headers.get('Origin');
    const allowed = new Set([url.origin, ...(env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean)]);
    let status = 200, value;const context={};
    try {
      if (origin && !allowed.has(origin)) throw new ApiError('Запрос с другого сайта отклонён', 403);
      if (request.method === 'OPTIONS') {
        if (request.headers.get('Access-Control-Request-Method') && !['GET','POST'].includes(request.headers.get('Access-Control-Request-Method'))) throw new ApiError('Метод не поддерживается', 405);
        const headers = new Headers({'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization, X-Telegram-Init-Data','Access-Control-Max-Age':'600','Vary':'Origin','Cache-Control':'no-store'});
        if (origin) headers.set('Access-Control-Allow-Origin', origin);
        return new Response(null, {status:204, headers});
      }
      if(!/^\/api\/(health|bot|wallet|tap|shop|support|friends|clans|levels|campaigns|growth|admin|device|telegram|daily|account|client)(?:\/|$)/.test(url.pathname))throw new ApiError('Не найдено',404);
      if(url.pathname!=='/api/health'&&url.pathname!=='/api/bot'&&!request.headers.has('X-Telegram-Init-Data')&&!request.headers.has('Authorization')&&!url.pathname.includes('webhook')&&url.pathname!=='/api/device/pair')throw new ApiError('Открой Walker через Telegram-бота',401);
      const rawDB=database(env);await migrate(rawDB);env={...env,DB:requestDB(rawDB)};
      value = await route(request, env, url, context);
    } catch (error) {
      status = error instanceof ApiError || error instanceof CampaignError || error instanceof TapError || error instanceof GrowthError ? error.status : 503;
      value = {error:error instanceof ApiError || error instanceof CampaignError || error instanceof TapError || error instanceof GrowthError ? error.message : 'Ошибка настройки или выполнения запроса сервера'};
      // No request bodies, initData, pairing codes, tokens, or raw exception contents in logs.
      if (!(error instanceof ApiError) && !(error instanceof CampaignError) && !(error instanceof TapError) && !(error instanceof GrowthError)) console.error('Walker API failed', url.pathname);
    }
    if(env.DB&&context.user&&(context.event||status>=400)){
      const telemetry=recordStatistics(env.DB,context,status,url.pathname,value?.error).catch(()=>console.error('Walker statistics unavailable'));
      if(execution?.waitUntil)execution.waitUntil(telemetry);else await telemetry;
    }
    const headers = new Headers({'Content-Type':'application/json; charset=UTF-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Origin'});
    if (origin && allowed.has(origin)) headers.set('Access-Control-Allow-Origin', origin);
    return new Response(JSON.stringify(value), {status, headers});
  }
};
