// Shared presentation and server eligibility thresholds. No client-supplied rewards.
export const LEVELS=Object.freeze([
 {level:1,name:'Первый шаг',steps:0,reward:0,style:'Лаймовая футболка',description:'Начинающий пешеход. Всё большое начинается с первого шага.'},
 {level:2,name:'Любитель прогулок',steps:45000,reward:50,style:'Первый рюкзак',description:'Волкер собрал рюкзак и готов гулять вместе с тобой.'},
 {level:3,name:'Следопыт',steps:90000,reward:150,style:'Кепка и спортивная куртка',description:'Знакомые улицы становятся твоим маршрутом.'},
 {level:4,name:'Исследователь',steps:135000,reward:300,style:'Походный комплект',description:'Больше прогулок, больше открытий. Волкер готов к приключениям.'},
 {level:5,name:'Мастер ходьбы',steps:180000,reward:600,style:'Серебряная медаль',description:'Ты набираешь уверенный темп, а Волкер получает первую медаль.'},
 {level:6,name:'Чемпион маршрутов',steps:225000,reward:1000,style:'Золотая медаль',description:'Прогулки стали привычкой. Пора за золотом.'},
 {level:7,name:'Успешный волк',steps:270000,reward:2000,style:'Пиджак и золотая цепочка',description:'Опытный Волкер меняет спортивный образ на стильный пиджак.'},
 {level:8,name:'Богатый путешественник',steps:315000,reward:4000,style:'Костюм и золотые часы',description:'Большой путь, дорогой костюм и коллекция игровых WC.'},
 {level:9,name:'Вожак стаи',steps:360000,reward:7500,style:'Костюм с золотой отделкой',description:'Твой опыт вдохновляет стаю. Волкер становится её лидером.'},
 {level:10,name:'Легенда Walker',steps:405000,reward:12000,style:'Изумрудный костюм и корона',description:'405 тысяч шагов. Самый роскошный образ и высшее звание.'}
]);
export function walkingLevel(totalSteps){return LEVELS.filter(x=>totalSteps>=x.steps).at(-1)||LEVELS[0];}

export const DIVINE_LEVEL=Object.freeze({level:11,name:'Божественный Walker',steps:0,reward:0,style:'Корона и божественное золотое сияние',description:'Особое звание разработчика. Включается вручную в меню управления.',developerOnly:true});
