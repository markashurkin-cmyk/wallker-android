// Request-local memoization only: settings are never cached across requests.
export function memo(db,key,load){
 if(!db.requestMemo)return load();
 if(!db.requestMemo.has(key))db.requestMemo.set(key,Promise.resolve().then(load));
 return db.requestMemo.get(key);
}
export function invalidate(db,prefix){if(db.requestMemo)for(const key of db.requestMemo.keys())if(key.startsWith(prefix))db.requestMemo.delete(key)}
const initialized=new WeakMap();
export async function migrate(db){
 if(initialized.has(db))return initialized.get(db);
 const pending=(async()=>{
  const {DDL}=await import('./schema-ddl.mjs');
  await db.prepare('CREATE TABLE IF NOT EXISTS walker_migrations(version INTEGER PRIMARY KEY,created INTEGER NOT NULL)').run();
  const version=await db.prepare('SELECT version FROM walker_migrations WHERE version=21').first();
  if(!version){
   await db.batch(DDL.map(sql=>db.prepare(sql)));
   const columns=(await db.prepare('PRAGMA table_info(campaigns)').all()).results.map(x=>x.name);
   for(const field of ['title_en','description_en'])if(!columns.includes(field)){
    try{await db.prepare(`ALTER TABLE campaigns ADD COLUMN ${field} TEXT NOT NULL DEFAULT ''`).run()}
    catch(error){
     // The WeakMap serializes this isolate only. Another cold isolate may
     // add the same column after our PRAGMA; accept that exact race only.
     if(!String(error).includes('duplicate column name: '+field))throw error;
     const current=(await db.prepare('PRAGMA table_info(campaigns)').all()).results;
     if(!current.some(c=>c.name===field&&c.type.toUpperCase()==='TEXT'&&c.notnull===1&&c.dflt_value==="''"))throw error;
    }
   }
   await db.batch([
    db.prepare("INSERT OR IGNORE INTO step_rewards(user_id,day,accounted_steps,units) SELECT user_id,day,steps,CASE WHEN day<'2026-10-11' THEN CAST(MIN(steps,10000)/1000 AS INTEGER)*1000 ELSE CAST(MIN(steps,10000)*4/10 AS INTEGER)*100 END FROM days"),
    db.prepare("INSERT OR IGNORE INTO referral_qualified(invitee,inviter,qualified) SELECT r.invitee,r.inviter,COALESCE(c.reviewed,c.created) FROM referrals r JOIN campaign_claims c ON c.campaign_id='referral:'||r.invitee||':host' AND c.state='approved'"),
    // Preserve historical balances and ranks, never relabel old sensor data as verified.
    db.prepare('INSERT OR IGNORE INTO tap_reward_baseline(user_id,legacy_total) SELECT user_id,total FROM tap_state'),
    db.prepare('INSERT OR IGNORE INTO tap_paid(user_id,units) SELECT s.user_id,b.legacy_total*100+MAX(0,s.total-b.legacy_total)*10 FROM tap_state s JOIN tap_reward_baseline b ON b.user_id=s.user_id'),
    db.prepare('INSERT OR IGNORE INTO trusted_step_totals(user_id,steps) SELECT user_id,SUM(steps) FROM days GROUP BY user_id'),
    db.prepare('INSERT OR IGNORE INTO analytics_meta(id,started,cleaned) VALUES(1,?,0)').bind(Date.now()),
    db.prepare("INSERT OR IGNORE INTO support_chat(user_id,sender,author_id,request_id,message,created) SELECT user_id,'user',user_id,'legacy_'||request_id,message,created FROM support_messages WHERE NOT EXISTS(SELECT 1 FROM support_chat_meta WHERE id=1)"),
    db.prepare('INSERT OR IGNORE INTO support_chat_meta(id) VALUES(1)'),
    db.prepare('INSERT OR IGNORE INTO support_chat_legacy_cursor(id,last_id) SELECT 1,COALESCE(MAX(id),0) FROM support_messages'),
    db.prepare('INSERT OR IGNORE INTO walker_migrations(version,created) VALUES(21,?)').bind(Date.now())
   ]);
  }
  const growthVersion=await db.prepare('SELECT version FROM walker_migrations WHERE version=22').first();
  if(!growthVersion){
   const {GROWTH_DDL}=await import('./growth-schema.mjs');
   const {growthDefaults}=await import('./growth-config.mjs');
   await db.batch(GROWTH_DDL.map(sql=>db.prepare(sql)));
   const value=JSON.stringify(growthDefaults),now=Date.now();
   await db.batch([
    db.prepare('INSERT OR IGNORE INTO growth_meta(id,started) VALUES(1,?)').bind(now),
    db.prepare('INSERT OR IGNORE INTO growth_settings(id,value,revision) VALUES(1,?,1)').bind(value),
    db.prepare("INSERT OR IGNORE INTO growth_settings_history(revision,value,created,actor,reason) SELECT revision,value,?,'migration:22','Initial growth settings' FROM growth_settings WHERE id=1").bind(now),
    db.prepare('INSERT OR IGNORE INTO walker_migrations(version,created) VALUES(22,?)').bind(now)
   ]);
  }
  if(!await db.prepare('SELECT version FROM walker_migrations WHERE version=23').first()){
   const {BETA_DDL}=await import('./beta-access.mjs');
   await db.batch([...BETA_DDL.map(sql=>db.prepare(sql)),db.prepare('INSERT OR IGNORE INTO walker_migrations(version,created) VALUES(23,?)').bind(Date.now())]);
  }
 })();initialized.set(db,pending);try{await pending}catch(e){initialized.delete(db);throw e}
}
export function requestDB(db){return {rawDB:db,schemaReady:true,requestMemo:new Map(),prepare:db.prepare.bind(db),batch:db.batch.bind(db),exec:db.exec?.bind(db)}}
