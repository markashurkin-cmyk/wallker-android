package com.wallker.wallet

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import org.json.JSONObject

class MainActivity:ComponentActivity(){
    private lateinit var vault:DeviceVault
    private lateinit var store:StepStore
    private lateinit var status:TextView
    private lateinit var counter:TextView
    private lateinit var pending:TextView
    private lateinit var code:EditText
    private lateinit var pair:Button
    private lateinit var tracking:Button
    private lateinit var sync:Button
    private lateinit var badge:TextView
    private lateinit var connection:TextView
    private lateinit var pairStatus:TextView
    private lateinit var tapWallet:TapWallet
    private lateinit var tapBalance:TextView
    private lateinit var tapEnergy:TextView
    private lateinit var tapNotice:TextView
    private lateinit var tapMetric:TextView
    private lateinit var energyMetric:TextView
    private lateinit var wolfButton:FrameLayout
    private var tapBusy=false
    private var tapStateLoaded=false
    private var tapRetry=0L
    private var stateRefreshAt=0L
    private lateinit var ring:StepRing
    private val bg=Color.parseColor("#111512")
    private val surface=Color.parseColor("#1a201b")
    private val lime=Color.parseColor("#bdff58")
    private val muted=Color.parseColor("#a9b4a9")
    private var busy=false
    private val handler=Handler(Looper.getMainLooper())
    private val ticker=object:Runnable{override fun run(){refresh();handler.postDelayed(this,1000)}}
    private val permissionRequest=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){
        if(motionAllowed())startCounter() else {store.setStatus("Разреши физическую активность в настройках телефона.");refresh()}
    }
    private fun motionAllowed()=Build.VERSION.SDK_INT<29 || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)==PackageManager.PERMISSION_GRANTED
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState);vault=DeviceVault(this);store=StepStore(this);tapWallet=TapWallet(this,vault)
        buildInterface()
        StepSyncWorker.schedule(this);refresh()
    }
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()
    private fun shape(fill:Int, radius:Int=20, border:Boolean=false)=GradientDrawable().apply{
        setColor(fill);cornerRadius=dp(radius).toFloat()
        if(border)setStroke(dp(1),Color.parseColor("#303930"))
    }
    private fun label(value:String,size:Float=14f,color:Int=muted,bold:Boolean=false)=TextView(this).apply{
        text=value;textSize=size;setTextColor(color)
        if(bold)typeface=Typeface.create("sans-serif",Typeface.BOLD)
    }
    private fun stack()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
    private fun LinearLayout.put(view:View, gap:Int=0){
        addView(view,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(gap)})
    }
    private fun card()=stack().apply{background=shape(surface,border=true);setPadding(dp(20),dp(20),dp(20),dp(20))}
    private fun action(title:String,primary:Boolean=false,click:()->Unit)=Button(this).apply{
        text=title;isAllCaps=false;textSize=14f;typeface=Typeface.create("sans-serif",Typeface.BOLD)
        setTextColor(if(primary)bg else Color.parseColor("#f4f7f1"))
        background=shape(if(primary)lime else Color.parseColor("#303a30"),12)
        backgroundTintList=ColorStateList(arrayOf(intArrayOf(-android.R.attr.state_enabled),intArrayOf()),intArrayOf(Color.parseColor("#303930"),if(primary)lime else Color.parseColor("#303a30")))
        minHeight=dp(52);minimumHeight=dp(52);setPadding(dp(16),dp(10),dp(16),dp(10))
        setOnClickListener{click()}
    }
    private fun openTelegram(){
        try{startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://t.me/wallker_wallet_bot")))}
        catch(_:android.content.ActivityNotFoundException){Toast.makeText(this,"Установи Telegram или браузер",Toast.LENGTH_LONG).show()}
    }
    private fun showBackgroundHelp(){
        AlertDialog.Builder(this).setTitle("Работа с выключенным экраном")
            .setMessage("Разреши физическую активность и уведомления. В настройках батареи выбери «Без ограничений». На Xiaomi / POCO включи фоновый автозапуск Walker. После перезагрузки телефона открой приложение и проверь, что шагомер включён.")
            .setPositiveButton("Открыть настройки"){_,_->startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+packageName)))}
            .setNegativeButton("Закрыть",null).show()
    }
    private fun showPrivacy(){
        AlertDialog.Builder(this).setTitle("Данные Walker")
            .setMessage("Шаги считаются датчиком телефона без GPS. На телефоне хранятся даты и суммы за последние семь дней. После привязки они передаются по HTTPS на сервер Walker при доступной связи. Telegram передаёт ID и имя; сервер хранит часовой пояс, историю и привязку. Токен на телефоне защищён Android Keystore.\n\nОчистка удаляет местные шаги и токен. Для отзыва доступа также отключи устройство в разделе «Телефон» в Telegram. Серверная история сохраняется.\n\nКамера, геолокация, контакты, Apple Health и Health Connect не используются. WC — игровые монеты бета-версии без вывода; рекламы и платежей нет.")
            .setPositiveButton("Понятно",null).show()
    }
    private fun buildInterface(){
        val root=stack().apply{setBackgroundColor(bg)}
        root.setOnApplyWindowInsetsListener{v,insets->
            if(Build.VERSION.SDK_INT>=30){
                val safe=insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(safe.left,safe.top,safe.right,safe.bottom)
            }else v.setPadding(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom)
            insets
        }
        val header=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16))}
        header.addView(label("W",27f,bg,true).apply{gravity=Gravity.CENTER;background=shape(lime,13)},LinearLayout.LayoutParams(dp(44),dp(44)))
        header.addView(stack().apply{put(label("wallker",23f,Color.WHITE,true));put(label("W A L L E T  /  A N D R O I D",10f))},LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(12)})
        header.addView(label("БЕТА",11f,lime,true).apply{background=shape(Color.parseColor("#283322"),20);setPadding(dp(12),dp(7),dp(12),dp(7))})
        root.put(header)
        val host=FrameLayout(this)
        root.addView(host,LinearLayout.LayoutParams(-1,0,1f))
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false}
        host.addView(scroll,FrameLayout.LayoutParams(-1,-1))
        val body=stack().apply{setPadding(dp(20),dp(8),dp(20),dp(24))};scroll.addView(body)
        val home=stack().apply{setPadding(dp(18),dp(4),dp(18),dp(8))}
        host.addView(home,FrameLayout.LayoutParams(-1,-1))
        val phone=stack();val settings=stack();body.put(phone);body.put(settings)
        home.put(label("В СТАЕ ВОЛКЕРА",11f,lime,true).apply{gravity=Gravity.CENTER},2)
        val metrics=LinearLayout(this).apply{background=shape(surface,14,true);setPadding(dp(6),dp(8),dp(6),dp(8))}
        tapMetric=label("",11f,Color.WHITE,true).apply{gravity=Gravity.CENTER}
        energyMetric=label("",11f,Color.WHITE,true).apply{gravity=Gravity.CENTER}
        listOf(tapMetric,energyMetric,label("ШАГОМЕР\nХоди каждый день",11f,Color.WHITE,true).apply{gravity=Gravity.CENTER}).forEach{metrics.addView(it,LinearLayout.LayoutParams(0,-2,1f))}
        home.put(metrics,8)
        tapBalance=label("0 WC",34f,Color.WHITE,true).apply{gravity=Gravity.CENTER;setAutoSizeTextTypeUniformWithConfiguration(18,34,1,android.util.TypedValue.COMPLEX_UNIT_SP)}
        home.addView(tapBalance,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(8)})
        home.put(label("Волкер • нажимай и собирай",12f,muted).apply{gravity=Gravity.CENTER},2)
        val stage=FrameLayout(this)
        home.addView(stage,LinearLayout.LayoutParams(-1,0,1f).apply{topMargin=dp(8);bottomMargin=dp(8)})
        wolfButton=FrameLayout(this).apply{
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.parseColor("#474687"),Color.parseColor("#1b2230"))).apply{shape=GradientDrawable.OVAL;setStroke(dp(6),Color.parseColor("#665cc7"))}
            isClickable=true;isFocusable=true;contentDescription="Нажать на Волкера";clipChildren=false;clipToPadding=false
        }
        stage.addView(wolfButton,FrameLayout.LayoutParams(dp(200),dp(200),Gravity.CENTER))
        wolfButton.addView(ImageView(this).apply{setImageResource(R.drawable.volker);scaleType=ImageView.ScaleType.FIT_CENTER;importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_NO},FrameLayout.LayoutParams(-1,-1).apply{setMargins(dp(12),dp(5),dp(12),dp(5))})
        stage.addOnLayoutChangeListener{_,left,top,right,bottom,_,_,_,_->
            val diameter=minOf(right-left,bottom-top,dp(380)).coerceAtLeast(1)
            if(wolfButton.layoutParams.width!=diameter)wolfButton.layoutParams=FrameLayout.LayoutParams(diameter,diameter,Gravity.CENTER)
        }
        wolfButton.setOnClickListener{
            if(tapWallet.tap()){
                wolfButton.animate().scaleX(.96f).scaleY(.96f).setDuration(60).withEndAction{wolfButton.animate().scaleX(1f).scaleY(1f).setDuration(90).start()}.start()
                val gain=label("+"+wc(tapWallet.rate()),30f,Color.parseColor("#fff2a8"),true).apply{gravity=Gravity.CENTER}
                wolfButton.addView(gain,FrameLayout.LayoutParams(-1,dp(44),Gravity.CENTER))
                gain.animate().translationY(-dp(90).toFloat()).alpha(0f).setDuration(700).withEndAction{wolfButton.removeView(gain)}.start();refresh()
            }
        }
        tapNotice=label("Подключи Telegram для начислений",11f,muted).apply{gravity=Gravity.CENTER;maxLines=2}
        home.put(tapNotice)
        tapEnergy=label("⚡ 0 / 100",16f,Color.parseColor("#ffd66a"),true);home.put(tapEnergy,6)
        home.put(label("Общий баланс с Telegram • WC — игровые монеты",10f,muted).apply{gravity=Gravity.CENTER},4)
        phone.put(label("ТВОЙ АККАУНТ",11f,muted,true))
        phone.put(label("Подключение Telegram",28f,Color.WHITE,true),8)
        phone.put(label("Свяжи телефон с кошельком, чтобы передавать шаги."),8)
        val pairing=card();phone.put(pairing,24)
        connection=label("",16f,lime,true);pairing.put(connection)
        pairing.put(label("1. Открой бота и раздел «Телефон».\n2. Получи код на 10 минут.\n3. Вставь все 48 символов сюда."),16)
        pairing.put(action("Получить код в Telegram"){openTelegram()},16)
        code=EditText(this).apply{
            hint="Вставь код привязки";textSize=14f;setTextColor(Color.WHITE);setHintTextColor(muted)
            background=shape(bg,12,true);setPadding(dp(14),dp(14),dp(14),dp(14));minHeight=dp(56)
            inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            isSingleLine=true;importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        };pairing.put(code,16)
        pair=action("Привязать Telegram",true){pairDevice()};pairing.put(pair,12)
        pairStatus=label("",13f);pairing.put(pairStatus,14)
        pairing.put(label("При повторной привязке к тому же аккаунту местные шаги сохраняются. Telegram может быть на другом телефоне.",12f),16)
        val activity=card();phone.put(activity,20)
        val title=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        title.addView(label("Шаги сегодня",17f,Color.WHITE,true),LinearLayout.LayoutParams(0,-2,1f))
        badge=label("",11f,lime,true);title.addView(badge);activity.put(title)
        val circle=FrameLayout(this)
        ring=StepRing(this).apply{importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_NO};circle.addView(ring,FrameLayout.LayoutParams(-1,-1))
        val numbers=stack().apply{gravity=Gravity.CENTER}
        numbers.put(label("СЕГОДНЯ",11f,lime,true).apply{gravity=Gravity.CENTER})
        counter=label("0",48f,Color.WHITE,true).apply{gravity=Gravity.CENTER;maxLines=1;setAutoSizeTextTypeUniformWithConfiguration(24,48,1,android.util.TypedValue.COMPLEX_UNIT_SP)};numbers.put(counter,4)
        numbers.put(label("шагов на телефоне",12f).apply{gravity=Gravity.CENTER},4)
        circle.addView(numbers,FrameLayout.LayoutParams(-1,-1))
        activity.addView(circle,LinearLayout.LayoutParams(-1,dp(258)).apply{topMargin=dp(12);bottomMargin=dp(12)})
        tracking=action("Включить шагомер",true){
            if(store.enabled()){store.setEnabled(false);stopService(Intent(this,StepService::class.java));store.setStatus("Шагомер приостановлен");refresh()}else requestCounter()
        };activity.put(tracking)
        activity.put(label("Носи телефон с собой. Шаги сохраняются даже без интернета.",12f),14)
        val transfer=card();phone.put(transfer,16)
        transfer.put(label("Синхронизация",17f,Color.WHITE,true))
        pending=label("");transfer.put(pending,10)
        sync=action("Передать сохранённые шаги",true){StepSyncWorker.now(this);store.setSyncStatus("Передадим шаги при доступной связи");refresh()};transfer.put(sync,16)
        status=label("",13f);transfer.put(status,14)
        settings.put(label("ПРИЛОЖЕНИЕ",11f,muted,true))
        settings.put(label("Настройки",28f,Color.WHITE,true),8)
        val options=card();settings.put(options,24)
        options.put(label("Считай шаги в фоне",17f,Color.WHITE,true))
        options.put(label("Разреши уведомления, физическую активность и работу без ограничений батареи."),10)
        options.put(action("Настройки фоновой работы"){showBackgroundHelp()},16)
        options.put(action("Какие данные передаются"){showPrivacy()},12)
        val clear=card();settings.put(clear,16)
        clear.put(label("Управление устройством",17f,Color.WHITE,true))
        clear.put(label("Очистка удалит привязку и ещё не переданные шаги с этого телефона."),10)
        clear.put(action("Отключить и очистить"){
            if(!busy)AlertDialog.Builder(this).setTitle("Очистить данные телефона?")
                .setMessage("Местные шаги и привязка будут удалены. Уже переданная история останется в Telegram.")
                .setPositiveButton("Очистить"){_,_->stopService(Intent(this,StepService::class.java));tapWallet.clear();vault.clear();store.clear();store.setStatus("Для отзыва доступа отключи телефон также в Telegram");refresh()}
                .setNegativeButton("Отмена",null).show()
        },16)
        settings.put(label("Walker Wallet • "+packageManager.getPackageInfo(packageName,0).versionName+"\nБета-версия. WC — игровые монеты без вывода.",12f).apply{gravity=Gravity.CENTER},24)
        val nav=LinearLayout(this).apply{setPadding(dp(12),dp(10),dp(12),dp(10));background=shape(surface,0)}
        val pages=listOf(home,phone,settings)
        val tabs=listOf("Волкер","Телефон","Настройки").map{label(it,13f,muted,true).apply{
            gravity=Gravity.CENTER;minHeight=dp(48);isClickable=true;isFocusable=true
        }}
        fun select(index:Int){scroll.visibility=if(index==0)View.GONE else View.VISIBLE;pages.forEachIndexed{i,page->page.visibility=if(i==index)View.VISIBLE else View.GONE};tabs.forEachIndexed{i,t->t.setTextColor(if(i==index)lime else muted);t.background=shape(if(i==index)Color.parseColor("#283322") else surface,12);t.isSelected=i==index};scroll.scrollTo(0,0)}
        tabs.forEachIndexed{i,t->nav.addView(t,LinearLayout.LayoutParams(0,-2,1f).apply{marginStart=dp(3);marginEnd=dp(3)});t.setOnClickListener{select(i)}}
        root.put(nav);setContentView(root);root.requestApplyInsets();select(0)
    }
    override fun onStart(){super.onStart();tapStateLoaded=false;handler.post(ticker);if(store.enabled() && motionAllowed())startCounter();StepSyncWorker.now(this)}
    override fun onStop(){handler.removeCallbacks(ticker);super.onStop()}
    private fun wc(value:Double)=java.text.DecimalFormat("#,##0.##").format(value)
    private fun refresh(){
        tapBalance.text=wc(tapWallet.balance())+" WC"
        tapMetric.text="ЗА НАЖАТИЕ\n+"+wc(tapWallet.rate())+" WC"
        energyMetric.text="ЭНЕРГИЯ\n+1 / "+wc(tapWallet.regenMs()/1000.0)+" сек"
        tapEnergy.text="⚡ %,d / %,d".format(tapWallet.energy(),tapWallet.capacity())
        wolfButton.isEnabled=vault.token()!=null && tapWallet.energy()>0 && tapWallet.remaining()+0.000001>=tapWallet.rate()
        tapNotice.text=if(vault.token()==null)"Подключи Telegram в разделе «Телефон»" else if(!tapWallet.ready())"Загружаем кошелёк…" else if(tapWallet.pending()>0)"Сохраняем нажатия · "+tapWallet.pending() else if(tapWallet.remaining()+0.000001<tapWallet.rate())"Дневной лимит тапов достигнут" else if(tapWallet.energy()==0)"Энергия восстанавливается" else "За тап +"+wc(tapWallet.rate())+" WC · осталось "+wc(tapWallet.remaining())+" WC сегодня"
        flushTaps()
        val today=store.today();counter.text="%,d".format(today)
        ring.active=store.enabled()
        badge.text=if(store.enabled())"● ВКЛЮЧЁН" else "НА ПАУЗЕ"
        badge.setTextColor(if(store.enabled())lime else muted)
        val connected=vault.token()!=null
        connection.text=if(connected)"Telegram подключён" else "Telegram не подключён"
        pairStatus.text=listOf(store.status(),store.syncStatus()).filter{it.isNotEmpty()}.joinToString("\n")
        val days=store.pending().days.size
        pending.text=if(!connected)"Подключи Telegram в нижнем меню" else if(days==0)"Все сохранённые шаги переданы" else "Дней ожидают передачи: $days"
        status.text=listOf(if(store.enabled())"Шагомер включён" else "Шагомер выключен",store.status().ifEmpty{"Включи шагомер и разреши физическую активность"},store.syncStatus()).filter{it.isNotEmpty()}.joinToString("\n")
        tracking.text=if(store.enabled())"Приостановить шагомер" else "Включить шагомер"
        tracking.isEnabled=!busy;pair.isEnabled=!busy;code.isEnabled=!busy;sync.isEnabled=!busy && vault.token()!=null
        pair.text=if(busy)"Подключаем…" else if(vault.token()==null)"Привязать Telegram" else "Обновить привязку Telegram"
    }
    private fun flushTaps(){
        val token=vault.token() ?: return
        if(tapBusy || System.currentTimeMillis()<tapRetry)return
        val batch=tapWallet.next()
        if(batch==null && tapStateLoaded && System.currentTimeMillis()<stateRefreshAt)return
        val account=vault.accountId();tapBusy=true;tapWallet.inFlight=batch?.optString("requestId")
        lifecycleScope.launch{
            try{
                val result=WallkerAPI.post("/api/device/tap",batch ?: JSONObject().put("action","state"),token)
                if(vault.token()==token && vault.accountId()==account){tapWallet.commit(result,batch?.getString("requestId"));tapStateLoaded=true;stateRefreshAt=System.currentTimeMillis()+30000}
            }catch(_:Exception){tapRetry=System.currentTimeMillis()+5000}
            finally{tapBusy=false;tapWallet.inFlight=null}
        }
    }
    private fun requestCounter(){
        val sensors=getSystemService(SENSOR_SERVICE) as SensorManager
        if(sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)==null){store.setStatus("В этом телефоне нет датчика шагов");refresh();return}
        val permissions=mutableListOf<String>()
        if(Build.VERSION.SDK_INT>=29 && !motionAllowed())permissions.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if(permissions.isEmpty())startCounter() else permissionRequest.launch(permissions.toTypedArray())
    }
    private fun startCounter(){
        try{store.setEnabled(true);startForegroundService(Intent(this,StepService::class.java))}
        catch(e:Exception){store.setEnabled(false);store.setStatus("Не удалось включить шагомер: ${e.javaClass.simpleName}. Повтори при открытом Walker.")}
        refresh()
    }
    private suspend fun confirmAccountChange(unknown:Boolean):Boolean=suspendCancellableCoroutine{continuation->
        val dialog=AlertDialog.Builder(this).setTitle(if(unknown)"Проверить смену аккаунта" else "Другой аккаунт Telegram")
            .setMessage((if(unknown)"Не удалось подтвердить, что это прежний аккаунт. " else "Этот код выдан другому Telegram-аккаунту. ")+"При продолжении местные шаги прежнего аккаунта будут очищены. Уже переданная история останется в его Telegram-кошельке. Продолжить?")
            .setPositiveButton("Сменить аккаунт"){_,_->if(continuation.isActive)continuation.resume(true)}
            .setNegativeButton("Отмена"){_,_->if(continuation.isActive)continuation.resume(false)}
            .setOnCancelListener{if(continuation.isActive)continuation.resume(false)}.create()
        continuation.invokeOnCancellation{dialog.dismiss()};dialog.show()
    }
    private fun pairDevice(){
        if(busy)return
        val value=code.text.toString().trim()
        if(!Regex("[a-f0-9]{48}").matches(value)){store.setStatus("Вставь полный код из Telegram");refresh();return}
        lifecycleScope.launch{
            busy=true;refresh()
            try{
                val previousToken=vault.token();val previousAccount=vault.accountId()
                val check=WallkerAPI.post("/api/device/pair",JSONObject().put("code",value).put("platform","android").put("checkOnly",true),previousToken)
                val accountId=check.getString("accountId")
                val first=previousToken==null && previousAccount==null
                val same=if(previousAccount!=null)previousAccount==accountId else check.optBoolean("sameAccount",false)
                val unknown=previousAccount==null && check.isNull("sameAccount")
                if(!first && !same && !confirmAccountChange(unknown))return@launch
                val result=WallkerAPI.post("/api/device/pair",JSONObject().put("code",value).put("platform","android").put("expectedAccountId",accountId),previousToken)
                require(result.getString("accountId")==accountId){"Аккаунт изменился. Повтори привязку."}
                val reset=!first && !same
                if(reset){store.setEnabled(false);stopService(Intent(this@MainActivity,StepService::class.java))}
                vault.save(result.getString("token"),result.getString("timezone"),accountId)
                store.mergeHistory(result.getJSONArray("history"),reset);code.setText("")
                store.setSyncStatus(if(reset)"Аккаунт сменён. История нового кошелька загружена." else "Привязка обновлена. Местные шаги сохранены.")
                StepSyncWorker.now(this@MainActivity)
            }catch(e:Exception){store.setStatus(e.message ?: "Не удалось привязать телефон")}
            finally{busy=false;refresh()}
        }
    }
}

// Decorative activity ring: it does not imply a daily goal or WC reward.
private class StepRing(context:android.content.Context):View(context){
    var active=false
        set(value){if(field!=value){field=value;invalidate()}}
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas)
        val stroke=10*resources.displayMetrics.density;paint.strokeWidth=stroke
        val diameter=minOf(width,height)-stroke*3
        val left=(width-diameter)/2;val top=(height-diameter)/2
        val bounds=RectF(left,top,left+diameter,top+diameter)
        paint.color=Color.parseColor("#333e2c");canvas.drawOval(bounds,paint)
        paint.color=Color.parseColor(if(active)"#bdff58" else "#526348")
        canvas.drawArc(bounds,-90f,if(active)280f else 45f,false,paint)
    }
}
