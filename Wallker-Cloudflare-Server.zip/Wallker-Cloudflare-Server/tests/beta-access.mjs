import assert from 'node:assert/strict';
import {createHmac,createHash} from 'node:crypto';
import {Miniflare} from 'miniflare';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),token='123:BETA_LOCAL_ONLY';
const bindings={TELEGRAM_BOT_TOKEN:token,ADMIN_TELEGRAM_ID:'1001',BETA_GATE_ENABLED:'true',TELEGRAM_WEBHOOK_SECRET:'beta-local-secret'};
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings});
function auth(id,start){const p=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Beta tester',username:'tester_'+id})});if(start)p.set('start_param',start);const key=createHmac('sha256','WebAppData').update(token).digest();p.set('hash',createHmac('sha256',key).update([...p].sort(([a],[b])=>a<b?-1:1).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return p.toString()}
async function api(path,id=1002,data,extra={}){const r=await mf.dispatchFetch('http://localhost'+path,{method:data===undefined?'GET':'POST',headers:{...(id?{'X-Telegram-Init-Data':auth(id,extra.start)}:{}),'Content-Type':'application/json',...extra.headers},...(data===undefined?{}:{body:JSON.stringify(data)})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const sql of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(sql).run();
 assert.equal((await api('/api/beta',null)).status,401);
 let status=await api('/api/beta');assert.equal(status.status,200);assert.equal(status.value.allowed,false);assert.equal(status.value.status,'none');assert.equal(status.value.telegramId,'1002');assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM users').first()).n,0);
 for(const [path,data] of [['/api/wallet',undefined],['/api/tap',{count:1,requestId:'beta_bypass_tap_0001'}],['/api/friends',undefined],['/api/clans',undefined],['/api/growth',undefined],['/api/levels',undefined],['/api/campaigns',undefined],['/api/shop',undefined],['/api/shop/invoice',{}],['/api/admin/beta',undefined]]){const r=await api(path,1002,data);assert.equal(r.status,403,path);assert.equal(r.value.code,'BETA_ACCESS_REQUIRED',path);assert.ok(!('balance' in r.value),path);}
 const applications=await Promise.all(Array.from({length:3},()=>api('/api/beta',1002,{action:'apply',userId:'tg:1001',status:'approved'})));assert.ok(applications.every(r=>r.status===200&&r.value.status==='pending'&&!r.value.allowed));
 let row=await db.prepare('SELECT * FROM beta_access WHERE user_id=?').bind('tg:1002').first();assert.equal(row.revision,1);const requested=row.requested;
 assert.equal((await api('/api/beta',1002,{action:'approve'})).status,405);
 assert.equal((await api('/api/beta',1001)).value.allowed,true);assert.equal((await api('/api/wallet',1001)).status,200);
 let inbox=await api('/api/admin/beta',1001);assert.equal(inbox.value.counts.pending,1);assert.equal(inbox.value.rows[0].user_id,'tg:1002');
 assert.equal((await api('/api/admin/beta',1001,{action:'approve',userId:'1002',revision:1})).status,200);
 assert.equal((await api('/api/beta')).value.allowed,true);assert.equal((await api('/api/wallet')).status,200);
 assert.equal((await api('/api/admin/beta',1002,{action:'approve',userId:'1003',revision:0})).status,403);
 assert.equal((await api('/api/admin/beta',1001,{action:'revoke',userId:'1002',revision:1})).status,409);
 const pair=(await api('/api/wallet',1002,{action:'pair'})).value.code;
 const paired=await api('/api/device/pair',null,{code:pair,platform:'ios'});assert.equal(paired.status,200);const device=paired.value.token;
 const unusedPair=(await api('/api/wallet',1002,{action:'pair'})).value.code;
 const before=(await api('/api/wallet')).value.balance;
 assert.equal((await api('/api/admin/beta',1001,{action:'revoke',userId:'1002',revision:2})).status,200);
 for(const [path,data] of [['/api/device/state',undefined],['/api/device/steps',{day:new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow'}).format(new Date()),steps:1000}],['/api/device/pair',{code:unusedPair,platform:'ios',checkOnly:true}]]){const r=await api(path,null,data,{headers:{Authorization:'Bearer '+device}});assert.equal(r.status,403,path);assert.equal(r.value.code,'BETA_ACCESS_REQUIRED');}
 assert.equal((await api('/api/wallet')).status,403);
 assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM pairings WHERE device_hash IS NOT NULL').first()).n,1);
 assert.equal((await api('/api/beta',1002,{action:'apply'})).value.status,'revoked');assert.equal((await db.prepare('SELECT requested FROM beta_access WHERE user_id=?').bind('tg:1002').first()).requested,requested);
 assert.equal((await api('/api/admin/beta',1001,{action:'approve',userId:'@tester_1002',revision:3})).status,200);assert.equal((await api('/api/wallet')).value.balance,before);
 assert.equal((await api('/api/admin/beta',1001,{action:'approve',userId:'1004',revision:0})).status,200);assert.equal((await api('/api/beta',1004)).value.allowed,true);assert.equal((await api('/api/wallet',1004)).status,200);
 assert.equal((await api('/api/admin/beta',1001,{action:'revoke',userId:'1001',revision:0})).status,400);
 await api('/api/beta',1005,{action:'apply'});assert.equal((await api('/api/admin/beta',1001,{action:'reject',userId:'1005',revision:1})).status,200);assert.equal((await api('/api/beta',1005)).value.status,'rejected');assert.equal((await api('/api/beta',1005,{action:'apply'})).value.status,'rejected');
 const races=await Promise.all([api('/api/admin/beta',1001,{action:'approve',userId:'1005',revision:2}),api('/api/admin/beta',1001,{action:'reject',userId:'1005',revision:2})]);assert.deepEqual(races.map(r=>r.status).sort(),[200,409]);
 // A marketing referral is remembered while waiting, but does not count as a player yet.
 const code=(await api('/api/friends',1001)).value.code;
 const webhook={message:{message_id:99,chat:{id:1010,type:'private'},from:{id:1010,first_name:'Marketing'},text:'/start ref_'+code}};
 const bot=await api('/api/telegram/webhook',null,webhook,{headers:{'X-Telegram-Bot-Api-Secret-Token':'beta-local-secret'}});assert.equal(bot.status,200);assert.match(bot.value.caption,/launching soon/);assert.ok(bot.value.reply_markup.inline_keyboard[0][0].web_app);
 assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM referrals WHERE invitee=?').bind('tg:1010').first()).n,0);
 await api('/api/beta',1010);await api('/api/admin/beta',1001,{action:'approve',userId:'1010',revision:0});await api('/api/wallet',1010);assert.equal((await db.prepare('SELECT inviter FROM referrals WHERE invitee=?').bind('tg:1010').first()).inviter,'tg:1001');
 assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM beta_access_audit').first()).n,7);
 assert.equal((await mf.dispatchFetch('http://localhost/growth-preview')).status,404);
 assert.equal((await api('/api/admin/beta?status=all&q=1004',1001)).value.lookup[0].user_id,'tg:1004');
 console.log('PASS: signed beta applications, admin bypass, manual grants, approval/rejection/revocation, optimistic race protection, device gates, no preapproval game data or minting, persistent state/audit and delayed referral attribution.');
}finally{await mf.dispose()}
