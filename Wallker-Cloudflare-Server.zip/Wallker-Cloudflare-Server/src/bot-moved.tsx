import {LanguageSelect,useLanguage} from './language';
import {ArrowUpRight,ShieldCheck} from 'lucide-react';
import './bot-moved.css';
export type BotDestination={username:string,link:string};
export function BotMoved({bot}:{bot:BotDestination}){
 const {language}=useLanguage(),en=language==='en';
 return <section className="bot-moved" aria-labelledby="bot-moved-title">
  <div className="bot-moved-top"><strong>Walker Wallet</strong><LanguageSelect/></div>
  <div className="bot-moved-card">
   <img src="/wolf-walk-1.jpg" alt={en?'Walker is ready for the next step':'Волкер готов к новому шагу'}/>
   <p className="eyebrow">{en?'OUR NEW HOME':'НАШ НОВЫЙ ДОМ'}</p>
   <h1 id="bot-moved-title">{en?'Walker has moved':'Walker переехал'}</h1>
   <p>{en?'Continue in our new bot using the same Telegram account.':'Продолжай в новом боте с того же Telegram-аккаунта.'}</p>
   <a className="button primary" href={bot.link} target="_top" onClick={e=>{const tg=window.Telegram?.WebApp;if(tg?.openTelegramLink){e.preventDefault();tg.openTelegramLink(bot.link)}}}>{en?'Open the new Walker':'Открыть нового Walker'}<ArrowUpRight size={20}/></a>
   <span className="bot-moved-handle">@{bot.username}</span>
   <div className="bot-moved-saved"><ShieldCheck size={21}/><p>{en?'Your balance, level and progress are saved. Your step counter stays connected.':'Баланс, уровень и прогресс сохранены. Шагомер остаётся подключённым.'}</p></div>
  </div>
 </section>;
}
