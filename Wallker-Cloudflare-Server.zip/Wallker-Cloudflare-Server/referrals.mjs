import {growthSettings,totalInvited,multiplier,BOOST_SOURCES} from './growth-config.mjs';
import {memo} from './runtime.mjs';
import {botUsername} from './bot-config.mjs';
import {ensureCampaigns} from './campaigns.mjs';
export async function ensureReferrals(db){if(db.schemaReady)return;await ensureCampaigns(db);await db.batch([
 db.prepare('CREATE TABLE IF NOT EXISTS referrals(invitee TEXT PRIMARY KEY,inviter TEXT NOT NULL,created INTEGER NOT NULL,host_reward INTEGER NOT NULL DEFAULT 500,welcome_reward INTEGER NOT NULL DEFAULT 100)'),
 db.prepare('CREATE INDEX IF NOT EXISTS referrals_inviter ON referrals(inviter)'),
 db.prepare('CREATE TABLE IF NOT EXISTS referral_qualified(invitee TEXT PRIMARY KEY,inviter TEXT NOT NULL,qualified INTEGER NOT NULL)'),
 db.prepare('CREATE INDEX IF NOT EXISTS referral_qualified_inviter ON referral_qualified(inviter)'),
 db.prepare("INSERT OR IGNORE INTO referral_qualified(invitee,inviter,qualified) SELECT r.invitee,r.inviter,COALESCE(c.reviewed,c.created) FROM referrals r JOIN campaign_claims c ON c.campaign_id='referral:'||r.invitee||':host' AND c.state='approved'")]);}
// The only inputs accepted here come from signed initData or the secret-protected bot webhook.
export async function attributeReferral(db,id,param,now=Date.now(),firstOpen=false){
 await ensureReferrals(db);
 let inviter=null;
 if(typeof param==='string'&&/^ref_[a-f0-9]{20}$/.test(param))inviter=(await db.prepare('SELECT user_id FROM friend_codes WHERE code=?').bind(param.slice(4)).first())?.user_id||null;
 if(typeof param==='string'&&/^c_[A-Z][A-Z0-9_]{4,23}$/.test(param))inviter=(await db.prepare('SELECT user_id FROM growth_creator_codes WHERE code=?').bind(param.slice(2)).first())?.user_id||null;
 if(inviter===id)inviter=null;
 if(firstOpen){
  const receipt=crypto.randomUUID();
  await db.batch([
   db.prepare('INSERT OR IGNORE INTO growth_onboarding(user_id,first_open,receipt) VALUES(?,?,?)').bind(id,now,receipt),
   db.prepare(`INSERT OR IGNORE INTO referrals(invitee,inviter,created) SELECT ?,?,? WHERE ? IS NOT NULL AND EXISTS(SELECT 1 FROM growth_onboarding WHERE user_id=? AND receipt=?) AND EXISTS(SELECT 1 FROM users u WHERE u.id=? AND u.created>=(SELECT started FROM growth_meta WHERE id=1))`).bind(id,inviter,now,inviter,id,receipt,id)
  ]);
 }else if(inviter){
  await db.prepare('INSERT OR IGNORE INTO referrals(invitee,inviter,created) SELECT ?,?,? WHERE NOT EXISTS(SELECT 1 FROM users WHERE id=?) AND NOT EXISTS(SELECT 1 FROM growth_onboarding WHERE user_id=?)').bind(id,inviter,now,id,id).run();
 }
}
export async function settleReferrals(db,id,now=Date.now()){
 await ensureReferrals(db);
 await db.prepare(`INSERT OR IGNORE INTO referral_qualified(invitee,inviter,qualified) SELECT invitee,inviter,? FROM referrals r WHERE (inviter=? OR invitee=?) AND EXISTS(SELECT 1 FROM users WHERE id=r.invitee) AND NOT EXISTS(SELECT 1 FROM abuse_controls WHERE user_id=r.invitee AND frozen=1)`).bind(now,id,id).run();
}
export async function referralBoost(db,id){return memo(db,'referral:'+id,async()=>{
 await settleReferrals(db,id);
 const n=await totalInvited(db,id),config=await growthSettings(db),boost=multiplier(n,config);
 return {qualified:n,multiplier:boost,percent:Math.round((boost-1)*1000000)/10000};
 });}
// All earned-reward callers must supply a server-owned source. Financial flows
// are excluded even if a future caller accidentally asks for their boost.
export async function referralRewardBoost(db,id,source){
 if(!BOOST_SOURCES.includes(source))return {qualified:0,multiplier:1,percent:0};
 return referralBoost(db,id);
}
export async function referralSnapshot(db,id,code,env={}){
 const boost=await referralBoost(db,id);
 const {invited}=await db.prepare('SELECT COUNT(*) AS invited FROM referrals WHERE inviter=?').bind(id).first();
 return {...boost,invited,minSteps:0,minDays:0,link:`https://t.me/${botUsername(env)}?start=ref_${code}`};
}
