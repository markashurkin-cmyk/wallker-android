import {createContext,createElement,useContext,useState,ReactNode} from 'react';
import {english} from './translations';
export type Language='ru'|'en';
let active:Language='ru';
const Context=createContext<{language:Language,setLanguage:(v:Language)=>void}>({language:'ru',setLanguage:()=>{}});
export const getLanguage=()=>active;
export const getLocale=()=>active==='en'?'en-US':'ru-RU';
const patterns:[RegExp,(...args:string[])=>string][]=[
 [/^Ещё (.+) шагов до уровня (.+)$/,(n,level)=>`${n} steps to level ${level}`],
 [/^За тап \+(.+) WC$/,(n)=>`Per tap +${n} WC`],
 [/^Энергия: \+1 за (.+) сек\.$/,(n)=>`Energy: +1 every ${n} sec.`],
 [/^(.+) дней · без автопродления$/,(n)=>`${n} days · no auto-renewal`],
 [/^УРОВЕНЬ (.+)$/,(n)=>`LEVEL ${n}`],
 [/^(.+) шагов суммарно$/,(n)=>`${n} total steps`],
 [/^\+(.+) WC один раз$/,(n)=>`+${n} WC once`],
 [/^Получить (.+) WC$/,(n)=>`Claim ${n} WC`],
 [/^Уровень (.+): (.+)$/,(n,name)=>`Level ${n}: ${english[name]||name}`],
 [/^Открыть уровни\. (.+)$/,(name)=>`Open levels. ${english[name]||name}`],
 [/^Волкер уровня (.+)$/,(n)=>`Walker level ${n}`],
 [/^Выдано (.+) WC: (.+)\.$/,(n,name)=>`Granted ${n} WC: ${name}.`],
 [/^Партнёр · (.+)$/,(name)=>`Partner · ${name}`],
 [/^Скачиваем: (.+) · (.+) записей$/,(dataset,n)=>`Downloading: ${dataset} · ${n} records`],
 [/^(.+)% · (.+) из (.+)$/,(percent,n,total)=>`${percent}% · ${n} of ${total}`]
];
export function translate(text:string){if(active==='ru'||!/[а-яё]/i.test(text))return text;const value=english[text];if(value!==undefined)return value;const trimmed=text.trim();if(english[trimmed]!==undefined)return text.replace(trimmed,english[trimmed]);for(const [pattern,render]of patterns){const match=trimmed.match(pattern);if(match)return render(...match.slice(1))}for(const [key,value]of Object.entries(english)){if(key.endsWith(' ')&&key.trim().length>3&&text.startsWith(key))return value+translate(text.slice(key.length));if(key.startsWith(' ')&&key.trim().length>3&&text.endsWith(key))return translate(text.slice(0,-key.length))+value}return text;}
export function localizedError(text:string,status=0){const converted=translate(text);if(active!=='en'||!/[а-яё]/i.test(converted))return converted;return status===401?'Open Walker again through Telegram.':status===403?'This action is not available for your account.':status===429?'Too many requests. Please wait a minute.':status===409?'The data changed or this action is already complete. Refresh and try again.':status===423?'Rewards are suspended. Please contact support.':'Could not complete the request. Check your input or contact support.';}

export function LanguageProvider({children}:{children:ReactNode}){
 const [language,set]=useState<Language>(()=>{try{const saved=localStorage.getItem('walker-language');if(saved==='ru'||saved==='en')return saved}catch{};const code=(window.Telegram?.WebApp as any)?.initDataUnsafe?.user?.language_code||navigator.language;return code.startsWith('ru')?'ru':'en'});
 active=language;document.documentElement.lang=language;
 function setLanguage(v:Language){set(v);try{localStorage.setItem('walker-language',v)}catch{}}
 return createElement(Context.Provider,{value:{language,setLanguage}},children);
}
export function useLanguage(){return useContext(Context)}
export function LanguageSelect(){const {language,setLanguage}=useLanguage();return <label className="language-select"><span className="sr-only">Language / Язык</span><select aria-label="Language / Язык" value={language} onChange={e=>setLanguage(e.target.value as Language)}><option value="ru">RU</option><option value="en">EN</option></select></label>}
