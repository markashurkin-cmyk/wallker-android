// Stable server asset keys: changing an outfit never changes earned entitlements.
const outfits:Record<string,string>={
 recruiter:'/wolf-level-1.png',
 'pack-frame':'/wolf-level-2.png',
 'alpha-outfit':'/growth/alpha-outfit.webp',
 'leader-badge':'/growth/leader-badge.webp',
 'creator-wolf':'/growth/creator-wolf.webp',
 'pro-frame':'/growth/pro-frame.webp',
 'influencer-skin':'/growth/influencer-skin.webp',
 'wolf-influencer':'/growth/wolf-influencer.webp',
 'ambassador-profile':'/growth/ambassador-profile.webp',
 'legend-badge':'/growth/legend-badge.webp'
};
// Owner-defined keys get a safe local fallback, never a constructed remote URL.
export const milestoneArt=(key?:string)=>outfits[key||'']||outfits.recruiter;
