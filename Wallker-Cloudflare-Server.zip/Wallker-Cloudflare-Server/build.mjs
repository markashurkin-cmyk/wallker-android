import {build} from 'esbuild';
import {mkdir, copyFile} from 'node:fs/promises';
await mkdir('public', {recursive:true});
await build({entryPoints:['src/main.tsx'], outdir:'public', entryNames:'app', bundle:true, minify:true, format:'esm', target:'es2022', jsx:'automatic', legalComments:'eof'});
await copyFile('src/index.html', 'public/index.html');

await copyFile('assets/volker.png', 'public/volker.png');

await copyFile('assets/bot-avatar.jpg', 'public/bot-avatar.jpg');

for(const i of [1,2]) await copyFile(`assets/wolf-walk-${i}.jpg`, `public/wolf-walk-${i}.jpg`);

await copyFile('assets/wolf-levels.png','public/wolf-levels.png');

await copyFile('assets/volker-vk-steps.png','public/volker-vk-steps.png');
