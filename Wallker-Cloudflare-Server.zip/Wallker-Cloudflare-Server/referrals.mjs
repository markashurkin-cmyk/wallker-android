import {memo} from './runtime.mjs';
import {botUsername} from './bot-config.mjs';
import {ensureCampaigns} from './campaigns.mjs';
export async function ensureReferrals(db){if(db.schemaReady)return;await ensureCampaigns(db);await db.batch([
 db.prepare('CREATE TABLE IF NOT EXISTS referrals(invitee TEXT PRIMARY KEY,inviter TEXT NOT NULL,created INTEGER NOT NULL,host_reward INTEGER NOT NULL DEFAULT 500,welcome_reward INTEGER NOT NULL DEFAULT 100)'),
 db.prepare('CREATE INDEX IF NOT EXISTS referrals_inviter ON referrals(inviter)'),
 db.prepare('CREATE TABLE IF NOT EXISTS referral_qualified(invitee TEXT PRIMARY KEY,inviter TEXT NOT NULL,qualified INTEGER NOT NULL)'),
 db.prepare('CREATE INDEX IF NOT EXISTS referral_qualified_inviter ON referral_qualified(inviter)'),
 db.prepare("INSERT OR IGNORE INTO referral_qualified(invitee,inviter,qualified) SELECT r.invitee,r.inviter,COALESCE(c.reviewed,c.created) FROM referrals r JOIN campaign_claims c ON c.campaign_id='referral:'||r.invitee||':host' AND c.state='approved'")]);}
// The only inputs accepted here come from signed initData or the secret-protected bot webhook.
export async function attributeReferral(db,id,param,now=Date.now()){
 if(typeof param!=='string'||!/^ref_[a-f0-9]{20}$/.test(param))return;
 await ensureReferrals(db);
 await db.prepare(`INSERT OR IGNORE INTO referrals(invitee,inviter,created) SELECT ?,user_id,? FROM friend_codes WHERE code=? AND user_id<>? AND NOT EXISTS(SELECT 1 FROM users WHERE id=? AND (created<? OR EXISTS(SELECT 1 FROM days WHERE user_id=? AND steps>0) OR EXISTS(SELECT 1 FROM tap_state WHERE user_id=? AND total>0)))`).bind(id,now,param.slice(4),id,id,now-300000,id,id).run();
}
export async function settleReferrals(db,id,now=Date.now()){
 await ensureReferrals(db);
 await db.prepare(`INSERT OR IGNORE INTO referral_qualified(invitee,inviter,qualified) SELECT invitee,inviter,? FROM referrals r WHERE (inviter=? OR invitee=?) AND EXISTS(SELECT 1 FROM users WHERE id=r.invitee) AND NOT EXISTS(SELECT 1 FROM abuse_controls WHERE user_id=r.invitee AND frozen=1)`).bind(now,id,id).run();
}
export async function referralBoost(db,id){return memo(db,'referral:'+id,async()=>{
 await settleReferrals(db,id);
 const {n}=await db.prepare('SELECT COUNT(*) AS n FROM referral_qualified WHERE inviter=?').bind(id).first();
 return {qualified:n,multiplier:(100+n)/100,percent:n};
 });}
export async function referralSnapshot(db,id,code,env={}){
 const boost=await referralBoost(db,id);
 const {invited}=await db.prepare('SELECT COUNT(*) AS invited FROM referrals WHERE inviter=?').bind(id).first();
 return {...boost,invited,minSteps:0,minDays:0,link:`https://t.me/${botUsername(env)}?start=ref_${code}`};
}
