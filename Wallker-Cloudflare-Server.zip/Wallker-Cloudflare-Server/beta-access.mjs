import {isAdmin} from './campaigns.mjs';
import {limit} from './security.mjs';
export const BETA_DDL=[
 "CREATE TABLE IF NOT EXISTS beta_access(user_id TEXT PRIMARY KEY,name TEXT NOT NULL DEFAULT '',username TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'none' CHECK(status IN ('none','pending','approved','rejected','revoked')),requested INTEGER,updated INTEGER NOT NULL,reviewer TEXT NOT NULL DEFAULT '',revision INTEGER NOT NULL DEFAULT 0,start_param TEXT NOT NULL DEFAULT '',last_action TEXT NOT NULL DEFAULT '')",
 "CREATE INDEX IF NOT EXISTS beta_access_username ON beta_access(username COLLATE NOCASE)",
 "CREATE INDEX IF NOT EXISTS beta_access_status ON beta_access(status,requested,user_id)",
 "CREATE TABLE IF NOT EXISTS beta_access_audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,revision INTEGER NOT NULL,created INTEGER NOT NULL)"
];
export const betaClosed=env=>env.BETA_GATE_ENABLED==='true';
export class BetaError extends Error {constructor(message,status=400,access){super(message);this.status=status;this.access=access;}}
export async function betaStatus(db,user,env){
 const row=await db.prepare('SELECT status,requested,revision FROM beta_access WHERE user_id=?').bind(user.id).first();
 return {required:betaClosed(env),allowed:!betaClosed(env)||isAdmin(user,env)||row?.status==='approved',status:row?.status||'none',telegramId:user.id.slice(3),requestedAt:row?.requested||null,revision:row?.revision||0};
}
export async function requireBeta(db,user,env){if(!betaClosed(env)||isAdmin(user,env))return;const access=await betaStatus(db,user,env);if(!access.allowed)throw new BetaError('Запуск Walker уже скоро. Подай заявку на бета-тест.',403,access);}
export async function betaVisit(db,user){
 const param=typeof user.startParam==='string'&&/^(?:ref_[a-f0-9]{20}|c_[A-Z][A-Z0-9_]{4,23})$/.test(user.startParam)?user.startParam:'';
 await db.prepare("INSERT INTO beta_access(user_id,name,username,updated,start_param) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET name=excluded.name,username=excluded.username,start_param=CASE WHEN beta_access.start_param='' THEN excluded.start_param ELSE beta_access.start_param END").bind(user.id,user.name||'',user.username||'',Date.now(),param).run();
}
export async function betaApply(db,user,env){
 await limit(db,'beta-apply:'+user.id,5);await betaVisit(db,user);
 await db.prepare("UPDATE beta_access SET status='pending',requested=?,updated=?,revision=revision+1 WHERE user_id=? AND status='none'").bind(Date.now(),Date.now(),user.id).run();
 return betaStatus(db,user,env);
}
export async function betaAdmin(db,actor,env,url,method,data){
 if(!isAdmin(actor,env))throw new BetaError('Только для владельца',403);
 if(method==='POST'){
  if(!['approve','reject','revoke'].includes(data.action))throw new BetaError('Выбери действие с доступом');
  let target=String(data.userId||'').trim();
  if(/^@[a-zA-Z0-9_]{5,32}$/.test(target)){
   const rows=(await db.prepare("SELECT user_id FROM beta_access WHERE username=? COLLATE NOCASE LIMIT 2").bind(target.slice(1)).all()).results;
   if(rows.length!==1)throw new BetaError('Укажи Telegram ID или попроси человека сначала подать заявку');target=rows[0].user_id;
  }else target='tg:'+target.replace(/^tg:/,'');
  if(!/^tg:[1-9][0-9]{0,15}$/.test(target)||!Number.isSafeInteger(Number(target.slice(3))))throw new BetaError('Укажи корректный Telegram ID');
  if(isAdmin({id:target},env)&&data.action!=='approve')throw new BetaError('Аккаунт разработчика всегда имеет доступ');
  const revision=Number(data.revision);if(!Number.isSafeInteger(revision)||revision<0)throw new BetaError('Обнови список заявок',409);
  const existing=await db.prepare('SELECT revision FROM beta_access WHERE user_id=?').bind(target).first();
  if(!existing&&(data.action!=='approve'||revision!==0))throw new BetaError('Заявка не найдена',404);
  const status={approve:'approved',reject:'rejected',revoke:'revoked'}[data.action],now=Date.now(),marker=crypto.randomUUID();
  const results=await db.batch([
   db.prepare("INSERT INTO beta_access(user_id,status,updated,reviewer,revision,last_action) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET status=excluded.status,updated=excluded.updated,reviewer=excluded.reviewer,revision=beta_access.revision+1,last_action=excluded.last_action WHERE beta_access.revision=?").bind(target,status,now,actor.id,revision+1,marker,revision),
   db.prepare('INSERT INTO beta_access_audit(id,user_id,actor,action,revision,created) SELECT ?,user_id,?,?,revision,? FROM beta_access WHERE user_id=? AND last_action=?').bind(marker,actor.id,data.action,now,target,marker)
  ]);
  if(!results[0].meta.changes)throw new BetaError('Доступ уже изменился. Обнови список.',409);
  return {ok:true,userId:target,status};
 }
 if(method!=='GET')throw new BetaError('Метод не поддерживается',405);
 const filter=url.searchParams.get('status')||'pending';if(!['pending','approved','rejected','revoked','all'].includes(filter))throw new BetaError('Выбери статус заявок');
 const page=Math.max(1,Math.min(100000,Number(url.searchParams.get('page'))||1));
 const query=String(url.searchParams.get('q')||'').trim().slice(0,64);
 const where="status<>'none' AND (?='all' OR status=?) AND (?='' OR user_id=? OR username=? COLLATE NOCASE)";
 const args=[filter,filter,query,'tg:'+query.replace(/^tg:/,''),query.replace(/^@/,'')];
 const rows=(await db.prepare(`SELECT user_id,name,username,status,requested,updated,revision FROM beta_access WHERE ${where} ORDER BY COALESCE(requested,updated) DESC,user_id LIMIT 31 OFFSET ?`).bind(...args,(Math.floor(page)-1)*30).all()).results;
 const counts=(await db.prepare("SELECT status,COUNT(*) AS n FROM beta_access WHERE status<>'none' GROUP BY status").all()).results;
 // An exact ID lookup also permits editing a manual grant outside the current filter.
 const lookup=query?(await db.prepare('SELECT user_id,name,username,status,requested,updated,revision FROM beta_access WHERE user_id=? OR username=? COLLATE NOCASE LIMIT 2').bind('tg:'+query.replace(/^tg:/,''),query.replace(/^@/,'')).all()).results:[];
 return {closed:betaClosed(env),rows:rows.slice(0,30),hasNext:rows.length>30,page:Math.floor(page),counts:Object.fromEntries(counts.map(r=>[r.status,r.n])),lookup};
}
