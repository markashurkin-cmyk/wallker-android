// Localize application-owned labels at the React JSX boundary, never DOM text or input values.
import {jsx as reactJSX,jsxs as reactJSXs,Fragment} from 'react/jsx-runtime';
import {createElement} from 'react';
import {translate,useLanguage} from '../language';
const wrappers=new WeakMap<Function,Function>();
function child(value:any):any{return typeof value==='string'?translate(value):Array.isArray(value)?value.map(child):value}
function localized(runtime:any,type:any,props:any,key?:any){
 if(typeof type==='function'){
  let wrapper=wrappers.get(type);if(!wrapper){wrapper=function LocalizedComponent(p:any){useLanguage();return createElement(type,p)};wrappers.set(type,wrapper)}
  return runtime(wrapper,props,key);
 }
 if(typeof type==='string'&&props&&!props['data-user-content']){
  const copy={...props};if(props.children!==undefined&&type!=='textarea')copy.children=child(props.children);
  for(const name of ['alt','title','placeholder','aria-label'])if(typeof copy[name]==='string')copy[name]=translate(copy[name]);
  return runtime(type,copy,key);
 }
 return runtime(type,props,key);
}
export const jsx=(type:any,props:any,key?:any)=>localized(reactJSX,type,props,key);
export const jsxs=(type:any,props:any,key?:any)=>localized(reactJSXs,type,props,key);
export {Fragment};
