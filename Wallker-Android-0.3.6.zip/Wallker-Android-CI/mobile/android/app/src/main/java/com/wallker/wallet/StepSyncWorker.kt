package com.wallker.wallet

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class ApiFailure(val status:Int,message:String):Exception(message)
object WallkerAPI {
    suspend fun post(path:String,data:JSONObject,token:String?=null):JSONObject=withContext(Dispatchers.IO){
        val connection=URL("https://wallker-wallet.markashurkin.workers.dev"+path).openConnection() as HttpURLConnection
        try {
            connection.requestMethod="POST";connection.connectTimeout=15000;connection.readTimeout=15000;connection.doOutput=true
            connection.instanceFollowRedirects=false
            connection.setRequestProperty("Content-Type","application/json")
            if(token!=null)connection.setRequestProperty("Authorization","Bearer $token")
            connection.outputStream.use{it.write(data.toString().toByteArray(Charsets.UTF_8))}
            val status=connection.responseCode
            val raw=(if(status in 200..299)connection.inputStream else connection.errorStream)?.bufferedReader(Charsets.UTF_8)?.use{it.readText().take(8192)} ?: ""
            val result=try{JSONObject(raw)}catch(_:Exception){val cloudflare1010=raw.lowercase().contains("error code: 1010")
                val detail=when {
                    cloudflare1010 -> "Защита хостинга отклонила запрос: HTTP $status, Cloudflare 1010. Передай это сообщение разработчику."
                    status in 300..399 -> "Сервер перенаправляет запрос привязки (HTTP $status). Передай это сообщение разработчику."
                    status==403 -> "Доступ к серверу запрещён (HTTP 403, ответ не JSON). Передай это сообщение разработчику."
                    else -> "Некорректный ответ сервера (HTTP $status, ответ не JSON). Передай это сообщение разработчику."
                }
                throw ApiFailure(status,detail)}
            if(status !in 200..299)throw ApiFailure(status,result.optString("error","Ошибка сервера"))
            result
        }finally{connection.disconnect()}
    }
}
class StepSyncWorker(context:Context,parameters:WorkerParameters):CoroutineWorker(context,parameters){
    override suspend fun doWork():Result {
        val vault=DeviceVault(applicationContext);val token=vault.token() ?: return Result.success()
        val store=StepStore(applicationContext);val pending=store.pending()
        return try{
            for((day,count) in pending.days){
                if(vault.token()!=token)return Result.success()
                WallkerAPI.post("/api/device/steps",JSONObject().put("day",day).put("steps",count),token)
                store.acknowledge(pending.generation,day,count)
            }
            store.setSyncStatus("Шаги переданы. Обнови баланс в Telegram.");Result.success()
        }catch(e:ApiFailure){
            store.setSyncStatus(if(e.status==401)"Привязка отозвана. Подключи Telegram заново." else "Шаги сохранены. Передача повторится позже.")
            if(e.status in 400..499 && e.status!=429)Result.failure() else Result.retry()
        }catch(_:Exception){store.setSyncStatus("Нет связи. Шаги сохранены на телефоне.");Result.retry()}
    }
    companion object {
        private fun constraints()=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        fun schedule(context:Context){
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("wallker-step-sync",ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<StepSyncWorker>(15,TimeUnit.MINUTES).setConstraints(constraints()).build())
        }
        fun now(context:Context){
            WorkManager.getInstance(context).enqueueUniqueWork("wallker-step-sync-now",ExistingWorkPolicy.KEEP,
                OneTimeWorkRequestBuilder<StepSyncWorker>().setConstraints(constraints()).build())
        }
    }
}
