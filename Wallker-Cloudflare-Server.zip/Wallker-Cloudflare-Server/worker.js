import {rewardSettings,saveRewardSettings,ensureStepRewards,stepRewardStatements} from './rewards.mjs';
import {TapError,tapSnapshot,earnTaps} from './taps.mjs';
import {CampaignError,isAdmin,campaignSnapshot,bonusBalance,campaignRoute} from './campaigns.mjs';
const encoder = new TextEncoder();
class ApiError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const hex = bytes => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
const digest = async value => hex(await crypto.subtle.digest('SHA-256', encoder.encode(value)));
const randomToken = () => hex(crypto.getRandomValues(new Uint8Array(24)));
const APP_ORIGIN = 'https://wallker-wallet.markashurkin.workers.dev';
function sameURL(actual, expected) {
  try {
    if(typeof actual !== 'string') return false;
    // URL canonicalisation handles an implicit root slash and host casing,
    // while preserving the full path, query, fragment and credentials.
    return new URL(actual).href === new URL(expected).href;
  } catch { return false; }
}
export class TelegramSetupError extends Error {
  constructor(code, reason) { super('Telegram setup failed'); this.code=code; this.reason=reason; }
}
function safeTelegramReason(code, description) {
  const text=String(description || '').toLowerCase();
  if(code===401) return 'bot_token_rejected';
  if(code===429) return 'telegram_rate_limit';
  if(text.includes('secret token')) return 'webhook_secret_invalid';
  if(text.includes('resolve host') || text.includes('ip address')) return 'webhook_address_unreachable';
  if(text.includes('certificate') || text.includes('ssl')) return 'webhook_certificate_rejected';
  if(text.includes('url')) return 'telegram_url_rejected';
  return 'telegram_rejected_request';
}
async function webhookSecret(env) {
  return env.TELEGRAM_WEBHOOK_SECRET || hex(await hmac(encoder.encode(env.TELEGRAM_BOT_TOKEN || ''), `wallker-webhook:${APP_ORIGIN}`));
}
async function telegramCall(env, method, data) {
  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data), signal:AbortSignal.timeout(10000)
  });
  const result = await response.json();
  if (!response.ok || result.ok !== true) {
    const code=Number.isInteger(result.error_code) ? result.error_code : response.status;
    throw new TelegramSetupError(code,safeTelegramReason(code,result.description));
  }
  return result.result;
}
// Deployment-owned configuration only: the caller cannot choose a bot, URL or secret.
// A D1 lease prevents concurrent health checks from repeatedly configuring Telegram.
export async function configureBot(env, call = telegramCall) {
  if (env.BOT_AUTO_SETUP !== 'true' || !env.TELEGRAM_BOT_TOKEN) return 'disabled';
  const db=database(env), secret=await webhookSecret(env);
  const key=await digest(`${env.TELEGRAM_BOT_TOKEN}:${secret}:${APP_ORIGIN}:v2`);
  await db.prepare('CREATE TABLE IF NOT EXISTS bot_setup (id TEXT PRIMARY KEY, config_hash TEXT, ready INTEGER NOT NULL DEFAULT 0, lease_until INTEGER NOT NULL DEFAULT 0)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS bot_setup_errors (id TEXT PRIMARY KEY, stage TEXT, code INTEGER, reason TEXT, at INTEGER)').run();
  await db.prepare("INSERT OR IGNORE INTO bot_setup(id) VALUES('telegram')").run();
  const current=await db.prepare("SELECT config_hash,ready FROM bot_setup WHERE id='telegram'").first();
  if(current.config_hash===key && current.ready===1) return 'ready';
  const lease=await db.prepare("UPDATE bot_setup SET lease_until=? WHERE id='telegram' AND lease_until<=? RETURNING id").bind(Date.now()+60000,Date.now()).first();
  if(!lease) return current.ready===-1 ? 'configuration_failed' : 'pending';
  await db.prepare("UPDATE bot_setup SET config_hash=?,ready=0 WHERE id='telegram'").bind(key).run();
  let stage='getMe';
  try {
    const bot=await call(env,'getMe',{});
    if(bot?.username!=='wallker_wallet_bot') throw new TelegramSetupError(0,'bot_identity_mismatch');
    stage='setWebhook';
    const webhookURL=APP_ORIGIN+'/api/telegram/webhook';
    await call(env,'setWebhook',{url:webhookURL,secret_token:secret,allowed_updates:['message'],drop_pending_updates:false});
    stage='setChatMenuButton';
    await call(env,'setChatMenuButton',{menu_button:{type:'web_app',text:'Открыть Wallker',web_app:{url:APP_ORIGIN}}});
    stage='getWebhookInfo';
    const webhook=await call(env,'getWebhookInfo',{});
    stage='getChatMenuButton';
    const menu=await call(env,'getChatMenuButton',{});
    stage='verifyConfiguration';
    if(!sameURL(webhook.url,webhookURL)) throw new TelegramSetupError(0,'telegram_webhook_address_mismatch');
    if(menu.type!=='web_app') throw new TelegramSetupError(0,'telegram_menu_type_mismatch');
    if(!sameURL(menu.web_app?.url,APP_ORIGIN)) throw new TelegramSetupError(0,'telegram_menu_address_mismatch');
    stage='saveConfiguration';
    await db.prepare("UPDATE bot_setup SET config_hash=?,ready=1,lease_until=0 WHERE id='telegram'").bind(key).run();
    await db.prepare("DELETE FROM bot_setup_errors WHERE id='telegram'").run();
    return 'ready';
  } catch(error) {
    // No token, secret or raw Telegram response is exposed or logged.
    const code=error instanceof TelegramSetupError ? error.code : null;
    const reason=error instanceof TelegramSetupError ? error.reason : stage==='saveConfiguration' ? 'database_write_failed' : 'network_or_response_error';
    await db.batch([
      db.prepare("UPDATE bot_setup SET ready=-1 WHERE id='telegram'"),
      db.prepare("INSERT INTO bot_setup_errors(id,stage,code,reason,at) VALUES('telegram',?,?,?,?) ON CONFLICT(id) DO UPDATE SET stage=excluded.stage,code=excluded.code,reason=excluded.reason,at=excluded.at").bind(stage,code,reason,Date.now())
    ]);
    return 'configuration_failed';
  }
}
async function hmac(key, value) {
  const imported = await crypto.subtle.importKey('raw', key, {name:'HMAC', hash:'SHA-256'}, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', imported, encoder.encode(value)));
}
function equal(a, b) {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}
function localDay(timezone, now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {timeZone:timezone, year:'numeric', month:'2-digit', day:'2-digit'}).formatToParts(now);
  const part = name => parts.find(p => p.type === name).value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}
function timezone(value) {
  try { if (typeof value === 'string' && value.length < 80) { new Intl.DateTimeFormat('en', {timeZone:value}); return value; } } catch {}
  return 'Europe/Moscow';
}
function validDay(value, zone) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const day = Date.parse(`${value}T00:00:00Z`);
  if (!Number.isFinite(day) || new Date(day).toISOString().slice(0,10) !== value) return false;
  const today = Date.parse(`${localDay(zone)}T00:00:00Z`);
  return day <= today && day >= today - 6 * 86400000;
}
const coins = (steps,day='2026-10-11') => day<'2026-10-11'?Math.floor(Math.min(10000,Math.max(0,steps))/1000)*10:Math.floor(Math.min(10000,Math.max(0,steps))*0.4);
function database(env) {
  if (!env.DB) throw new ApiError('База сервера ещё не подключена', 503);
  return env.DB;
}
async function body(request, limit = 8192) {
  const reader = request.body?.getReader();
  if (!reader) throw new ApiError('Пустой запрос');
  const chunks = [];
  let length = 0;
  while (true) {
    const {done, value} = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > limit) { await reader.cancel(); throw new ApiError('Слишком большой запрос', 413); }
    chunks.push(value);
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  try {
    const parsed = JSON.parse(new TextDecoder().decode(bytes));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error();
    return parsed;
  } catch { throw new ApiError('Неверный формат запроса'); }
}
async function identity(request, env) {
  const raw = request.headers.get('X-Telegram-Init-Data');
  if (!raw) throw new ApiError('Открой Wallker через Telegram-бота', 401);
  if (raw.length > 8192) throw new ApiError('Слишком большой запрос входа', 413);
  if (!env.TELEGRAM_BOT_TOKEN) throw new ApiError('Telegram-бот ещё не подключён к серверу', 503);
  const params = new URLSearchParams(raw);
  if (new Set(params.keys()).size !== [...params.keys()].length) throw new ApiError('Повторяющиеся поля входа', 401);
  const supplied = params.get('hash') || '';
  if (!/^[a-f0-9]{64}$/.test(supplied)) throw new ApiError('Неверная подпись Telegram', 401);
  const authDate = Number(params.get('auth_date'));
  const now = Date.now()/1000;
  if (!authDate || !Number.isFinite(authDate) || now-authDate > 3600 || authDate > now+30) throw new ApiError('Открой приложение заново в Telegram', 401);
  params.delete('hash');
  const check = [...params].sort(([a], [b]) => a<b ? -1 : a>b ? 1 : 0).map(([k,v]) => `${k}=${v}`).join('\n');
  const secret = await hmac(encoder.encode('WebAppData'), env.TELEGRAM_BOT_TOKEN);
  if (!equal(hex(await hmac(secret, check)), supplied)) throw new ApiError('Неверная подпись Telegram', 401);
  let user;
  try { user = JSON.parse(params.get('user') || 'null'); } catch { throw new ApiError('Неверные данные Telegram', 401); }
  if (!user || !Number.isSafeInteger(user.id) || user.id <= 0) throw new ApiError('Нет пользователя Telegram', 401);
  return {id:`tg:${user.id}`, name:String(user.first_name || 'Участник').slice(0,60), mode:'beta'};
}
async function snapshot(db, id, env) {
  const user = await db.prepare('SELECT name,timezone,mode FROM users WHERE id=?').bind(id).first();
  if (!user) throw new ApiError('Сначала открой кошелёк');
  await ensureStepRewards(db);
  const settings=await rewardSettings(db);
  const history = (await db.prepare('SELECT d.day,d.steps,d.source,d.updated,r.units/100.0 AS coins FROM days d JOIN step_rewards r ON d.user_id=r.user_id AND d.day=r.day WHERE d.user_id=? ORDER BY d.day DESC LIMIT 90').bind(id).all()).results;
  const sum=await db.prepare('SELECT COALESCE(SUM(units),0)/100.0 AS coins FROM step_rewards WHERE user_id=?').bind(id).first();
  const today = localDay(user.timezone);
  const steps = history.find(row => row.day === today)?.steps || 0;
  const devices = (await db.prepare('SELECT platform FROM pairings WHERE user_id=? AND device_hash IS NOT NULL').bind(id).all()).results;
  const tap=await tapSnapshot(db,id);
  return {...tap,rewardSettings:settings,user, today, steps, todayCoins:history.find(row=>row.day===today)?.coins||0, balance:(sum?.coins || 0)+await bonusBalance(db,id)+tap.tapCoins, bonusCoins:await bonusBalance(db,id), history, devices, botConnected:true, ...await campaignSnapshot(db,{id},env)};
}
async function route(request, env, url) {
  const path = url.pathname;
  if (path === '/api/health' && request.method === 'GET') {
    const db = database(env);
    await db.prepare('SELECT id FROM users LIMIT 1').all();
    const botSetup=await configureBot(env);
    const botSetupError=botSetup==='configuration_failed'
      ? await db.prepare("SELECT stage,code,reason FROM bot_setup_errors WHERE id='telegram'").first() : null;
    return {ok:true, version:'0.2.5', botConfigured:Boolean(env.TELEGRAM_BOT_TOKEN), botSetup,...(botSetupError ? {botSetupError} : {})};
  }
  if (path === '/api/wallet' && ['GET','POST'].includes(request.method)) {
    const user = await identity(request, env);
    const db = database(env);
    if (request.method === 'GET') {
      await db.prepare('INSERT INTO users(id,name,timezone,mode,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').bind(user.id, user.name, timezone(url.searchParams.get('timezone')), user.mode, Date.now()).run();
      return snapshot(db, user.id, env);
    }
    const data = await body(request);
    if (!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first()) throw new ApiError('Сначала открой кошелёк');
    if (data.action !== 'pair') throw new ApiError('Неизвестное действие');
    const code = randomToken();
    const expires = Date.now()+600000;
    await db.batch([
      db.prepare('DELETE FROM pairings WHERE user_id=? AND device_hash IS NULL').bind(user.id),
      db.prepare('INSERT INTO pairings(code_hash,user_id,expires) VALUES(?,?,?)').bind(await digest(code), user.id, expires)
    ]);
    return {code, expires};
  }
  if (['/api/tap','/api/device/tap'].includes(path) && request.method==='POST') {
    const db=database(env),data=await body(request);let id;
    if(path==='/api/tap')id=(await identity(request,env)).id;
    else {
      const token=request.headers.get('Authorization')?.replace(/^Bearer /,'')||'';
      if(!/^[a-f0-9]{48}$/.test(token))throw new ApiError('Привяжи телефон заново',401);
      const device=await db.prepare('SELECT user_id FROM pairings WHERE device_hash=?').bind(await digest(token)).first();
      if(!device)throw new ApiError('Телефон не привязан',401);id=device.user_id;
    }
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(id).first())throw new ApiError('Сначала открой кошелёк');
    const tap=data.action==='state'?await tapSnapshot(db,id):await earnTaps(db,id,data);
    const wallet=await snapshot(db,id,env);
    return {...tap,balance:wallet.balance};
  }
  if (path.startsWith('/api/admin/') || path === '/api/campaigns' || path === '/api/campaigns/claim') {
    const user=await identity(request,env);const db=database(env);
    if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new ApiError('Сначала открой кошелёк');
    const payload=request.method==='POST'?await body(request):{};
    const wallet=path==='/api/campaigns/claim'?await snapshot(db,user.id,env):null;
    if(path==='/api/admin/rewards'){
      if(!isAdmin(user,env))throw new ApiError('Настройки наград доступны только владельцу',403);
      if(request.method==='GET')return {settings:await rewardSettings(db)};
      if(request.method==='POST')return {settings:await saveRewardSettings(db,payload)};
      throw new ApiError('Метод не поддерживается',405);
    }
    return campaignRoute(path,request.method,payload,db,user,env,wallet?.steps||0);
  }
  if (path === '/api/device/pair' && request.method === 'POST') {
    const data = await body(request);
    if (typeof data.code !== 'string' || !/^[a-f0-9]{48}$/.test(data.code) || !['android','ios'].includes(data.platform)) throw new ApiError('Неверный код привязки');
    const db = database(env);
    const token = randomToken();
    const codeHash = await digest(data.code);
    const previousToken = request.headers.get('Authorization')?.replace(/^Bearer /,'') || '';
    const previousHash = /^[a-f0-9]{48}$/.test(previousToken) ? await digest(previousToken) : null;
    const candidate = await db.prepare('SELECT user_id,expires,device_hash FROM pairings WHERE code_hash=?').bind(codeHash).first();
    if (candidate && candidate.device_hash === null && candidate.expires > Date.now()) {
      const accountId = await digest(`wallker-account:${candidate.user_id}`);
      const previous = previousHash ? await db.prepare('SELECT user_id FROM pairings WHERE device_hash=?').bind(previousHash).first() : null;
      const sameAccount = previous ? previous.user_id === candidate.user_id : null;
      if (data.checkOnly === true) return {accountId, sameAccount};
      if (data.expectedAccountId && data.expectedAccountId !== accountId) throw new ApiError('Аккаунт изменился. Проверь привязку заново.', 409);
    } else if (data.checkOnly === true) {
      if (!candidate) throw new ApiError('Такой код не найден на этом сервере. Перенеси текущий код из Telegram целиком.', 401);
      throw new ApiError(candidate.device_hash !== null ? 'Этот код уже использован. Получи новый в Telegram.' : 'Срок действия этого кода истёк. Получи новый в Telegram.', 401);
    }
    const pairing = await db.prepare('UPDATE pairings SET device_hash=?,platform=? WHERE code_hash=? AND expires>? AND device_hash IS NULL RETURNING user_id').bind(await digest(token), data.platform, codeHash, Date.now()).first();
    if (!pairing) {
      const existing = await db.prepare('SELECT expires,device_hash FROM pairings WHERE code_hash=?').bind(codeHash).first();
      if (!existing) throw new ApiError(`Такой код не найден на этом сервере. Проверка ввода: ${codeHash.slice(0,12)}. Перенеси текущий код из Telegram целиком.`, 401);
      if (existing.device_hash !== null) throw new ApiError('Этот код уже использован. Получи новый в Telegram.', 401);
      if (existing.expires <= Date.now()) throw new ApiError('Срок действия этого кода истёк. Получи новый в Telegram.', 401);
      throw new ApiError('Код найден и действует, но сервер не завершил привязку. Повтори попытку.', 503);
    }
    const user = await db.prepare('SELECT timezone FROM users WHERE id=?').bind(pairing.user_id).first();
    if (previousHash) await db.prepare('DELETE FROM pairings WHERE device_hash=?').bind(previousHash).run();
    const accountId = await digest(`wallker-account:${pairing.user_id}`);
    const history = (await db.prepare('SELECT day,steps FROM days WHERE user_id=? ORDER BY day DESC LIMIT 7').bind(pairing.user_id).all()).results;
    return {token, timezone:user?.timezone || 'Europe/Moscow', accountId, history};
  }
  if (path === '/api/device/steps' && request.method === 'POST') {
    const token = request.headers.get('Authorization')?.replace(/^Bearer /,'') || '';
    if (!/^[a-f0-9]{48}$/.test(token)) throw new ApiError('Привяжи телефон заново', 401);
    const db = database(env);
    const device = await db.prepare('SELECT p.user_id,p.platform,u.timezone FROM pairings p JOIN users u ON u.id=p.user_id WHERE p.device_hash=?').bind(await digest(token)).first();
    if (!device) throw new ApiError('Телефон не привязан', 401);
    const data = await body(request);
    if (!Number.isSafeInteger(data.steps) || data.steps < 0 || data.steps > 100000) throw new ApiError('Неверное количество шагов');
    if (!validDay(data.day, device.timezone)) throw new ApiError('Можно передать шаги за сегодня и шесть предыдущих дней');
    const settings=await rewardSettings(db);
    const award=await stepRewardStatements(db,device.user_id,data.day,data.steps,settings);
    await db.batch([db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET steps=MAX(days.steps,excluded.steps),updated=excluded.updated,source=excluded.source').bind(device.user_id, data.day, data.steps, Date.now(), `${device.platform}:unverified`),award]);
    const row = await db.prepare('SELECT steps FROM days WHERE user_id=? AND day=?').bind(device.user_id, data.day).first();
    const awarded=await db.prepare('SELECT units FROM step_rewards WHERE user_id=? AND day=?').bind(device.user_id,data.day).first();
    return {steps:row.steps,coins:awarded.units/100,status:'beta_unverified'};
  }
  if (path === '/api/device/revoke' && request.method === 'POST') {
    const user = await identity(request, env);
    await database(env).prepare('DELETE FROM pairings WHERE user_id=?').bind(user.id).run();
    return {ok:true};
  }
  if (path === '/api/telegram/webhook' && request.method === 'POST') {
    const expected = env.TELEGRAM_BOT_TOKEN ? await webhookSecret(env) : env.TELEGRAM_WEBHOOK_SECRET;
    const supplied = request.headers.get('X-Telegram-Bot-Api-Secret-Token') || '';
    if (!expected || !equal(expected, supplied)) throw new ApiError('Unauthorized', 401);
    const update = await body(request, 32768);
    const message = update.message;
    if (!message || message.chat?.type !== 'private' || !Number.isSafeInteger(message.chat?.id)) return {ok:true};
    const command = String(message.text || '').split(/\s/)[0].split('@')[0];
    if (!['/start','/help','/privacy','/id'].includes(command)) return {ok:true};
    const text = command === '/id' ? `Твой Telegram ID: ${message.chat.id}` : command === '/privacy'
      ? 'Wallker хранит Telegram ID, имя, часовой пояс, даты и число шагов для игровых баллов. GPS и медицинские данные не используются. Телефон можно отключить в разделе «Телефон». Это не удаляет историю на сервере.'
      : 'Добро пожаловать в Wallker Wallet! Открой приложение и раздел «Телефон», получи код и введи его в Android-приложении. WC — игровые баллы бета-версии, без вывода и гарантированного обмена на токены. iPhone пока не выпущен.';
    return {method:'sendMessage', chat_id:message.chat.id, text, reply_markup:{inline_keyboard:[[{text:'Открыть Wallker', web_app:{url:url.origin}}]]}};
  }
  const known = ['/api/health','/api/wallet','/api/device/pair','/api/device/steps','/api/device/revoke','/api/telegram/webhook'];
  throw new ApiError(known.includes(path) ? 'Метод не поддерживается' : 'Не найдено', known.includes(path) ? 405 : 404);
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) {
      if (!env.ASSETS) return new Response('Wallker: интерфейс ещё не загружен', {status:503});
      const original = await env.ASSETS.fetch(request);
      const response = new Response(original.body, original);
      response.headers.set('X-Content-Type-Options', 'nosniff');
      response.headers.set('Referrer-Policy', 'no-referrer');
      return response;
    }
    const origin = request.headers.get('Origin');
    const allowed = new Set([url.origin, ...(env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean)]);
    let status = 200, value;
    try {
      if (origin && !allowed.has(origin)) throw new ApiError('Запрос с другого сайта отклонён', 403);
      if (request.method === 'OPTIONS') {
        if (request.headers.get('Access-Control-Request-Method') && !['GET','POST'].includes(request.headers.get('Access-Control-Request-Method'))) throw new ApiError('Метод не поддерживается', 405);
        const headers = new Headers({'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization, X-Telegram-Init-Data','Access-Control-Max-Age':'600','Vary':'Origin','Cache-Control':'no-store'});
        if (origin) headers.set('Access-Control-Allow-Origin', origin);
        return new Response(null, {status:204, headers});
      }
      value = await route(request, env, url);
    } catch (error) {
      status = error instanceof ApiError || error instanceof CampaignError || error instanceof TapError ? error.status : 503;
      value = {error:error instanceof ApiError || error instanceof CampaignError || error instanceof TapError ? error.message : 'Ошибка настройки или выполнения запроса сервера'};
      // No request bodies, initData, pairing codes, tokens, or raw exception contents in logs.
      if (!(error instanceof ApiError) && !(error instanceof CampaignError) && !(error instanceof TapError)) console.error('Wallker API failed', url.pathname);
    }
    const headers = new Headers({'Content-Type':'application/json; charset=UTF-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Origin'});
    if (origin && allowed.has(origin)) headers.set('Access-Control-Allow-Origin', origin);
    return new Response(JSON.stringify(value), {status, headers});
  }
};
