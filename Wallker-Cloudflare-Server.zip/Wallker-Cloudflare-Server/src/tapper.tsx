import {getLocale} from './language';
import {LevelButton,WolfLevelIcon,LevelState} from './levels';
import {useEffect,useRef,useState} from 'react';
import {Coins,Footprints,Zap,Target,MessageCircle} from 'lucide-react';
import {campaignAPI,Sponsor} from './campaigns';
type TapWallet={serverNow:number,referralMultiplier:number,referralPercent:number,levels:LevelState,telegramId:string,balance:number,tapReward:number,tapDailyLimit:number,tapTodayCoins:number,tapDailyRemaining:number,tapCoins:number,tapCount:number,tapRemainder:number,tapsPerCoin:number,energy:number,capacity:number,regenMs:number,steps:number,todayCoins:number,user:{name:string},mascot:Sponsor|null};
type Batch={requestId:string,count:number};
export function useTapper(wallet:TapWallet|null,onCommit:(value:any)=>void){
 const ref=useRef({id:'',queue:[] as Batch[],sending:false,retryAt:0,server:null as TapWallet|null,at:performance.now(),inFlight:''});
 const commit=useRef(onCommit);commit.current=onCommit;
 const [tick,setTick]=useState(0),[message,setMessage]=useState('');
 const redraw=()=>setTick(x=>x+1);
 function save(){try{localStorage.setItem('wallker-taps:'+ref.current.id,JSON.stringify(ref.current.queue))}catch{}}
 useEffect(()=>{
  if(!wallet)return;
  const r=ref.current;
  if(r.id!==wallet.telegramId){r.id=wallet.telegramId;r.queue=[];try{const q=JSON.parse(localStorage.getItem('wallker-taps:'+r.id)||'[]');r.queue=q.filter((x:Batch)=>/^[a-zA-Z0-9_-]{16,80}$/.test(x.requestId)&&Number.isInteger(x.count)&&x.count>0&&x.count<=50).slice(0,100)}catch{};r.retryAt=0;r.inFlight='';r.sending=false;}
  if(r.server&&wallet.serverNow<r.server.serverNow)return;r.server=wallet;r.at=performance.now();if(r.retryAt===Infinity)r.retryAt=0;if(wallet.tapDailyRemaining>0&&wallet.energy>0&&!r.queue.length)setMessage('');redraw();
 },[wallet]);
 useEffect(()=>{
  const timer=setInterval(async()=>{
   const r=ref.current;redraw();
   if(!r.id||!r.queue.length||r.sending||performance.now()<r.retryAt)return;
   const batch=r.queue[0],id=r.id;r.sending=true;r.inFlight=batch.requestId;
   try{
    const result=await campaignAPI('/api/tap',batch);
    if(ref.current.id!==id)return;
    r.queue.shift();save();r.server={...r.server!,...result};r.at=performance.now();commit.current(result);
    setMessage(result.accepted<batch.count?(result.tapDailyRemaining<=0?'Дневной лимит достигнут.':'Энергия закончилась. Она восстановится.'):'');
   }catch(e){if(ref.current.id===id){const status=(e as any).status;if(status===401||status===423){r.retryAt=Infinity;setMessage(status===401?'Открой приложение заново в Telegram. Тапы ожидают отправки.':'Начисления приостановлены. Напиши в поддержку.');}else if([400,409,410].includes(status)){r.queue.shift();save();setMessage('Пакет не принят: '+(e as Error).message);}else{r.retryAt=performance.now()+(status===429?60000:3000);setMessage(status===429?'Пауза перед отправкой. Тапы остаются в очереди.':'Ожидаем подтверждения. Нажатия сохранены.');}}}
   finally{if(ref.current.id===id){r.sending=false;r.inFlight='';redraw()}}
  },400);return()=>clearInterval(timer);
 },[]);
 const r=ref.current,pending=r.queue.reduce((sum,x)=>sum+x.count,0),server=r.server||wallet;
 const energy=Math.max(0,Math.min(server?.capacity||100,(server?.energy||0)+Math.floor(Math.max(0,performance.now()-r.at)/(server?.regenMs||1000)))-pending);
 const remaining=Math.max(0,Math.round(((server?.tapDailyRemaining??1000)-pending*(server?.tapReward||0.1))*10000)/10000);
 function tap(){
  if(!server||energy<1||remaining<=0||r.queue.length>=100)return false;
  let last=r.queue[r.queue.length-1];
  if(!last||last.count>=50||last.requestId===r.inFlight){last={requestId:crypto.randomUUID(),count:0};r.queue.push(last)}
  last.count++;save();redraw();return true;
 }
 const earned=Math.min(server?.tapDailyRemaining??1000,pending*(server?.tapReward||0.1));
 return {tap,energy,remaining,pending,todayCoins:(server?.tapTodayCoins||0)+earned,balance:Math.round(((server?.balance||0)+earned)*10000)/10000,tapCoins:(server?.tapCoins||0)+earned,tapCount:(server?.tapCount||0)+pending,remainder:((server?.tapRemainder||0)+pending)%10,message};
}
export function TapGame({wallet,tapper,onTab}:{wallet:TapWallet,tapper:ReturnType<typeof useTapper>,onTab:(tab:string)=>void}){
 const resting=tapper.remaining<=0,shownEnergy=resting?0:tapper.energy;
 const [bursts,setBursts]=useState<{id:number,x:number,y:number,amount:number}[]>([]),serial=useRef(0);
 function click(e:React.MouseEvent<HTMLButtonElement>){
  const rect=e.currentTarget.getBoundingClientRect();if(e.detail!==0&&Math.hypot(e.clientX-rect.left-rect.width/2,e.clientY-rect.top-rect.height/2)>rect.width/2)return;
  const amount=Math.min(wallet.tapReward,tapper.remaining);if(!tapper.tap())return;
  const id=++serial.current;
  const x=e.detail===0?rect.width/2:e.clientX-rect.left,y=e.detail===0?rect.height/2:e.clientY-rect.top;
  setBursts(b=>[...b.slice(-14),{id,x,y,amount}]);
 }
 return <section className="tap-game" aria-label="Игра с Волкером">
  <div className="player-bar"><WolfLevelIcon level={wallet.levels.level} className="player-avatar level-player-avatar"/><strong data-user-content>{wallet.user.name}</strong><span className="player-rank">{wallet.levels.name}</span><button className="support-shortcut" onClick={()=>onTab('support')} aria-label="Открыть чат поддержки"><MessageCircle size={20}/><small>Поддержка</small></button></div>
  <div className="earn-stats"><div><span>За нажатие</span><strong><Coins size={15}/>+{wallet.tapReward.toLocaleString(getLocale(),{maximumFractionDigits:4})} WC</strong></div><button onClick={()=>onTab('goals')}><span>За задания</span><strong><Target size={15}/>Награды</strong></button><button onClick={()=>onTab('phone')}><span>За шаги сегодня</span><strong><Footprints size={15}/>+{wallet.todayCoins} WC</strong></button></div>
  <button className="tap-balance" onClick={()=>onTab('wallet')} aria-label="Открыть кошелёк"><span className="gold-coin">W</span><strong>{tapper.balance.toLocaleString(getLocale(),{maximumFractionDigits:4})}</strong><span>WC</span></button>
  <LevelButton levels={wallet.levels} onClick={()=>onTab('levels')}/>
  <div className="tap-stage"><button className={'wolf-tap '+(resting?'wolf-resting':'')} onClick={click} disabled={tapper.energy<1||tapper.remaining<=0} aria-label="Нажать на Волкера: получить WC"><WolfLevelIcon level={wallet.levels.level} className="tap-rank-portrait"/>{bursts.map(b=><span key={b.id} className="tap-burst" style={{left:b.x,top:b.y}} onAnimationEnd={()=>setBursts(items=>items.filter(x=>x.id!==b.id))}>+{b.amount.toLocaleString(getLocale(),{maximumFractionDigits:4})} WC</span>)}</button></div>
  <p className="tap-hint">{(tapper.remaining<=0?'Волкер отдыхает 💤 Лимит собран — новые тапы в 00:00 МСК':tapper.message)|| (tapper.energy?`За тап +${Math.min(wallet.tapReward,tapper.remaining).toLocaleString(getLocale(),{maximumFractionDigits:4})} WC`:`Энергия: +1 за ${wallet.regenMs/1000} сек.`)}</p>
  <p className="tap-hint referral-home">Стая: ×{wallet.referralMultiplier?.toLocaleString(getLocale(),{maximumFractionDigits:4})||'1'} · +{wallet.referralPercent||0}% к наградам</p>
  <p className="tap-hint">Тапы за день: {tapper.todayCoins.toLocaleString(getLocale(),{maximumFractionDigits:4})} / {wallet.tapDailyLimit||1000} WC</p>
  <div className="energy-row"><Zap size={23}/><strong>{shownEnergy.toLocaleString(getLocale(),{maximumFractionDigits:4})} <span>/ {wallet.capacity}</span></strong><span className="pending-taps" role="status">{tapper.pending?'Сохраняем…':'Сохранено'}</span></div>
  <div className="energy-track"><div style={{width:shownEnergy/wallet.capacity*100+'%'}}/></div>
  {wallet.mascot&&<a className="tap-partner" href={wallet.mascot.url} target="_blank" rel="noopener noreferrer">Партнёр Волкера · {wallet.mascot.partner} ↗</a>}
 </section>;
}
