import {CampaignError} from './campaigns.mjs';
import {canEarn,limit} from './security.mjs';
import {moscowTapDay} from './taps.mjs';
import {referralBoost} from './referrals.mjs';
const cards=[{icon:'🌳',name:'Парк',clue:'Там шумят деревья'},{icon:'🌉',name:'Мост',clue:'Перейди на другой берег'},{icon:'☕',name:'Кофейня',clue:'Согрейся чашкой кофе'},{icon:'🏟️',name:'Стадион',clue:'Пройди круг у трибун'},{icon:'🌊',name:'Набережная',clue:'Прогуляйся вдоль воды'},{icon:'⛲',name:'Площадь',clue:'Найди городской фонтан'}];
export async function dailyRoute(db,user,data,env){
 await canEarn(db,user.id);const day=moscowTapDay(Date.now());
 const seed=Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
 await db.prepare('INSERT OR IGNORE INTO daily_puzzles(day,seed) VALUES(?,?)').bind(day,seed).run();
 const stored=(await db.prepare('SELECT seed FROM daily_puzzles WHERE day=?').bind(day).first()).seed;
 const bytes=stored.match(/../g).map(x=>parseInt(x,16));
 const pool=[0,1,2,3,4,5],solution=[];for(let i=0;i<3;i++)solution.push(pool.splice(bytes[i]%pool.length,1)[0]);
 const receipt=await db.prepare('SELECT units FROM daily_claims WHERE user_id=? AND day=?').bind(user.id,day).first();const reward=Math.round(200*(await referralBoost(db,user.id)).multiplier*10000)/10000;
 if(data){await limit(db,'daily:'+user.id,20);if(data.day!==day||!Array.isArray(data.picked)||data.picked.length!==3||!data.picked.every((v,i)=>v===solution[i]))throw new CampaignError('Маршрут не совпал. Проверь подсказки.',409);
 await db.batch([db.prepare('INSERT OR IGNORE INTO daily_claims(user_id,day,units,created) VALUES(?,?,?,?)').bind(user.id,day,reward*100,Date.now()),db.prepare("INSERT OR IGNORE INTO admin_grants(admin_id,request_id,user_id,units,created) SELECT 'system:daily',user_id||':'||day,user_id,units,created FROM daily_claims WHERE user_id=? AND day=?").bind(user.id,day)]);return {ok:true,reward:receipt?.units/100||reward};}
 return {day,reward,claimed:!!receipt,cards:cards.map(({icon,name})=>({icon,name})),clues:solution.map(i=>cards[i].clue)};
}
