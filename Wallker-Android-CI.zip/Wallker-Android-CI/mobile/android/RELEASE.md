# Постоянная подпись и релиз 0.3.0

Статус: конфигурация подготовлена, релизный APK ещё не собран. Изменения 0.3.0 требуют запуска GitHub Actions и проверки на телефоне. Ранее собран debug 0.2.0:
https://github.com/markashurkin-cmyk/wallker-android/actions/runs/37039720127

## Подготовить репозиторий

В новом архиве папки `.github`, `mobile` и `publishing` должны лежать в корне репозитория. Текущий GitHub-репозиторий использует прежний ZIP и извлекающий его workflow: новые исходники ещё НЕ загружены туда.

Распаковать пакет. Загрузить содержимое его корневой папки Wallker-RuStore в репозиторий, включая скрытую `.github`, заменив прежний debug workflow. После перехода на распакованные исходники удалить старый `Wallker-Android-CI.zip`, чтобы он не использовался по ошибке. Можно загрузить через git на Windows или веб-редактор GitHub; Mac не нужен.

## Создать ключ один раз на Windows

Нужен JDK 17 или Android Studio с JDK. Выполнить в PowerShell, в отдельной приватной папке вне репозитория:

```powershell
keytool -genkeypair -v -keystore wallker-release.jks -alias wallker -keyalg RSA -keysize 3072 -validity 10000
```

Ввести пароль и сведения владельца в интерактивном запросе keytool. Сохранить ключ и пароль в надёжном месте, сделать резервную копию. Не менять ключ при следующих обновлениях. Не загружать ключ, Base64-файл или пароли в репозиторий, RuStore-описание или чат. Base64 не шифрует ключ.

Скопировать Base64 в буфер обмена, не печатая его в терминал:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path .\wallker-release.jks))).Trim() | Set-Clipboard
```

GitHub → Settings → Secrets and variables → Actions → New repository secret:
- WALLKER_KEYSTORE_BASE64: содержимое буфера обмена.
- WALLKER_KEYSTORE_PASSWORD: пароль хранилища.
- WALLKER_KEY_ALIAS: wallker.
- WALLKER_KEY_PASSWORD: пароль ключа, заданный при генерации (часто совпадает с паролем хранилища).

Очистить буфер после вставки. Доступ к этим секретам означает возможность подписывать приложение; предоставлять его только доверенным сопровождающим.

## Собрать

Actions → Build signed Android release → Run workflow. Workflow ручной, не запускает публикацию магазина. Он собирает release без отладки, проверяет подпись и сохраняет `wallker-android-release` на 14 дней. Скачать артефакт, распаковать `wallker-wallet-0.3.0.apk` и `SHA256SUMS.txt`. Проверка подписи не заменяет тест датчика.

Без всех четырёх секретов сборка прекращается. Конфигурация не создаёт временный релизный ключ. Не запускать workflow из неизвестных изменений, имеющих доступ к секретам.

Проверить APK на телефоне по `mobile/DEVICE_TESTS.md`. Обновление поверх debug с другой подписью невозможно: обычно нужно удалить debug, что очистит местные данные. Сначала передать шаги и убедиться, что они есть в Telegram. Для будущих обновлений использовать тот же applicationId, тот же ключ и увеличивать versionCode.

## Локальная сборка для разработчика

JDK 17, Gradle 8.13, SDK 36, Build Tools 36.0.0. Передать через защищённое окружение четыре значения: WALLKER_KEYSTORE_PATH (абсолютный путь), WALLKER_KEYSTORE_PASSWORD, WALLKER_KEY_ALIAS, WALLKER_KEY_PASSWORD. В `mobile/android` выполнить `gradle :app:assembleRelease`. Debug по-прежнему собирается без ключей через `gradle :app:assembleDebug`.
