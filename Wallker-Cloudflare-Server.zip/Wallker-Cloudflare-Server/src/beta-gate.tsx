import {ReactNode,useCallback,useEffect,useRef,useState} from 'react';
import {ArrowUpRight,Check,Clock3,RefreshCw,Send} from 'lucide-react';
import {LanguageSelect,useLanguage} from './language';
import {BotMoved,BotDestination} from './bot-moved';
import {BETA_EVENT,BetaAccess} from './beta-signal';
import './beta-gate.css';
export function BetaGate({children}:{children:ReactNode}){
 const {language}=useLanguage(),en=language==='en';
 const [access,setAccess]=useState<BetaAccess|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState(false),[login,setLogin]=useState(false),[moved,setMoved]=useState<BotDestination|null>(null),[bot,setBot]=useState<BotDestination|null>(null);
 const current=useRef(0),inFlight=useRef(false);
 const check=useCallback(async(apply=false)=>{
  if(inFlight.current)return;inFlight.current=true;const ticket=++current.current;setBusy(true);setError(false);
  try{
   const init=window.Telegram?.WebApp.initData||'';
   const response=await fetch('/api/beta',{method:apply?'POST':'GET',headers:{'X-Telegram-Init-Data':init,...(apply?{'Content-Type':'application/json'}:{})},...(apply?{body:JSON.stringify({action:'apply'})}:{})});const j=await response.json();
   if(ticket!==current.current)return;
   if(j.code==='BOT_MOVED'&&j.migration&&/^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(j.migration.username)&&j.migration.link==='https://t.me/'+j.migration.username){setMoved(j.migration);setAccess(null);return;}
   if(response.status===401){setLogin(true);setAccess(null);return;}
   if(!response.ok)throw Error();
   if(typeof j.allowed!=='boolean'||!['none','pending','approved','rejected','revoked'].includes(j.status))throw Error();
   setLogin(false);setAccess(j);
  }catch{if(ticket===current.current)setError(true)}finally{inFlight.current=false;setBusy(false)}
 },[]);
 useEffect(()=>{window.Telegram?.WebApp.ready();window.Telegram?.WebApp.expand();check();fetch('/api/bot').then(r=>r.json()).then(j=>{if(/^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(j.username)&&j.link==='https://t.me/'+j.username)setBot(j)}).catch(()=>{});const denied=(event:Event)=>{++current.current;setAccess((event as CustomEvent<BetaAccess>).detail);setError(false)};window.addEventListener(BETA_EVENT,denied);const visible=()=>{if(document.visibilityState==='visible')check()};document.addEventListener('visibilitychange',visible);const timer=setInterval(()=>{if(document.visibilityState==='visible')check()},30000);return()=>{++current.current;clearInterval(timer);window.removeEventListener(BETA_EVENT,denied);document.removeEventListener('visibilitychange',visible)}},[check]);
 if(moved)return <BotMoved bot={moved}/>;
 if(access?.allowed)return <>{children}</>;
 const pending=access?.status==='pending',declined=access?.status==='rejected'||access?.status==='revoked';
 return <section className="beta-launch" aria-labelledby="launch-title">
  <header className="beta-launch-top"><strong><span className="brand-mark">W</span> Walker Wallet</strong><LanguageSelect/></header>
  <div className="beta-launch-content">
   <div className="beta-launch-art"><img src="/wolf-level-7.png" alt={en?'Walker is getting ready to launch':'Волкер готовится к запуску'}/></div>
   <p className="beta-launch-eyebrow">{en?'THE PACK IS GETTING READY':'СТАЯ ГОТОВИТСЯ К СТАРТУ'}</p>
   <h1 id="launch-title">{en?'Walker is launching soon':'Walker скоро стартует'}</h1>
   <p className="beta-launch-description">{en?'The project launches soon. Join the closed beta while we get everything ready.':'Ожидайте запуск проекта в ближайшее время. А пока можно подать заявку на закрытый бета-тест.'}</p>
   {!access&&!login&&!error&&<p className="beta-launch-status" role="status"><RefreshCw size={18} className="spin"/>{en?'Checking access…':'Проверяем доступ…'}</p>}
   {pending&&<div className="beta-launch-status" role="status"><Check size={20}/><div><strong>{en?'Application submitted':'Заявка отправлена'}</strong><p>{en?'The developer will review it. Access will appear here once approved.':'Разработчик рассмотрит её. После одобрения здесь откроется приложение.'}</p></div></div>}
   {declined&&<div className="beta-launch-status" role="status"><Clock3 size={20}/><p>{en?'Beta access is not available for your account yet. Please wait for the public launch.':'Бета-доступ для твоего аккаунта пока не открыт. Дождись запуска проекта.'}</p></div>}
   {error&&<p className="beta-launch-error" role="alert">{en?'Could not connect. Please try again.':'Не удалось связаться с сервером. Попробуй ещё раз.'}</p>}
   {access?.status==='none'&&<button className="button primary beta-launch-apply" disabled={busy} onClick={()=>check(true)}><Send size={19}/>{busy?(en?'Submitting…':'Отправляем…'):(en?'Apply for the beta':'Подать заявку на бета-тест')}</button>}
   {login&&<>{bot?<a className="button primary beta-launch-apply" href={bot.link} target="_top">{en?'Open in Telegram':'Открыть в Telegram'}<ArrowUpRight size={19}/></a>:<p className="beta-launch-status">{en?'Open Walker from its Telegram bot to apply.':'Чтобы подать заявку, открой Walker через Telegram-бота.'}</p>}</>}
   {(access||error||login)&&<button className="beta-launch-refresh" disabled={busy} onClick={()=>check()}><RefreshCw size={15} className={busy?'spin':''}/>{en?'Check access':'Проверить доступ'}</button>}
   {access&&<p className="beta-launch-id">Telegram ID: <span>{access.telegramId}</span></p>}
  </div>
  <footer className="beta-launch-footer"><span>Walker Wallet</span><a href={en?'/privacy-en.html':'/privacy.html'} target="_blank" rel="noopener">{en?'Privacy':'Конфиденциальность'}</a></footer>
 </section>;
}
