package com.wallker.wallet

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.*
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

class StepService:Service(),SensorEventListener {
    private lateinit var sensors:SensorManager
    private lateinit var store:StepStore
    override fun onCreate(){super.onCreate();sensors=getSystemService(SENSOR_SERVICE) as SensorManager;store=StepStore(this)}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action=="STOP"){store.setEnabled(false);stopSelf();return START_NOT_STICKY}
        if(!store.enabled()){stopSelf();return START_NOT_STICKY}
        if(Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED){
            store.setEnabled(false);store.setStatus("Разреши доступ к физической активности");stopSelf();return START_NOT_STICKY
        }
        val sensor=sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if(sensor==null){store.setEnabled(false);store.setStatus("В этом телефоне нет датчика шагов");stopSelf();return START_NOT_STICKY}
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("steps","Шагомер Wallker",NotificationManager.IMPORTANCE_LOW))
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop=PendingIntent.getService(this,1,Intent(this,StepService::class.java).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification=Notification.Builder(this,"steps").setSmallIcon(R.drawable.ic_wallker).setContentTitle("Wallker считает шаги")
            .setContentText("Носи телефон с собой. Нажми, чтобы открыть.").setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this,android.R.drawable.ic_media_pause),"Приостановить",stop).build()).build()
        try {
            if(Build.VERSION.SDK_INT>=34)startForeground(1,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH) else startForeground(1,notification)
            if(!sensors.registerListener(this,sensor,SensorManager.SENSOR_DELAY_NORMAL))error("Не удалось включить датчик шагов")
            store.setStatus("Шагомер работает")
        }catch(e:Exception){store.setEnabled(false);store.setStatus(e.message ?: "Не удалось запустить шагомер");stopSelf();return START_NOT_STICKY}
        return START_STICKY
    }
    override fun onSensorChanged(event:SensorEvent){
        if(event.sensor.type==Sensor.TYPE_STEP_COUNTER && event.values[0].isFinite() && event.values[0]>=0) {
            try{store.record(event.values[0].toLong(),event.timestamp)}catch(_:Exception){store.setEnabled(false);stopSelf()}
        }
    }
    override fun onAccuracyChanged(sensor:Sensor?,accuracy:Int){}
    override fun onDestroy(){sensors.unregisterListener(this);super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
