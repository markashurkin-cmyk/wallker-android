const encoder = new TextEncoder();
class ApiError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const hex = bytes => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
const digest = async value => hex(await crypto.subtle.digest('SHA-256', encoder.encode(value)));
const randomToken = () => hex(crypto.getRandomValues(new Uint8Array(24)));
async function hmac(key, value) {
  const imported = await crypto.subtle.importKey('raw', key, {name:'HMAC', hash:'SHA-256'}, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', imported, encoder.encode(value)));
}
function equal(a, b) {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}
function localDay(timezone, now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {timeZone:timezone, year:'numeric', month:'2-digit', day:'2-digit'}).formatToParts(now);
  const part = name => parts.find(p => p.type === name).value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}
function timezone(value) {
  try { if (typeof value === 'string' && value.length < 80) { new Intl.DateTimeFormat('en', {timeZone:value}); return value; } } catch {}
  return 'Europe/Moscow';
}
function validDay(value, zone) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const day = Date.parse(`${value}T00:00:00Z`);
  if (!Number.isFinite(day) || new Date(day).toISOString().slice(0,10) !== value) return false;
  const today = Date.parse(`${localDay(zone)}T00:00:00Z`);
  return day <= today && day >= today - 6 * 86400000;
}
const coins = steps => Math.floor(Math.min(10000, Math.max(0, steps))/1000)*10;
function database(env) {
  if (!env.DB) throw new ApiError('База сервера ещё не подключена', 503);
  return env.DB;
}
async function body(request, limit = 8192) {
  const reader = request.body?.getReader();
  if (!reader) throw new ApiError('Пустой запрос');
  const chunks = [];
  let length = 0;
  while (true) {
    const {done, value} = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > limit) { await reader.cancel(); throw new ApiError('Слишком большой запрос', 413); }
    chunks.push(value);
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  try {
    const parsed = JSON.parse(new TextDecoder().decode(bytes));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error();
    return parsed;
  } catch { throw new ApiError('Неверный формат запроса'); }
}
async function identity(request, env) {
  const raw = request.headers.get('X-Telegram-Init-Data');
  if (!raw) throw new ApiError('Открой Wallker через Telegram-бота', 401);
  if (raw.length > 8192) throw new ApiError('Слишком большой запрос входа', 413);
  if (!env.TELEGRAM_BOT_TOKEN) throw new ApiError('Telegram-бот ещё не подключён к серверу', 503);
  const params = new URLSearchParams(raw);
  if (new Set(params.keys()).size !== [...params.keys()].length) throw new ApiError('Повторяющиеся поля входа', 401);
  const supplied = params.get('hash') || '';
  if (!/^[a-f0-9]{64}$/.test(supplied)) throw new ApiError('Неверная подпись Telegram', 401);
  const authDate = Number(params.get('auth_date'));
  const now = Date.now()/1000;
  if (!authDate || !Number.isFinite(authDate) || now-authDate > 3600 || authDate > now+30) throw new ApiError('Открой приложение заново в Telegram', 401);
  params.delete('hash');
  const check = [...params].sort(([a], [b]) => a<b ? -1 : a>b ? 1 : 0).map(([k,v]) => `${k}=${v}`).join('\n');
  const secret = await hmac(encoder.encode('WebAppData'), env.TELEGRAM_BOT_TOKEN);
  if (!equal(hex(await hmac(secret, check)), supplied)) throw new ApiError('Неверная подпись Telegram', 401);
  let user;
  try { user = JSON.parse(params.get('user') || 'null'); } catch { throw new ApiError('Неверные данные Telegram', 401); }
  if (!user || !Number.isSafeInteger(user.id) || user.id <= 0) throw new ApiError('Нет пользователя Telegram', 401);
  return {id:`tg:${user.id}`, name:String(user.first_name || 'Участник').slice(0,60), mode:'beta'};
}
async function snapshot(db, id) {
  const user = await db.prepare('SELECT name,timezone,mode FROM users WHERE id=?').bind(id).first();
  if (!user) throw new ApiError('Сначала открой кошелёк');
  const history = (await db.prepare('SELECT day,steps,source,updated FROM days WHERE user_id=? ORDER BY day DESC LIMIT 90').bind(id).all()).results;
  const sum = await db.prepare('SELECT COALESCE(SUM(CAST(MIN(steps,10000)/1000 AS INTEGER)*10),0) AS coins FROM days WHERE user_id=?').bind(id).first();
  const today = localDay(user.timezone);
  const steps = history.find(row => row.day === today)?.steps || 0;
  const devices = (await db.prepare('SELECT platform FROM pairings WHERE user_id=? AND device_hash IS NOT NULL').bind(id).all()).results;
  return {user, today, steps, todayCoins:coins(steps), balance:sum?.coins || 0, history, devices, botConnected:true};
}
async function route(request, env, url) {
  const path = url.pathname;
  if (path === '/api/health' && request.method === 'GET') {
    const db = database(env);
    await db.prepare('SELECT id FROM users LIMIT 1').all();
    return {ok:true, version:'0.1.1', botConfigured:Boolean(env.TELEGRAM_BOT_TOKEN)};
  }
  if (path === '/api/wallet' && ['GET','POST'].includes(request.method)) {
    const user = await identity(request, env);
    const db = database(env);
    if (request.method === 'GET') {
      await db.prepare('INSERT INTO users(id,name,timezone,mode,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').bind(user.id, user.name, timezone(url.searchParams.get('timezone')), user.mode, Date.now()).run();
      return snapshot(db, user.id);
    }
    const data = await body(request);
    if (!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first()) throw new ApiError('Сначала открой кошелёк');
    if (data.action !== 'pair') throw new ApiError('Неизвестное действие');
    const code = randomToken();
    const expires = Date.now()+600000;
    await db.batch([
      db.prepare('DELETE FROM pairings WHERE user_id=? AND device_hash IS NULL').bind(user.id),
      db.prepare('INSERT INTO pairings(code_hash,user_id,expires) VALUES(?,?,?)').bind(await digest(code), user.id, expires)
    ]);
    return {code, expires};
  }
  if (path === '/api/device/pair' && request.method === 'POST') {
    const data = await body(request);
    if (typeof data.code !== 'string' || !/^[a-f0-9]{48}$/.test(data.code) || !['android','ios'].includes(data.platform)) throw new ApiError('Неверный код привязки');
    const db = database(env);
    const token = randomToken();
    const codeHash = await digest(data.code);
    const pairing = await db.prepare('UPDATE pairings SET device_hash=?,platform=? WHERE code_hash=? AND expires>? AND device_hash IS NULL RETURNING user_id').bind(await digest(token), data.platform, codeHash, Date.now()).first();
    if (!pairing) {
      const existing = await db.prepare('SELECT expires,device_hash FROM pairings WHERE code_hash=?').bind(codeHash).first();
      if (!existing) throw new ApiError(`Такой код не найден на этом сервере. Проверка ввода: ${codeHash.slice(0,12)}. Перенеси текущий код из Telegram целиком.`, 401);
      if (existing.device_hash !== null) throw new ApiError('Этот код уже использован. Получи новый в Telegram.', 401);
      if (existing.expires <= Date.now()) throw new ApiError('Срок действия этого кода истёк. Получи новый в Telegram.', 401);
      throw new ApiError('Код найден и действует, но сервер не завершил привязку. Повтори попытку.', 503);
    }
    const user = await db.prepare('SELECT timezone FROM users WHERE id=?').bind(pairing.user_id).first();
    return {token, timezone:user?.timezone || 'Europe/Moscow'};
  }
  if (path === '/api/device/steps' && request.method === 'POST') {
    const token = request.headers.get('Authorization')?.replace(/^Bearer /,'') || '';
    if (!/^[a-f0-9]{48}$/.test(token)) throw new ApiError('Привяжи телефон заново', 401);
    const db = database(env);
    const device = await db.prepare('SELECT p.user_id,p.platform,u.timezone FROM pairings p JOIN users u ON u.id=p.user_id WHERE p.device_hash=?').bind(await digest(token)).first();
    if (!device) throw new ApiError('Телефон не привязан', 401);
    const data = await body(request);
    if (!Number.isSafeInteger(data.steps) || data.steps < 0 || data.steps > 100000) throw new ApiError('Неверное количество шагов');
    if (!validDay(data.day, device.timezone)) throw new ApiError('Можно передать шаги за сегодня и шесть предыдущих дней');
    await db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET steps=MAX(days.steps,excluded.steps),updated=excluded.updated,source=excluded.source').bind(device.user_id, data.day, data.steps, Date.now(), `${device.platform}:unverified`).run();
    const row = await db.prepare('SELECT steps FROM days WHERE user_id=? AND day=?').bind(device.user_id, data.day).first();
    return {steps:row.steps, coins:coins(row.steps), status:'beta_unverified'};
  }
  if (path === '/api/device/revoke' && request.method === 'POST') {
    const user = await identity(request, env);
    await database(env).prepare('DELETE FROM pairings WHERE user_id=?').bind(user.id).run();
    return {ok:true};
  }
  if (path === '/api/telegram/webhook' && request.method === 'POST') {
    const expected = env.TELEGRAM_WEBHOOK_SECRET;
    const supplied = request.headers.get('X-Telegram-Bot-Api-Secret-Token') || '';
    if (!expected || !equal(expected, supplied)) throw new ApiError('Unauthorized', 401);
    const update = await body(request, 32768);
    const message = update.message;
    if (!message || message.chat?.type !== 'private' || !Number.isSafeInteger(message.chat?.id)) return {ok:true};
    const command = String(message.text || '').split(/\s/)[0].split('@')[0];
    if (!['/start','/help','/privacy'].includes(command)) return {ok:true};
    const text = command === '/privacy'
      ? 'Wallker хранит Telegram ID, имя, часовой пояс, даты и число шагов для игровых баллов. GPS и медицинские данные не используются. Телефон можно отключить в разделе «Телефон». Это не удаляет историю на сервере.'
      : 'Добро пожаловать в Wallker Wallet! Открой приложение и раздел «Телефон», получи код и введи его в Android-приложении. WC — игровые баллы бета-версии, без вывода и гарантированного обмена на токены. iPhone пока не выпущен.';
    return {method:'sendMessage', chat_id:message.chat.id, text, reply_markup:{inline_keyboard:[[{text:'Открыть Wallker', web_app:{url:url.origin}}]]}};
  }
  const known = ['/api/health','/api/wallet','/api/device/pair','/api/device/steps','/api/device/revoke','/api/telegram/webhook'];
  throw new ApiError(known.includes(path) ? 'Метод не поддерживается' : 'Не найдено', known.includes(path) ? 405 : 404);
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) {
      if (!env.ASSETS) return new Response('Wallker: интерфейс ещё не загружен', {status:503});
      const original = await env.ASSETS.fetch(request);
      const response = new Response(original.body, original);
      response.headers.set('X-Content-Type-Options', 'nosniff');
      response.headers.set('Referrer-Policy', 'no-referrer');
      return response;
    }
    const origin = request.headers.get('Origin');
    const allowed = new Set([url.origin, ...(env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean)]);
    let status = 200, value;
    try {
      if (origin && !allowed.has(origin)) throw new ApiError('Запрос с другого сайта отклонён', 403);
      if (request.method === 'OPTIONS') {
        if (request.headers.get('Access-Control-Request-Method') && !['GET','POST'].includes(request.headers.get('Access-Control-Request-Method'))) throw new ApiError('Метод не поддерживается', 405);
        const headers = new Headers({'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization, X-Telegram-Init-Data','Access-Control-Max-Age':'600','Vary':'Origin','Cache-Control':'no-store'});
        if (origin) headers.set('Access-Control-Allow-Origin', origin);
        return new Response(null, {status:204, headers});
      }
      value = await route(request, env, url);
    } catch (error) {
      status = error instanceof ApiError ? error.status : 503;
      value = {error:error instanceof ApiError ? error.message : 'Ошибка настройки или выполнения запроса сервера'};
      // No request bodies, initData, pairing codes, tokens, or raw exception contents in logs.
      if (!(error instanceof ApiError)) console.error('Wallker API failed', url.pathname);
    }
    const headers = new Headers({'Content-Type':'application/json; charset=UTF-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Origin'});
    if (origin && allowed.has(origin)) headers.set('Access-Control-Allow-Origin', origin);
    return new Response(JSON.stringify(value), {status, headers});
  }
};
