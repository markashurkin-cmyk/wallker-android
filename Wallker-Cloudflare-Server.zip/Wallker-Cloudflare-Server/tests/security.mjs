import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {Miniflare} from 'miniflare';
import {createInvoice,paymentPrecheck,creditPayment,refundedPayment,buyProduct,shopBalance,reconcilePayments} from '../shop.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),token='123:ISOLATED_SECURITY_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:token,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id,start){const p=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Security test'})});if(start)p.set('start_param',start);const key=createHmac('sha256','WebAppData').update(token).digest();p.set('hash',createHmac('sha256',key).update([...p].sort(([a],[b])=>a<b?-1:1).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return p.toString()}
async function api(path,id=1002,data,device,start){const r=await mf.dispatchFetch('http://localhost'+path,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id,start)}:{}),...(device?{Authorization:'Bearer '+device}:{})},...(data===undefined?{}:{body:JSON.stringify(data)})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const sql of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(sql).run();
 await api('/api/wallet?timezone=Europe%2FMoscow',1001);await api('/api/wallet?timezone=Europe%2FMoscow',1002);
 const code=(await api('/api/friends',1002)).value.code;await api('/api/wallet?timezone=Europe%2FMoscow',1003,undefined,undefined,'ref_'+code);
 const today=(await api('/api/wallet',1003)).value.today,day=n=>new Date(Date.parse(today+'T12:00:00Z')-n*86400000).toISOString().slice(0,10);
 const pair=(await api('/api/wallet',1003,{action:'pair'})).value.code;
 const pairNonce='a'.repeat(48);const phone=(await api('/api/device/pair',null,{code:pair,platform:'ios',pairNonce})).value.token;
 assert.equal((await api('/api/device/pair',null,{code:pair,platform:'ios',pairNonce})).value.token,phone);assert.equal((await api('/api/device/pair',null,{code:pair,platform:'ios',pairNonce:'b'.repeat(48)})).status,401);
 // Automatic sensor sync credits immediately; replay/concurrency must not double mint.
 const reports=await Promise.all(Array.from({length:4},()=>api('/api/device/steps',null,{day:today,steps:10000},phone)));
 assert.ok(reports.every(r=>r.status===200&&r.value.status==='synced'&&r.value.coins===4000));
 let w=(await api('/api/wallet',1003)).value;assert.equal(w.todayCoins,4000);assert.equal(w.levels.totalSteps,10000);assert.equal(w.pendingSteps.length,0);
 assert.equal((await api('/api/device/steps',null,{day:today,steps:5000},phone)).value.coins,4000);
 assert.equal((await api('/api/device/steps',null,{day:today,steps:100001},phone)).status,400);
 assert.equal((await api('/api/levels/claim',1003,{level:2})).status,409);
 assert.equal((await api('/api/device/tap',null,{count:1,requestId:'forbidden_device_tap'},phone)).status,410);
 assert.equal((await api('/api/admin/security',1001,{action:'approve',userId:'tg:1003',day:today,expectedSteps:10000})).status,400);
 assert.equal((await api('/api/wallet',1002)).value.referralMultiplier,1.01);
 // Simulate elapsed calendar days; no production time override exists.
 await db.prepare('UPDATE users SET created=? WHERE id=?').bind(Date.now()-4*86400000,'tg:1003').run();await db.prepare('UPDATE referrals SET created=? WHERE invitee=?').bind(Date.now()-4*86400000,'tg:1003').run();
 for(let i=1;i<3;i++){const r=await api('/api/device/steps',null,{day:day(i),steps:5000},phone);assert.equal(r.status,200);assert.equal(r.value.status,'synced');assert.ok(r.value.coins>0);}
 assert.equal((await api('/api/wallet',1002)).value.referralMultiplier,1.01);
 // Zero awards never create a fresh receipt; reset still follows Moscow server day.
 const tapDay=(await api('/api/wallet',1002)).value.tapDay;
 await db.prepare('UPDATE tap_daily_paid SET units=101000 WHERE user_id=? AND day=?').bind('tg:1002',tapDay).run();
 for(let i=0;i<12;i++){const r=await api('/api/tap',1002,{count:50,requestId:'zero_limit_request_'+i});assert.equal(r.status,200);assert.equal(r.value.accepted,0)}
 assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM tap_receipts WHERE user_id=?').bind('tg:1002').first()).n,0);
 const freeze={action:'freeze',userId:'tg:1003',frozen:true,reason:'Test anomaly'};assert.equal((await api('/api/admin/security',1001,freeze)).status,200);
 assert.equal((await api('/api/device/steps',null,{day:today,steps:11000},phone)).status,423);assert.equal((await api('/api/levels/claim',1003,{level:2})).status,423);assert.equal((await api('/api/wallet',1002)).value.referralMultiplier,1.01); // Growth preserves attributed Total during a freeze.
 assert.equal((await api('/api/admin/security',1001,{...freeze,frozen:false})).status,200);
 // Exactly one invoice call and a bounded reservation allow a new checkout.
 const env={TELEGRAM_BOT_TOKEN:token,STARS_PAYMENTS_ENABLED:'true'},topup={credits:100,termsAccepted:true,requestId:'security_invoice_001'};let calls=0;
 for(let i=0;i<25;i++)await createInvoice(db,'tg:1002',topup,env,async()=>{calls++;return 'https://t.me/invoice/local'});assert.equal(calls,1);
 const order='1002_'+topup.requestId,payment={invoice_payload:order,currency:'XTR',total_amount:100,telegram_payment_charge_id:'TEST_CHARGE_A'},q={...payment,id:'checkout_a',from:{id:1002}};
 assert.equal(await paymentPrecheck(db,q,env),true);assert.equal(await paymentPrecheck(db,{...q,id:'checkout_b'},env),false);await db.prepare('UPDATE shop_checkout_leases SET until=0 WHERE order_id=?').bind(order).run();assert.equal(await paymentPrecheck(db,{...q,id:'checkout_b'},env),true);
 await creditPayment(db,1002,payment,env);await buyProduct(db,'tg:1002',{product:'coins-1000',requestId:'security_purchase_01'});assert.equal(await shopBalance(db,'tg:1002'),1000);
 await refundedPayment(db,1002,payment,env);assert.equal(await shopBalance(db,'tg:1002'),0);assert.equal((await api('/api/wallet',1002)).value.purchaseCoins,0);
 const second=await creditPayment(db,1002,{...payment,telegram_payment_charge_id:'TEST_CHARGE_B'},env);assert.equal(second.refundQueued,true);await refundedPayment(db,1002,{...payment,telegram_payment_charge_id:'TEST_CHARGE_B'},env);assert.equal((await db.prepare('SELECT state FROM shop_extra_charges WHERE charge_id=?').bind('TEST_CHARGE_B').first()).state,'refunded');
 // Recovery discovers a lost paid event and subsequently a refund, idempotently.
 const topup2={...topup,requestId:'security_reconcile01'};await createInvoice(db,'tg:1002',topup2,env,async()=> 'https://t.me/invoice/local2');
 let pages=0;const fake=async(_env,method,data)=>{if(method==='refundStarPayment')return true;assert.equal(method,'getStarTransactions');pages++;return {transactions:pages===1?[{id:'RECOVERY_C',amount:100,source:{type:'user',transaction_type:'invoice_payment',invoice_payload:'1002_'+topup2.requestId,user:{id:1002}}}]:pages===2?[{id:'RECOVERY_C',amount:100,receiver:{type:'user',transaction_type:'invoice_payment',user:{id:1002}}}]:[]}};
 await reconcilePayments(db,env,fake);await reconcilePayments(db,env,fake);assert.equal((await db.prepare('SELECT state FROM shop_orders WHERE id=?').bind('1002_'+topup2.requestId).first()).state,'refunded');
 const correction={action:'correction',userId:'tg:1002',amount:-5,reason:'Исправление ошибочного начисления',requestId:'security_correction01'};const c=await Promise.all(Array.from({length:3},()=>api('/api/admin/security',1001,correction)));assert.ok(c.every(r=>r.status===200));assert.equal((await db.prepare('SELECT SUM(units) AS n FROM admin_grants WHERE user_id=?').bind('tg:1002').first()).n,-500);assert.equal((await api('/api/admin/security',1001,{...correction,requestId:'security_bad_reason01',reason:''})).status,400);
 // Safe diagnostic code only and rate quota; no body/token is stored.
 assert.equal((await api('/api/device/errors',null,{platform:'ios',version:'0.1.1',code:'sensor_unavailable'},phone)).status,200);
 assert.equal((await api('/api/device/errors',null,{version:'0.1.1',code:phone},phone)).status,400);
 for(let i=0;i<31;i++)await api('/api/device/state',null,{},phone);assert.equal((await api('/api/device/state',null,{},phone)).status,429);
 assert.equal((await api('/api/daily',1002)).status,410);
 assert.equal((await api('/api/daily',1002,{day:today,picked:[0,1,2]})).status,410);
 // Recall is scoped to the owner's original grant and cannot exceed its remaining amount.
 await api('/api/wallet',1004);
 const original={userId:'tg:1004',amount:100,requestId:'original_grant_recall_001'};
 assert.equal((await api('/api/admin/grants',1001,original)).status,200);
 const revoke={action:'revoke',userId:'tg:1004',originalRequestId:original.requestId,amount:20,reason:'Ошибочная тестовая выдача',requestId:'recall_grant_exactly_once_01'};
 const recalls=await Promise.all(Array.from({length:4},()=>api('/api/admin/grants',1001,revoke)));
 assert.ok(recalls.every(r=>r.status===200));assert.equal((await api('/api/wallet',1004)).value.balance,80);
 assert.equal((await api('/api/admin/grants',1002,revoke)).status,403);
 assert.equal((await api('/api/admin/grants',1001,{...revoke,requestId:'recall_too_much_0000001',amount:90})).status,409);
 assert.equal((await api('/api/admin/grants',1001,{...revoke,amount:25})).status,409);
 const history=(await api('/api/admin/grants?userId=tg:1004',1001)).value;assert.equal(history.grants[0].reversed,20);
 await db.prepare('INSERT INTO admin_grants(admin_id,request_id,user_id,units,created) VALUES(?,?,?,?,?)').bind('tg:2001','another_admin_grant_0001','tg:1004',10000,Date.now()).run();
 assert.equal((await api('/api/admin/grants',1001,{...revoke,requestId:'recall_wrong_owner_00001',originalRequestId:'another_admin_grant_0001'})).status,409);
 assert.equal((await api('/api/admin/grants',1001,{...revoke,requestId:'recall_remaining_0000001',amount:80})).status,200);
 assert.equal((await api('/api/admin/grants',1001,{...revoke,requestId:'recall_over_final_000001',amount:.01})).status,409);
 const bilingualQuest={title:'Тестовый квест',description:'Пройди сто шагов',title_en:'Test walking quest',description_en:'Walk one hundred steps',kind:'steps',reward:10,target:100,starts:Date.now()-1000,ends:Date.now()+86400000,status:'published'};
 const quest=(await api('/api/admin/campaigns',1001,bilingualQuest));assert.equal(quest.status,200);
 const published=(await api('/api/wallet',1003)).value.campaigns.find(t=>t.id===quest.value.id);assert.equal(published.title_en,bilingualQuest.title_en);assert.equal(published.description_en,bilingualQuest.description_en);
 assert.equal((await api('/api/campaigns/claim',1003,{id:quest.value.id})).status,200);
 assert.equal((await api('/api/admin/campaigns',1001,{...bilingualQuest,id:quest.value.id,description_en:'Different rules'})).status,409);
 assert.equal((await api('/api/account/delete',1003,{confirm:true})).status,200);assert.equal((await api('/api/device/state',null,{},phone)).status,401);assert.equal((await api('/api/admin/security',1002,{action:'delete-account',userId:'tg:1003',confirm:true})).status,403);assert.equal((await api('/api/admin/security',1001,{action:'delete-account',userId:'tg:1003',confirm:true})).status,200);assert.equal(await db.prepare('SELECT id FROM users WHERE id=?').bind('tg:1003').first(),null);
 console.log('PASS: automatic step rewards are immediate and atomic, replay-safe and capped for rank progression; immediate referrals, freeze/revocation, device scope, zero receipts, cached invoices, bounded checkout retry, refund debt suspension, extra-charge refund queue, payment reconciliation, diagnostic quotas disabled daily game, scoped partial grant recalls and frozen bilingual quest rules.');
}finally{await mf.dispose()}
