plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
val signingNames = listOf("WALLKER_KEYSTORE_PATH", "WALLKER_KEYSTORE_PASSWORD", "WALLKER_KEY_ALIAS", "WALLKER_KEY_PASSWORD")
val signingValues = signingNames.associateWith { System.getenv(it)?.takeIf(String::isNotBlank) }
val hasReleaseSigning = signingValues.values.all { it != null }
android {
    namespace = "com.wallker.wallet"
    compileSdk = 36
    buildToolsVersion = "36.0.0"
    defaultConfig { applicationId = "com.wallker.wallet"; minSdk = 28; targetSdk = 36; versionCode = 3; versionName = "0.3.0" }
    signingConfigs {
        if (hasReleaseSigning) create("wallkerRelease") {
            storeFile = file(signingValues.getValue("WALLKER_KEYSTORE_PATH")!!)
            storePassword = signingValues.getValue("WALLKER_KEYSTORE_PASSWORD")
            keyAlias = signingValues.getValue("WALLKER_KEY_ALIAS")
            keyPassword = signingValues.getValue("WALLKER_KEY_PASSWORD")
        }
    }
    buildTypes {
        getByName("release") {
            isDebuggable = false
            isMinifyEnabled = false
            if (hasReleaseSigning) signingConfig = signingConfigs.getByName("wallkerRelease")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
// Debug builds need no secrets. Never distribute an unsigned release by mistake.
gradle.taskGraph.whenReady {
    if (allTasks.any { it.project.path == ":app" && (it.name == "assembleRelease" || it.name == "bundleRelease") }) {
        check(hasReleaseSigning) { "Release signing missing. Configure the four WALLKER_* signing variables; never commit a keystore or passwords." }
        check(file(signingValues.getValue("WALLKER_KEYSTORE_PATH")!!).isFile) { "Release keystore file is missing." }
    }
}
dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.0")
    implementation("androidx.work:work-runtime-ktx:2.10.1")
}
