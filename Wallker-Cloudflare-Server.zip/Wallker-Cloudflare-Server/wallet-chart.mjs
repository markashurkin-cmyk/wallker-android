export async function walletChart(db,id,today,timezone){
 const start=new Date(today+'T12:00:00Z');start.setUTCDate(start.getUTCDate()-6);const from=start.toISOString().slice(0,10);
 const rows=await db.batch([
  db.prepare('SELECT day,units/100.0 AS coins FROM step_rewards WHERE user_id=? AND day>=? AND day<=?').bind(id,from,today),
  db.prepare('SELECT day,units/100.0 AS coins FROM tap_daily_paid WHERE user_id=? AND day>=? AND day<=?').bind(id,from,today),
  db.prepare('SELECT a.units/100.0 AS coins,r.created FROM tap_awards a JOIN tap_receipts r ON r.user_id=a.user_id AND r.request_id=a.request_id WHERE a.user_id=? AND r.applied=1 AND r.created>=?').bind(id,start.getTime()-2*86400000),
  db.prepare("SELECT reward AS coins,COALESCE(reviewed,created) AS created FROM campaign_claims WHERE user_id=? AND state='approved' AND COALESCE(reviewed,created)>=? UNION ALL SELECT units/100.0 AS coins,created FROM level_claims WHERE user_id=? AND created>=? UNION ALL SELECT units/100.0 AS coins,created FROM admin_grants WHERE user_id=? AND created>=? UNION ALL SELECT units/100.0 AS coins,created FROM shop_game_awards WHERE user_id=? AND created>=? AND NOT EXISTS(SELECT 1 FROM shop_accounts a WHERE a.user_id=shop_game_awards.user_id AND a.credits<0)").bind(id,start.getTime()-2*86400000,id,start.getTime()-2*86400000,id,start.getTime()-2*86400000,id,start.getTime()-2*86400000)
 ]);
 const days=Array.from({length:7},(_,i)=>{const d=new Date(from+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+i);return {day:d.toISOString().slice(0,10),coins:0}});
 const formatter=new Intl.DateTimeFormat('sv-SE',{timeZone:timezone}),moscow=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow'});
 // Receipt timestamps place new tap awards on the chart's calendar. Legacy
 // daily rows retain only their residual, excluding timezone-cutover copies.
 const taps=rows[2].results;
 const legacy=rows[1].results.map(r=>({...r,coins:Math.max(0,r.coins-taps.filter(t=>formatter.format(new Date(t.created))===r.day||moscow.format(new Date(t.created))===r.day).reduce((sum,t)=>sum+t.coins,0))}));
 for(const row of [...rows[0].results,...legacy,...[...taps,...rows[3].results].map(r=>({...r,day:formatter.format(new Date(r.created))}))]){const day=days.find(d=>d.day===row.day);if(day)day.coins=Math.round((day.coins+row.coins)*10000)/10000;}
 return days;
}
