# Walker achievement artwork

Eight outfits were created with the built-in image generation tool, using the project's `assets/wolf-level-1.png` and `assets/wolf-level-7.png` as identity/style references. Recruiter and Pack Builder reuse the original full-body art (`wolf-level-1.png` and `wolf-level-2.png`). No external mascot or partner brand is used.

Final project assets: `assets/growth/{alpha-outfit,leader-badge,creator-wolf,pro-frame,influencer-skin,wolf-influencer,ambassador-profile,legend-badge}.webp`. The build copies them to `/growth/`. Transparent PNG originals remain in the generation workspace; WebP encoding preserves dimensions and alpha, without cropping, drawing or background replacement. Images contain no interface text and work in both languages.

`prompts.json` records the identity brief and outfit prompt set. The two initial Alpha/Legend descriptions summarize their generation briefs; the other six contain the exact prompts. `src/growth-art.ts` maps stable earned server keys to local art; unknown custom keys fall back to Recruiter. Frame decoration is CSS with reduced-motion support. These are profile achievement cosmetics, not new reward rules or automatic replacement of walking-rank mascots.
