import {qualifiedFixture,trustedFixture} from './fixtures.mjs';
import assert from 'node:assert/strict';
import {createHmac,createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {Miniflare} from 'miniflare';
import {ensureReferrals} from '../referrals.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),token='123:LOCAL_CLANS';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:token,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id,start=''){const p=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Игрок '+id}),...(start?{start_param:start}:{})}),key=createHmac('sha256','WebAppData').update(token).digest();p.set('hash',createHmac('sha256',key).update([...p].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return p.toString()}
async function api(path,id=1002,data,start=''){const r=await mf.dispatchFetch('http://localhost'+path,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id,start)}:{})},...(data===undefined?{}:{body:JSON.stringify(data)})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])assert.equal((await api('/api/wallet',id)).status,200);
 const first=(await api('/api/tap',1002,{requestId:'before_referral_taps1',count:3})).value;assert.equal(first.tapCoins,.3);
 const code=(await api('/api/friends')).value.code;
 async function qualify(id){await api('/api/wallet',id,undefined,'ref_'+code);}
 await qualify(1004);
 let state=(await api('/api/wallet')).value;assert.equal(state.referralMultiplier,1.01);assert.equal(state.tapReward,.101);assert.equal(state.tapDailyLimit,1010);assert.equal(state.rewardSettings.stepReward,.404);assert.equal(state.rewardSettings.stepDailyLimit,4040);assert.equal(state.bonusCoins,0);assert.equal(state.tapCoins,.3);
 const payload={requestId:'fraction_boost_taps_1',count:15,multiplier:99};
 const taps=await Promise.all(Array.from({length:5},()=>api('/api/tap',1002,payload)));assert.ok(taps.every(x=>x.value.tapCoins===1.815));assert.equal((await api('/api/wallet',1004)).value.bonusCoins,0);
 await qualify(1005);assert.equal((await api('/api/wallet')).value.referralMultiplier,1.02);
 for(let id=1006;id<=1013;id++)await qualify(id);
 state=(await api('/api/wallet')).value;assert.equal(state.referralMultiplier,1.10);assert.equal(state.tapReward,.11);assert.equal(state.tapDailyLimit,1100);assert.equal(state.tapCoins,1.815);
 await api('/api/tap',1002,payload);assert.equal((await api('/api/wallet')).value.tapCoins,1.815); // replay freezes old multiplier
 const phone='b'.repeat(48);await db.prepare('INSERT INTO pairings(code_hash,user_id,expires,device_hash,platform) VALUES(?,?,?,?,?)').bind('host-phone','tg:1002',Date.now(),createHash('sha256').update(phone).digest('hex'),'ios').run();
 const sync=()=>mf.dispatchFetch('http://localhost/api/device/steps',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+phone},body:JSON.stringify({day:state.today,steps:10000,multiplier:999})});
 assert.equal((await sync()).status,200);assert.equal((await api('/api/wallet')).value.todayCoins,4400);await sync();assert.equal((await api('/api/wallet')).value.todayCoins,4400);
 await db.prepare('UPDATE tap_daily_paid SET units=? WHERE user_id=? AND day=?').bind(109999.99,'tg:1002',state.tapDay).run();
 const capped=await Promise.all(Array.from({length:4},(_,i)=>api('/api/tap',1002,{count:10,requestId:'fraction_cap_concur_'+i})));
 assert.equal(capped.reduce((n,r)=>n+r.value.accepted,0),1);assert.equal((await api('/api/wallet')).value.tapTodayCoins,1100);
 await api('/api/admin/levels',1001,{level:11}); // owner can select a test rank
 await db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET steps=excluded.steps').bind('tg:1002',state.today,45000,Date.now(),'ios:unverified').run();
 await trustedFixture(db,'tg:1002',45000);const rank=await api('/api/levels/claim',1002,{level:2});assert.equal(rank.value.coins,55);assert.equal((await api('/api/levels/claim',1002,{level:2})).value.coins,55);
 // A legacy fixed award remains in the balance and grants exactly one new qualification.
 await api('/api/wallet',1900);await db.prepare('INSERT INTO referrals(invitee,inviter,created) VALUES(?,?,?)').bind('tg:1901','tg:1900',Date.now()).run();await db.prepare("INSERT INTO campaign_claims(campaign_id,user_id,state,reward,created) VALUES(?,'tg:1900','approved',500,?)").bind('referral:tg:1901:host',Date.now()).run();await ensureReferrals(db);await ensureReferrals(db);const legacy=(await api('/api/wallet',1900)).value;assert.equal(legacy.bonusCoins,500);assert.equal(legacy.referralMultiplier,1.01);
 assert.equal((await api('/api/clans',null)).status,401);
 const clan={action:'create',name:'Ночная стая',description:'Шагаем вместе',requestId:'create_clan_replay_01'};
 const created=await Promise.all(Array.from({length:4},()=>api('/api/clans',1002,clan)));assert.ok(created.every(x=>x.status===200));assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM clans WHERE archived=0').first()).n,1);
 let c=(await api('/api/clans')).value;assert.equal(c.clan.isOwner,true);assert.equal(c.members.length,1);
 await api('/api/clans',1001,{action:'join',code:c.clan.id});const divine=(await api('/api/clans')).value.members.find(m=>m.id==='tg:1001');assert.equal(divine.level,11);await api('/api/clans',1001,{action:'leave'});
 const before=(await api('/api/wallet',1003)).value.balance,outsider=(await api('/api/clans',1003)).value;assert.equal(outsider.clan,null);assert.deepEqual(outsider.members,[]);assert.equal(outsider.directory[0].members,1);
 assert.equal((await api('/api/clans',1003,{...clan,requestId:'duplicate_name_clan1'})).status,409);
 assert.equal((await api('/api/clans',1003,{action:'join',code:c.clan.id,userId:'tg:1004'})).status,200);assert.equal((await api('/api/wallet',1003)).value.balance,before);assert.equal((await api('/api/wallet',1003)).value.referralMultiplier,1);
 c=(await api('/api/clans')).value;assert.equal(c.members.length,2);assert.equal(c.clan.budget,Math.round(c.members.reduce((n,m)=>n+m.balance,0)*10000)/10000);
 assert.equal((await api('/api/clans',1003,{action:'create',name:'Другая стая',description:'',requestId:'second_clan_attempt1'})).status,409);
 assert.equal((await api('/api/clans',1002,{action:'leave',userId:'tg:1003'})).status,200);assert.equal((await api('/api/clans')).value.clan,null);assert.equal((await api('/api/clans',1003)).value.clan.isOwner,true);
 // Concurrent joins cannot exceed 100 and an account cannot join two clans.
 const id=c.clan.id;for(let i=0;i<105;i++)await db.prepare('INSERT INTO users(id,name,timezone,mode,created) VALUES(?,?,?,?,?)').bind('tg:'+(2000+i),'Участник '+i,'UTC','beta',Date.now()).run();
 const joins=await Promise.all(Array.from({length:105},(_,i)=>api('/api/clans',2000+i,{action:'join',code:id})));assert.equal(joins.filter(x=>x.status===200).length,99);assert.equal((await api('/api/clans',1003)).value.members.length,100);
 await api('/api/clans',1003,{action:'leave'});assert.equal((await api('/api/clans',1003)).value.clan,null);
 assert.equal((await api('/api/clans',1002,{action:'join',code:id})).status,200);
 const stats=(await api('/api/admin/stats/user?id=tg:1002',1001)).value.user;assert.equal(stats.referralMultiplier,1.1);assert.equal(stats.referralPercent,10);
 console.log('PASS: additive 1/2/10 referral boosts, 0.101 WC precision, unchanged old balances, frozen replays, step/tap caps and partial last tap, boosted level awards, legacy migration; clan auth, exact budget, consent boundary, idempotent creation, unique membership, owner succession and concurrent member cap, zero economic effects.');
}finally{await mf.dispose()}
