import {memo} from './runtime.mjs';
import {referralBoost} from './referrals.mjs';
import {rewardSettings,levelTapSettings} from './rewards.mjs';
import {CampaignError} from './campaigns.mjs';
import {LEVELS,DIVINE_LEVEL,walkingLevel} from './level-catalog.mjs';
export async function ensureLevels(db){if(db.schemaReady)return;
 await db.prepare('CREATE TABLE IF NOT EXISTS trusted_step_totals(user_id TEXT PRIMARY KEY,steps INTEGER NOT NULL DEFAULT 0)').run();
 await db.prepare('CREATE TABLE IF NOT EXISTS developer_levels(user_id TEXT PRIMARY KEY,level INTEGER NOT NULL)').run();
 await db.prepare('CREATE TABLE IF NOT EXISTS level_claims(user_id TEXT NOT NULL,level INTEGER NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(user_id,level))').run();
}
export async function levelSnapshot(db,id,allowOverride=false){return memo(db,`level:${id}:${allowOverride}`,async()=>{
 await ensureLevels(db);
 const totalSteps=db.schemaReady?(await db.prepare('SELECT COALESCE(steps,0) AS n FROM trusted_step_totals WHERE user_id=?').bind(id).first())?.n||0:(await db.prepare('SELECT COALESCE(SUM(steps),0) AS n FROM days WHERE user_id=?').bind(id).first()).n;
 const claims=(await db.prepare('SELECT level,units,created FROM level_claims WHERE user_id=?').bind(id).all()).results;
 const natural=walkingLevel(totalSteps);
 const override=allowOverride?(await db.prepare('SELECT level FROM developer_levels WHERE user_id=?').bind(id).first())?.level||null:null;
 const current=override===11?DIVINE_LEVEL:override?LEVELS[override-1]:natural,next=LEVELS[current.level]||null;
 const boost=await referralBoost(db,id),settings=await rewardSettings(db),entries=allowOverride?[...LEVELS,DIVINE_LEVEL]:LEVELS;
 const catalog=entries.map(x=>{const claim=claims.find(c=>c.level===x.level);const base=levelTapSettings(settings,x.level);return {...x,reward:Math.round(x.reward*boost.multiplier*10000)/10000,tapReward:Math.round(base.tapReward*boost.multiplier*10000)/10000,tapDailyLimit:Math.round(base.tapDailyLimit*boost.multiplier*100)/100,unlocked:x.developerOnly?override===11:totalSteps>=x.steps||!!override&&x.level<=override,claimed:x.reward===0||!!claim,claimedCoins:claim?claim.units/100:0,claimedAt:claim?.created||null};});
 return {developerOverride:override,naturalLevel:natural.level,level:current.level,name:current.name,totalSteps,nextSteps:next?.steps??null,remainingSteps:next?Math.max(0,next.steps-totalSteps):0,progress:next?Math.max(0,Math.min(1,(totalSteps-current.steps)/(next.steps-current.steps))):1,coins:claims.reduce((sum,c)=>sum+c.units,0)/100,availableCoins:catalog.filter(c=>c.unlocked&&!c.claimed).reduce((sum,c)=>sum+c.reward,0),catalog};
 });}
export async function claimLevel(db,id,data,allowOverride=false){
 if(!Number.isSafeInteger(data.level)||data.level<2||data.level>LEVELS.length)throw new CampaignError('Выбери уровень от 2 до 10');
 const level=LEVELS[data.level-1];await ensureLevels(db);const boost=await referralBoost(db,id),units=Math.round(level.reward*100*boost.multiplier*100)/100;
 // Unique account/level and server-side step eligibility are evaluated in one write.
 // Concurrent/replayed claims cannot pay twice; claimed awards are frozen.
 await db.prepare(`INSERT OR IGNORE INTO level_claims(user_id,level,units,created) SELECT ?,?,?,? WHERE ${db.schemaReady?'COALESCE((SELECT steps FROM trusted_step_totals WHERE user_id=?),0)':'(SELECT COALESCE(SUM(steps),0) FROM days WHERE user_id=?)'}>=? OR (?=1 AND COALESCE((SELECT level FROM developer_levels WHERE user_id=?),0)>=?)`).bind(id,level.level,units,Date.now(),id,level.steps,allowOverride?1:0,id,level.level).run();
 const receipt=await db.prepare('SELECT units FROM level_claims WHERE user_id=? AND level=?').bind(id,level.level).first();
 if(!receipt)throw new CampaignError('Сначала передай нужное количество шагов с телефона',409);
 return {ok:true,level:level.level,coins:receipt.units/100};
}

export async function setDeveloperLevel(db,id,level){
 if(level!==null&&(!Number.isSafeInteger(level)||level<1||level>11))throw new CampaignError('Выбери уровень от 1 до 10, Божественный Walker или автоматический режим');
 await ensureLevels(db);
 if(level===null)await db.prepare('DELETE FROM developer_levels WHERE user_id=?').bind(id).run();
 else await db.prepare('INSERT INTO developer_levels(user_id,level) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET level=excluded.level').bind(id,level).run();
 return levelSnapshot(db,id,true);
}
