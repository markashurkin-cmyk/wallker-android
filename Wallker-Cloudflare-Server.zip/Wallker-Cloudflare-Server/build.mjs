import {ensureAssets} from './asset-bootstrap.mjs';
await ensureAssets();
import {build} from 'esbuild';
import {mkdir, copyFile} from 'node:fs/promises';
await mkdir('public', {recursive:true});
await build({entryPoints:['src/main.tsx'], outdir:'public', entryNames:'app', bundle:true, minify:true, format:'esm', target:'es2022', jsx:'automatic', jsxImportSource:'./localized', legalComments:'eof'});
await copyFile('src/index.html', 'public/index.html');



await copyFile('assets/bot-avatar.jpg', 'public/bot-avatar.jpg');

for(const i of [1,2]) await copyFile(`assets/wolf-walk-${i}.jpg`, `public/wolf-walk-${i}.jpg`);



await copyFile('assets/volker-vk-steps.png','public/volker-vk-steps.png');

for(const name of ['connected','tasks','friends','wallet']) await copyFile(`assets/wolf-${name}.png`,`public/wolf-${name}.png`);

for(let level=1;level<=11;level++) await copyFile(`assets/wolf-level-${level}.png`,`public/wolf-level-${level}.png`);

for(const name of ['avatar-telegram.jpg','avatar-tiktok.jpg','task-telegram.webp','task-tiktok.webp']) await copyFile('assets/'+name,'public/'+name);

// A separate sample-data preview, with no account authentication or API bypass.
await build({entryPoints:['src/growth-preview.tsx'],outdir:'public',entryNames:'growth-preview',bundle:true,minify:true,format:'esm',target:'es2022',jsx:'automatic',jsxImportSource:'./localized',legalComments:'eof'});
await copyFile('src/growth-preview.html','public/growth-preview.html');
