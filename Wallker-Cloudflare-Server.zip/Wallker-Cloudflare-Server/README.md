# Wallker Wallet — собственный Cloudflare сервер

Подготовлено 3 октября 2026. Сервер и интерфейс проверены локально. Публикация в аккаунте владельца, перенос прежних записей, переключение Telegram-бота и Android APK с новым адресом ещё не выполнены. Текущий APK 0.3.1 продолжает обращаться к старому Sites-серверу.

Этот пакет запускает отдельное приложение и отдельную базу данных. Он не проксирует запросы к Sites, не использует ключи платформы Sites и не изменяет её защиту.

## Первый шаг для владельца

1. В своей панели Cloudflare открой D1 SQL database (обычно Storage & databases → D1).
2. Нажми Create Database, назови новую базу `wallker-wallet`, затем Create.
3. Открой базу и скопируй её Database ID. Это идентификатор базы, не API token.
4. В этом экземпляре `wrangler.jsonc` уже указан Database ID новой базы `wallker-wallet`: `6ceddc00-80eb-4abc-a0b5-a03cec5ddf6a`, полученный со скриншота владельца. Перед публикацией проверь совпадение с базой в своей панели.
5. В консоли именно новой базы выполни содержимое `schema.sql`. SQL создаёт три таблицы и индексы; не удаляет существующие данные. Альтернативный способ после авторизации Wrangler: `npm run db:init`.

## Развёртывание через GitHub

Помести исходники пакета в репозиторий GitHub. Если это папка в общем репозитории, укажи её как Root directory в настройках сборки Cloudflare.

В Cloudflare: Workers & Pages → Create application → Import Git repository. Выбери свой репозиторий, Worker name `wallker-wallet`, build command `npm run build`, deploy command `npx wrangler deploy`. Менеджер пакетов установит зависимости из package.json. Перед публикацией проверь D1 Database ID в исходниках.

Локальный вариант для компьютера с Node 22+: `npm install`, `npm run build`, `npx wrangler login`, `npm run db:init`, `npm run deploy`. Платный тариф не требуется для небольшого теста в пределах бесплатных лимитов; этот пакет не включает его автоматически.

## Подключение бота

В Worker Settings → Variables and Secrets добавь как Secret:

- `TELEGRAM_BOT_TOKEN`: токен именно `wallker_wallet_bot` из BotFather.
- `TELEGRAM_WEBHOOK_SECRET`: отдельная случайная строка длиной не менее 32 символов (буквы, цифры, `_`, `-`).

Секреты не должны быть в исходниках, ZIP, GitHub-файлах, Android APK или сообщениях чата. Публикация не настраивает webhook автоматически. После проверки нового сервера нужно отдельно переключить webhook Telegram на `https://<фактический-адрес-worker>/api/telegram/webhook` с тем же secret_token и обновить кнопку Mini App в BotFather на корень нового Worker. Адрес получаем из панели Cloudflare; он не известен заранее.

Все запросы Telegram к wallet проверяются по подписи initData. ChatGPT-вход и демо-начисления в независимом сервере отсутствуют. При открытии сайта вне Telegram он предлагает открыть Telegram-бота. CORS по умолчанию разрешает только свой адрес; список дополнительных доверенных источников при необходимости задаётся через ALLOWED_ORIGINS, разделитель — запятая.

## Проверка перед переключением

1. `/api/health` должен вернуть JSON с `ok: true` и `botConfigured: true`. Это проверяет наличие таблиц и настройку токена; не подтверждает связь с телефоном.
2. Неверный 48-значный код в `/api/device/pair` должен дать JSON HTTP 401; без токена `/api/device/steps` тоже HTTP 401. Это ожидаемые отказы авторизации.
3. Открой новый адрес как Mini App именно через бота. Создай код и используй APK, собранный с новым адресом.
4. Проверь: привязка, датчик, передача суточной суммы, обновление баланса в Telegram, повторная передача без повторного начисления, отзыв устройства.

Окончательный результат подтверждается на физическом Android. Локальные тесты не доказывают доступность сервера из сети телефона и не проверяют датчик шагов.

## Перенос и эксплуатация

Новая D1 база начинает пустой. История и балансы из Sites пока не перенесены. Не удаляй старый проект или данные. До переключения пользователей согласуй экспорт/импорт; таблицы users/days/pairings имеют совместимые имена и базовые поля, но секреты и доступы переносятся отдельной процедурой. Старые коды привязки не действуют в новой базе без импорта. После переключения создаём свежие коды.

Шаги поступают без полноценной защиты от накрутки. WC — игровые баллы, без денежных выплат, курса, листинга или гарантии дохода. Награда: 10 WC за полную тысячу шагов, максимум 100 WC за день. Синхронизация принимает сегодня и шесть предыдущих дней по фиксированному часовому поясу профиля; повторные суммы объединяются через MAX.

В базе хранятся Telegram ID, имя, часовой пояс, даты/суточные суммы и хеши секретов привязки. Автоматического удаления истории через 90 дней нет: 90 — только лимит отображаемых строк. Отзыв устройства удаляет привязку, не историю. Политику конфиденциальности, удаление аккаунта, мониторинг, резервные копии, ограничение частоты запросов и защиту от накрутки нужно завершить до публичного запуска с большим числом пользователей.

## Состав

- worker.js: API, проверка Telegram, привязка и синхронизация, webhook.
- schema.sql: новая D1 база.
- wrangler.jsonc: привязки D1/статических файлов.
- src/: интерфейс с прежним дизайном.
- public/: уже собранные статические файлы; build пересоздаёт их из src.
- tests/integration.mjs: проверки в локальном Workers runtime с настоящей временной SQLite/D1 базой.

Проверки выполнены: подпись/срок Telegram, однократное потребление кода при двух параллельных запросах, хранение хешей, повторная синхронизация, суточный лимит, окно 7 дней, разделение аккаунтов, отзыв токена, CORS, secret webhook, ограничения тела запроса, JSON-ошибки. Интерфейс успешно собран esbuild.

Официальные инструкции:
- https://developers.cloudflare.com/workers/get-started/dashboard/
- https://developers.cloudflare.com/d1/get-started/
- https://developers.cloudflare.com/workers/ci-cd/builds/git-integration/github-integration/
- https://developers.cloudflare.com/workers/platform/pricing/

## Beta 0.1.2 / Android 0.3.4

The deployed Android application uses this Worker. Same-account pairing preserves the local ledger and merges up to seven server days; preflight never consumes a code. Replacing a device revokes only its old bearer token. Different-account pairing needs Android confirmation. The ledger uses cumulative daily values, and D1 MAX prevents duplicate WC on retransmission.

`BOT_AUTO_SETUP=true` enables one-time deployment-owned Telegram setup when `/api/health` is checked. The target origin is fixed in the source. Setup uses the configured bot token, sets the webhook and default menu, then verifies both via Telegram. An explicit TELEGRAM_WEBHOOK_SECRET is respected; otherwise a domain-specific HMAC secret is derived from the bot token and never returned. A D1 lease and configuration digest prevent repeated setup. No pending updates are dropped. Main App profile launch settings still require BotFather; historic inline buttons remain unchanged.

The test guide is `public/beta-guide.html`, also linked in the Phone screen. Daily rewards: 10 WC per complete 1,000 steps, at most 100 WC/day. Beta data is unverified; no withdrawal, monetary value or token allocation is promised. Use one phone per account in the first test cohort.
