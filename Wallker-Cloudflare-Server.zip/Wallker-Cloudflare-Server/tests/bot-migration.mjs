import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {Miniflare} from 'miniflare';
import {configureBot} from '../worker.js';
import {ensureShop,stampPaymentBots,createInvoice,creditPayment,paymentPrecheck,refundedPayment,refundOrder} from '../shop.mjs';
import {legacyBotEnv,botUsername} from '../bot-config.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),old='111:OLD_LOCAL_ONLY',fresh='222:NEW_LOCAL_ONLY',base={TELEGRAM_BOT_TOKEN:fresh,TELEGRAM_BOT_USERNAME:'walker_wallet_bot',LEGACY_TELEGRAM_BOT_TOKEN:old,LEGACY_TELEGRAM_BOT_USERNAME:'wallker_wallet_bot',STARS_PAYMENTS_ENABLED:'true',TELEGRAM_WEBHOOK_SECRET:'new-local-secret',LEGACY_TELEGRAM_WEBHOOK_SECRET:'old-local-secret'};
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:base});
function auth(token,id=1002){const p=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Участник'})}),key=createHmac('sha256','WebAppData').update(token).digest();p.set('hash',createHmac('sha256',key).update([...p].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return p.toString()}
async function api(path,{token=fresh,data,secret}={}){const r=await mf.dispatchFetch('http://localhost'+path,{method:data===undefined?'GET':'POST',headers:{'X-Telegram-Init-Data':auth(token),'Content-Type':'application/json',...(secret?{'X-Telegram-Bot-Api-Secret-Token':secret}:{})},...(data===undefined?{}:{body:JSON.stringify(data)})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 await ensureShop(db);await db.prepare("INSERT INTO shop_orders(id,user_id,credits,stars,state,charge_id,created) VALUES('old-paid','tg:1002',300,300,'paid','old-charge',?)").bind(Date.now()).run();await db.prepare('INSERT INTO shop_accounts(user_id,credits) VALUES(?,300)').bind('tg:1002').run();
 const oldWallet=await api('/api/wallet',{token:old});assert.equal(oldWallet.status,200);const newWallet=await api('/api/wallet');assert.equal(newWallet.status,200);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM users').first()).n,1);
 assert.equal((await api('/api/wallet',{token:'333:UNRELATED'})).status,401);assert.equal((await api('/api/bot')).value.username,'walker_wallet_bot');assert.ok((await api('/api/friends')).value.referrals.link.startsWith('https://t.me/walker_wallet_bot?'));
 assert.equal((await db.prepare("SELECT bot_id FROM shop_order_bots WHERE order_id='old-paid'").first()).bot_id,'111');assert.equal((await api('/api/shop')).value.credits,300);
 const fakeInvoice=async(e,m,p)=>{assert.equal(e.TELEGRAM_BOT_TOKEN,fresh);assert.equal(m,'createInvoiceLink');return 'https://t.me/invoice/local'};
 await createInvoice(db,'tg:1002',{credits:100,requestId:'migration_new_order1',termsAccepted:true},base,fakeInvoice);
 const payload='1002_migration_new_order1',payment={invoice_payload:payload,currency:'XTR',total_amount:100,telegram_payment_charge_id:'new-charge'};
 assert.equal((await db.prepare('SELECT bot_id FROM shop_order_bots WHERE order_id=?').bind(payload).first()).bot_id,'222');
 assert.equal(await paymentPrecheck(db,{...payment,id:'new-checkout',from:{id:1002}},legacyBotEnv(base)),false);
 assert.equal(await paymentPrecheck(db,{...payment,id:'new-checkout',from:{id:1002}},base),true);
 await assert.rejects(()=>creditPayment(db,1002,payment,legacyBotEnv(base)),/другого бота/);
 await creditPayment(db,1002,payment,base);await creditPayment(db,1002,payment,base);
 assert.equal((await api('/api/shop')).value.credits,400);
 await assert.rejects(()=>refundedPayment(db,1002,{currency:'XTR',total_amount:300,telegram_payment_charge_id:'old-charge'},base),/другого бота/);
 const returned=[];await refundOrder(db,'old-paid',base,async(e,m,p)=>{returned.push([e.TELEGRAM_BOT_TOKEN,m]);return true});assert.deepEqual(returned,[[old,'refundStarPayment']]);assert.equal((await api('/api/shop')).value.credits,100);
 const calls=[],hooks=new Map();const call=async(e,m,d)=>{calls.push({legacy:e.TELEGRAM_BOT_TOKEN===old,method:m,data:d});if(m==='setWebhook'){hooks.set(e.TELEGRAM_BOT_TOKEN,d.url);return true;}if(m==='getMe')return {id:e.TELEGRAM_BOT_TOKEN===old?111:222,username:botUsername(e)};if(m==='getMyName')return {name:'Walker Wallet'};if(m==='getUserProfilePhotos')return {photos:[[{file_id:'local'}]]};if(m==='getWebhookInfo')return {url:hooks.get(e.TELEGRAM_BOT_TOKEN)};if(m==='getChatMenuButton')return {type:'web_app',web_app:{url:'https://wallker-wallet.markashurkin.workers.dev'}};return true};
 assert.equal(await configureBot({...base,DB:db,BOT_AUTO_SETUP:'true'},call),'ready');assert.ok(calls.find(c=>c.legacy&&c.method==='setWebhook').data.url.endsWith('legacy-webhook'));assert.ok(calls.find(c=>!c.legacy&&c.method==='setWebhook').data.url.endsWith('/webhook'));
 const count=calls.length;assert.equal(await configureBot({...base,DB:db,BOT_AUTO_SETUP:'true'},call),'ready');assert.equal(calls.length,count);
 assert.equal(await configureBot({...base,TELEGRAM_BOT_TOKEN:old,TELEGRAM_BOT_USERNAME:'wallker_wallet_bot',DB:db,BOT_AUTO_SETUP:'true'},call),'ready'); // staging the old-token copy does not interrupt the old bot
 const message={message:{message_id:1,chat:{id:1002,type:'private'},from:{id:1002},text:'/start'}};
 assert.equal((await api('/api/telegram/legacy-webhook',{data:message,secret:'new-local-secret'})).status,401);
 assert.equal((await api('/api/telegram/legacy-webhook',{data:message,secret:'old-local-secret'})).status,200);
 assert.equal((await api('/api/telegram/webhook',{data:message,secret:'old-local-secret'})).status,401);
 const leak=JSON.stringify((await api('/api/bot')).value);assert.ok(!leak.includes(old)&&!leak.includes(fresh));
 console.log('PASS: old/new signed identities share one account and balances; dynamic links, legacy payment origin, cross-bot payment/refund rejection, original-bot refund routing; dual secret-protected webhooks, idempotent configuration and no public secrets.');
}finally{await mf.dispose()}
