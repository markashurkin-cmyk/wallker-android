import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {recordStatistics,ensureStatistics} from '../statistics.mjs';
const {Miniflare}=await import(process.env.WALLKER_MINIFLARE_MODULE||'miniflare');
const root=fileURLToPath(new URL('../',import.meta.url)),botToken='12345:LOCAL_STATS_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:botToken,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id,name='Участник',username=''){
 const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:name,username})});
 const secret=createHmac('sha256','WebAppData').update(botToken).digest();
 const check=[...f].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');f.set('hash',createHmac('sha256',secret).update(check).digest('hex'));return f.toString();
}
async function api(path,id=1001,method='GET',data,extra={}){
 const headers={...extra,...(id?{'X-Telegram-Init-Data':auth(id,id===1001?'Владелец':'Друг','friend_'+id)}:{})};
 if(data)headers['Content-Type']='application/json';
 const r=await mf.dispatchFetch('http://localhost'+path,{method,headers,...(data?{body:JSON.stringify(data)}:{})});return {status:r.status,value:await r.json()};
}
try{
 const db=await mf.getD1Database('DB');
 for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])assert.equal((await api('/api/wallet',id)).status,200);
 for(const path of ['/api/admin/stats','/api/admin/stats/users','/api/admin/stats/user?id=tg:1001','/api/admin/stats/errors']){
  assert.equal((await api(path,null)).status,401);
  const r=await api(path,1002);assert.equal(r.status,403);assert.deepEqual(Object.keys(r.value),['error']);
 }
 const now=Date.now(),day=new Date(now).toISOString().slice(0,10);
 // Every award source, legacy taps, zero-balance users and mixed phones.
 await api('/api/admin/stats');
 await db.batch([
  db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?)').bind('tg:1002',day,7500,now,'ios:unverified'),
  db.prepare('INSERT INTO step_rewards(user_id,day,accounted_steps,units) VALUES(?,?,?,?)').bind('tg:1002',day,7500,300000),
  db.prepare('UPDATE tap_paid SET units=155 WHERE user_id=?').bind('tg:1002'),
  db.prepare("INSERT INTO campaign_claims(campaign_id,user_id,state,reward,created) VALUES('stats-bonus','tg:1002','approved',42,?)").bind(now),
  db.prepare("INSERT INTO campaign_claims(campaign_id,user_id,state,reward,created) VALUES('stats-pending','tg:1002','pending',900,?)").bind(now),
  db.prepare('INSERT INTO pairings(code_hash,user_id,expires,device_hash,platform) VALUES(?,?,?,?,?)').bind('stats-code','tg:1002',now,'a'.repeat(64),'ios')
 ]);
 const list=await api('/api/admin/stats/users');assert.equal(list.status,200);assert.equal(list.value.total,3);
 const friend=list.value.users.find(u=>u.id==='tg:1002');assert.equal(friend.balance,3043.55);assert.equal(friend.walkCoins,3000);assert.equal(friend.tapCoins,1.55);assert.equal(friend.bonusCoins,42);assert.equal(friend.steps,7500);assert.equal(friend.ios,1);assert.equal(list.value.users[0].id,'tg:1002');
 const overview=(await api('/api/admin/stats')).value;assert.equal(overview.totals.balance,3043.55);assert.equal(overview.totals.users,3);assert.equal(overview.totals.ios,1);assert.equal(overview.totals.linked,1);assert.equal(overview.totals.walkers,1);assert.equal(overview.retention[7],null);
 for(const q of ['1002','tg:1002','@friend_1002']){assert.equal((await api('/api/admin/stats/users?q='+encodeURIComponent(q))).value.total,1)}
 assert.equal((await api('/api/admin/stats/users?q='+encodeURIComponent("%' OR 1=1 --"))).value.total,0);
 assert.equal((await api('/api/admin/stats/users?q=%25')).value.total,0);
 assert.equal((await api('/api/admin/stats/users?page=2')).value.users.length,0);
 for(const suffix of ['page=0','page=-1','page=1.2','sort=balance%3BDROP'])assert.equal((await api('/api/admin/stats/users?'+suffix)).status,400);
 const detail=await api('/api/admin/stats/user?id=tg:1002');assert.equal(detail.value.user.balance,friend.balance);assert.equal(detail.value.todaySteps,7500);assert.equal(detail.value.history[0].coins,3000);assert.equal(detail.value.claims.length,2);
 assert.equal((await api('/api/admin/stats/user?id=tg:999999')).status,404);
 assert.equal((await api('/api/admin/stats/user?id='+encodeURIComponent('tg:1002 OR 1=1'))).status,400);
 assert.equal((await api('/api/admin/stats',1001,'POST',{})).status,405);
 const start=await db.prepare('SELECT started FROM analytics_meta').first();
 const profile={id:'tg:1002',username:'friend_1002'};
 await recordStatistics(db,{user:profile,event:'wallet',platform:'telegram'},200,'/api/wallet','',now);
 await recordStatistics(db,{user:profile,event:'sync',positiveSteps:true,platform:'ios'},200,'/api/device/steps','',now);
 const daily=await db.prepare('SELECT * FROM analytics_daily WHERE user_id=? AND day=?').bind(profile.id,day).first();assert.ok(daily.opens>=1);assert.equal(daily.syncs,1);
 assert.equal((await db.prepare('SELECT first_sync FROM analytics_profiles WHERE user_id=?').bind(profile.id).first()).first_sync,now);
 const sentSecrets='token=SECRET_TOKEN initData=SECRET_LOGIN code=SECRET_PAIR';
 for(let i=0;i<2;i++)await recordStatistics(db,{user:profile,platform:'ios'},400,'/api/device/steps',sentSecrets,now);
 await recordStatistics(db,{},503,'/api/untrusted-SECRET_PATH',sentSecrets,now);
 const errors=(await api('/api/admin/stats/errors?q=1002')).value;
 const grouped=errors.errors.find(e=>e.path==='/api/device/steps');assert.equal(grouped.count,2);assert.equal(grouped.code,'step_count_invalid');assert.equal(grouped.platform,'ios');assert.equal(grouped.user_id,profile.id);
 const all=(await api('/api/admin/stats/errors')).value;assert.ok(!JSON.stringify(all).includes('SECRET'));assert.ok(all.errors.some(e=>e.path==='/api/other'&&e.status===503));
 const severe=(await api('/api/admin/stats/errors?severity=server')).value;assert.ok(severe.errors.length>0);assert.ok(severe.errors.every(e=>e.status>=500));
 assert.equal((await api('/api/admin/stats/errors?days=999')).status,400);
 // Actual authenticated device validation failures are attributed to the device user.
 const code=(await api('/api/wallet',1002,'POST',{action:'pair'})).value.code;
 const paired=await api('/api/device/pair',null,'POST',{code,platform:'ios'});assert.equal(paired.status,200);
 const rejected=await api('/api/device/steps',null,'POST',{day,steps:-1},{Authorization:'Bearer '+paired.value.token});assert.equal(rejected.status,400);
 // Await the background write through repeated D1 reads, without a timing assumption.
 let logged=false;for(let i=0;i<100&&!logged;i++){const row=await db.prepare('SELECT SUM(count) AS n FROM analytics_errors WHERE user_id=? AND path=?').bind(profile.id,'/api/device/steps').first();logged=row.n>=3;}assert.ok(logged);
 // Viewing private statistics never counts as a new activity/open or changes a balance.
 const before=await db.prepare('SELECT SUM(opens) AS n FROM analytics_daily').first();
 await api('/api/admin/stats');await api('/api/admin/stats/user?id=tg:1002');
 assert.equal((await db.prepare('SELECT SUM(opens) AS n FROM analytics_daily').first()).n,before.n);
 assert.equal((await api('/api/admin/stats/users?q=1002')).value.users[0].balance,3043.55);
 // Mature cohorts; repeated visits count once, distinct activity dates yield D1/D7 retention.
 const today=Date.parse(day);await db.prepare('UPDATE analytics_meta SET started=?,cleaned=?').bind(today-10*86400000,now).run();
 await db.prepare('UPDATE users SET created=? WHERE id=?').bind(today-86400000+100,'tg:1002').run();
 await db.prepare('UPDATE users SET created=? WHERE id=?').bind(today-7*86400000+100,'tg:1003').run();
 await recordStatistics(db,{user:{id:'tg:1003'},event:'wallet',platform:'telegram'},200,'/api/wallet','',now);
 const retained=(await api('/api/admin/stats')).value;assert.equal(retained.retention[1].percent,100);assert.equal(retained.retention[7].percent,100);assert.equal(retained.active[1],3);
 // Legacy tap conversion matches the ordinary wallet and does not include pending rewards.
 await db.batch([db.prepare('DELETE FROM tap_paid WHERE user_id=?').bind('tg:1003'),db.prepare('DELETE FROM tap_reward_baseline WHERE user_id=?').bind('tg:1003'),db.prepare('UPDATE tap_state SET total=123 WHERE user_id=?').bind('tg:1003')]);
 assert.equal((await api('/api/admin/stats/users?q=1003')).value.users[0].tapCoins,123);
 assert.equal((await api('/api/wallet',1003)).value.tapCoins,123);
 // Concurrent errors are aggregated atomically; expired records are removed.
 await Promise.all(Array.from({length:4},()=>recordStatistics(db,{user:profile,platform:'ios'},400,'/api/device/steps','',now)));
 assert.ok((await db.prepare("SELECT SUM(count) AS n FROM analytics_errors WHERE user_id='tg:1002' AND path='/api/device/steps'").first()).n>=7);
 await db.prepare("INSERT INTO analytics_errors(hour,path,status,code,user_id,platform,count,first_at,last_at,version) VALUES(0,'/api/other',400,'invalid_request','','unknown',1,1,1,'old')").run();
 await db.prepare("INSERT INTO analytics_daily(user_id,day,last_seen) VALUES('tg:1002','2000-01-01',1)").run();
 await db.prepare('UPDATE analytics_meta SET cleaned=0').run();
 await recordStatistics(db,{user:profile,event:'wallet'},200,'/api/wallet','',now);
 assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM analytics_errors WHERE hour=0').first()).n,0);
 assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM analytics_daily WHERE day='2000-01-01'").first()).n,0);
 // A statistics storage failure must not break the user's wallet response.
 const worker=(await import('../worker.js')).default;
 const broken={prepare(sql){if(sql.includes('analytics_'))throw new Error('SECRET_DATABASE_ERROR');return db.prepare(sql)},batch(statements){return db.batch(statements)}};
 const tasks=[];const result=await worker.fetch(new Request('http://localhost/api/wallet',{headers:{'X-Telegram-Init-Data':auth(1002)}}),{DB:broken,TELEGRAM_BOT_TOKEN:botToken,ADMIN_TELEGRAM_ID:'1001'},{waitUntil(p){tasks.push(p)}});
 assert.equal(result.status,200);assert.equal((await result.json()).balance,3043.55);await Promise.all(tasks);
 assert.equal(start.started>0,true);
 console.log('PASS: owner-only statistics, exact balances from all reward sources, legacy preservation, user details/search/pagination, SQL input handling, real device error attribution, secret-free grouped errors, UTC activity/retention, private reads without activity or award inflation.');
}finally{await mf.dispose()}
