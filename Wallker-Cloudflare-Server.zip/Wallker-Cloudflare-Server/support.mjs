import {CampaignError} from './campaigns.mjs';
export async function ensureSupport(db){if(db.schemaReady)return;await db.prepare(`CREATE TABLE IF NOT EXISTS support_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,request_id TEXT NOT NULL,message TEXT NOT NULL,created INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,lease_until INTEGER NOT NULL DEFAULT 0,next_try INTEGER NOT NULL DEFAULT 0,delivered INTEGER,UNIQUE(user_id,request_id))`).run()}
function destination(env){const id=String(env.SUPPORT_CHAT_ID||env.ADMIN_TELEGRAM_ID||'');return env.SUPPORT_BOT_TOKEN&&/^-?[1-9][0-9]{0,19}$/.test(id)?id:null}
export async function deliverSupport(db,env,id,send=fetch){
 const chat=destination(env);if(!chat)return false;
 const now=Date.now(),row=await db.prepare("UPDATE support_messages SET state='sending',lease_until=?,attempts=attempts+1 WHERE id=? AND next_try<=? AND (state='pending' OR (state='sending' AND lease_until<=?)) RETURNING *").bind(now+120000,id,now,now).first();if(!row)return false;
 try{
  const user=await db.prepare('SELECT name FROM users WHERE id=?').bind(row.user_id).first();
  const text=`🐺 Walker Wallet · обращение #${row.id}\nОт: ${user?.name||'Пользователь'}\nTelegram ID: ${row.user_id.slice(3)}\n\n${row.message}`;
  const response=await send(`https://api.telegram.org/bot${env.SUPPORT_BOT_TOKEN}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:chat,text}),signal:AbortSignal.timeout(10000)});
  const result=await response.json();if(!response.ok||!result.ok)throw new Error('Support delivery unavailable');
  await db.prepare("UPDATE support_messages SET state='delivered',delivered=?,lease_until=0 WHERE id=? AND state='sending' AND lease_until=?").bind(Date.now(),id,now+120000).run();return true;
 }catch{await db.prepare("UPDATE support_messages SET state='pending',lease_until=0,next_try=? WHERE id=? AND state='sending' AND lease_until=?").bind(Date.now()+Math.min(21600000,30000*2**Math.min(row.attempts,10)),id,now+120000).run();return false}
}
export async function flushSupport(db,env){if(!destination(env))return;await ensureSupport(db);const now=Date.now();const rows=(await db.prepare("SELECT id FROM support_messages WHERE next_try<=? AND (state='pending' OR (state='sending' AND lease_until<=?)) ORDER BY id LIMIT 5").bind(now,now).all()).results;await Promise.all(rows.map(row=>deliverSupport(db,env,row.id)))}
export async function submitSupport(db,env,user,data){
 const text=typeof data.message==='string'?data.message.trim():'';
 if(typeof data.requestId!=='string'||text.length<10||text.length>2000||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(text)||!/^[-a-zA-Z0-9_]{16,80}$/.test(data.requestId||''))throw new CampaignError('Напиши от 10 до 2000 символов',400);
 await ensureSupport(db);if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())throw new CampaignError('Сначала открой кошелёк',400);const existing=await db.prepare('SELECT * FROM support_messages WHERE user_id=? AND request_id=?').bind(user.id,data.requestId).first();
 if(existing&&existing.message!==text)throw new CampaignError('Это обращение уже сохранено с другим текстом',409);
 if(!existing){const now=Date.now();await db.prepare(`INSERT OR IGNORE INTO support_messages(user_id,request_id,message,created) SELECT ?,?,?,? WHERE EXISTS(SELECT 1 FROM users WHERE id=?) AND (SELECT COUNT(*) FROM support_messages WHERE user_id=? AND created>?)<3 AND NOT EXISTS(SELECT 1 FROM support_messages WHERE user_id=? AND created>?)`).bind(user.id,data.requestId,text,now,user.id,user.id,now-86400000,user.id,now-60000).run()}
 const row=await db.prepare('SELECT * FROM support_messages WHERE user_id=? AND request_id=?').bind(user.id,data.requestId).first();
 if(!row)throw new CampaignError('Можно отправить до трёх обращений за 24 часа, с паузой в минуту',429);
 await deliverSupport(db,env,row.id);return supportStatus(db,env,user.id);
}
export async function supportStatus(db,env,id){await ensureSupport(db);return {botConnected:!!destination(env),messages:(await db.prepare('SELECT id,message,created,state FROM support_messages WHERE user_id=? ORDER BY id DESC LIMIT 20').bind(id).all()).results}}
export async function supportInbox(db,env){await ensureSupport(db);return {botConnected:!!destination(env),messages:(await db.prepare('SELECT s.id,s.user_id,s.message,s.created,s.state,s.attempts,u.name FROM support_messages s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 50').all()).results}}
