import {WelcomeGuide} from './welcome-guide';
import './welcome-guide.css';
// Static, explicitly labelled visual fixture. Never authenticates a real account.
import {createRoot} from 'react-dom/client';
import {useState} from 'react';
import {LanguageProvider,LanguageSelect,getLanguage} from './language';
import {MyPack,GrowthProfile} from './growth';
import {Challenges,Campaign} from './campaigns';
import {GrowthAdmin} from './growth-admin';
import {growthDefaults} from '../growth-config.mjs';
import './app.css';
import './growth.css';
const now=Date.now(),rank={rows:[{name:'Walker 15C9D2A1',score:120,rank:1},{name:'Walker A4B2C8D1',score:93,rank:2},{name:'Walker 17C9E2A1',score:81,rank:3}],self:{score:93,rank:2,weeklyChange:null},asOf:now};
const pack={catalog:growthDefaults.milestones,total:147,active:93,multiplier:2.047,eligible:false,trust:'NORMAL',creatorCode:null,creatorThresholds:{total:500,active:100},activeCriteria:{days:2},link:'https://example.invalid/walker-demo',milestones:[{milestone:1,title:'Recruiter',asset:'recruiter',created:now},{milestone:10,title:'Pack Builder',asset:'pack-frame',created:now},{milestone:50,title:'Alpha',asset:'alpha-outfit',created:now},{milestone:100,title:'Pack Leader',asset:'leader-badge',created:now}],next:{count:500,title:'Creator'},remaining:353,founder:{number:18421},seasons:[],history:[],rank};
const questSamples:Campaign[]=[
 {id:'demo-tg',title:'Подпишись на канал Walker',title_en:'Follow the Walker channel',description:'Новости проекта, анонсы и события нашей стаи. Это пример карточки, подписки здесь не проверяются.',description_en:'Project news, announcements and pack events. This is a sample card; subscriptions are not checked here.',kind:'telegram',partner:'Walker Wallet',url:'https://example.invalid/telegram-demo',target:0,reward:200,starts:now-86400000,ends:now+7*86400000,status:'published'},
 {id:'demo-tt',title:'Walker в TikTok',title_en:'Walker on TikTok',description:'Присоединяйся к нашему TikTok. Это пример задания.',description_en:'Follow our TikTok. This is a sample quest.',kind:'tiktok',partner:'Walker Wallet',url:'https://example.invalid/tiktok-demo',target:0,reward:200,starts:now-86400000,ends:now+7*86400000,status:'published'},
 {id:'demo-partner',title:'Знакомься с партнёром',title_en:'Meet our partner',description:'Здесь будут условия согласованного партнёрского задания. Пример без реальных наград.',description_en:'Approved partner quest requirements will appear here. Sample only; no real rewards.',kind:'partner',partner:'Пример партнёра',url:'https://example.invalid/partner-demo',target:0,reward:500,starts:now-86400000,ends:now+7*86400000,status:'published'}
];
const nativeFetch=window.fetch.bind(window);
window.fetch=async(input,options)=>{
 const path=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url,location.origin).pathname;
 if(!path.startsWith('/api/'))return nativeFetch(input,options);
 if(options?.method==='POST')return new Response(JSON.stringify({error:'Visual preview only. Changes are disabled.'}),{status:409,headers:{'Content-Type':'application/json'}});
 let value:any;
 if(path==='/api/growth')value=pack;
 else if(path==='/api/growth/profile')value={pack,profile:{steps:128420,walkingDays:18,activeDays:12,ageDays:24,quests:7,clan:'Moon Walkers',coverageStart:now-12*86400000}};
 else if(path==='/api/growth/leaderboard')value=rank;
 else if(path==='/api/admin/growth')value={settings:{...growthDefaults,revision:1},meta:{backfill_done:1,ranked_at:now},reviews:[],seasons:[],history:[{revision:1,actor:'demo',reason:'Preview fixture',created:now}],audit:[]};
 else return new Response(JSON.stringify({error:'Preview fixture unavailable'}),{status:404});
 return new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json'}});
};
function Demo(){const [view,setView]=useState('pack'),en=getLanguage()==='en';return <main style={{maxWidth:520,margin:'auto',padding:16}}><header className="growth-heading"><strong>Walker Wallet <small style={{fontSize:12,color:"#b4c4af"}}>0.2.31</small></strong><LanguageSelect/></header><p className="growth-founder">{en?'VISUAL PREVIEW · SAMPLE DATA · NO REAL ACCOUNTS':'ВИЗУАЛЬНОЕ ПРЕВЬЮ · ПРИМЕР ДАННЫХ · БЕЗ РЕАЛЬНЫХ АККАУНТОВ'}</p><div className="growth-tabs">{['pack','quests','guide','profile','owner'].map(v=><button key={v} className={'button '+(view===v?'primary':'')} onClick={()=>setView(v)}>{v==='pack'?(en?'MY PACK':'Моя стая'):v==='quests'?(en?'Quests':'Квесты'):v==='guide'?(en?'Guide':'Обучение'):v==='profile'?(en?'PROFILE':'Профиль'):(en?'OWNER':'Разработчик')}</button>)}</div>{view==='guide'?<WelcomeGuide account="visual-preview" forceOpen onDismiss={()=>setView('pack')}/>:view==='pack'?<MyPack/>:view==='quests'?<Challenges tasks={questSamples} reload={async()=>{}}/>:view==='profile'?<GrowthProfile balance={48320} level={4}/>:<GrowthAdmin/>}</main>}
createRoot(document.getElementById('root')!).render(<LanguageProvider><Demo/></LanguageProvider>);
