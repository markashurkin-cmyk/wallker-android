import {GrowthError,growthSettings} from './growth-config.mjs';
import {packSnapshot,profileSnapshot,creatorDashboard,creatorCode,leaderboard,saveGrowthSettings,reviewTrust,trustSignals,growthTick} from './growth.mjs';
import {saveSeason} from './growth-seasons.mjs';
export async function growthRoute(db,user,env,url,method,data){
 const path=url.pathname,now=Date.now();
 if(method==='GET'){
  if(path==='/api/growth')return packSnapshot(db,user.id,env,now);
  if(path==='/api/growth/profile')return {profile:await profileSnapshot(db,user.id,now),pack:await packSnapshot(db,user.id,env,now)};
  if(path==='/api/growth/creator')return creatorDashboard(db,user.id,now);
  if(path==='/api/admin/growth/signals')return trustSignals(db,url.searchParams.get('userId'),now);
  if(path==='/api/growth/leaderboard')return leaderboard(db,user.id,url.searchParams.get('metric')||'global',url.searchParams.get('season'),Number(url.searchParams.get('page')||1),now);
  if(path==='/api/admin/growth'){
   const page=Number(url.searchParams.get('page')||1);if(!Number.isSafeInteger(page)||page<1||page>10000)throw new GrowthError('Invalid page');
   return {settings:await growthSettings(db),meta:await db.prepare('SELECT started,backfill_cursor,backfill_done,ranked_at FROM growth_meta WHERE id=1').first(),
    reviews:(await db.prepare('SELECT * FROM growth_trust ORDER BY updated DESC,user_id LIMIT 50 OFFSET ?').bind((page-1)*50).all()).results,
    seasons:(await db.prepare('SELECT * FROM growth_seasons ORDER BY created DESC LIMIT 50 OFFSET ?').bind((page-1)*50).all()).results,
    history:(await db.prepare('SELECT revision,created,actor,reason FROM growth_settings_history ORDER BY revision DESC LIMIT 50 OFFSET ?').bind((page-1)*50).all()).results,
    audit:(await db.prepare('SELECT * FROM growth_audit ORDER BY id DESC LIMIT 50 OFFSET ?').bind((page-1)*50).all()).results,page};
  }
  if(path==='/api/admin/growth/campaign'){
   const id=url.searchParams.get('id');if(typeof id!=='string'||id.length>80)throw new GrowthError('Invalid campaign');
   const events=(await db.prepare('SELECT event,COUNT(*) AS events,COUNT(DISTINCT user_id) AS uniqueUsers,SUM(verified) AS verifiedEvents FROM growth_campaign_events WHERE campaign_id=? GROUP BY event').bind(id).all()).results;
   const completions=await db.prepare("SELECT COUNT(*) AS completions,COUNT(DISTINCT user_id) AS validUsers FROM campaign_claims WHERE campaign_id=? AND state='approved'").bind(id).first();
   return {events,completions,clientEventsAreUnverified:true,cashPayoutsEnabled:false};
  }
 }
 if(method==='POST'){
  if(path==='/api/growth/creator-code')return creatorCode(db,user.id,data.code,now);
  if(path==='/api/growth/campaign-event'){
   if(!['impression','open','start'].includes(data.event)||typeof data.campaignId!=='string'||data.campaignId.length>80||typeof data.receipt!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.receipt))throw new GrowthError('Invalid campaign event');
   if(!await db.prepare("SELECT id FROM campaigns WHERE id=? AND status='published' AND starts<=? AND ends>?").bind(data.campaignId,now,now).first())throw new GrowthError('Campaign unavailable',404);
   // One unverified client event per user/type/UTC day. Never a paid conversion.
   await db.prepare('INSERT OR IGNORE INTO growth_campaign_events(campaign_id,user_id,event,receipt,created) VALUES(?,?,?,?,?)').bind(data.campaignId,user.id,data.event,new Date(now).toISOString().slice(0,10),now).run();return {ok:true,verified:false};
  }
  if(path==='/api/admin/growth/settings')return {settings:await saveGrowthSettings(db,user.id,data,now)};
  if(path==='/api/admin/growth/season')return saveSeason(db,user.id,data,now);
  if(path==='/api/admin/growth/review')return reviewTrust(db,user.id,data,now);
  if(path==='/api/admin/growth/refresh'){await growthTick(db,now);return {ok:true};}
 }
 throw new GrowthError('Growth endpoint or method unavailable',405);
}
