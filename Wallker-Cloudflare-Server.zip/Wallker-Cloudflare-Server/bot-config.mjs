import {CampaignError} from './campaigns.mjs';
export function botUsername(env={},legacy=false){const value=String((legacy?env.LEGACY_TELEGRAM_BOT_USERNAME:env.TELEGRAM_BOT_USERNAME)||'wallker_wallet_bot').replace(/^@/,'');if(!/^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(value))throw new CampaignError('Проверь имя бота в настройках сервера',503);return value;}
export function botId(env={}){return /^(\d+):/.exec(String(env.TELEGRAM_BOT_TOKEN||''))?.[1]||'';}
export function legacyBotEnv(env){if(!env.LEGACY_TELEGRAM_BOT_TOKEN||env.LEGACY_TELEGRAM_BOT_TOKEN===env.TELEGRAM_BOT_TOKEN)throw new CampaignError('Старый бот не подключён',409);return {...env,TELEGRAM_BOT_TOKEN:env.LEGACY_TELEGRAM_BOT_TOKEN,TELEGRAM_BOT_USERNAME:botUsername(env,true),TELEGRAM_WEBHOOK_SECRET:env.LEGACY_TELEGRAM_WEBHOOK_SECRET||''};}
export function publicBot(env){const username=botUsername(env);return {username,link:`https://t.me/${username}`};}
