import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {Miniflare} from 'miniflare';
import {fileURLToPath} from 'node:url';
import worker from '../worker.js';
const root=fileURLToPath(new URL('../',import.meta.url)),token='123:PERFORMANCE_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB']});
let calls=0;
try{
 const raw=await mf.getD1Database('DB');
 function statement(s){return new Proxy(s,{get(t,k){if(k==='bind')return (...a)=>statement(t.bind(...a));if(['all','run','first','raw'].includes(k))return (...a)=>{calls++;return t[k](...a)};return Reflect.get(t,k)}})}
 const db={prepare:q=>statement(raw.prepare(q)),batch:async s=>{calls++;return raw.batch(s)}};
 const fields=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id:1002,first_name:'Performance'})});const key=createHmac('sha256','WebAppData').update(token).digest();fields.set('hash',createHmac('sha256',key).update([...fields].sort(([a],[b])=>a<b?-1:1).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));
 async function api(path,data){calls=0;const pending=[];const r=await worker.fetch(new Request('http://localhost'+path,{method:data?'POST':'GET',headers:{'X-Telegram-Init-Data':fields.toString(),'Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})}),{DB:db,TELEGRAM_BOT_TOKEN:token},{waitUntil:p=>pending.push(p)});const value=await r.json();await Promise.all(pending);assert.equal(r.status,200,JSON.stringify(value));return {calls,value}}
 await api('/api/wallet');
 const wallet=await api('/api/wallet');const tap=await api('/api/tap',{count:5,requestId:'perf_positive_taps_1'});assert.equal(tap.value.tapCoins,.5);
 await raw.prepare('UPDATE tap_daily_paid SET units=100000 WHERE user_id=?').bind('tg:1002').run();
 const exhausted=await api('/api/tap',{count:5,requestId:'perf_exhausted_taps1'});assert.equal(exhausted.value.accepted,0);
 assert.ok(wallet.calls<=50,`Wallet D1 calls ${wallet.calls}`);assert.ok(tap.calls<=50,`Tap D1 calls ${tap.calls}`);assert.ok(exhausted.calls<=35,`Exhausted D1 calls ${exhausted.calls}`);
 console.log(JSON.stringify({wallet:wallet.calls,tap:tap.calls,exhausted:exhausted.calls}));console.log('PASS: warm request budgets, including telemetry; no full-wallet fetch from tap path.');
}finally{await mf.dispose()}
