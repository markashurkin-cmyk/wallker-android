import {referralBoost} from './referrals.mjs';
import {activeBoosts} from './shop.mjs';
import {levelSnapshot} from './levels.mjs';
import {isAdmin} from './campaigns.mjs';
import {rewardSettings,levelTapSettings} from './rewards.mjs';
export class TapError extends Error {
  constructor(message,status=400){super(message);this.status=status;}
}

export async function ensureTaps(db){if(db.schemaReady)return;
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_limit_state(user_id TEXT PRIMARY KEY,day TEXT NOT NULL,cap INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_state(user_id TEXT PRIMARY KEY,total INTEGER NOT NULL DEFAULT 0,energy INTEGER NOT NULL DEFAULT 100,energy_at INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_paid(user_id TEXT PRIMARY KEY,units INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_daily_paid(user_id TEXT NOT NULL,day TEXT NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,day))').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_awards(user_id TEXT NOT NULL,request_id TEXT NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_daily(user_id TEXT NOT NULL,day TEXT NOT NULL,count INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,day))').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_reward_baseline(user_id TEXT PRIMARY KEY,legacy_total INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS tap_receipts(user_id TEXT NOT NULL,request_id TEXT NOT NULL,requested INTEGER NOT NULL,accepted INTEGER NOT NULL,applied INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))').run();
}
export const moscowTapDay=now=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow'}).format(new Date(now));
export async function tapSnapshot(db,id,now=Date.now(),env={}){
  if(db.schemaReady)return fastSnapshot(db,id,now,env);
  await ensureTaps(db);
  const referral=await referralBoost(db,id),settings=await rewardSettings(db),level=(await levelSnapshot(db,id,isAdmin({id},env))).level,base=levelTapSettings(settings,level),boosts=await activeBoosts(db,id,now),pct=kind=>1+(boosts.find(b=>b.kind===kind)?.strength||0)/100,tapSettings={tapReward:Math.round(base.tapReward*pct('tap')*referral.multiplier*10000)/10000,tapDailyLimit:Math.round(Math.round(base.tapDailyLimit*pct('cap'))*referral.multiplier*100)/100},capacity=Math.round(settings.energyCapacity*pct('energy')),regenMs=settings.energyRegenSeconds*1000;
  await db.prepare('INSERT OR IGNORE INTO tap_state(user_id,energy_at,energy) VALUES(?,?,?)').bind(id,now,capacity).run();
  let row=await db.prepare('SELECT total,energy,energy_at FROM tap_state WHERE user_id=?').bind(id).first();
  await db.prepare('INSERT OR IGNORE INTO tap_reward_baseline(user_id,legacy_total) VALUES(?,?)').bind(id,row.total).run();
  const baseline=await db.prepare('SELECT legacy_total FROM tap_reward_baseline WHERE user_id=?').bind(id).first();
  const day=moscowTapDay(now);
  await db.prepare('INSERT OR IGNORE INTO tap_daily(user_id,day) VALUES(?,?)').bind(id,day).run();
  const daily=await db.prepare('SELECT count FROM tap_daily WHERE user_id=? AND day=?').bind(id,day).first();
  const newTaps=Math.max(0,row.total-baseline.legacy_total);
  await db.prepare('INSERT OR IGNORE INTO tap_paid(user_id,units) VALUES(?,?)').bind(id,baseline.legacy_total*100+newTaps*10).run();
  await db.prepare('INSERT OR IGNORE INTO tap_daily_paid(user_id,day,units) VALUES(?,?,?)').bind(id,day,daily.count*10).run();
  // Timestamped receipts prevent a second allowance when switching calendar zones.
  await db.prepare("UPDATE tap_daily_paid SET units=MAX(units,ROUND(COALESCE((SELECT SUM(a.units) FROM tap_awards a JOIN tap_receipts r ON r.user_id=a.user_id AND r.request_id=a.request_id WHERE a.user_id=? AND r.created>=? AND r.created<?),0),2)) WHERE user_id=? AND day=?").bind(id,Date.parse(day+'T00:00:00+03:00'),Date.parse(day+'T00:00:00+03:00')+86400000,id,day).run();
  const paid=await db.prepare('SELECT units FROM tap_paid WHERE user_id=?').bind(id).first();
  const todayPaid=await db.prepare('SELECT units FROM tap_daily_paid WHERE user_id=? AND day=?').bind(id,day).first();
  // An owner raising an exhausted allowance unlocks a fresh energy bar once.
  await db.batch([db.prepare('UPDATE tap_state SET energy=?,energy_at=? WHERE user_id=? AND EXISTS(SELECT 1 FROM tap_limit_state WHERE user_id=? AND day=? AND cap<=? AND cap<?)').bind(capacity,now,id,id,day,todayPaid.units,tapSettings.tapDailyLimit*100),db.prepare('INSERT INTO tap_limit_state(user_id,day,cap) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET day=excluded.day,cap=excluded.cap').bind(id,day,tapSettings.tapDailyLimit*100)]);
  row=await db.prepare('SELECT total,energy,energy_at FROM tap_state WHERE user_id=?').bind(id).first();
  return {referralMultiplier:referral.multiplier,referralPercent:referral.percent,serverNow:now,tapResetAt:Date.parse(day+'T00:00:00+03:00')+86400000,tapTimezone:'Europe/Moscow',tapDay:day,tapDailyLimit:tapSettings.tapDailyLimit,tapTodayCoins:todayPaid.units/100,tapDailyRemaining:Math.max(0,Math.round((tapSettings.tapDailyLimit-todayPaid.units/100)*10000)/10000),tapReward:tapSettings.tapReward,tapCount:row.total,tapsPerCoin:1/tapSettings.tapReward,tapRemainder:0,tapCoins:paid.units/100,energy:Math.min(capacity,row.energy+Math.max(0,Math.floor((now-row.energy_at)/regenMs))),capacity,regenMs};
}
export async function earnTaps(db,id,data,now=Date.now(),env={}){
  if(!Number.isSafeInteger(data.count)||data.count<1||data.count>50)throw new TapError('Можно передать от 1 до 50 нажатий');
  if(typeof data.requestId!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.requestId))throw new TapError('Неверный номер начисления');
  const previous=await db.prepare('SELECT requested,accepted FROM tap_receipts WHERE user_id=? AND request_id=?').bind(id,data.requestId).first();
  if(previous&&previous.requested!==data.count)throw new TapError('Номер начисления уже использован для другого количества',409);
  const state=await tapSnapshot(db,id,now,env);
  if(!previous&&(state.tapDailyRemaining<=0||state.energy<1))return {...state,accepted:0};
  const day=state.tapDay,rate=Math.round(state.tapReward*10000)/100,cap=Math.round(state.tapDailyLimit*100),capacity=state.capacity,regenMs=state.regenMs;
  // The receipt, energy deduction and balance update commit together. Replayed
  // requests are harmless, including parallel requests from Android and Telegram.
  const available=`MIN(${capacity},energy+MAX(0,CAST((?-energy_at)/${regenMs} AS INTEGER)))`;
  await db.batch([
    db.prepare(`INSERT OR IGNORE INTO tap_receipts(user_id,request_id,requested,accepted,created) SELECT user_id,?,?,MIN(?,${available},MAX(0,CAST((${cap}-(SELECT units FROM tap_daily_paid WHERE user_id=tap_state.user_id AND day=?)+${rate}-0.000001)/${rate} AS INTEGER))),? FROM tap_state WHERE user_id=?`).bind(data.requestId,data.count,data.count,now,day,now,id),
    db.prepare('INSERT OR IGNORE INTO tap_awards(user_id,request_id,units) SELECT user_id,request_id,ROUND(MIN(accepted*?,MAX(0,?-(SELECT units FROM tap_daily_paid WHERE user_id=tap_receipts.user_id AND day=?))),2) FROM tap_receipts WHERE user_id=? AND request_id=?').bind(rate,cap,day,id,data.requestId),
    db.prepare(`UPDATE tap_state SET total=total+(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?),energy=${available}-(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?),energy_at=CASE WHEN ${available}=${capacity} THEN ? ELSE energy_at+MAX(0,CAST((?-energy_at)/${regenMs} AS INTEGER))*${regenMs} END WHERE user_id=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)`).bind(id,data.requestId,now,id,data.requestId,now,now,now,id,id,data.requestId),
    db.prepare('UPDATE tap_daily SET count=count+(SELECT accepted FROM tap_receipts WHERE user_id=? AND request_id=?) WHERE user_id=? AND day=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)').bind(id,data.requestId,id,day,id,data.requestId),
    db.prepare('UPDATE tap_paid SET units=ROUND(units+(SELECT units FROM tap_awards WHERE user_id=? AND request_id=?),2) WHERE user_id=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)').bind(id,data.requestId,id,id,data.requestId),
    db.prepare('UPDATE tap_daily_paid SET units=ROUND(units+(SELECT units FROM tap_awards WHERE user_id=? AND request_id=?),2) WHERE user_id=? AND day=? AND EXISTS(SELECT 1 FROM tap_receipts WHERE user_id=? AND request_id=? AND applied=0)').bind(id,data.requestId,id,day,id,data.requestId),
    db.prepare('UPDATE tap_receipts SET applied=1 WHERE user_id=? AND request_id=? AND applied=0').bind(id,data.requestId)
  ]);
  const receipt=await db.prepare('SELECT requested,accepted FROM tap_receipts WHERE user_id=? AND request_id=?').bind(id,data.requestId).first();
  if(receipt.requested!==data.count)throw new TapError('Номер начисления уже использован для другого количества',409);
  return {...await tapSnapshot(db,id,now,env),accepted:receipt.accepted};
}

async function fastSnapshot(db,id,now,env){
 const referral=await referralBoost(db,id),settings=await rewardSettings(db),level=(await levelSnapshot(db,id,isAdmin({id},env))).level,base=levelTapSettings(settings,level),boosts=await activeBoosts(db,id,now);
 const pct=k=>1+(boosts.find(b=>b.kind===k)?.strength||0)/100;
 const tapReward=Math.round(base.tapReward*pct('tap')*referral.multiplier*10000)/10000,tapDailyLimit=Math.round(base.tapDailyLimit*pct('cap')*referral.multiplier*100)/100,capacity=Math.round(settings.energyCapacity*pct('energy')),regenMs=settings.energyRegenSeconds*1000,day=moscowTapDay(now);
 await db.batch([
 db.prepare('INSERT OR IGNORE INTO tap_state(user_id,energy_at,energy) VALUES(?,?,?)').bind(id,now,capacity),
 db.prepare('INSERT OR IGNORE INTO tap_reward_baseline(user_id,legacy_total) SELECT user_id,total FROM tap_state WHERE user_id=?').bind(id),
 db.prepare('INSERT OR IGNORE INTO tap_paid(user_id,units) SELECT s.user_id,b.legacy_total*100+MAX(0,s.total-b.legacy_total)*10 FROM tap_state s JOIN tap_reward_baseline b ON b.user_id=s.user_id WHERE s.user_id=?').bind(id),
 db.prepare('INSERT OR IGNORE INTO tap_daily(user_id,day) VALUES(?,?)').bind(id,day),
 db.prepare('INSERT OR IGNORE INTO tap_daily_paid(user_id,day,units) SELECT user_id,day,count*10 FROM tap_daily WHERE user_id=? AND day=?').bind(id,day)
 ]);
 const rows=await db.batch([
 db.prepare('UPDATE tap_state SET energy=?,energy_at=? WHERE user_id=? AND EXISTS(SELECT 1 FROM tap_limit_state l JOIN tap_daily_paid d ON d.user_id=l.user_id AND d.day=l.day WHERE l.user_id=? AND l.day=? AND l.cap<=d.units AND l.cap<?)').bind(capacity,now,id,id,day,tapDailyLimit*100),
 db.prepare('INSERT INTO tap_limit_state(user_id,day,cap) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET day=excluded.day,cap=excluded.cap WHERE day<>excluded.day OR cap<>excluded.cap').bind(id,day,tapDailyLimit*100),
 db.prepare('SELECT s.total,s.energy,s.energy_at,p.units AS paid,d.units AS todayPaid FROM tap_state s JOIN tap_paid p ON p.user_id=s.user_id JOIN tap_daily_paid d ON d.user_id=s.user_id AND d.day=? WHERE s.user_id=?').bind(day,id)
 ]);const v=rows[2].results[0];
 return {referralMultiplier:referral.multiplier,referralPercent:referral.percent,serverNow:now,tapResetAt:Date.parse(day+'T00:00:00+03:00')+86400000,tapTimezone:'Europe/Moscow',tapDay:day,tapDailyLimit,tapTodayCoins:v.todayPaid/100,tapDailyRemaining:Math.max(0,Math.round((tapDailyLimit-v.todayPaid/100)*10000)/10000),tapReward,tapCount:v.total,tapsPerCoin:1/tapReward,tapRemainder:0,tapCoins:v.paid/100,energy:Math.min(capacity,v.energy+Math.max(0,Math.floor((now-v.energy_at)/regenMs))),capacity,regenMs};
}
