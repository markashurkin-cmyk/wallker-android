import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Miniflare} from 'miniflare';
import {migrate,requestDB} from '../runtime.mjs';
import {seasonScoreSource} from '../growth-seasons.mjs';
import {growthDefaults} from '../growth-config.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),DAY=86400000,starts=Date.parse('2026-10-15T21:00:00Z'),ends=starts+5*DAY;
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB']});
try{
 const raw=await mf.getD1Database('DB');await migrate(raw);const db=requestDB(raw);
 const events=[];for(let h=0;h<24;h++)for(let i=0;i<10+h*2;i++)events.push({invitee:'tg:'+String(8000000+h*100+i),inviter:'tg:'+String(7000000+h),qualified:starts-2*DAY+(i%6)*DAY,activated:starts-2*DAY+(i%6)*DAY+(i%2?0:1),legacy:i%7===0?1:0,restricted:i%13===0,frozen:i%17===0});
 const people=new Set(events.flatMap(e=>[e.invitee,e.inviter]));
 for(const id of people)await db.prepare("INSERT INTO users(id,name,timezone,mode,created) VALUES(?,'Fixture','Europe/Moscow','beta',?)").bind(id,starts-20*DAY).run();
 for(let at=0;at<events.length;at+=50){const ss=[];for(const e of events.slice(at,at+50)){ss.push(db.prepare('INSERT INTO referral_qualified(invitee,inviter,qualified) VALUES(?,?,?)').bind(e.invitee,e.inviter,e.qualified));if(Number(e.invitee.slice(3))%5!==0)ss.push(db.prepare('INSERT INTO growth_activations(invitee,inviter,activated,legacy,criteria_revision) VALUES(?,?,?,?,1)').bind(e.invitee,e.inviter,e.activated,e.legacy));if(e.restricted)ss.push(db.prepare("INSERT INTO growth_trust(user_id,state,reason,score,updated,actor) VALUES(?,'RESTRICTED','Fixture',0,?,'fixture')").bind(e.invitee,starts));if(e.frozen)ss.push(db.prepare("INSERT INTO abuse_controls(user_id,frozen,reason,updated,admin_id) VALUES(?,1,'Fixture',?,'fixture')").bind(e.invitee,starts));}await db.batch(ss);}
 await db.prepare("INSERT INTO growth_trust(user_id,state,reason,score,updated,actor) VALUES('tg:7000005','RESTRICTED','Fixture',0,?,'fixture')").bind(starts).run();
 await db.prepare("INSERT INTO abuse_controls(user_id,frozen,reason,updated,admin_id) VALUES('tg:7000011',1,'Fixture',?,'fixture')").bind(starts).run();
 const restricted=new Set(events.filter(e=>e.restricted).map(e=>e.invitee)),frozen=new Set(events.filter(e=>e.frozen).map(e=>e.invitee));restricted.add('tg:7000005');frozen.add('tg:7000011');
 function expected(now,config,creator){const groups=new Map();for(const e of events){if(Number(e.invitee.slice(3))%5===0||restricted.has(e.invitee)||frozen.has(e.invitee)||restricted.has(e.inviter)||frozen.has(e.inviter))continue;if(e.legacy===0&&e.activated>=starts&&e.activated<ends&&e.activated<=now)groups.set(e.inviter,(groups.get(e.inviter)||0)+1);}
  if(creator)for(const [id] of groups){const q=events.filter(e=>e.inviter===id&&e.qualified<Math.min(now+1,ends)).length,a=events.filter(e=>e.inviter===id&&Number(e.invitee.slice(3))%5!==0&&e.activated<Math.min(now+1,ends)&&!restricted.has(e.invitee)&&!frozen.has(e.invitee)).length;if(q<config.creatorTotal||a<config.creatorActive)groups.delete(id);}
  return [...groups].map(([subject,score])=>({subject,score})).sort((a,b)=>a.subject.localeCompare(b.subject));}
 let cases=0;for(const limits of [[5,2],[20,10],[40,20]])for(const now of [starts-1,starts,starts+1,starts+2*DAY,ends-1,ends,ends+DAY])for(const creator of [false,true]){
  const config={...growthDefaults,creatorTotal:limits[0],creatorActive:limits[1]},season={starts,ends,rules:JSON.stringify(config)};
  const source=seasonScoreSource(season,now,{...config,creatorTotal:1,creatorActive:1},creator),got=(await db.prepare(source.sql).bind(...source.args).all()).results.sort((a,b)=>a.subject.localeCompare(b.subject));
  assert.deepEqual(got,expected(now,config,creator),JSON.stringify({limits,now,creator}));cases++;
 }
 console.log(`PASS: ${cases} independent season score cases — frozen criteria, exact boundaries, Moscow midnight, missing activations, legacy, restrictions and frozen invitees/inviters.`);
}finally{await mf.dispose();}
