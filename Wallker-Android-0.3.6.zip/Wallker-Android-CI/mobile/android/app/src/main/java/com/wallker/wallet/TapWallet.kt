package com.wallker.wallet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Pending batches survive process death and are isolated by the paired account. */
class TapWallet(context:Context,private val vault:DeviceVault){
    private val prefs=context.getSharedPreferences("wallker-tap-wallet",Context.MODE_PRIVATE)
    var inFlight:String?=null
    private fun key()=vault.accountId() ?: "unpaired"
    private fun state()=try{JSONObject(prefs.getString(key(),"{}") ?: "{}")}catch(_:Exception){JSONObject()}
    private fun save(value:JSONObject){prefs.edit().putString(key(),value.toString()).apply()}
    private fun queue(value:JSONObject)=value.optJSONArray("queue") ?: JSONArray()
    fun pending():Int{val q=queue(state());return (0 until q.length()).sumOf{q.getJSONObject(it).getInt("count")}}
    fun rate():Double=state().optDouble("tapReward",0.1)
    fun capacity():Int=state().optInt("capacity",100)
    fun regenMs():Long=state().optLong("regenMs",1000).coerceAtLeast(1)
    fun remaining():Double=(state().optDouble("tapDailyRemaining",1000.0)-pending()*rate()).coerceAtLeast(0.0)
    fun balance():Double=state().optDouble("balance")+pending()*rate()
    fun energy():Int{val s=state();if(!s.optBoolean("ready"))return 0;val regen=((System.currentTimeMillis()-s.optLong("at",System.currentTimeMillis())).coerceAtLeast(0)/regenMs()).coerceAtMost(capacity().toLong()).toInt();return (minOf(capacity(),s.optInt("energy")+regen)-pending()).coerceAtLeast(0)}
    fun ready()=state().optBoolean("ready")
    fun tap():Boolean{
        if(vault.token()==null||energy()<1||remaining()+0.000001<rate())return false
        val s=state();val q=queue(s);if(q.length()>=100)return false
        var last=if(q.length()>0)q.getJSONObject(q.length()-1)else null
        if(last==null||last.optInt("count")>=50||last.optString("requestId")==inFlight){last=JSONObject().put("requestId",UUID.randomUUID().toString()).put("count",0);q.put(last)}
        last.put("count",last.getInt("count")+1);s.put("queue",q);save(s);return true
    }
    fun next():JSONObject?{val q=queue(state());return if(q.length()==0)null else JSONObject(q.getJSONObject(0).toString())}
    fun commit(response:JSONObject,requestId:String?=null){
        val s=state();val old=queue(s);val q=JSONArray()
        for(i in 0 until old.length()){val item=old.getJSONObject(i);if(item.optString("requestId")!=requestId)q.put(item)}
        for(field in listOf("tapReward","capacity","regenMs","tapDailyRemaining","tapDailyLimit","tapDay")){
            if(response.has(field))s.put(field,response.get(field))
        }
        s.put("queue",q).put("balance",response.getDouble("balance")).put("energy",response.getInt("energy")).put("at",System.currentTimeMillis()).put("ready",true);save(s)
    }
    fun clear(){prefs.edit().remove(key()).apply()}
}
