// Synthetic legacy layouts, not a production dump. No live credentials or APIs.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {Miniflare} from 'miniflare';
import {DDL} from '../schema-ddl.mjs';
import {migrate,requestDB} from '../runtime.mjs';
import {defaults,defaultTapLevels,rewardSettings} from '../rewards.mjs';
import {backfillGrowth,saveGrowthSettings} from '../growth.mjs';
import {growthDefaults} from '../growth-config.mjs';
const now=Date.now(),old=now-120*86400000,id='tg:7101',day='2026-10-12';
const settings={...defaults,tapReward:.17,stepReward:.53,tapDailyLimit:4321,stepDailyLimit:6789,energyCapacity:234,energyRegenSeconds:7,tapLevels:defaultTapLevels().map(x=>({...x,tapDailyLimit:x.tapDailyLimit+123}))};
const legacy=new Set(('users days pairings campaigns campaign_claims mascot_config clans clan_members support_chat support_reads support_chat_meta admin_grants reward_settings reward_settings_history step_rewards developer_levels level_claims support_messages friend_codes friendships shop_accounts shop_orders shop_order_bots shop_payment_meta shop_checkout shop_purchases shop_boosts shop_game_awards referrals referral_qualified tap_limit_state tap_state tap_paid tap_daily_paid tap_awards tap_daily tap_reward_baseline tap_receipts analytics_meta analytics_profiles analytics_daily analytics_errors trusted_step_totals').split(' '));
const preserved=['users','days','pairings','campaigns','campaign_claims','clans','clan_members','friend_codes','friendships','admin_grants','reward_settings','reward_settings_history','step_rewards','developer_levels','level_claims','shop_accounts','shop_orders','shop_order_bots','shop_payment_meta','shop_purchases','shop_boosts','shop_game_awards','tap_limit_state','tap_state','tap_paid','tap_daily_paid','tap_awards','tap_daily','tap_reward_baseline','tap_receipts','support_chat','support_messages','support_reads','analytics_profiles','analytics_daily','analytics_errors','trusted_step_totals'];
const report={type:'synthetic-legacy-migration-rehearsal',created:new Date(now).toISOString(),productionSnapshot:false,cases:[]};
const quote=s=>'"'+s.replaceAll('"','""')+'"';
const canon=rows=>JSON.stringify(rows.map(row=>JSON.stringify(row)).sort());
const fresh=raw=>({prepare:raw.prepare.bind(raw),batch:raw.batch.bind(raw)});
async function run(raw,sql,...args){return raw.prepare(sql).bind(...args).run()}
async function rows(raw,table,columns='*'){return (await raw.prepare(`SELECT ${columns} FROM ${quote(table)}`).all()).results;}
async function capture(raw,tables=preserved){return Object.fromEntries(await Promise.all(tables.map(async table=>[table,canon(await rows(raw,table,table==='campaigns'?'id,title,description,kind,partner,url,target,reward,starts,ends,status,created,updated':'*'))])));}
async function seed(raw,marker=false){
 const ddl=DDL.filter(sql=>{const t=sql.match(/^CREATE TABLE IF NOT EXISTS (\w+)/)?.[1];if(t)return legacy.has(t);const target=sql.match(/\bON (\w+)\(/)?.[1];return !!target&&legacy.has(target)});
 await raw.batch(ddl.map(sql=>raw.prepare(sql)));
 for(const n of [7101,7102,7103])await run(raw,'INSERT INTO users VALUES(?,?,?,?,?)','tg:'+n,"Fixture O’Walker ' 🐺 "+n,'Europe/Moscow','beta',old);
 await run(raw,'INSERT INTO days VALUES(?,?,?,?,?)',id,day,12345,old,'sensor');
 await run(raw,'INSERT INTO days VALUES(?,?,?,?,?)','tg:7102',day,7000,old,'sensor');
 await run(raw,'INSERT INTO days VALUES(?,?,?,?,?)','tg:7102','2026-10-11',5000,old,'sensor');
 await run(raw,'INSERT INTO pairings VALUES(?,?,?,?,?)','fixture-code-hash','tg:7102',old,createHash('sha256').update('fixture-device').digest('hex'),'ios');
 await run(raw,'INSERT INTO campaigns VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)','fixture_quest','Старый квест','История','steps','','',3000,37,old,now+86400000,'published',old,old);
 await run(raw,'INSERT INTO campaign_claims VALUES(?,?,?,?,?,?,?)','fixture_quest',id,'','approved',37,old,old);
 await run(raw,'INSERT INTO campaign_claims VALUES(?,?,?,?,?,?,?)','referral:tg:7103:host',id,'','approved',500,old,old);
 await run(raw,'INSERT INTO referrals VALUES(?,?,?,?,?)','tg:7102',id,old,500,100);
 await run(raw,'INSERT INTO referrals VALUES(?,?,?,?,?)','tg:7103',id,old,500,100);
 await run(raw,'INSERT INTO referral_qualified VALUES(?,?,?)','tg:7102',id,old);
 await run(raw,'INSERT INTO clans VALUES(?,?,?,?,?,?,?)','fixture-clan','Стая','стая','Saved clan',id,old,0);
 await run(raw,'INSERT INTO clan_members VALUES(?,?,?)',id,'fixture-clan',old);
 await run(raw,'INSERT INTO friend_codes VALUES(?,?)',id,'0123456789abcdef0123');
 await run(raw,'INSERT INTO friendships VALUES(?,?,?,?,?)',id,'tg:7102',id,'accepted',old);
 await run(raw,'INSERT INTO admin_grants VALUES(?,?,?,?,?)',id,'fixture_grant_0001',id,98765,old);
 await run(raw,'INSERT INTO reward_settings VALUES(1,?,77)',JSON.stringify(settings));
 await run(raw,'INSERT INTO reward_settings_history VALUES(77,?,?)',JSON.stringify(settings),old);
 await run(raw,'INSERT INTO step_rewards VALUES(?,?,?,?)',id,day,12345,88765.43);
 await run(raw,'INSERT INTO step_rewards VALUES(?,?,7000,280000)','tg:7102',day);
 await run(raw,'INSERT INTO step_rewards VALUES(?,?,5000,200000)','tg:7102','2026-10-11');
 await run(raw,'INSERT INTO developer_levels VALUES(?,11)',id);
 await run(raw,'INSERT INTO level_claims VALUES(?,2,15200,?)',id,old);
 await run(raw,'INSERT INTO shop_accounts VALUES(?,223)',id);
 await run(raw,'INSERT INTO shop_orders VALUES(?,?,?,?,?,?,?)','fixture-order',id,300,300,'paid','FAKE_MIGRATION_CHARGE',old);
 await run(raw,'INSERT INTO shop_order_bots VALUES(?,?)','fixture-order','123');
 await run(raw,"INSERT INTO shop_payment_meta VALUES(1,'123',1)");
 await run(raw,"INSERT INTO shop_purchases VALUES(?,?,'coins-1000',99,'coins',1000,0,?,1)",id,'fixture_purchase_01',old);
 await run(raw,'INSERT INTO shop_game_awards VALUES(?,?,100000,?)',id,'fixture_purchase_01',old);
 await run(raw,"INSERT INTO shop_boosts VALUES(?,'tap',25,?)",id,now+86400000);
 await run(raw,'INSERT INTO tap_limit_state VALUES(?,?,4321)',id,day);
 await run(raw,'INSERT INTO tap_state VALUES(?,200,17,?)',id,now);
 await run(raw,'INSERT INTO tap_reward_baseline VALUES(?,100)',id);
 await run(raw,'INSERT INTO tap_paid VALUES(?,12345.67)',id);
 await run(raw,'INSERT INTO tap_daily_paid VALUES(?,?,345.67)',id,day);
 await run(raw,'INSERT INTO tap_daily VALUES(?,?,20)',id,day);
 await run(raw,'INSERT INTO tap_awards VALUES(?,?,345.67)',id,'fixture_tap_00001');
 await run(raw,'INSERT INTO tap_receipts VALUES(?,?,20,20,1,?)',id,'fixture_tap_00001',now);
 await run(raw,'INSERT INTO trusted_step_totals VALUES(?,12345)',id);
 await run(raw,'INSERT INTO trusted_step_totals VALUES(?,12000)','tg:7102');
 await run(raw,'INSERT INTO support_chat_meta VALUES(1)');
 await run(raw,"INSERT INTO support_chat(user_id,sender,author_id,request_id,message,created) VALUES(?,'user',?,?,?,?)",id,id,'fixture_chat_0001','Сохраните историю 🐺',old);
 await run(raw,"INSERT INTO support_messages(user_id,request_id,message,created,state) VALUES(?,?,?,?,'delivered')",id,'fixture_support_01','Old support',old);
 await run(raw,'INSERT INTO support_reads VALUES(?,1,1)',id);
 await run(raw,"INSERT INTO analytics_profiles VALUES(?,'fixture',?,?,?)",id,old,old,old);
 await run(raw,'INSERT INTO analytics_daily VALUES(?,?,3,2,1,?)',id,day,old);
 await run(raw,"INSERT INTO analytics_errors VALUES(1,'/api/wallet',500,'test',?,'ios',2,?,?,'0.2.18')",id,old,old);
 if(marker){await run(raw,'CREATE TABLE walker_migrations(version INTEGER PRIMARY KEY,created INTEGER NOT NULL)');await run(raw,'INSERT INTO walker_migrations VALUES(21,?)',old);}
}
async function checkpoint(raw){
 assert.equal((await raw.prepare('SELECT value FROM reward_settings WHERE id=1').first()).value,JSON.stringify(settings));
 assert.equal((await raw.prepare('SELECT revision FROM reward_settings WHERE id=1').first()).revision,77);
 assert.equal((await raw.prepare('SELECT COUNT(*) AS n FROM walker_migrations WHERE version IN (21,22)').first()).n,2);
 assert.equal((await raw.prepare('SELECT COUNT(*) AS n FROM growth_settings_history').first()).n,1);
}
async function harness(fn){const mf=new Miniflare({modules:true,script:'export default {fetch(){return new Response("isolated fixture")}}',compatibilityDate:'2026-05-15',d1Databases:['DB']});try{return await fn(await mf.getD1Database('DB'));}finally{await mf.dispose()}}
async function scenario(name,fn){await harness(fn);report.cases.push({name,result:'pass'});console.log('PASS:',name)}
// Same SQL layouts can be exported/restored locally, retaining table, index,
// trigger and AUTOINCREMENT sequence state. No arbitrary user SQL is executed.
async function dump(raw){
 const schema=(await raw.prepare("SELECT type,name,sql FROM sqlite_schema WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_cf_%' AND name NOT LIKE 'd1_%' AND type IN ('table','index','trigger') ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 ELSE 2 END,name").all()).results;
 const tables={};for(const s of schema.filter(s=>s.type==='table'))tables[s.name]=await rows(raw,s.name);
 return {schema,tables,sequence:(await rows(raw,'sqlite_sequence')).sort((a,b)=>a.name.localeCompare(b.name))};
}
async function restore(raw,dump){
 const statements=[raw.prepare('PRAGMA defer_foreign_keys=ON'),...dump.schema.filter(s=>s.type==='table').map(s=>raw.prepare(s.sql))];
 for(const [table,data] of Object.entries(dump.tables))for(const row of data){const keys=Object.keys(row);statements.push(raw.prepare(`INSERT INTO ${quote(table)}(${keys.map(quote).join(',')}) VALUES(${keys.map(()=>'?').join(',')})`).bind(...keys.map(k=>row[k])));}
 statements.push(...dump.schema.filter(s=>s.type!=='table').map(s=>raw.prepare(s.sql)));
 for(const row of dump.sequence)statements.push(raw.prepare('DELETE FROM sqlite_sequence WHERE name=?').bind(row.name),raw.prepare('INSERT INTO sqlite_sequence(name,seq) VALUES(?,?)').bind(row.name,row.seq));
 await raw.batch(statements);
}
try{
 await scenario('Populated pre-marker legacy: balances, rates, limits, devices, receipts and chat preserved',async raw=>{
  await seed(raw);const before=await capture(raw);await migrate(fresh(raw));assert.deepEqual(await capture(raw),before);await checkpoint(raw);
  const first=await dump(raw);await migrate(fresh(raw));assert.deepEqual(await dump(raw),first);
  const db=requestDB(raw);await backfillGrowth(db,now);await backfillGrowth(requestDB(raw),now);assert.equal((await raw.prepare('SELECT total FROM growth_totals WHERE user_id=?').bind(id).first()).total,2);assert.deepEqual(await capture(raw),before);
 });
 await scenario('Pre-Growth migration 21: preserve ledger through migration 22, export and restore',async raw=>{
  await seed(raw,true);const before=await capture(raw);await migrate(fresh(raw));await checkpoint(raw);assert.deepEqual(await capture(raw),before);
  // Deleted Founder IDs must not be recycled after a restore.
  await run(raw,"INSERT INTO growth_founders(number,user_id,season_id,created) VALUES(100,'tg:7999','fixture-founder',?)",old);await run(raw,'DELETE FROM growth_founders WHERE number=100');
  const snapshot=await dump(raw);await harness(async copy=>{await restore(copy,snapshot);await migrate(fresh(copy));assert.deepEqual(await dump(copy),snapshot);assert.deepEqual(await capture(copy),before);await run(copy,"INSERT INTO growth_founders(user_id,season_id,created) VALUES(?,'fixture-founder',?)",id,now);assert.equal((await copy.prepare('SELECT number FROM growth_founders WHERE user_id=?').bind(id).first()).number,101);});
 });
 await scenario('Interrupted Growth initialization resumes once and preserves owner settings',async raw=>{
  await seed(raw,true);const before=await capture(raw);let failed=false,initializing=false;
  await assert.rejects(()=>migrate({prepare(sql){if(sql.startsWith('INSERT OR IGNORE INTO growth_meta'))initializing=true;return raw.prepare(sql)},batch:async statements=>{if(!failed&&initializing){failed=true;throw Error('SIMULATED_INITIALIZATION_FAILURE')}return raw.batch(statements)}}),/SIMULATED_INITIALIZATION_FAILURE/);
  assert.ok(failed);await migrate(fresh(raw));await checkpoint(raw);assert.deepEqual(await capture(raw),before);
  await saveGrowthSettings(requestDB(raw),id,{revision:1,settings:{...growthDefaults,creatorTotal:777,creatorActive:123},reason:'Fixture owner customization'},now);
  await migrate(fresh(raw));assert.equal((await raw.prepare('SELECT revision FROM growth_settings').first()).revision,2);assert.equal(JSON.parse((await raw.prepare('SELECT value FROM growth_settings').first()).value).creatorTotal,777);
 });
 await scenario('Reward settings recover from history rather than resetting to defaults',async raw=>{
  await seed(raw,true);await run(raw,'DELETE FROM reward_settings');await migrate(fresh(raw));const recovered=await rewardSettings(requestDB(raw));assert.equal(recovered.revision,77);assert.equal(recovered.tapDailyLimit,4321);assert.equal(recovered.stepReward,.53);assert.deepEqual(recovered.tapLevels,settings.tapLevels);
 });
 await scenario('Independent cold-start instances safely race on bilingual schema columns',async raw=>{
  await seed(raw);const before=await capture(raw);let readers=0,release;const both=new Promise(r=>release=r);
  const connection=()=>({batch:raw.batch.bind(raw),prepare(sql){const s=raw.prepare(sql);if(sql==='PRAGMA table_info(campaigns)')return {async all(){const result=await s.all();if(readers<2){if(++readers===2)release();await both;}return result}};return s}});
  await Promise.all([migrate(connection()),migrate(connection())]);assert.equal(readers,2);await checkpoint(raw);assert.deepEqual(await capture(raw),before);
 });
 await scenario('Unrelated storage failures surface and a later startup retries safely',async raw=>{
  await seed(raw);const before=await capture(raw);
  await assert.rejects(()=>migrate({batch:raw.batch.bind(raw),prepare(sql){if(sql.startsWith('ALTER TABLE campaigns'))return {async run(){throw Error('SIMULATED_STORAGE_UNAVAILABLE')}};return raw.prepare(sql)}}),/SIMULATED_STORAGE_UNAVAILABLE/);
  assert.equal((await raw.prepare('SELECT COUNT(*) AS n FROM walker_migrations').first()).n,0);
  await migrate(fresh(raw));await checkpoint(raw);assert.deepEqual(await capture(raw),before);
 });
 await writeFile(new URL('../growth-migration-results.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
 console.log('PASS: synthetic migration rehearsal; no production snapshot, database, bot or payment service accessed.');
}catch(error){report.error=String(error);await writeFile(new URL('../growth-migration-results.json',import.meta.url),JSON.stringify(report,null,2)+'\n');throw error}
