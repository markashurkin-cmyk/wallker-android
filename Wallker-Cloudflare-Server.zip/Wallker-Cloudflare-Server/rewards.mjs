import {memo,invalidate} from './runtime.mjs';
import {referralRewardBoost} from './referrals.mjs';
import {CampaignError} from './campaigns.mjs';
export const defaults={tapReward:0.1,stepReward:0.4,tapDailyLimit:1000,stepDailyLimit:4000,energyCapacity:100,energyRegenSeconds:1};
export const defaultTapLevels=()=>Array.from({length:10},(_,i)=>({level:i+2,tapReward:i===9?2:(i+2)/10,tapDailyLimit:i===9?10000:1500+i*500}));
export function levelTapSettings(settings,level){return level===1?{tapReward:settings.tapReward,tapDailyLimit:settings.tapDailyLimit}:settings.tapLevels.find(x=>x.level===level)||{tapReward:settings.tapReward,tapDailyLimit:settings.tapDailyLimit};}
export async function rewardSettings(db){return memo(db,'settings',async()=>{
 if(!db.schemaReady){
 await db.prepare('CREATE TABLE IF NOT EXISTS reward_settings(id INTEGER PRIMARY KEY,value TEXT NOT NULL,revision INTEGER NOT NULL)').run();
 await db.prepare('CREATE TABLE IF NOT EXISTS reward_settings_history(revision INTEGER PRIMARY KEY,value TEXT NOT NULL,created INTEGER NOT NULL)').run();
 }
 await db.prepare('INSERT OR IGNORE INTO reward_settings(id,value,revision) SELECT 1,value,revision FROM reward_settings_history ORDER BY revision DESC LIMIT 1').run();
 await db.prepare('INSERT OR IGNORE INTO reward_settings(id,value,revision) VALUES(1,?,1)').bind(JSON.stringify({...defaults,tapLevels:defaultTapLevels()})).run();
 const row=await db.prepare('SELECT value,revision FROM reward_settings WHERE id=1').first();
 await db.prepare('INSERT OR IGNORE INTO reward_settings_history(revision,value,created) VALUES(?,?,?)').bind(row.revision,row.value,Date.now()).run();
 const value=JSON.parse(row.value);return {...value,tapLevels:value.tapLevels||defaultTapLevels(),revision:row.revision};
 });}
export async function saveRewardSettings(db,data){
 const current=await rewardSettings(db),value={};
 const fields={tapReward:[0.01,100,2],stepReward:[0.01,100,2],tapDailyLimit:[1,1000000,0],stepDailyLimit:[1,1000000,0],energyCapacity:[1,10000,0],energyRegenSeconds:[1,3600,0]};
 for(const [key,[min,max,precision]] of Object.entries(fields)){
  const x=data[key],factor=10**precision;
  if(typeof x!=='number'||!Number.isFinite(x)||x<min||x>max||Math.abs(x*factor-Math.round(x*factor))>1e-7)throw new CampaignError('Проверь значения наград, лимитов и энергии');
  value[key]=x;
 }
 const levels=data.tapLevels===undefined?current.tapLevels:data.tapLevels;
 if(!Array.isArray(levels)||levels.length!==10)throw new CampaignError('Заполни настройки тапов для всех уровней');
 value.tapLevels=levels.map((x,i)=>{
  if(x?.level!==i+2||typeof x.tapReward!=='number'||!Number.isFinite(x.tapReward)||x.tapReward<0.01||x.tapReward>100||Math.abs(x.tapReward*100-Math.round(x.tapReward*100))>1e-7||!Number.isSafeInteger(x.tapDailyLimit)||x.tapDailyLimit<1||x.tapDailyLimit>1000000)throw new CampaignError('Проверь награды и лимиты уровней');
  return {level:x.level,tapReward:x.tapReward,tapDailyLimit:x.tapDailyLimit};
 });
 if(data.revision!==current.revision)throw new CampaignError('Настройки уже изменились. Обнови страницу и повтори.',409);
 const results=await db.batch([
 db.prepare('UPDATE reward_settings SET value=?,revision=revision+1 WHERE id=1 AND revision=? RETURNING revision').bind(JSON.stringify(value),current.revision),
 db.prepare('INSERT OR IGNORE INTO reward_settings_history(revision,value,created) SELECT revision,value,? FROM reward_settings WHERE id=1').bind(Date.now())
 ]);const result=results[0].results[0];
 if(!result)throw new CampaignError('Настройки уже изменились. Обнови страницу и повтори.',409);
 invalidate(db,'settings');return {...value,revision:result.revision};
}
export async function ensureStepRewards(db){if(db.schemaReady)return;
 await db.prepare('CREATE TABLE IF NOT EXISTS step_rewards(user_id TEXT NOT NULL,day TEXT NOT NULL,accounted_steps INTEGER NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,day))').run();
 // Preserve all existing daily awards at the previous deployed rules.
 await db.prepare(`INSERT OR IGNORE INTO step_rewards(user_id,day,accounted_steps,units) SELECT user_id,day,steps,CASE WHEN day<'2026-10-11' THEN CAST(MIN(steps,10000)/1000 AS INTEGER)*1000 ELSE CAST(MIN(steps,10000)*4/10 AS INTEGER)*100 END FROM days`).run();
}
export async function stepRewardStatements(db,id,day,steps,settings){
 await ensureStepRewards(db);
 await db.prepare('INSERT OR IGNORE INTO step_rewards(user_id,day,accounted_steps,units) VALUES(?,?,0,0)').bind(id,day).run();
 if(day<'2026-10-11')return db.prepare('UPDATE step_rewards SET units=MAX(units,CAST(MIN(?,10000)/1000 AS INTEGER)*1000),accounted_steps=MAX(accounted_steps,?) WHERE user_id=? AND day=?').bind(steps,steps,id,day);
 const {multiplier}=await referralRewardBoost(db,id,'steps'),rate=Math.round(settings.stepReward*100*multiplier*100)/100,cap=Math.round(settings.stepDailyLimit*100*multiplier);
 return db.prepare('UPDATE step_rewards SET units=ROUND(units+MIN(MAX(0,?-units),MAX(0,?-accounted_steps)*?),2),accounted_steps=MAX(accounted_steps,?) WHERE user_id=? AND day=?').bind(cap,steps,rate,steps,id,day);
}
