import {createRoot} from 'react-dom/client';
import Wallet from './wallet';
import './app.css';
createRoot(document.getElementById('root')!).render(<Wallet/>);
