import {CampaignError} from './campaigns.mjs';
import {ensureSupport,deliverSupport} from './support.mjs';
export async function ensureChat(db){if(db.schemaReady){await db.batch([
 db.prepare("INSERT OR IGNORE INTO support_chat(user_id,sender,author_id,request_id,message,created) SELECT user_id,'user',user_id,'legacy_'||request_id,message,created FROM support_messages WHERE id>(SELECT last_id FROM support_chat_legacy_cursor WHERE id=1) AND NOT EXISTS(SELECT 1 FROM support_chat c WHERE c.author_id=support_messages.user_id AND c.request_id=support_messages.request_id) ORDER BY id LIMIT 100"),
 db.prepare('UPDATE support_chat_legacy_cursor SET last_id=COALESCE((SELECT MAX(id) FROM (SELECT id FROM support_messages WHERE id>support_chat_legacy_cursor.last_id ORDER BY id LIMIT 100)),last_id) WHERE id=1')]);return;}await ensureSupport(db);await db.batch([
 db.prepare('CREATE TABLE IF NOT EXISTS support_chat(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,sender TEXT NOT NULL,author_id TEXT NOT NULL,request_id TEXT NOT NULL,message TEXT NOT NULL,created INTEGER NOT NULL,UNIQUE(author_id,request_id))'),
 db.prepare('CREATE INDEX IF NOT EXISTS support_chat_thread ON support_chat(user_id,id)'),
 db.prepare('CREATE TABLE IF NOT EXISTS support_reads(user_id TEXT PRIMARY KEY,user_read INTEGER NOT NULL DEFAULT 0,admin_read INTEGER NOT NULL DEFAULT 0)'),
 db.prepare('CREATE TABLE IF NOT EXISTS support_chat_meta(id INTEGER PRIMARY KEY)'),
 db.prepare("INSERT OR IGNORE INTO support_chat(user_id,sender,author_id,request_id,message,created) SELECT user_id,'user',user_id,'legacy_'||request_id,message,created FROM support_messages WHERE NOT EXISTS(SELECT 1 FROM support_chat_meta WHERE id=1)"),
 db.prepare('INSERT OR IGNORE INTO support_chat_meta(id) VALUES(1)')]);}
function threadID(id){if(typeof id!=='string'||!/^tg:[1-9]\d*$/.test(id))throw new CampaignError('Выбери пользователя');}
export async function chatSnapshot(db,id,admin=false,url){threadID(id);await ensureChat(db);
 const user=await db.prepare('SELECT name FROM users WHERE id=?').bind(id).first();if(!user)throw new CampaignError('Пользователь не найден',404);
 const before=Number(url?.searchParams.get('before')||0);if(!Number.isSafeInteger(before)||before<0)throw new CampaignError('Неверная страница');
 const rows=(await db.prepare('SELECT id,sender,message,created FROM support_chat WHERE user_id=? AND (?=0 OR id<?) ORDER BY id DESC LIMIT 100').bind(id,before,before).all()).results;
 if(!before&&rows.length){const col=admin?'admin_read':'user_read';await db.prepare(`INSERT INTO support_reads(user_id,${col}) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET ${col}=MAX(support_reads.${col},excluded.${col})`).bind(id,rows[0].id).run();}
 const next=rows.length===100?rows.at(-1).id:null;return {userId:id,name:user.name,messages:rows.reverse(),before:next};
}
export async function chatInbox(db,url){await ensureChat(db);const q=(url?.searchParams.get('q')||'').trim().slice(0,60),like='%'+q.replace(/[\\%_]/g,'\\$&')+'%';return {threads:(await db.prepare("SELECT c.user_id,u.name,c.message,c.created,c.sender,(SELECT COUNT(*) FROM support_chat m WHERE m.user_id=c.user_id AND m.sender='user' AND m.id>COALESCE(r.admin_read,0)) AS unread FROM support_chat c JOIN users u ON u.id=c.user_id LEFT JOIN support_reads r ON r.user_id=c.user_id WHERE c.id=(SELECT MAX(id) FROM support_chat WHERE user_id=c.user_id) AND (u.name LIKE ? ESCAPE '\\' OR c.user_id LIKE ? ESCAPE '\\') ORDER BY c.id DESC LIMIT 100").bind(like,like).all()).results};}
export async function sendChat(db,env,user,data,admin=false){
 const id=admin?data.userId:user.id;threadID(id);
 const text=typeof data.message==='string'?data.message.trim():'';
 if(!text||text.length>2000||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(text)||!/^[-a-zA-Z0-9_]{16,80}$/.test(data.requestId||''))throw new CampaignError('Напиши от 1 до 2000 символов');
 await ensureChat(db);if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(id).first())throw new CampaignError('Пользователь не найден',404);
 const old=await db.prepare('SELECT user_id,message,sender FROM support_chat WHERE author_id=? AND request_id=?').bind(user.id,data.requestId).first();
 if(old&&(old.user_id!==id||old.message!==text||old.sender!==(admin?'admin':'user')))throw new CampaignError('Номер сообщения уже использован',409);
 if(!old){const now=Date.now();const statements=[db.prepare("INSERT OR IGNORE INTO support_chat(user_id,sender,author_id,request_id,message,created) SELECT ?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM support_chat WHERE author_id=? AND created>?)<? AND NOT EXISTS(SELECT 1 FROM support_chat WHERE author_id=? AND created>?)").bind(id,admin?'admin':'user',user.id,data.requestId,text,now,user.id,now-86400000,admin?1000:100,user.id,now-2000)];
 if(!admin)statements.push(db.prepare('INSERT OR IGNORE INTO support_messages(user_id,request_id,message,created) SELECT user_id,request_id,message,created FROM support_chat WHERE author_id=? AND request_id=?').bind(user.id,data.requestId));
 await db.batch(statements);
 if(!await db.prepare('SELECT id FROM support_chat WHERE author_id=? AND request_id=?').bind(user.id,data.requestId).first())throw new CampaignError('Подожди 2 секунды. Лимит — 100 сообщений в сутки.',429);
 }
 if(!admin){const queued=await db.prepare('SELECT id FROM support_messages WHERE user_id=? AND request_id=?').bind(user.id,data.requestId).first();if(queued)await deliverSupport(db,env,queued.id);}
 return chatSnapshot(db,id,admin);
}
