import {useEffect,useRef,useState} from 'react';
import {Coins,Footprints,Zap,Target} from 'lucide-react';
import {campaignAPI,Sponsor} from './campaigns';
type TapWallet={telegramId:string,balance:number,tapReward:number,tapDailyLimit:number,tapTodayCoins:number,tapDailyRemaining:number,tapCoins:number,tapCount:number,tapRemainder:number,tapsPerCoin:number,energy:number,capacity:number,regenMs:number,steps:number,todayCoins:number,user:{name:string},mascot:Sponsor|null};
type Batch={requestId:string,count:number};
export function useTapper(wallet:TapWallet|null,onCommit:(value:any)=>void){
 const ref=useRef({id:'',queue:[] as Batch[],sending:false,retryAt:0,server:null as TapWallet|null,at:Date.now(),inFlight:''});
 const commit=useRef(onCommit);commit.current=onCommit;
 const [tick,setTick]=useState(0),[message,setMessage]=useState('');
 const redraw=()=>setTick(x=>x+1);
 function save(){try{localStorage.setItem('wallker-taps:'+ref.current.id,JSON.stringify(ref.current.queue))}catch{}}
 useEffect(()=>{
  if(!wallet)return;
  const r=ref.current;
  if(r.id!==wallet.telegramId){r.id=wallet.telegramId;r.queue=[];try{const q=JSON.parse(localStorage.getItem('wallker-taps:'+r.id)||'[]');r.queue=q.filter((x:Batch)=>/^[a-zA-Z0-9_-]{16,80}$/.test(x.requestId)&&Number.isInteger(x.count)&&x.count>0&&x.count<=50).slice(0,100)}catch{};r.retryAt=0;r.inFlight='';r.sending=false;}
  r.server=wallet;r.at=Date.now();redraw();
 },[wallet]);
 useEffect(()=>{
  const timer=setInterval(async()=>{
   const r=ref.current;redraw();
   if(!r.id||!r.queue.length||r.sending||Date.now()<r.retryAt)return;
   const batch=r.queue[0],id=r.id;r.sending=true;r.inFlight=batch.requestId;
   try{
    const result=await campaignAPI('/api/tap',batch);
    if(ref.current.id!==id)return;
    r.queue.shift();save();r.server={...r.server!,...result};r.at=Date.now();commit.current(result);
    setMessage(result.accepted<batch.count?'Энергия закончилась. Она восстановится.':'');
   }catch(e){if(ref.current.id===id){r.retryAt=Date.now()+3000;setMessage('Ожидаем подтверждения. Нажатия сохранены.')}}
   finally{if(ref.current.id===id){r.sending=false;r.inFlight='';redraw()}}
  },400);return()=>clearInterval(timer);
 },[]);
 const r=ref.current,pending=r.queue.reduce((sum,x)=>sum+x.count,0),server=r.server||wallet;
 const energy=Math.max(0,Math.min(server?.capacity||100,(server?.energy||0)+Math.floor((Date.now()-r.at)/(server?.regenMs||1000)))-pending);
 const remaining=Math.max(0,Math.round(((server?.tapDailyRemaining??1000)-pending*(server?.tapReward||0.1))*100)/100);
 function tap(){
  if(!server||energy<1||remaining<(server?.tapReward||0.1)||r.queue.length>=100)return false;
  let last=r.queue[r.queue.length-1];
  if(!last||last.count>=50||last.requestId===r.inFlight){last={requestId:crypto.randomUUID(),count:0};r.queue.push(last)}
  last.count++;save();redraw();return true;
 }
 const earned=pending/(server?.tapsPerCoin||10);
 return {tap,energy,remaining,pending,balance:Math.round(((server?.balance||0)+earned)*100)/100,tapCoins:(server?.tapCoins||0)+earned,tapCount:(server?.tapCount||0)+pending,remainder:((server?.tapRemainder||0)+pending)%10,message};
}
export function TapGame({wallet,tapper,onTab}:{wallet:TapWallet,tapper:ReturnType<typeof useTapper>,onTab:(tab:string)=>void}){
 const [bursts,setBursts]=useState<{id:number,x:number,y:number}[]>([]),serial=useRef(0);
 const milestones=[0,1000,5000,10000,25000,50000,100000,250000,500000,1000000];
 const level=milestones.filter(n=>tapper.tapCount>=n).length,next=milestones[level]||milestones[9],base=milestones[level-1];
 const progress=level===10?1:(tapper.tapCount-base)/(next-base);
 function click(e:React.MouseEvent<HTMLButtonElement>){
  if(!tapper.tap())return;
  const rect=e.currentTarget.getBoundingClientRect(),id=++serial.current;
  const x=e.detail===0?rect.width/2:e.clientX-rect.left,y=e.detail===0?rect.height/2:e.clientY-rect.top;
  setBursts(b=>[...b.slice(-14),{id,x,y}]);
 }
 return <section className="tap-game" aria-label="Игра с Волкером">
  <div className="player-bar"><span className="player-avatar">{wallet.user.name[0]}</span><strong>{wallet.user.name}</strong><span className="player-rank">В стае Волкера</span></div>
  <div className="earn-stats"><div><span>За нажатие</span><strong><Coins size={15}/>+{wallet.tapReward.toLocaleString('ru-RU')} WC</strong></div><button onClick={()=>onTab('goals')}><span>За задания</span><strong><Target size={15}/>Награды</strong></button><button onClick={()=>onTab('phone')}><span>За шаги сегодня</span><strong><Footprints size={15}/>+{wallet.todayCoins} WC</strong></button></div>
  <button className="tap-balance" onClick={()=>onTab('wallet')} aria-label="Открыть кошелёк"><span className="gold-coin">W</span><strong>{tapper.balance.toLocaleString('ru-RU')}</strong><span>WC</span></button>
  <div className="level-row"><span>{['Новичок','Следопыт','Бегун','Охотник','Вожак'][Math.min(4,Math.floor((level-1)/2))]}</span><span>Уровень {level}/10</span><div className="level-track"><div style={{width:Math.min(100,progress*100)+'%'}}/></div></div>
  <div className="tap-stage"><button className="wolf-tap" onClick={click} disabled={tapper.energy<1||tapper.remaining<wallet.tapReward} aria-label="Нажать на Волкера: получить WC"><div className="tap-character"><img src="/volker.png" alt="Волкер — волк в футболке Wallker" draggable={false}/>{wallet.mascot&&<span className="tap-shirt">{wallet.mascot.partner.slice(0,12)}</span>}</div>{bursts.map(b=><span key={b.id} className="tap-burst" style={{left:b.x,top:b.y}} onAnimationEnd={()=>setBursts(items=>items.filter(x=>x.id!==b.id))}>+{wallet.tapReward.toLocaleString('ru-RU')} WC</span>)}</button></div>
  <p className="tap-hint">{(tapper.remaining<wallet.tapReward?'Дневной лимит тапов достигнут · возвращайся завтра':tapper.message)|| (tapper.energy?`За тап +${wallet.tapReward.toLocaleString('ru-RU')} WC`:`Энергия: +1 за ${wallet.regenMs/1000} сек.`)}</p>
  <p className="tap-hint">Тапы за день: {((wallet.tapDailyLimit||1000)-tapper.remaining).toLocaleString('ru-RU')} / {wallet.tapDailyLimit||1000} WC</p>
  <div className="energy-row"><Zap size={23}/><strong>{tapper.energy.toLocaleString('ru-RU')} <span>/ {wallet.capacity}</span></strong><span className="pending-taps" role="status">{tapper.pending?'Сохраняем…':'Сохранено'}</span></div>
  <div className="energy-track"><div style={{width:tapper.energy/wallet.capacity*100+'%'}}/></div>
  {wallet.mascot&&<a className="tap-partner" href={wallet.mascot.url} target="_blank" rel="noopener noreferrer">Партнёр Волкера · {wallet.mascot.partner} ↗</a>}
 </section>;
}
