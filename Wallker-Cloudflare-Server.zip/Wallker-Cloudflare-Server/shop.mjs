import {limit} from './security.mjs';
import {botId,legacyBotEnv} from './bot-config.mjs';
import {CampaignError} from './campaigns.mjs';
export const SHOP=[
 {id:'tap-7',kind:'tap',title:'+25% WC за тап',days:7,price:99,strength:25},
 {id:'tap-30',kind:'tap',title:'+25% WC за тап',days:30,price:299,strength:25},
 {id:'energy-7',kind:'energy',title:'+50% выносливости',days:7,price:69,strength:50},
 {id:'energy-30',kind:'energy',title:'+50% выносливости',days:30,price:199,strength:50},
 {id:'cap-7',kind:'cap',title:'+50% дневного лимита WC за тапы',days:7,price:99,strength:50},
 {id:'cap-30',kind:'cap',title:'+50% дневного лимита WC за тапы',days:30,price:299,strength:50},
 {id:'coins-1000',kind:'coins',title:'1 000 игровых WC',days:0,price:99,strength:1000},
 {id:'coins-5000',kind:'coins',title:'5 000 игровых WC',days:0,price:399,strength:5000}
];
const validID=x=>typeof x==='string'&&/^[a-zA-Z0-9_-]{16,80}$/.test(x);
export async function ensureShop(db){if(db.schemaReady)return;await db.batch([
 db.prepare('CREATE TABLE IF NOT EXISTS shop_accounts(user_id TEXT PRIMARY KEY,credits INTEGER NOT NULL DEFAULT 0)'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_orders(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,credits INTEGER NOT NULL,stars INTEGER NOT NULL,state TEXT NOT NULL,charge_id TEXT UNIQUE,created INTEGER NOT NULL)'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_order_bots(order_id TEXT PRIMARY KEY,bot_id TEXT NOT NULL)'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_payment_meta(id INTEGER PRIMARY KEY,origin_bot_id TEXT NOT NULL,backfilled INTEGER NOT NULL DEFAULT 0)'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_checkout(order_id TEXT PRIMARY KEY,query_id TEXT NOT NULL)'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_invoice_links(order_id TEXT PRIMARY KEY,url TEXT,lease_until INTEGER NOT NULL DEFAULT 0)'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_checkout_leases(order_id TEXT PRIMARY KEY,query_id TEXT NOT NULL,until INTEGER NOT NULL)'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_reconciliation(id TEXT PRIMARY KEY,offset INTEGER NOT NULL DEFAULT 0,last_at INTEGER NOT NULL DEFAULT 0,lease_until INTEGER NOT NULL DEFAULT 0)'),
 db.prepare("CREATE TABLE IF NOT EXISTS shop_extra_charges(charge_id TEXT PRIMARY KEY,order_id TEXT NOT NULL,user_id TEXT NOT NULL,stars INTEGER NOT NULL,bot_id TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'pending')"),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_purchases(user_id TEXT NOT NULL,request_id TEXT NOT NULL,product TEXT NOT NULL,price INTEGER NOT NULL,kind TEXT NOT NULL,strength INTEGER NOT NULL,days INTEGER NOT NULL,created INTEGER NOT NULL,applied INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,request_id))'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_boosts(user_id TEXT NOT NULL,kind TEXT NOT NULL,strength INTEGER NOT NULL,expires INTEGER NOT NULL,PRIMARY KEY(user_id,kind))'),
 db.prepare('CREATE TABLE IF NOT EXISTS shop_game_awards(user_id TEXT NOT NULL,request_id TEXT NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))')]);}
export async function stampPaymentBots(db,env){
 await ensureShop(db);const active=botId(env),legacy=botId({TELEGRAM_BOT_TOKEN:env.LEGACY_TELEGRAM_BOT_TOKEN});if(!active)throw new CampaignError('Проверь подключение бота к оплате',503);
 await db.prepare('INSERT OR IGNORE INTO shop_payment_meta(id,origin_bot_id) VALUES(1,?)').bind(legacy||active).run();
 const meta=await db.prepare('SELECT origin_bot_id,backfilled FROM shop_payment_meta WHERE id=1').first();
 if(!meta.backfilled)await db.batch([db.prepare('INSERT OR IGNORE INTO shop_order_bots(order_id,bot_id) SELECT id,? FROM shop_orders').bind(meta.origin_bot_id),db.prepare('UPDATE shop_payment_meta SET backfilled=1 WHERE id=1')]);
}
async function paymentBotMatches(db,order,env){
 if(!env)return true;await stampPaymentBots(db,env);
 // Covers late receipts from the old deployment without rescanning every order.
 await db.prepare('INSERT OR IGNORE INTO shop_order_bots(order_id,bot_id) SELECT id,(SELECT origin_bot_id FROM shop_payment_meta WHERE id=1) FROM shop_orders WHERE id=?').bind(order.id).run();
 const row=await db.prepare('SELECT bot_id FROM shop_order_bots WHERE order_id=?').bind(order.id).first();return row?.bot_id===botId(env);
}
export async function shopBalance(db,id){await ensureShop(db);return (await db.prepare('SELECT COALESCE(SUM(units),0)/100.0 AS n FROM shop_game_awards WHERE user_id=? AND NOT EXISTS(SELECT 1 FROM shop_accounts a WHERE a.user_id=shop_game_awards.user_id AND a.credits<0)').bind(id).first()).n;}
export async function activeBoosts(db,id,now=Date.now()){await ensureShop(db);return (await db.prepare('SELECT kind,strength,expires FROM shop_boosts WHERE user_id=? AND expires>? AND NOT EXISTS(SELECT 1 FROM shop_accounts a WHERE a.user_id=shop_boosts.user_id AND a.credits<0)').bind(id,now).all()).results;}
export async function shopSnapshot(db,id,env={}){
 await ensureShop(db);await db.prepare('INSERT OR IGNORE INTO shop_accounts(user_id) VALUES(?)').bind(id).run();
 return {credits:(await db.prepare('SELECT credits FROM shop_accounts WHERE user_id=?').bind(id).first()).credits,products:SHOP,boosts:await activeBoosts(db,id),purchases:(await db.prepare('SELECT product,price,created FROM shop_purchases WHERE user_id=? ORDER BY created DESC LIMIT 30').bind(id).all()).results,paymentsEnabled:env.STARS_PAYMENTS_ENABLED==='true',topups:[100,300,1000].map(n=>({credits:n,stars:n}))};
}
export async function buyProduct(db,id,data,now=Date.now()){
 const product=SHOP.find(p=>p.id===data.product);if(!product||!validID(data.requestId))throw new CampaignError('Выбери товар и номер покупки');
 await shopSnapshot(db,id);
 await db.batch([
 db.prepare('INSERT OR IGNORE INTO shop_purchases(user_id,request_id,product,price,kind,strength,days,created) SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM shop_accounts WHERE user_id=? AND credits>=?)').bind(id,data.requestId,product.id,product.price,product.kind,product.strength,product.days,now,id,product.price),
 db.prepare('UPDATE shop_accounts SET credits=credits-? WHERE user_id=? AND EXISTS(SELECT 1 FROM shop_purchases WHERE user_id=? AND request_id=? AND applied=0)').bind(product.price,id,id,data.requestId),
 db.prepare('INSERT INTO shop_boosts(user_id,kind,strength,expires) SELECT user_id,kind,strength,created+days*86400000 FROM shop_purchases WHERE user_id=? AND request_id=? AND applied=0 AND kind<>\'coins\' ON CONFLICT(user_id,kind) DO UPDATE SET strength=excluded.strength,expires=MAX(shop_boosts.expires,?)+?').bind(id,data.requestId,now,product.days*86400000),
 db.prepare("INSERT OR IGNORE INTO shop_game_awards(user_id,request_id,units,created) SELECT user_id,request_id,strength*100,created FROM shop_purchases WHERE user_id=? AND request_id=? AND kind='coins'").bind(id,data.requestId),
 db.prepare('UPDATE shop_purchases SET applied=1 WHERE user_id=? AND request_id=?').bind(id,data.requestId)
 ]);
 const row=await db.prepare('SELECT product FROM shop_purchases WHERE user_id=? AND request_id=?').bind(id,data.requestId).first();
 if(!row)throw new CampaignError('Недостаточно WC-Донатов',409);
 if(row.product!==product.id)throw new CampaignError('Этот номер покупки уже использован',409);
 return {ok:true};
}
export async function createInvoice(db,id,data,env,call){
 if(env.STARS_PAYMENTS_ENABLED!=='true')throw new CampaignError('Пополнение пока готовится. Покупки появятся после запуска оплаты.',409);
 if(data.termsAccepted!==true)throw new CampaignError('Подтверди условия покупки');
 if(![100,300,1000].includes(data.credits)||!validID(data.requestId))throw new CampaignError('Выбери пакет пополнения');
 await stampPaymentBots(db,env);const orderID=id.slice(3)+'_'+data.requestId;
 await db.batch([db.prepare("INSERT OR IGNORE INTO shop_orders(id,user_id,credits,stars,state,created) SELECT ?,?,?,?,'pending',? WHERE (SELECT COUNT(*) FROM shop_orders WHERE user_id=? AND created>?)<20").bind(orderID,id,data.credits,data.credits,Date.now(),id,Date.now()-86400000),db.prepare("INSERT OR IGNORE INTO shop_order_bots(order_id,bot_id) SELECT id,? FROM shop_orders WHERE id=?").bind(botId(env),orderID)]);
 const order=await db.prepare('SELECT * FROM shop_orders WHERE id=?').bind(orderID).first();
 if(!order)throw new CampaignError('Лимит новых счетов на сегодня достигнут',429);
 if(!await paymentBotMatches(db,order,env))throw new CampaignError('Этот счёт создан старым ботом. Создай новое пополнение.',409);
 if(order.credits!==data.credits||order.state!=='pending')throw new CampaignError('Номер пополнения уже использован',409);
 if(Date.now()-order.created>=30*60000)throw new CampaignError('Срок счёта истёк. Создай новое пополнение.',409);
 await db.prepare('INSERT OR IGNORE INTO shop_invoice_links(order_id) VALUES(?)').bind(order.id).run();
 const cached=await db.prepare('SELECT url FROM shop_invoice_links WHERE order_id=?').bind(order.id).first();if(cached?.url)return {invoice:cached.url};
 const now=Date.now();const lease=await db.prepare('UPDATE shop_invoice_links SET lease_until=? WHERE order_id=? AND url IS NULL AND lease_until<=? RETURNING order_id').bind(now+20000,order.id,now).first();if(!lease)throw new CampaignError('Счёт создаётся. Повтори через несколько секунд.',429);
 let invoice;try{invoice=await call(env,'createInvoiceLink',{title:`${order.credits} ${data.language==='en'?'Shop WC':'WC-Донатов'}`,description:data.language==='en'?'Walker shop balance: temporary boosts and game WC.':'Баланс магазина Walker: временные усиления и игровые WC.',payload:order.id,currency:'XTR',prices:[{label:data.language==='en'?'Shop WC':'WC-Донаты',amount:order.stars}],provider_token:''});await db.prepare('UPDATE shop_invoice_links SET url=?,lease_until=0 WHERE order_id=?').bind(invoice,order.id).run();}catch(error){await db.prepare('UPDATE shop_invoice_links SET lease_until=0 WHERE order_id=?').bind(order.id).run();throw error}
 return {invoice};
}
export async function paymentPrecheck(db,query,env){
 await ensureShop(db);const order=await db.prepare('SELECT * FROM shop_orders WHERE id=?').bind(String(query.invoice_payload||'')).first();
 if(order&&!await paymentBotMatches(db,order,env))return false;
 if(!(env.STARS_PAYMENTS_ENABLED==='true'&&order?.state==='pending'&&order.user_id===`tg:${query.from?.id}`&&query.currency==='XTR'&&query.total_amount===order.stars&&typeof query.id==='string'&&query.id.length<=256&&Date.now()-order.created<30*60000))return false;
 const now=Date.now();
 await db.prepare('INSERT INTO shop_checkout_leases(order_id,query_id,until) VALUES(?,?,?) ON CONFLICT(order_id) DO UPDATE SET query_id=excluded.query_id,until=excluded.until WHERE shop_checkout_leases.query_id=excluded.query_id OR shop_checkout_leases.until<=?').bind(order.id,query.id,now+30000,now).run();
 return (await db.prepare('SELECT query_id FROM shop_checkout_leases WHERE order_id=?').bind(order.id).first()).query_id===query.id;
}
export async function creditPayment(db,from,payment,env){
 await ensureShop(db);const order=await db.prepare('SELECT * FROM shop_orders WHERE id=?').bind(String(payment.invoice_payload||'')).first();
 if(order&&!await paymentBotMatches(db,order,env))throw new CampaignError('Платёж пришёл от другого бота',409);
 const charge=payment.telegram_payment_charge_id;
 if(!order||order.user_id!==`tg:${from}`||payment.currency!=='XTR'||payment.total_amount!==order.stars||typeof charge!=='string'||!charge||charge.length>256)throw new CampaignError('Платёж не соответствует заказу',409);
 if(order.charge_id&&order.charge_id!==charge){await db.prepare("INSERT OR IGNORE INTO shop_extra_charges(charge_id,order_id,user_id,stars,bot_id) VALUES(?,?,?,?,?)").bind(charge,order.id,order.user_id,order.stars,env?botId(env):'local').run();return {ok:true,refundQueued:true};}
 await db.batch([
 db.prepare('INSERT OR IGNORE INTO shop_accounts(user_id) VALUES(?)').bind(order.user_id),
 db.prepare("UPDATE shop_orders SET charge_id=? WHERE id=? AND state='pending' AND charge_id IS NULL").bind(charge,order.id),
 db.prepare("UPDATE shop_accounts SET credits=credits+? WHERE user_id=? AND EXISTS(SELECT 1 FROM shop_orders WHERE id=? AND state='pending' AND charge_id=?)").bind(order.credits,order.user_id,order.id,charge),
 db.prepare("UPDATE shop_orders SET state='paid' WHERE id=? AND state='pending' AND charge_id=?").bind(order.id,charge)
 ]);const saved=await db.prepare('SELECT charge_id FROM shop_orders WHERE id=?').bind(order.id).first();if(saved?.charge_id&&saved.charge_id!==charge){await db.prepare('INSERT OR IGNORE INTO shop_extra_charges(charge_id,order_id,user_id,stars,bot_id) VALUES(?,?,?,?,?)').bind(charge,order.id,order.user_id,order.stars,env?botId(env):'local').run();return {ok:true,refundQueued:true};}return {ok:true};
}
// Telegram can report a refund after coins were spent. Keep debt, never mint a
// second balance or silently delete old gameplay awards; support resolves debt.
export async function refundedPayment(db,from,payment,env){
 await ensureShop(db);const row=await db.prepare('SELECT * FROM shop_orders WHERE charge_id=? AND user_id=?').bind(String(payment.telegram_payment_charge_id||''),`tg:${from}`).first();
 if(row&&!await paymentBotMatches(db,row,env))throw new CampaignError('Возврат пришёл от другого бота',409);
 if(!row){const extra=await db.prepare('SELECT * FROM shop_extra_charges WHERE charge_id=? AND user_id=?').bind(String(payment.telegram_payment_charge_id||''),'tg:'+from).first();if(extra&&extra.stars===payment.total_amount&&payment.currency==='XTR'){if(env&&extra.bot_id!==botId(env))throw new CampaignError('Возврат пришёл от другого бота',409);await db.prepare("UPDATE shop_extra_charges SET state='refunded' WHERE charge_id=? AND state='pending'").bind(extra.charge_id).run();}return;}
 if(row.stars!==payment.total_amount||payment.currency!=='XTR')return;
 await db.batch([db.prepare("UPDATE shop_accounts SET credits=credits-? WHERE user_id=? AND EXISTS(SELECT 1 FROM shop_orders WHERE id=? AND state IN ('paid','refund_pending'))").bind(row.credits,row.user_id,row.id),db.prepare("UPDATE shop_orders SET state='refunded' WHERE id=? AND state IN ('paid','refund_pending')").bind(row.id)]);
}

export async function refundOrder(db,id,env,call){
 await ensureShop(db);const order=await db.prepare('SELECT * FROM shop_orders WHERE id=?').bind(id).first();
 if(!order||!order.charge_id||!['paid','refund_pending','refunded'].includes(order.state))throw new CampaignError('Оплаченный заказ не найден',404);
 if(order.state==='refunded')return {ok:true};
 await paymentBotMatches(db,order,env);const origin=await db.prepare('SELECT bot_id FROM shop_order_bots WHERE order_id=?').bind(order.id).first();const payEnv=origin?.bot_id===botId(env)?env:legacyBotEnv(env);if(origin?.bot_id!==botId(payEnv))throw new CampaignError('Сохрани токен бота, который принял оплату, для возврата',409);
 await db.prepare("UPDATE shop_orders SET state='refund_pending' WHERE id=? AND state='paid'").bind(id).run();
 // A failed or unknown response preserves the pending state for reconciliation.
 await call(payEnv,'refundStarPayment',{user_id:Number(order.user_id.slice(3)),telegram_payment_charge_id:order.charge_id});
 await refundedPayment(db,Number(order.user_id.slice(3)),{telegram_payment_charge_id:order.charge_id,currency:'XTR',total_amount:order.stars});return {ok:true};
}

export async function reconcilePayments(db,env,call){
 if(env.STARS_PAYMENTS_ENABLED!=='true')return;
 for(const payEnv of [env,...(env.LEGACY_TELEGRAM_BOT_TOKEN&&env.LEGACY_TELEGRAM_BOT_TOKEN!==env.TELEGRAM_BOT_TOKEN?[legacyBotEnv(env)]:[])]){
 const id=botId(payEnv);if(!id)continue;
 await db.prepare('INSERT OR IGNORE INTO shop_reconciliation(id) VALUES(?)').bind(id).run();const now=Date.now();
 const lease=await db.prepare('UPDATE shop_reconciliation SET lease_until=? WHERE id=? AND lease_until<=? RETURNING offset').bind(now+120000,id,now).first();if(!lease)continue;
 try{
 const result=await call(payEnv,'getStarTransactions',{offset:lease.offset,limit:100});const transactions=result.transactions||[];
 for(const t of transactions){
  const partner=t.source||t.receiver;if(partner?.type!=='user'||partner.transaction_type!=='invoice_payment'||!Number.isSafeInteger(t.amount)||t.nanostar_amount)continue;
  const payment={invoice_payload:partner.invoice_payload,currency:'XTR',total_amount:Math.abs(t.amount),telegram_payment_charge_id:t.id};
  if(t.source&&partner.invoice_payload){const order=await db.prepare('SELECT id FROM shop_orders WHERE id=?').bind(partner.invoice_payload).first();if(order)await creditPayment(db,partner.user.id,payment,payEnv)}
  else if(t.receiver)await refundedPayment(db,partner.user.id,payment,payEnv);
 }
 await db.prepare('UPDATE shop_reconciliation SET offset=offset+?,last_at=?,lease_until=0 WHERE id=?').bind(transactions.length,Date.now(),id).run();
 }catch{await db.prepare('UPDATE shop_reconciliation SET lease_until=0 WHERE id=?').bind(id).run();}
 const pending=(await db.prepare("SELECT o.id FROM shop_orders o JOIN shop_order_bots b ON b.order_id=o.id WHERE o.state='refund_pending' AND b.bot_id=? LIMIT 5").bind(id).all()).results;
 for(const row of pending)try{await refundOrder(db,row.id,env,call)}catch{}
 const extras=(await db.prepare("SELECT * FROM shop_extra_charges WHERE bot_id=? AND state='pending' LIMIT 5").bind(id).all()).results;
 for(const row of extras)try{await call(payEnv,'refundStarPayment',{user_id:Number(row.user_id.slice(3)),telegram_payment_charge_id:row.charge_id});await db.prepare("UPDATE shop_extra_charges SET state='refunded' WHERE charge_id=?").bind(row.charge_id).run()}catch{ /* Retry from cron; keep durable pending record. */ }
 }
}
