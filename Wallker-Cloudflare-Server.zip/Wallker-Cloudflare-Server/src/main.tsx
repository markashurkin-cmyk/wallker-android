import {LanguageProvider} from './language';
import {Component,ReactNode} from 'react';
import {createRoot} from 'react-dom/client';
import Wallet from './wallet';
import './app.css';
import './tap-button.css';
import './growth.css';
class AppBoundary extends Component<{children:ReactNode},{failed:boolean}>{
 state={failed:false};static getDerivedStateFromError(){return {failed:true}}
 componentDidCatch(){try{localStorage.setItem('walker-client-diagnostic','ui_crash')}catch{}}
 render(){return this.state.failed?<main className="panel"><h1>Не удалось открыть экран</h1><p>Закрой Walker и открой заново в Telegram. Баланс хранится на сервере.</p><button className="button" onClick={()=>window.location.reload()}>Повторить</button></main>:this.props.children}
}
createRoot(document.getElementById('root')!).render(<LanguageProvider><AppBoundary><Wallet/></AppBoundary></LanguageProvider>);
