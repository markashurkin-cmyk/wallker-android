import {CampaignError} from './campaigns.mjs';
export async function ensureGrants(db){await db.prepare('CREATE TABLE IF NOT EXISTS admin_grants(admin_id TEXT NOT NULL,request_id TEXT NOT NULL,user_id TEXT NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(admin_id,request_id))').run();}
export async function grantBalance(db,id){await ensureGrants(db);return (await db.prepare('SELECT COALESCE(SUM(units),0)/100.0 AS n FROM admin_grants WHERE user_id=?').bind(id).first()).n;}
export async function grantTokens(db,admin,data){
 if(typeof data.userId!=='string'||!/^tg:[1-9]\d*$/.test(data.userId)||typeof data.amount!=='number'||!Number.isFinite(data.amount)||data.amount<0.01||data.amount>1000000||Math.abs(data.amount*100-Math.round(data.amount*100))>1e-7||typeof data.requestId!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.requestId))throw new CampaignError('Укажи пользователя и от 0,01 до 1 000 000 WC');
 await ensureGrants(db);const units=Math.round(data.amount*100);
 await db.prepare('INSERT OR IGNORE INTO admin_grants(admin_id,request_id,user_id,units,created) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM users WHERE id=?)').bind(admin.id,data.requestId,data.userId,units,Date.now(),data.userId).run();
 const receipt=await db.prepare('SELECT user_id,units,created FROM admin_grants WHERE admin_id=? AND request_id=?').bind(admin.id,data.requestId).first();
 if(!receipt)throw new CampaignError('Пользователь не найден',404);
 if(receipt.user_id!==data.userId||receipt.units!==units)throw new CampaignError('Номер выдачи уже использован для другого начисления',409);
 return {ok:true,userId:receipt.user_id,amount:receipt.units/100,created:receipt.created};
}
