import {build} from 'esbuild';
import {mkdtemp,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=fileURLToPath(new URL('../',import.meta.url)),dir=await mkdtemp(join(root,'.language-test-'));
try{await build({entryPoints:[root+'tests/language-fixture.tsx'],outfile:dir+'/fixture.cjs',bundle:true,platform:'node',format:'cjs',jsx:'automatic',jsxImportSource:'./localized',plugins:[{name:'fixture-runtime',setup(b){b.onResolve({filter:/^\.\/localized\/jsx-runtime$/},()=>({path:root+'src/localized/jsx-runtime.tsx'}))}}]});execFileSync(process.execPath,[dir+'/fixture.cjs'],{stdio:'inherit'})}finally{await rm(dir,{recursive:true,force:true})}
