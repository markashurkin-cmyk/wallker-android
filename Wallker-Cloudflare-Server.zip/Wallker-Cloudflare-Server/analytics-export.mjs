import {ensureReferrals} from './referrals.mjs';
import {CampaignError} from './campaigns.mjs';
import {ensureStatistics,balancesReady,userQuery} from './statistics.mjs';
import {walkingLevel} from './level-catalog.mjs';
// Explicit columns omit device credentials, initData, support bodies and secrets.
const datasets={
 users:`SELECT id AS cursor,* FROM (${userQuery})`,
 errors:'SELECT rowid AS cursor,hour,path,status,code,user_id,platform,count,first_at,last_at,version FROM analytics_errors',
 activity:'SELECT rowid AS cursor,user_id,day,opens,syncs,pairs,last_seen FROM analytics_daily',
 steps:'SELECT rowid AS cursor,user_id,day,steps,source,updated FROM days',
 tapDays:'SELECT rowid AS cursor,user_id,day,units/100.0 AS coins FROM tap_daily_paid',
 levelAwards:'SELECT rowid AS cursor,user_id,level,units/100.0 AS coins,created FROM level_claims',
 grants:'SELECT rowid AS cursor,admin_id,user_id,units/100.0 AS coins,created FROM admin_grants',
 purchases:'SELECT rowid AS cursor,user_id,product,price,kind,strength,days,created FROM shop_purchases',
 orders:'SELECT rowid AS cursor,user_id,credits,stars,state,created FROM shop_orders',
 donations:'SELECT rowid AS cursor,user_id,credits FROM shop_accounts',
 referrals:'SELECT r.rowid AS cursor,r.invitee,r.inviter,r.created,q.qualified FROM referrals r LEFT JOIN referral_qualified q ON q.invitee=r.invitee',
 quests:"SELECT rowid AS cursor,user_id,campaign_id,state,reward,created,reviewed FROM campaign_claims"
};
export async function analyticsExport(db,url){
 await ensureStatistics(db);await balancesReady(db);await ensureReferrals(db);
 const type=url.searchParams.get('dataset')||'users';if(!datasets[type])throw new CampaignError('Неизвестный набор данных');
 const after=url.searchParams.get('after')||'';
 if(after.length>64||(type!=='users'&&after&&!/^\d+$/.test(after)))throw new CampaignError('Неверная страница экспорта');
 const rows=(await db.prepare(`SELECT * FROM (${datasets[type]}) WHERE cursor>? ORDER BY cursor LIMIT 500`).bind(type==='users'?after:Number(after)||0).all()).results;
 if(type==='users')for(const r of rows){const l=walkingLevel(r.rankSteps??r.steps);r.walkingLevel=l.level;r.walkingLevelName=l.name;}
 return {dataset:type,rows,next:rows.length===500?String(rows.at(-1).cursor):null,generated:Date.now(),retention:{errorsDays:30,activityDays:90},datasets:Object.keys(datasets)};
}
