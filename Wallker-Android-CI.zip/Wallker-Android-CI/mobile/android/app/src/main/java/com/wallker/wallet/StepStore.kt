package com.wallker.wallet

import android.content.Context
import android.provider.Settings
import android.os.SystemClock
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.util.UUID

// Separate local ledger, persisted atomically after every sensor event.
class StepStore(private val context:Context) {
    private val prefs=context.getSharedPreferences("wallker_steps",Context.MODE_PRIVATE)
    companion object { private val lock=Any() }
    private fun load()=JSONObject(prefs.getString("ledger","{}") ?: "{}")
    private fun save(data:JSONObject){check(prefs.edit().putString("ledger",data.toString()).commit()){"Не удалось сохранить шаги"}}
    private fun date(now:Long)=Instant.ofEpochMilli(now).atZone(DeviceVault(context).timezone()).toLocalDate().toString()
    fun enabled():Boolean=synchronized(lock){load().optBoolean("enabled")}
    fun status():String=synchronized(lock){load().optString("status","")}
    fun setStatus(message:String)=synchronized(lock){val d=load();d.put("status",message);save(d)}
    fun setEnabled(value:Boolean)=synchronized(lock){
        val d=load()
        if(d.optBoolean("enabled")!=value)d.remove("counter") // A pause must not include steps during the pause.
        d.put("enabled",value);save(d)
    }
    fun clear()=synchronized(lock){save(JSONObject().put("generation",UUID.randomUUID().toString()))}
    fun record(counter:Long,timestampNanos:Long)=synchronized(lock){
        val d=load();if(!d.optBoolean("enabled"))return@synchronized
        val eventTime=System.currentTimeMillis()-(SystemClock.elapsedRealtimeNanos()-timestampNanos).coerceAtLeast(0)/1000000
        val day=date(eventTime)
        val boot=Settings.Global.getInt(context.contentResolver,Settings.Global.BOOT_COUNT,-1)
        val previous=d.optLong("counter",-1)
        val sameBoot=d.optInt("boot",-2)==boot && timestampNanos>=d.optLong("timestamp",0)
        val delta=counter-previous
        val totals=d.optJSONObject("totals") ?: JSONObject()
        // An aggregate crossing midnight has no per-step timestamps. Skip it rather than credit it to the wrong day.
        if(previous>=0 && sameBoot && d.optString("day")==day && delta in 0L..100000L) {
            totals.put(day,minOf(100000L,totals.optLong(day,0)+delta))
        }
        d.put("totals",totals).put("counter",counter).put("timestamp",timestampNanos).put("boot",boot).put("day",day)
        d.put("status","Шагомер работает")
        prune(d);save(d)
    }
    private fun prune(d:JSONObject){
        val oldest=LocalDate.now(DeviceVault(context).timezone()).minusDays(6).toString()
        for(field in listOf("totals","sent")) {
            val values=d.optJSONObject(field) ?: JSONObject()
            values.keys().asSequence().toList().filter{it<oldest}.forEach{values.remove(it)}
            d.put(field,values)
        }
    }
    fun today():Long=synchronized(lock){load().optJSONObject("totals")?.optLong(date(System.currentTimeMillis()),0) ?: 0}
    data class Pending(val generation:String,val days:List<Pair<String,Long>>)
    fun pending():Pending=synchronized(lock){
        val d=load();val before=d.toString();prune(d)
        if(!d.has("generation"))d.put("generation",UUID.randomUUID().toString())
        if(d.toString()!=before)save(d)
        val totals=d.getJSONObject("totals");val sent=d.getJSONObject("sent")
        Pending(d.getString("generation"),totals.keys().asSequence().sorted().map{it to totals.getLong(it)}.filter{it.second>sent.optLong(it.first,0)}.toList())
    }
    fun acknowledge(generation:String,day:String,count:Long)=synchronized(lock){
        val d=load();if(d.optString("generation")!=generation)return@synchronized
        val sent=d.optJSONObject("sent") ?: JSONObject();sent.put(day,maxOf(sent.optLong(day,0),count));d.put("sent",sent);save(d)
    }
}
