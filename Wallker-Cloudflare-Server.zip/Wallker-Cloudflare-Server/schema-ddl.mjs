export const DDL=[
 "CREATE UNIQUE INDEX IF NOT EXISTS pairings_device ON pairings(device_hash) WHERE device_hash IS NOT NULL",
 "CREATE INDEX IF NOT EXISTS pairings_user ON pairings(user_id)",
 "CREATE TABLE IF NOT EXISTS pairings (\n  code_hash TEXT PRIMARY KEY NOT NULL,\n  user_id TEXT NOT NULL REFERENCES users(id),\n  expires INTEGER NOT NULL,\n  device_hash TEXT,\n  platform TEXT\n)",
 "CREATE TABLE IF NOT EXISTS days (\n  user_id TEXT NOT NULL REFERENCES users(id),\n  day TEXT NOT NULL,\n  steps INTEGER NOT NULL DEFAULT 0 CHECK(steps >= 0 AND steps <= 100000),\n  updated INTEGER NOT NULL,\n  source TEXT NOT NULL,\n  PRIMARY KEY(user_id, day)\n)",
 "CREATE TABLE IF NOT EXISTS users (\n  id TEXT PRIMARY KEY NOT NULL,\n  name TEXT NOT NULL,\n  timezone TEXT NOT NULL,\n  mode TEXT NOT NULL,\n  created INTEGER NOT NULL\n)",
 "CREATE TABLE IF NOT EXISTS campaigns(id TEXT PRIMARY KEY,title TEXT NOT NULL,description TEXT NOT NULL,kind TEXT NOT NULL,partner TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',target INTEGER NOT NULL DEFAULT 0,reward INTEGER NOT NULL,starts INTEGER NOT NULL,ends INTEGER NOT NULL,status TEXT NOT NULL,created INTEGER NOT NULL,updated INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS campaign_claims(campaign_id TEXT NOT NULL,user_id TEXT NOT NULL,proof TEXT NOT NULL DEFAULT '',state TEXT NOT NULL,reward INTEGER NOT NULL,created INTEGER NOT NULL,reviewed INTEGER,PRIMARY KEY(campaign_id,user_id))",
 "CREATE TABLE IF NOT EXISTS mascot_config(id TEXT PRIMARY KEY,partner TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS clans(id TEXT PRIMARY KEY,name TEXT NOT NULL,name_key TEXT NOT NULL,description TEXT NOT NULL,owner TEXT NOT NULL,created INTEGER NOT NULL,archived INTEGER NOT NULL DEFAULT 0)",
 "CREATE UNIQUE INDEX IF NOT EXISTS clans_name ON clans(name_key) WHERE archived=0",
 "CREATE TABLE IF NOT EXISTS clan_members(user_id TEXT PRIMARY KEY,clan_id TEXT NOT NULL,joined INTEGER NOT NULL)",
 "CREATE INDEX IF NOT EXISTS clan_members_clan ON clan_members(clan_id,joined)",
 "CREATE TABLE IF NOT EXISTS support_chat(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,sender TEXT NOT NULL,author_id TEXT NOT NULL,request_id TEXT NOT NULL,message TEXT NOT NULL,created INTEGER NOT NULL,UNIQUE(author_id,request_id))",
 "CREATE INDEX IF NOT EXISTS support_chat_thread ON support_chat(user_id,id)",
 "CREATE TABLE IF NOT EXISTS support_reads(user_id TEXT PRIMARY KEY,user_read INTEGER NOT NULL DEFAULT 0,admin_read INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS support_chat_meta(id INTEGER PRIMARY KEY)",
 "CREATE TABLE IF NOT EXISTS admin_grants(admin_id TEXT NOT NULL,request_id TEXT NOT NULL,user_id TEXT NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(admin_id,request_id))",
 "CREATE TABLE IF NOT EXISTS reward_settings(id INTEGER PRIMARY KEY,value TEXT NOT NULL,revision INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS reward_settings_history(revision INTEGER PRIMARY KEY,value TEXT NOT NULL,created INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS step_rewards(user_id TEXT NOT NULL,day TEXT NOT NULL,accounted_steps INTEGER NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,day))",
 "CREATE TABLE IF NOT EXISTS developer_levels(user_id TEXT PRIMARY KEY,level INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS level_claims(user_id TEXT NOT NULL,level INTEGER NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(user_id,level))",
 "CREATE TABLE IF NOT EXISTS support_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,request_id TEXT NOT NULL,message TEXT NOT NULL,created INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,lease_until INTEGER NOT NULL DEFAULT 0,next_try INTEGER NOT NULL DEFAULT 0,delivered INTEGER,UNIQUE(user_id,request_id))",
 "CREATE TABLE IF NOT EXISTS friend_codes(user_id TEXT PRIMARY KEY,code TEXT UNIQUE NOT NULL)",
 "CREATE TABLE IF NOT EXISTS friendships(a TEXT NOT NULL,b TEXT NOT NULL,requester TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('pending','accepted')),created INTEGER NOT NULL,PRIMARY KEY(a,b))",
 "CREATE INDEX IF NOT EXISTS friendships_b ON friendships(b,state)",
 "CREATE TABLE IF NOT EXISTS shop_accounts(user_id TEXT PRIMARY KEY,credits INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS shop_orders(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,credits INTEGER NOT NULL,stars INTEGER NOT NULL,state TEXT NOT NULL,charge_id TEXT UNIQUE,created INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS shop_order_bots(order_id TEXT PRIMARY KEY,bot_id TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS shop_payment_meta(id INTEGER PRIMARY KEY,origin_bot_id TEXT NOT NULL,backfilled INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS shop_checkout(order_id TEXT PRIMARY KEY,query_id TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS shop_purchases(user_id TEXT NOT NULL,request_id TEXT NOT NULL,product TEXT NOT NULL,price INTEGER NOT NULL,kind TEXT NOT NULL,strength INTEGER NOT NULL,days INTEGER NOT NULL,created INTEGER NOT NULL,applied INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,request_id))",
 "CREATE TABLE IF NOT EXISTS shop_boosts(user_id TEXT NOT NULL,kind TEXT NOT NULL,strength INTEGER NOT NULL,expires INTEGER NOT NULL,PRIMARY KEY(user_id,kind))",
 "CREATE TABLE IF NOT EXISTS shop_game_awards(user_id TEXT NOT NULL,request_id TEXT NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))",
 "CREATE TABLE IF NOT EXISTS referrals(invitee TEXT PRIMARY KEY,inviter TEXT NOT NULL,created INTEGER NOT NULL,host_reward INTEGER NOT NULL DEFAULT 500,welcome_reward INTEGER NOT NULL DEFAULT 100)",
 "CREATE INDEX IF NOT EXISTS referrals_inviter ON referrals(inviter)",
 "CREATE TABLE IF NOT EXISTS referral_qualified(invitee TEXT PRIMARY KEY,inviter TEXT NOT NULL,qualified INTEGER NOT NULL)",
 "CREATE INDEX IF NOT EXISTS referral_qualified_inviter ON referral_qualified(inviter)",
 "CREATE TABLE IF NOT EXISTS tap_limit_state(user_id TEXT PRIMARY KEY,day TEXT NOT NULL,cap INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS tap_state(user_id TEXT PRIMARY KEY,total INTEGER NOT NULL DEFAULT 0,energy INTEGER NOT NULL DEFAULT 100,energy_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS tap_paid(user_id TEXT PRIMARY KEY,units INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS tap_daily_paid(user_id TEXT NOT NULL,day TEXT NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,day))",
 "CREATE TABLE IF NOT EXISTS tap_awards(user_id TEXT NOT NULL,request_id TEXT NOT NULL,units INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))",
 "CREATE TABLE IF NOT EXISTS tap_daily(user_id TEXT NOT NULL,day TEXT NOT NULL,count INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,day))",
 "CREATE TABLE IF NOT EXISTS tap_reward_baseline(user_id TEXT PRIMARY KEY,legacy_total INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS tap_receipts(user_id TEXT NOT NULL,request_id TEXT NOT NULL,requested INTEGER NOT NULL,accepted INTEGER NOT NULL,applied INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))",
 "CREATE TABLE IF NOT EXISTS analytics_meta(id INTEGER PRIMARY KEY,started INTEGER NOT NULL,cleaned INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS analytics_profiles(user_id TEXT PRIMARY KEY,username TEXT NOT NULL DEFAULT '',last_seen INTEGER NOT NULL DEFAULT 0,last_wallet INTEGER NOT NULL DEFAULT 0,first_sync INTEGER)",
 "CREATE TABLE IF NOT EXISTS analytics_daily(user_id TEXT NOT NULL,day TEXT NOT NULL,opens INTEGER NOT NULL DEFAULT 0,syncs INTEGER NOT NULL DEFAULT 0,pairs INTEGER NOT NULL DEFAULT 0,last_seen INTEGER NOT NULL,PRIMARY KEY(user_id,day))",
 "CREATE INDEX IF NOT EXISTS analytics_daily_day ON analytics_daily(day,user_id)",
 "CREATE TABLE IF NOT EXISTS analytics_errors(hour INTEGER NOT NULL,path TEXT NOT NULL,status INTEGER NOT NULL,code TEXT NOT NULL,user_id TEXT NOT NULL,platform TEXT NOT NULL,count INTEGER NOT NULL,first_at INTEGER NOT NULL,last_at INTEGER NOT NULL,version TEXT NOT NULL,PRIMARY KEY(hour,path,status,code,user_id,platform))",
 "CREATE INDEX IF NOT EXISTS analytics_errors_last ON analytics_errors(last_at)",
 "CREATE TABLE IF NOT EXISTS trusted_step_totals(user_id TEXT PRIMARY KEY,steps INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS step_reports(user_id TEXT NOT NULL,day TEXT NOT NULL,steps INTEGER NOT NULL,approved_steps INTEGER NOT NULL DEFAULT 0,state TEXT NOT NULL,reason TEXT NOT NULL,received INTEGER NOT NULL,reviewed INTEGER,reviewer TEXT,PRIMARY KEY(user_id,day))",
 "CREATE TABLE IF NOT EXISTS device_sessions(device_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,started INTEGER NOT NULL,last_seen INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS abuse_controls(user_id TEXT PRIMARY KEY,frozen INTEGER NOT NULL DEFAULT 0,reason TEXT NOT NULL DEFAULT '',updated INTEGER NOT NULL,admin_id TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS request_limits(bucket TEXT PRIMARY KEY,window INTEGER NOT NULL,n INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS shop_invoice_links(order_id TEXT PRIMARY KEY,url TEXT,lease_until INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS shop_checkout_leases(order_id TEXT PRIMARY KEY,query_id TEXT NOT NULL,until INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS shop_reconciliation(id TEXT PRIMARY KEY,offset INTEGER NOT NULL DEFAULT 0,last_at INTEGER NOT NULL DEFAULT 0,lease_until INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS deletion_requests(user_id TEXT PRIMARY KEY,created INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'pending')",
 "CREATE TABLE IF NOT EXISTS client_errors(user_id TEXT NOT NULL,day TEXT NOT NULL,platform TEXT NOT NULL,version TEXT NOT NULL,code TEXT NOT NULL,count INTEGER NOT NULL,last_at INTEGER NOT NULL,PRIMARY KEY(user_id,day,platform,version,code))",
 "CREATE TABLE IF NOT EXISTS daily_claims(user_id TEXT NOT NULL,day TEXT NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(user_id,day))",
 "CREATE INDEX IF NOT EXISTS step_reports_state ON step_reports(state,received)",
 "CREATE INDEX IF NOT EXISTS shop_orders_user_created ON shop_orders(user_id,created)",
 "CREATE INDEX IF NOT EXISTS tap_receipts_created ON tap_receipts(user_id,created)",
 "CREATE INDEX IF NOT EXISTS campaign_claims_pending ON campaign_claims(state,created)",
 "CREATE INDEX IF NOT EXISTS days_updated ON days(user_id,updated)",
 "CREATE INDEX IF NOT EXISTS support_chat_created ON support_chat(author_id,created)",
 "CREATE INDEX IF NOT EXISTS shop_purchases_created ON shop_purchases(user_id,created)"
]
DDL.push("CREATE TABLE IF NOT EXISTS shop_extra_charges(charge_id TEXT PRIMARY KEY,order_id TEXT NOT NULL,user_id TEXT NOT NULL,stars INTEGER NOT NULL,bot_id TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'pending')");

DDL.sort((a,b)=>Number(/CREATE (?:UNIQUE )?INDEX/.test(a))-Number(/CREATE (?:UNIQUE )?INDEX/.test(b)));

DDL.push('CREATE TABLE IF NOT EXISTS support_chat_legacy_cursor(id INTEGER PRIMARY KEY,last_id INTEGER NOT NULL DEFAULT 0)');

DDL.push('CREATE TABLE IF NOT EXISTS grant_reasons(admin_id TEXT NOT NULL,request_id TEXT NOT NULL,reason TEXT NOT NULL,PRIMARY KEY(admin_id,request_id))');

DDL.push('CREATE TABLE IF NOT EXISTS deleted_payment_audit(charge_id TEXT PRIMARY KEY,stars INTEGER NOT NULL,state TEXT NOT NULL,created INTEGER NOT NULL)');

DDL.push('CREATE TABLE IF NOT EXISTS daily_puzzles(day TEXT PRIMARY KEY,seed TEXT NOT NULL)');

DDL.push('CREATE TABLE IF NOT EXISTS bot_card_rotation(chat_hash TEXT PRIMARY KEY,message_id INTEGER NOT NULL,sequence INTEGER NOT NULL)');

DDL.push("CREATE TABLE IF NOT EXISTS grant_reversals(admin_id TEXT NOT NULL,request_id TEXT NOT NULL,original_request_id TEXT NOT NULL,user_id TEXT NOT NULL,units INTEGER NOT NULL CHECK(units>0),reason TEXT NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(admin_id,request_id))");
