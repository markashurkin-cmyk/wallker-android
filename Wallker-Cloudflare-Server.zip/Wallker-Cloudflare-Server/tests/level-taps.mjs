import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {LEVELS,walkingLevel} from '../level-catalog.mjs';
const {Miniflare}=await import(process.env.WALLKER_MINIFLARE_MODULE||'miniflare');
const root=fileURLToPath(new URL('../',import.meta.url)),botToken='123:LOCAL_LEVEL_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:botToken,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id){const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Волкер'})});const secret=createHmac('sha256','WebAppData').update(botToken).digest();const check=[...f].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');f.set('hash',createHmac('sha256',secret).update(check).digest('hex'));return f.toString()}
async function api(path,id=1002,data,token){const method=data===undefined?'GET':'POST';const headers={'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id)}:{}),...(token?{Authorization:'Bearer '+token}:{})};const r=await mf.dispatchFetch('http://localhost'+path,{method,headers,...(data!==undefined?{body:JSON.stringify(data)}:{})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])assert.equal((await api('/api/wallet',id)).status,200);
 const day=(await api('/api/wallet')).value.today;
 async function setSteps(n){
  await db.prepare('DELETE FROM days WHERE user_id=?').bind('tg:1002').run();
  for(let i=0;n>0;i++){const date=new Date(day+'T12:00:00Z');date.setUTCDate(date.getUTCDate()-i);const steps=Math.min(n,100000);await db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?)').bind('tg:1002',date.toISOString().slice(0,10),steps,Date.now(),'ios:unverified').run();n-=steps}
 }

 assert.equal((await api('/api/wallet')).value.tapReward,0.1);
 assert.equal((await api('/api/tap',1002,{requestId:'rank_one_fifteen_001',count:15})).value.tapCoins,1.5);
 await db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?)').bind('tg:1002',day,45000,Date.now(),'ios:unverified').run();
 for(const l of LEVELS){
  await setSteps(l.steps);
  const w=(await api('/api/wallet')).value;
  assert.equal(w.levels.level,l.level);assert.equal(w.tapReward,l.level/10);assert.equal(w.tapDailyLimit,1000+(l.level-1)*500);
  assert.equal(w.levels.catalog[l.level-1].tapReward,w.tapReward);
 }
 await setSteps(45000);
 const earned=(await api('/api/tap',1002,{requestId:'rank_two_fifteen_001',count:15,level:11,tapReward:100})).value;
 assert.equal(earned.tapCoins,4.5);assert.equal(earned.tapReward,0.2);
 await db.prepare('UPDATE tap_daily_paid SET units=149980 WHERE user_id=? AND day=?').bind('tg:1002',day).run();
 await db.prepare('UPDATE tap_paid SET units=149980 WHERE user_id=?').bind('tg:1002').run();
 const capped=await Promise.all(Array.from({length:4},(_,i)=>api('/api/tap',1002,{requestId:'rank_two_cap_race_00'+i,count:15})));
 assert.equal(capped.reduce((n,r)=>n+r.value.accepted,0),1);
 assert.equal((await api('/api/wallet')).value.tapTodayCoins,1500);
 await setSteps(90000);
 const replay=(await api('/api/tap',1002,{requestId:'rank_two_fifteen_001',count:15})).value;
 assert.equal(replay.tapReward,0.3);assert.equal(replay.tapTodayCoins,1500);assert.equal(replay.tapDailyRemaining,500);
 const config=(await api('/api/admin/rewards',1001)).value.settings;
 assert.equal(config.tapLevels.length,10);
 assert.equal((await api('/api/admin/rewards',1002,config)).status,403);
 assert.equal((await api('/api/admin/rewards',1001,{...config,tapLevels:config.tapLevels.slice(1)})).status,400);
 assert.equal((await api('/api/admin/rewards',1001,{...config,tapLevels:config.tapLevels.map(x=>({...x,tapReward:0.001}))})).status,400);
 const custom={...config,tapLevels:config.tapLevels.map(x=>x.level===2?{...x,tapReward:0.75,tapDailyLimit:2000}:x.level===11?{...x,tapReward:3,tapDailyLimit:12000}:x)};
 assert.equal((await api('/api/admin/rewards',1001,custom)).status,200);
 assert.equal((await api('/api/admin/rewards',1001,custom)).status,409);
 await setSteps(45000);
 const customTap=(await api('/api/tap',1002,{requestId:'rank_custom_fifteen_1',count:15})).value;
 assert.equal(customTap.tapReward,0.75);assert.equal(customTap.tapTodayCoins,1511.25);
 const smaller=(await api('/api/admin/rewards',1001)).value.settings;smaller.tapLevels[0].tapDailyLimit=100;
 await api('/api/admin/rewards',1001,smaller);
 const frozen=(await api('/api/wallet')).value;assert.equal(frozen.tapTodayCoins,1511.25);assert.equal(frozen.tapDailyRemaining,0);
 assert.equal((await api('/api/tap',1002,{requestId:'rank_cap_lowered_001',count:1})).value.accepted,0);
 assert.equal((await api('/api/admin/levels',1003,{level:11})).status,403);
 const god=(await api('/api/admin/levels',1001,{level:11})).value.levels;
 assert.equal(god.name,'Божественный Walker');assert.equal(god.totalSteps,0);assert.equal(god.catalog.length,11);assert.equal(god.catalog[10].unlocked,true);
 const godTap=(await api('/api/tap',1001,{requestId:'divine_fifteen_taps_1',count:15})).value;
 assert.equal(godTap.tapReward,3);assert.equal(godTap.tapDailyLimit,12000);assert.equal(godTap.tapCoins,45);
 await api('/api/admin/levels',1001,{level:null});
 const reset=(await api('/api/wallet',1001)).value;assert.equal(reset.tapReward,0.1);assert.equal(reset.tapDailyLimit,1000);assert.equal(reset.tapCoins,45);
 await db.prepare('INSERT INTO developer_levels(user_id,level) VALUES(?,11)').bind('tg:1003').run();
 const outsider=(await api('/api/wallet',1003)).value;assert.equal(outsider.levels.level,1);assert.equal(outsider.levels.catalog.length,10);assert.equal(outsider.tapReward,0.1);
 assert.equal((await api('/api/levels/claim',1003,{level:11})).status,400);
 const stats=(await api('/api/admin/stats/users?q=1002',1001)).value.users[0];assert.equal(stats.tapCoins,1511.25);
 console.log('PASS: per-rank tap rates and caps, server-authoritative rank, custom validated settings, stale-edit conflicts, concurrent cap enforcement, frozen replay awards, lower-cap preservation, owner-only Divine Walker and automatic reset.');
}finally{await mf.dispose()}
