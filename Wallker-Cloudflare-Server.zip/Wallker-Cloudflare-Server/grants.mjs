import {CampaignError} from './campaigns.mjs';
export async function grantHistory(db,admin,userId){
 if(!/^tg:[1-9]\d*$/.test(userId||''))throw new CampaignError('Укажи пользователя');
 return {grants:(await db.prepare('SELECT g.request_id,g.units/100.0 AS amount,g.created,COALESCE((SELECT SUM(r.units) FROM grant_reversals r WHERE r.admin_id=g.admin_id AND r.original_request_id=g.request_id),0)/100.0 AS reversed FROM admin_grants g WHERE g.admin_id=? AND g.user_id=? AND g.units>0 ORDER BY g.created DESC LIMIT 100').bind(admin.id,userId).all()).results};
}
export async function revokeGrant(db,admin,data){
 if(!/^tg:[1-9]\d*$/.test(data.userId||'')||! /^[a-zA-Z0-9_-]{16,80}$/.test(data.originalRequestId||'')||! /^[a-zA-Z0-9_-]{16,80}$/.test(data.requestId||'')||typeof data.amount!=='number'||!Number.isFinite(data.amount)||data.amount<0.01||data.amount>1000000||Math.abs(data.amount*100-Math.round(data.amount*100))>1e-7||typeof data.reason!=='string'||data.reason.trim().length<10||data.reason.length>300)throw new CampaignError('Укажи выдачу, сумму и причину возврата');
 const units=Math.round(data.amount*100),now=Date.now();
 await db.batch([
  db.prepare('INSERT OR IGNORE INTO grant_reversals(admin_id,request_id,original_request_id,user_id,units,reason,created) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM admin_grants g WHERE g.admin_id=? AND g.request_id=? AND g.user_id=? AND g.units>0 AND g.units-COALESCE((SELECT SUM(r.units) FROM grant_reversals r WHERE r.admin_id=g.admin_id AND r.original_request_id=g.request_id),0)>=?) AND NOT EXISTS(SELECT 1 FROM admin_grants WHERE admin_id=? AND request_id=?)').bind(admin.id,data.requestId,data.originalRequestId,data.userId,units,data.reason.trim(),now,admin.id,data.originalRequestId,data.userId,units,admin.id,data.requestId),
  db.prepare('INSERT OR IGNORE INTO admin_grants(admin_id,request_id,user_id,units,created) SELECT admin_id,request_id,user_id,-units,created FROM grant_reversals WHERE admin_id=? AND request_id=?').bind(admin.id,data.requestId),
  db.prepare('INSERT OR IGNORE INTO grant_reasons(admin_id,request_id,reason) SELECT admin_id,request_id,reason FROM grant_reversals WHERE admin_id=? AND request_id=?').bind(admin.id,data.requestId)
 ]);
 const receipt=await db.prepare('SELECT * FROM grant_reversals WHERE admin_id=? AND request_id=?').bind(admin.id,data.requestId).first();
 if(!receipt)throw new CampaignError('Выдача не найдена или сумма уже отозвана',409);
 if(receipt.user_id!==data.userId||receipt.original_request_id!==data.originalRequestId||receipt.units!==units||receipt.reason!==data.reason.trim())throw new CampaignError('Номер возврата уже использован',409);
 return {ok:true,userId:receipt.user_id,amount:-receipt.units/100,created:receipt.created};
}
export async function ensureGrants(db){if(db.schemaReady)return;await db.prepare('CREATE TABLE IF NOT EXISTS admin_grants(admin_id TEXT NOT NULL,request_id TEXT NOT NULL,user_id TEXT NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(admin_id,request_id))').run();}
export async function grantBalance(db,id){await ensureGrants(db);return (await db.prepare('SELECT COALESCE(SUM(units),0)/100.0 AS n FROM admin_grants WHERE user_id=?').bind(id).first()).n;}
export async function grantTokens(db,admin,data){
 if(typeof data.userId!=='string'||!/^tg:[1-9]\d*$/.test(data.userId)||typeof data.amount!=='number'||!Number.isFinite(data.amount)||(data.amount<0.01 && !(data.action==='correction' && data.amount<=-0.01 && data.amount>=-1000000 && typeof data.reason==='string' && data.reason.trim().length>=10 && data.reason.length<=300))||data.amount>1000000||Math.abs(data.amount*100-Math.round(data.amount*100))>1e-7||typeof data.requestId!=='string'||!/^[a-zA-Z0-9_-]{16,80}$/.test(data.requestId))throw new CampaignError('Укажи пользователя и от 0,01 до 1 000 000 WC');
 if(data.action==='correction'&&(typeof data.reason!=='string'||data.reason.trim().length<10||data.reason.length>300))throw new CampaignError('Укажи причину коррекции от 10 до 300 символов');
 await ensureGrants(db);const units=Math.round(data.amount*100);
 const writes=[db.prepare('INSERT OR IGNORE INTO admin_grants(admin_id,request_id,user_id,units,created) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM users WHERE id=?)').bind(admin.id,data.requestId,data.userId,units,Date.now(),data.userId)];
 if(data.action==='correction')writes.push(db.prepare('INSERT OR IGNORE INTO grant_reasons(admin_id,request_id,reason) SELECT admin_id,request_id,? FROM admin_grants WHERE admin_id=? AND request_id=? AND user_id=? AND units=?').bind(data.reason,admin.id,data.requestId,data.userId,units));
 await db.batch(writes);
 const receipt=await db.prepare('SELECT user_id,units,created FROM admin_grants WHERE admin_id=? AND request_id=?').bind(admin.id,data.requestId).first();
 if(!receipt)throw new CampaignError('Пользователь не найден',404);
 if(receipt.user_id!==data.userId||receipt.units!==units)throw new CampaignError('Номер выдачи уже использован для другого начисления',409);
 
 return {ok:true,userId:receipt.user_id,amount:receipt.units/100,created:receipt.created};
}
