import {GrowthError,growthSettings} from './growth-config.mjs';
import {seasonState} from './growth.mjs';
const validID=s=>typeof s==='string'&&/^[a-zA-Z0-9_-]{8,80}$/.test(s);
export function seasonScoreSource(season,now,config,creator=false){
 config=season.rules?JSON.parse(season.rules):config;
 const quality=alias=>`NOT EXISTS(SELECT 1 FROM growth_trust t WHERE t.user_id IN (${alias}.inviter,${alias}.invitee) AND t.state='RESTRICTED') AND NOT EXISTS(SELECT 1 FROM abuse_controls b WHERE b.user_id IN (${alias}.inviter,${alias}.invitee) AND b.frozen=1)`;
 if(creator){
  // Count eligibility once per inviter, not twice for every invited account.
  // The same grouped pass computes lifetime-at-cutoff Active and season score.
  // Frozen season criteria and [start,end) semantics remain unchanged.
  const cutoff=Math.min(now+1,season.ends);
  return {sql:`WITH eligible_totals AS MATERIALIZED (
   SELECT inviter FROM referral_qualified WHERE qualified<? GROUP BY inviter HAVING COUNT(*)>=?
  ) SELECT p.inviter AS subject,SUM(CASE WHEN p.legacy=0 AND p.activated>=? THEN 1 ELSE 0 END) AS score
  FROM eligible_totals e JOIN growth_activations p ON p.inviter=e.inviter
  WHERE p.activated<? AND ${quality('p')}
  GROUP BY p.inviter HAVING COUNT(*)>=? AND score>0`,args:[cutoff,config.creatorTotal,season.starts,cutoff,config.creatorActive]};
 }
 return {sql:`SELECT a.inviter AS subject,COUNT(*) AS score FROM growth_activations a
 WHERE a.legacy=0 AND a.activated>=? AND a.activated<? AND a.activated<=? AND ${quality('a')}
 GROUP BY a.inviter`,args:[season.starts,season.ends,now]};
}
export async function saveSeason(db,actor,data,now=Date.now()){
 if(!validID(data.id)||!['referral','founder'].includes(data.kind)||!['draft','scheduled','active','finished','archived'].includes(data.status)||!Number.isSafeInteger(data.starts)||!Number.isSafeInteger(data.ends)||data.ends<=data.starts||data.ends-data.starts>366*86400000)throw new GrowthError('Invalid season');
 for(const k of ['title_ru','title_en'])if(typeof data[k]!=='string'||!data[k].trim()||data[k].length>100)throw new GrowthError('Both season titles are required');
 const rules=JSON.stringify(await growthSettings(db));
 const old=await db.prepare('SELECT * FROM growth_seasons WHERE id=?').bind(data.id).first();
 if(old){
  if(old.revision!==data.revision)throw new GrowthError('Season changed. Refresh.',409);
  if(old.kind!==data.kind)throw new GrowthError('Season kind is immutable',409);
  if(old.status!=='draft'&&(old.starts!==data.starts||old.ends!==data.ends||old.title_ru!==data.title_ru||old.title_en!==data.title_en))throw new GrowthError('Published season rules are frozen',409);
  const transitions={draft:['draft','scheduled','active','archived'],scheduled:['scheduled','active','finished','archived'],active:['active','finished'],finished:['finished','archived'],archived:['archived']};
  if(!transitions[old.status].includes(data.status))throw new GrowthError('Invalid season transition',409);
 }
 if(data.status==='active'&&!(data.starts<=now&&data.ends>now))throw new GrowthError('Active season must be inside its period');
 if(data.status==='scheduled'&&data.starts<=now)throw new GrowthError('Scheduled season must start later');
 if(data.status==='finished'&&data.ends>now)throw new GrowthError('Cannot finish before the published end');
 if(data.status==='archived'&&old&&['scheduled','active'].includes(old.status)&&old.ends>now)throw new GrowthError('Cannot archive a running published season');
 if(!old&&['finished','archived'].includes(data.status))throw new GrowthError('Create a draft first');
 if(data.kind==='founder'&&!old&&await db.prepare("SELECT id FROM growth_seasons WHERE kind='founder'").first())throw new GrowthError('Founder Season is one-time',409);
 if(old){const r=await db.prepare('UPDATE growth_seasons SET title_ru=?,title_en=?,status=?,starts=?,ends=?,updated=?,rules=?,revision=revision+1 WHERE id=? AND revision=? RETURNING id').bind(data.title_ru.trim(),data.title_en.trim(),data.status,data.starts,data.ends,now,old.status==='draft'?rules:old.rules,data.id,data.revision).first();if(!r)throw new GrowthError('Season changed. Refresh.',409)}
 else {
  // Conflict-safe duplicate submission without swallowing a different draft.
  await db.prepare('INSERT OR IGNORE INTO growth_seasons(id,kind,title_ru,title_en,status,starts,ends,created,updated,rules) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(data.id,data.kind,data.title_ru.trim(),data.title_en.trim(),data.status,data.starts,data.ends,now,now,rules).run();
  const row=await db.prepare('SELECT * FROM growth_seasons WHERE id=?').bind(data.id).first();if(!row||row.starts!==data.starts||row.ends!==data.ends||row.kind!==data.kind||row.title_ru!==data.title_ru.trim()||row.title_en!==data.title_en.trim()||row.status!==data.status)throw new GrowthError('Season conflicts with another request',409);
 }
 await db.prepare("INSERT INTO growth_audit(actor,action,target,before_value,after_value,reason,created) VALUES(?,'season',?,?,?,'Owner season change',?)").bind(actor,data.id,JSON.stringify(old),JSON.stringify(data),now).run();return {ok:true};
}
export async function finalizeSeasons(db,now=Date.now()){
 const config=await growthSettings(db),seasons=(await db.prepare("SELECT * FROM growth_seasons WHERE status IN ('scheduled','active','finished') AND ends<=? ORDER BY ends LIMIT 10").bind(now).all()).results;
 for(const season of seasons){
  const source=seasonScoreSource(season,season.ends-1,config),creatorSource=seasonScoreSource(season,season.ends-1,config,true);
  // marker prevents a later retry/review from rewriting finalized results.
  const done=await db.prepare('SELECT season_id FROM growth_season_finalized WHERE season_id=?').bind(season.id).first();if(done)continue;
  await db.batch([
   db.prepare(`INSERT OR IGNORE INTO growth_season_results(season_id,user_id,score,rank,created) SELECT ?,subject,score,RANK() OVER(ORDER BY score DESC),? FROM (${source.sql}) WHERE NOT EXISTS(SELECT 1 FROM growth_season_finalized WHERE season_id=?)`).bind(season.id,now,...source.args,season.id),
   db.prepare(`INSERT OR IGNORE INTO growth_creator_results(season_id,user_id,score,rank,created) SELECT ?,subject,score,RANK() OVER(ORDER BY score DESC),? FROM (${creatorSource.sql}) WHERE NOT EXISTS(SELECT 1 FROM growth_season_finalized WHERE season_id=?)`).bind(season.id,now,...creatorSource.args,season.id),
   db.prepare(`INSERT OR IGNORE INTO growth_season_claims(season_id,user_id,badge,created) SELECT season_id,user_id,'season-participant',? FROM growth_season_results WHERE season_id=?`).bind(now,season.id),
   db.prepare('INSERT OR IGNORE INTO growth_season_finalized(season_id,created) VALUES(?,?)').bind(season.id,now),
   db.prepare("UPDATE growth_seasons SET status='finished',updated=? WHERE id=? AND status!='archived'").bind(now,season.id)
  ]);
 }
 await db.prepare("UPDATE growth_seasons SET status='active',updated=? WHERE status='scheduled' AND starts<=? AND ends>?").bind(now,now,now).run();
}
