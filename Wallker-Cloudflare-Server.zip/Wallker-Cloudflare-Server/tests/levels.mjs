import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {LEVELS,walkingLevel} from '../level-catalog.mjs';
const {Miniflare}=await import(process.env.WALLKER_MINIFLARE_MODULE||'miniflare');
const root=fileURLToPath(new URL('../',import.meta.url)),botToken='123:LOCAL_LEVEL_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:botToken,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id){const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Волкер'})});const secret=createHmac('sha256','WebAppData').update(botToken).digest();const check=[...f].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');f.set('hash',createHmac('sha256',secret).update(check).digest('hex'));return f.toString()}
async function api(path,id=1002,data,token){const method=data===undefined?'GET':'POST';const headers={'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id)}:{}),...(token?{Authorization:'Bearer '+token}:{})};const r=await mf.dispatchFetch('http://localhost'+path,{method,headers,...(data!==undefined?{body:JSON.stringify(data)}:{})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])assert.equal((await api('/api/wallet',id)).status,200);
 for(const level of LEVELS){assert.equal(walkingLevel(level.steps).level,level.level);if(level.steps>0)assert.equal(walkingLevel(level.steps-1).level,level.level-1)}
 assert.equal((await api('/api/levels',null)).status,401);
 assert.equal((await api('/api/levels/claim',null,{level:2})).status,401);
 const initial=(await api('/api/levels')).value.levels;assert.equal(initial.level,1);assert.equal(initial.totalSteps,0);assert.equal(initial.nextSteps,45000);assert.equal(initial.availableCoins,0);assert.equal(initial.catalog.length,10);assert.equal(initial.catalog[0].claimed,true);
 assert.equal((await api('/api/levels/claim',1002,{level:2})).status,409);
 for(const level of [0,1,11,2.1,'2',null])assert.equal((await api('/api/levels/claim',1002,{level})).status,400);
 const code=(await api('/api/wallet',1002,{action:'pair'})).value.code;
 const token=(await api('/api/device/pair',null,{code,platform:'ios'})).value.token;
 const day=(await api('/api/wallet')).value.today;
 assert.equal((await api('/api/device/steps',null,{day,steps:44999},token)).status,200);assert.equal((await api('/api/levels')).value.levels.level,1);
 assert.equal((await api('/api/device/steps',null,{day,steps:45000},token)).status,200);
 const unlocked=(await api('/api/levels')).value.levels;assert.equal(unlocked.level,2);assert.equal(unlocked.availableCoins,50);assert.equal(unlocked.catalog[1].unlocked,true);assert.equal(unlocked.catalog[1].claimed,false);
 const base=(await api('/api/wallet')).value.balance;
 const claims=await Promise.all(Array.from({length:5},()=>api('/api/levels/claim',1002,{level:2,reward:999999,steps:500000,userId:'tg:1003'})));
 assert.ok(claims.every(r=>r.status===200&&r.value.coins===50));
 const wallet=(await api('/api/wallet')).value;assert.equal(wallet.balance,base+50);assert.equal(wallet.levelCoins,50);assert.equal(wallet.levels.coins,50);assert.equal(wallet.levels.availableCoins,0);
 assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM level_claims WHERE user_id=?').bind('tg:1002').first()).n,1);
 assert.equal((await api('/api/levels/claim',1003,{level:2,userId:'tg:1002'})).status,409);
 assert.equal((await api('/api/wallet',1003)).value.levelCoins,0);
 await api('/api/device/steps',null,{day,steps:45000},token);await api('/api/device/steps',null,{day,steps:500},token);
 assert.equal((await api('/api/levels')).value.levels.totalSteps,45000);assert.equal((await api('/api/wallet')).value.balance,base+50);
 // A large tap balance is not walking progress; levels follow daily step sums only.
 await db.prepare('UPDATE tap_state SET total=1000000 WHERE user_id=?').bind('tg:1003').run();await db.prepare('UPDATE tap_paid SET units=10000000 WHERE user_id=?').bind('tg:1003').run();
 assert.equal((await api('/api/wallet',1003)).value.levels.level,1);
 // Existing synced history counts on launch, without inventing steps or paying automatically.
 await db.prepare('UPDATE days SET steps=100000 WHERE user_id=? AND day=?').bind('tg:1002',day).run();
 for(let i=1;i<=4;i++){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-i);await db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?)').bind('tg:1002',d.toISOString().slice(0,10),100000,Date.now(),'ios:unverified').run()}
 const legend=(await api('/api/levels')).value.levels;assert.equal(legend.level,10);assert.equal(legend.totalSteps,500000);assert.equal(legend.progress,1);assert.equal(legend.nextSteps,null);assert.equal(legend.remainingSteps,0);assert.equal(legend.coins,50);
 assert.equal(legend.availableCoins,LEVELS.reduce((s,l)=>s+l.reward,0)-50);
 const before=(await api('/api/wallet')).value.balance;
 // Claim higher levels out of order; each threshold reward remains independently claimable.
 for(const level of [...LEVELS].reverse().filter(l=>l.level>=3))assert.equal((await api('/api/levels/claim',1002,{level:level.level})).status,200);
 const total=LEVELS.reduce((s,l)=>s+l.reward,0),final=(await api('/api/wallet')).value;assert.equal(final.levelCoins,total);assert.equal(final.balance,before+total-50);assert.equal(final.levels.availableCoins,0);
 await api('/api/levels/claim',1002,{level:10});assert.equal((await api('/api/wallet')).value.balance,final.balance);
 // Only the signed owner can choose a level; it never forges real step history.
 assert.equal((await api('/api/admin/levels',1002)).status,403);
 assert.equal((await api('/api/admin/levels',1002,{level:10})).status,403);
 for(const level of [0,12,'10',2.5])assert.equal((await api('/api/admin/levels',1001,{level})).status,400);
 const ownerBase=(await api('/api/wallet',1001)).value.balance;
 const chosen=(await api('/api/admin/levels',1001,{level:10,userId:'tg:1003'})).value.levels;
 assert.equal(chosen.level,10);assert.equal(chosen.totalSteps,0);assert.equal(chosen.naturalLevel,1);assert.equal(chosen.developerOverride,10);
 assert.equal((await api('/api/wallet',1001)).value.levels.level,10);
 assert.equal((await api('/api/wallet',1003)).value.levels.level,1);
 assert.equal((await api('/api/levels/claim',1001,{level:10})).status,200);
 assert.equal((await api('/api/wallet',1001)).value.balance,ownerBase+12000);
 await api('/api/admin/levels',1001,{level:2});await api('/api/admin/levels',1001,{level:10});await api('/api/levels/claim',1001,{level:10});
 assert.equal((await api('/api/wallet',1001)).value.balance,ownerBase+12000);
 const automatic=(await api('/api/admin/levels',1001,{level:null})).value.levels;
 assert.equal(automatic.level,1);assert.equal(automatic.developerOverride,null);assert.equal(automatic.coins,12000);
 assert.equal((await api('/api/levels/claim',1001,{level:9})).status,409);
 // Stale overrides are ignored if the account is no longer an administrator.
 await db.prepare('INSERT INTO developer_levels(user_id,level) VALUES(?,10)').bind('tg:1003').run();
 assert.equal((await api('/api/levels',1003)).value.levels.level,1);
 assert.equal((await api('/api/levels/claim',1003,{level:9})).status,409);
 const stats=(await api('/api/admin/stats/users?q=1002',1001)).value.users[0];assert.equal(stats.balance,final.balance);assert.equal(stats.levelCoins,total);
 const totals=(await api('/api/admin/stats',1001)).value.totals;assert.equal(totals.levelCoins,total+12000);
 const details=(await api('/api/admin/stats/user?id=tg:1002',1001)).value;assert.equal(details.levels.level,10);assert.equal(details.levels.coins,total);assert.equal(details.user.balance,final.balance);
 assert.equal((await api('/api/levels',1002,{})).status,405);
 console.log('PASS: all walking level boundaries, accumulated history, no tap-based progress, server eligibility, independent account awards, forged reward rejection, concurrent/replayed claims exactly once, max-level progress and exact wallet/admin balance reconciliation.');
}finally{await mf.dispose()}
