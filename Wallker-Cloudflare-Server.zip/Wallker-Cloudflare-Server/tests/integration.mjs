import assert from 'node:assert/strict';
import {createHmac,createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
// Local test uses the installed Workers runtime and a separate ephemeral SQLite/D1 database.
const {Miniflare} = await import(process.env.WALLKER_MINIFLARE_MODULE || 'miniflare');
const {configureBot,TelegramSetupError}=await import('../worker.js');
const root = fileURLToPath(new URL('../', import.meta.url));
const botToken = '12345:LOCAL_TEST_ONLY_NOT_A_TELEGRAM_TOKEN';
const webhookSecret = 'local-test-webhook-secret';
const mf = new Miniflare({modules:true, scriptPath:root+'worker.js', compatibilityDate:'2026-05-15', d1Databases:['DB'], bindings:{TELEGRAM_BOT_TOKEN:botToken, TELEGRAM_WEBHOOK_SECRET:webhookSecret, ALLOWED_ORIGINS:'https://allowed.example',ADMIN_TELEGRAM_ID:'1001'}});
function initData(id=1001, authDate=Math.floor(Date.now()/1000)) {
  const fields = new URLSearchParams({auth_date:String(authDate), query_id:'local-test-query', user:JSON.stringify({id,first_name:'Тест'})});
  const secret = createHmac('sha256','WebAppData').update(botToken).digest();
  const check = [...fields].sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join('\n');
  fields.set('hash',createHmac('sha256',secret).update(check).digest('hex'));
  return fields.toString();
}
function dayOffset(offset) { const date=new Date(); const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Tomsk',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date); const get=key=>parts.find(p=>p.type===key).value; const d=new Date(`${get('year')}-${get('month')}-${get('day')}T12:00:00Z`); d.setUTCDate(d.getUTCDate()+offset); return d.toISOString().slice(0,10); }
async function api(path, {method='GET',data,init,token,origin,secret}={}) {
  const headers = {'Content-Type':'application/json'};
  if(init) headers['X-Telegram-Init-Data']=init;
  if(token) headers.Authorization=`Bearer ${token}`;
  if(origin) headers.Origin=origin;
  if(secret) headers['X-Telegram-Bot-Api-Secret-Token']=secret;
  const response = await mf.dispatchFetch('http://localhost'+path,{method,headers,...(data!==undefined ? {body:JSON.stringify(data)} : {})});
  let value=response.status===204 ? null : await response.json();

  return {status:response.status,value,headers:response.headers};
}
try {
  const db=await mf.getD1Database('DB');
  const schema=(await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'');
  for(const sql of schema.split(';').map(s=>s.trim()).filter(Boolean)) await db.prepare(sql).run();
  const auth=initData();
  assert.equal((await api('/api/health')).status,200);
  assert.equal((await api('/api/wallet')).status,401);
  assert.equal((await api('/api/wallet',{init:initData(1001,Math.floor(Date.now()/1000)-3601)})).status,401);
  assert.equal((await api('/api/wallet',{init:auth.slice(0,-1)+(auth.endsWith('0')?'1':'0')})).status,401);
  const initial=await api('/api/wallet?timezone=Asia%2FTomsk',{init:auth});
  assert.equal(initial.status,200); assert.equal(initial.value.user.timezone,'Asia/Tomsk');
  const created=await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}});
  assert.equal(created.status,200); assert.match(created.value.code,/^[a-f0-9]{48}$/);
  const wrongCode=await api('/api/device/pair',{method:'POST',data:{code:'0'.repeat(48),platform:'android'}});
  assert.equal(wrongCode.status,401); assert.match(wrongCode.value.error,/Такой код не найден/);
  assert.ok(!wrongCode.value.error.includes('0'.repeat(48)));
  const pairing=(await Promise.all([1,2].map(()=>api('/api/device/pair',{method:'POST',data:{code:created.value.code,platform:'android'}}))));
  assert.deepEqual(pairing.map(p=>p.status).sort(),[200,401]);
  assert.match(pairing.find(p=>p.status===401).value.error,/уже использован/);
  const token=pairing.find(p=>p.status===200).value.token;
  assert.match(token,/^[a-f0-9]{48}$/);
  const stored=await db.prepare('SELECT code_hash,device_hash FROM pairings LIMIT 1').first();
  assert.notEqual(stored.code_hash,created.value.code); assert.notEqual(stored.device_hash,token);
  const sync=(steps,day=dayOffset(0))=>api('/api/device/steps',{method:'POST',token,data:{day,steps}});
  assert.equal((await sync(3500)).status,200);
  assert.equal((await sync(3500)).value.coins,1400);
  assert.equal((await sync(2000)).value.steps,3500);
  assert.equal((await sync(7500)).value.coins,3000);
  assert.equal((await sync(12000)).value.coins,4000);
  assert.equal((await sync(100001)).status,400);
  assert.equal((await sync(-1)).status,400);
  assert.equal((await sync(1000,dayOffset(1))).status,400);
  assert.equal((await sync(1000,dayOffset(-7))).status,400);
  assert.equal((await sync(1000,dayOffset(-6))).status,200);
  const snapshot=await api('/api/wallet',{init:auth});
  assert.equal(snapshot.value.balance,4010); assert.equal(snapshot.value.todayCoins,4000);
  const repairCode=(await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}})).value.code;
  const check=await api('/api/device/pair',{method:'POST',token,data:{code:repairCode,platform:'android',checkOnly:true}});
  assert.equal(check.status,200); assert.equal(check.value.sameAccount,true);
  assert.match(check.value.accountId,/^[a-f0-9]{64}$/);
  const unchecked=await api('/api/device/pair',{method:'POST',data:{code:repairCode,platform:'android',checkOnly:true}});
  assert.equal(unchecked.value.sameAccount,null);
  const mismatch=await api('/api/device/pair',{method:'POST',token,data:{code:repairCode,platform:'android',expectedAccountId:'incorrect'}});
  assert.equal(mismatch.status,409);
  assert.equal((await sync(12000)).status,200); // Preflight and refusal do not consume the code or revoke the old device.
  const repaired=await api('/api/device/pair',{method:'POST',token,data:{code:repairCode,platform:'android',expectedAccountId:check.value.accountId}});
  assert.equal(repaired.status,200); assert.equal(repaired.value.accountId,check.value.accountId);
  assert.ok(repaired.value.history.some(h=>h.day===dayOffset(0)&&h.steps===12000));
  assert.equal((await sync(12000)).status,401); // Only the replaced device credential is revoked.
  const repairedSync=await api('/api/device/steps',{method:'POST',token:repaired.value.token,data:{day:dayOffset(0),steps:12000}});
  assert.equal(repairedSync.value.coins,4000);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,4010);
  assert.equal((await api('/api/wallet',{init:auth})).value.devices.length,1);
  const other=await api('/api/wallet',{init:initData(1002)});
  assert.equal(other.value.balance,0); assert.equal(other.value.devices.length,0);
  const otherCode=(await api('/api/wallet',{method:'POST',init:initData(1002),data:{action:'pair'}})).value.code;
  const otherCheck=await api('/api/device/pair',{method:'POST',token:repaired.value.token,data:{code:otherCode,platform:'android',checkOnly:true}});
  assert.equal(otherCheck.value.sameAccount,false); assert.notEqual(otherCheck.value.accountId,check.value.accountId);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,4010);
  const calls=[];
  const fakeTelegram=async (_env,method,data)=>{
    calls.push({method,data});
    if(method==='getMe')return {id:12345,username:'wallker_wallet_bot'};
    if(method==='getMyName')return {name:'Walker Wallet'};
    if(method==='getUserProfilePhotos')return {photos:[[{file_id:'test-avatar'}]]};
    if(method==='getWebhookInfo')return {url:'https://wallker-wallet.markashurkin.workers.dev/api/telegram/webhook'};
    if(method==='getChatMenuButton')return {type:'web_app',web_app:{url:'https://wallker-wallet.markashurkin.workers.dev/'}};
    return true;
  };
  const setupEnv={DB:db,TELEGRAM_BOT_TOKEN:botToken,BOT_AUTO_SETUP:'true'};
  assert.equal(await configureBot(setupEnv,fakeTelegram),'ready');
  assert.deepEqual(calls.map(c=>c.method),['getMe','setWebhook','setChatMenuButton','setMyName','setMyName','setMyDescription','setMyDescription','setMyShortDescription','setMyShortDescription','setMyProfilePhoto','getMyName','getUserProfilePhotos','getWebhookInfo','getChatMenuButton']);
  assert.match(calls[1].data.secret_token,/^[a-f0-9]{64}$/);
  assert.equal(calls[1].data.drop_pending_updates,false);
  assert.equal(await configureBot(setupEnv,fakeTelegram),'ready'); assert.equal(calls.length,14);
  await db.prepare("UPDATE bot_setup SET ready=0,lease_until=0 WHERE id='telegram'").run();
  const rejectedTelegram=async (_env,method,data)=>{
    if(method==='setChatMenuButton')throw new TelegramSetupError(400,'telegram_url_rejected');
    return fakeTelegram(_env,method,data);
  };
  assert.equal(await configureBot(setupEnv,rejectedTelegram),'configuration_failed');
  const diagnostic=await db.prepare("SELECT stage,code,reason FROM bot_setup_errors WHERE id='telegram'").first();
  assert.deepEqual(diagnostic,{stage:'setChatMenuButton',code:400,reason:'telegram_url_rejected'});
  assert.ok(!JSON.stringify(diagnostic).includes(botToken));
  assert.equal(await configureBot(setupEnv,fakeTelegram),'configuration_failed'); // A failed attempt is not mislabeled pending during cooldown.
  await db.prepare("UPDATE bot_setup SET lease_until=0 WHERE id='telegram'").run();
  assert.equal(await configureBot(setupEnv,fakeTelegram),'ready');
  assert.equal(await db.prepare("SELECT id FROM bot_setup_errors WHERE id='telegram'").first(),null);
  await db.prepare("UPDATE bot_setup SET ready=0,lease_until=0 WHERE id='telegram'").run();
  const wrongBotCalls=[];
  assert.equal(await configureBot(setupEnv,async (_env,method)=>{wrongBotCalls.push(method);return {username:'other_bot'};}),'configuration_failed');
  assert.deepEqual(wrongBotCalls,['getMe']);
  assert.equal((await db.prepare("SELECT reason FROM bot_setup_errors WHERE id='telegram'").first()).reason,'bot_identity_mismatch');
  // Equivalent root URL is accepted; wrong routing remains rejected.
  for(const scenario of [
    {method:'getWebhookInfo',result:{url:'https://wallker-wallet.markashurkin.chatgpt.site/api/telegram/webhook'},reason:'telegram_webhook_address_mismatch'},
    {method:'getChatMenuButton',result:{type:'commands'},reason:'telegram_menu_type_mismatch'},
    {method:'getChatMenuButton',result:{type:'web_app',web_app:{url:'https://wallker-wallet.markashurkin.chatgpt.site/'}},reason:'telegram_menu_address_mismatch'},
    {method:'getChatMenuButton',result:{type:'web_app',web_app:{url:'https://wallker-wallet.markashurkin.workers.dev/?other=1'}},reason:'telegram_menu_address_mismatch'},
    {method:'getChatMenuButton',result:{type:'web_app',web_app:{url:'https://someone@wallker-wallet.markashurkin.workers.dev/'}},reason:'telegram_menu_address_mismatch'}
  ]) {
    await db.prepare("UPDATE bot_setup SET ready=0,lease_until=0 WHERE id='telegram'").run();
    assert.equal(await configureBot(setupEnv,async (_env,method,data)=>method===scenario.method ? scenario.result : fakeTelegram(_env,method,data)),'configuration_failed');
    const row=await db.prepare("SELECT stage,reason FROM bot_setup_errors WHERE id='telegram'").first();
    assert.deepEqual(row,{stage:'verifyConfiguration',reason:scenario.reason});
  }
  await db.prepare("UPDATE bot_setup SET lease_until=0 WHERE id='telegram'").run();
  assert.equal(await configureBot(setupEnv,fakeTelegram),'ready');
  const storedSetup=await db.prepare('SELECT config_hash FROM bot_setup').first();
  assert.ok(!storedSetup.config_hash.includes(botToken));
  const rejected=await api('/api/wallet',{method:'POST',init:auth,origin:'https://untrusted.example',data:{action:'pair'}});
  assert.equal(rejected.status,403); assert.equal(rejected.headers.get('Access-Control-Allow-Origin'),null);
  assert.equal((await api('/api/health',{method:'OPTIONS',origin:'https://allowed.example'})).status,204);
  assert.equal((await api('/api/health',{origin:'https://allowed.example'})).headers.get('Access-Control-Allow-Origin'),'https://allowed.example');
  assert.equal((await api('/api/telegram/webhook',{method:'POST',data:{}})).status,401);
  const botMessage=(message_id,content,chat_id=1001)=>api('/api/telegram/webhook',{method:'POST',secret:webhookSecret,data:{message:{message_id,chat:{id:chat_id,type:'private'},...content}}});
  const webhook=await botMessage(100,{text:'/start'});
  assert.equal(webhook.status,200); assert.equal(webhook.value.reply_markup.inline_keyboard[0][0].web_app.url,'https://wallker-wallet.markashurkin.workers.dev');
  assert.match(webhook.value.caption,/Волк готов/);
  assert.equal(webhook.value.method,'sendPhoto');
  assert.equal(webhook.value.photo,'https://wallker-wallet.markashurkin.workers.dev/wolf-walk-1.jpg');
  const contents=[{text:'привет'},{text:'/something'},{sticker:{file_id:'test'}},{photo:[{file_id:'test'}]}];
  for(let i=0;i<contents.length;i++) {
    // Incoming IDs advance by two because bot replies also consume IDs.
    const r=await botMessage(102+i*2,contents[i]);
    const card=i%2===0 ? 2 : 1;
    assert.equal(r.value.method,'sendPhoto'); assert.match(r.value.caption,/Walker Wallet/);
    assert.equal(r.value.photo,`https://wallker-wallet.markashurkin.workers.dev/wolf-walk-${card}.jpg`);
  }
  const repeated=await botMessage(108,contents[3]);
  assert.equal(repeated.value.photo,'https://wallker-wallet.markashurkin.workers.dev/wolf-walk-1.jpg');
  const secondChat=await botMessage(500,{text:'привет'},1002);
  assert.equal(secondChat.value.photo,'https://wallker-wallet.markashurkin.workers.dev/wolf-walk-1.jpg');
  assert.equal((await botMessage(110,{text:'/privacy'})).value.method,'sendMessage');
  assert.equal((await botMessage(112,{text:'дальше'})).value.photo,'https://wallker-wallet.markashurkin.workers.dev/wolf-walk-2.jpg');
  const group=await api('/api/telegram/webhook',{method:'POST',secret:webhookSecret,data:{message:{chat:{id:-10,type:'group'},text:'hi'}}});
  assert.deepEqual(group.value,{ok:true});
  assert.equal((await api('/api/device/revoke',{method:'POST',init:auth,data:{}})).status,200);
  assert.equal((await sync(4000)).status,401);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,4010);
  const expired=await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}});
  await db.prepare('UPDATE pairings SET expires=0 WHERE device_hash IS NULL').run();
  const expiredAttempt=await api('/api/device/pair',{method:'POST',data:{code:expired.value.code,platform:'android'}});
  assert.equal(expiredAttempt.status,401); assert.match(expiredAttempt.value.error,/Срок действия/);
  const huge=await api('/api/device/pair',{method:'POST',data:{padding:'x'.repeat(9000)}});
  assert.equal(huge.status,413);
  assert.equal((await api('/api/device/pair',{method:'GET'})).status,405);
  assert.equal((await api('/api/unknown')).status,404);

  const admin=(path,data)=>api(path,{method:data===undefined?'GET':'POST',init:auth,data});
  const member=(path,data)=>api(path,{method:data===undefined?'GET':'POST',init:initData(1002),data});
  assert.equal((await member('/api/admin/campaigns')).status,403);
  assert.equal((await member('/api/admin/mascot',{partner:'x',url:'https://example.com',active:true})).status,403);
  assert.equal((await api('/api/admin/campaigns')).status,401);
  const walletAdmin=(await admin('/api/wallet')).value;assert.equal(walletAdmin.isAdmin,true);assert.equal(walletAdmin.telegramId,'1001');
  assert.equal((await member('/api/wallet')).value.isAdmin,false);
  const draft={title:'5000 шагов',description:'Передай шаги за сегодня',kind:'steps',partner:'',url:'',target:5000,reward:33,starts:Date.now()-60000,ends:Date.now()+86400000,status:'draft'};
  const id=(await admin('/api/admin/campaigns',draft)).value.id;assert.ok(id);
  assert.equal((await admin('/api/campaigns')).value.campaigns.length,0);
  assert.equal((await member('/api/campaigns/claim',{id})).status,409);
  assert.equal((await admin('/api/admin/campaigns',{...draft,id,status:'published'})).status,200);
  assert.equal((await member('/api/campaigns/claim',{id})).status,400);
  const before=(await admin('/api/wallet')).value.balance;
  const raced=await Promise.all([admin('/api/campaigns/claim',{id}),admin('/api/campaigns/claim',{id})]);
  assert.ok(raced.every(r=>r.status===200&&r.value.state==='approved'));
  assert.equal((await admin('/api/wallet')).value.balance,before+33);
  const partner={...draft,title:'Партнёр',kind:'partner',partner:'Brand',url:'https://example.com/task',reward:70,status:'published'};
  const partnerId=(await admin('/api/admin/campaigns',partner)).value.id;
  assert.equal((await member('/api/campaigns/claim',{id:partnerId,proof:''})).status,400);
  assert.equal((await member('/api/campaigns/claim',{id:partnerId,proof:'account'})).value.state,'pending');
  assert.equal((await member('/api/wallet')).value.balance,0);
  assert.equal((await member('/api/admin/claims',{id:partnerId,userId:'tg:1002',state:'approved'})).status,403);
  assert.equal((await admin('/api/admin/campaigns',{...partner,id:partnerId,reward:500,status:'archived'})).status,409);
  assert.equal((await admin('/api/admin/campaigns',{...partner,id:partnerId,status:'archived'})).status,200);
  await Promise.all([1,2].map(()=>admin('/api/admin/claims',{id:partnerId,userId:'tg:1002',state:'approved'})));
  assert.equal((await member('/api/wallet')).value.balance,70); // Reward frozen when submitted, never duplicated.
  assert.equal((await member('/api/campaigns/claim',{id:partnerId,proof:'again'})).status,409);
  assert.equal((await admin('/api/admin/campaigns',{...partner,url:'javascript:alert(1)'})).status,400);
  assert.equal((await admin('/api/admin/campaigns',{...partner,reward:-1})).status,400);
  assert.equal((await admin('/api/admin/campaigns',{...partner,ends:Date.now()-1000})).status,400);
  const futureId=(await admin('/api/admin/campaigns',{...partner,starts:Date.now()+86400000,ends:Date.now()+172800000})).value.id;
  assert.ok(!(await admin('/api/campaigns')).value.campaigns.some(c=>c.id===futureId));
  assert.equal((await member('/api/campaigns/claim',{id:futureId,proof:'x'})).status,409);
  assert.equal((await admin('/api/admin/mascot',{partner:'Brand',url:'https://example.com',active:true})).status,200);
  assert.equal((await member('/api/wallet')).value.mascot.partner,'Brand');
  assert.equal((await admin('/api/admin/mascot',{partner:'Brand',url:'https://example.com',active:false})).status,200);
  assert.equal((await member('/api/wallet')).value.mascot,null);
  const {isAdmin}=await import('../campaigns.mjs');assert.equal(isAdmin({id:'tg:1001'},{}),false);assert.equal(isAdmin({id:'tg:1001'},{ADMIN_TELEGRAM_ID:'1002'}),false);
  const tapAuth=initData(1003);
  await api('/api/wallet',{init:tapAuth});
  assert.equal((await api('/api/tap',{method:'POST',data:{count:1,requestId:'missing_auth_0001'}})).status,401);
  const click=(requestId,count=1)=>api('/api/tap',{method:'POST',init:tapAuth,data:{requestId,count}});
  const tapRace=await Promise.all(Array.from({length:8},()=>click('same_tap_batch_0001',50)));
  assert.ok(tapRace.every(r=>r.status===200&&r.value.accepted===50));
  assert.equal((await api('/api/wallet',{init:tapAuth})).value.tapCoins,5);
  assert.equal((await click('same_tap_batch_0001',49)).status,409);
  assert.equal((await click('invalid_negative_001',-1)).status,400);
  assert.equal((await click('invalid_excessive_01',51)).status,400);
  assert.equal((await click('short',1)).status,400);
  const tapCode=(await api('/api/wallet',{method:'POST',init:tapAuth,data:{action:'pair'}})).value.code;
  const tapDevice=(await api('/api/device/pair',{method:'POST',data:{code:tapCode,platform:'android'}})).value.token;
  const mixed=await Promise.all([click('shared_device_batch_01',20),api('/api/device/tap',{method:'POST',token:tapDevice,data:{requestId:'shared_device_batch_01',count:20}})]);
  assert.deepEqual(mixed.map(r=>r.status),[200,410]);
  assert.equal((await api('/api/wallet',{init:tapAuth})).value.tapCoins,7);
  assert.equal((await api('/api/device/tap',{method:'POST',token:tapDevice,data:{action:'state'}})).status,410);
  const {earnTaps,tapSnapshot}=await import('../taps.mjs');
  const now=Date.now();
  await db.prepare('UPDATE tap_state SET energy=10,energy_at=? WHERE user_id=?').bind(now,'tg:1003').run();
  const depleted=await earnTaps(db,'tg:1003',{requestId:'energy_depleted_0001',count:50},now);
  assert.equal(depleted.accepted,10);assert.equal(depleted.energy,0);assert.equal(depleted.tapCoins,8);
  assert.equal((await earnTaps(db,'tg:1003',{requestId:'empty_energy_000001',count:10},now)).accepted,0);
  assert.equal((await tapSnapshot(db,'tg:1003',now+5500)).energy,5);
  const regen=await earnTaps(db,'tg:1003',{requestId:'regen_energy_000001',count:10},now+5500);
  assert.equal(regen.accepted,5);assert.equal(regen.energy,0);
  assert.equal((await tapSnapshot(db,'tg:1003',now+6000)).energy,1); // fractional regeneration survives taps
  assert.equal((await tapSnapshot(db,'tg:1003',now+10000000)).energy,100);
  assert.equal((await member('/api/wallet')).value.tapCoins,0);
  const reward=await earnTaps(db,'tg:1003',{requestId:'complete_hundred_001',count:15},now+10000000);
  assert.equal(reward.tapCount,100);assert.equal(reward.tapCoins,10);assert.equal(reward.tapRemainder,0);
  assert.equal((await earnTaps(db,'tg:1003',{requestId:'complete_hundred_001',count:15},now+10000000)).tapCoins,10);
  await tapSnapshot(db,'fraction-test',now);
  const fraction=await earnTaps(db,'fraction-test',{requestId:'fifteen_taps_000001',count:15},now);
  assert.equal(fraction.tapCoins,1.5);
  assert.equal((await earnTaps(db,'fraction-test',{requestId:'fifteen_taps_000001',count:15},now)).tapCoins,1.5);
  await db.prepare('INSERT INTO tap_state(user_id,total,energy,energy_at) VALUES(?,?,?,?)').bind('legacy-test',1234,1000,now).run();
  assert.equal((await tapSnapshot(db,'legacy-test',now)).tapCoins,1234);
  await earnTaps(db,'legacy-test',{requestId:'legacy_new_taps_0001',count:50},now);
  assert.equal((await earnTaps(db,'legacy-test',{requestId:'legacy_new_taps_0002',count:50},now)).tapCoins,1244);
  await api('/api/device/revoke',{method:'POST',init:tapAuth,data:{action:'revoke'}});
  assert.equal((await api('/api/device/tap',{method:'POST',token:tapDevice,data:{action:'state'}})).status,410);
  await tapSnapshot(db,'limit-test',now);
  const limitDay=(await tapSnapshot(db,'limit-test',now)).tapDay;
  await db.prepare('UPDATE tap_daily_paid SET units=99950 WHERE user_id=? AND day=?').bind('limit-test',limitDay).run();
  const limits=await Promise.all(Array.from({length:4},(_,i)=>earnTaps(db,'limit-test',{requestId:'daily_limit_batch_000'+i,count:15},now)));
  assert.equal(limits.reduce((sum,x)=>sum+x.accepted,0),5);
  assert.equal((await tapSnapshot(db,'limit-test',now)).tapTodayCoins,1000);
  assert.equal((await earnTaps(db,'limit-test',{requestId:'daily_limit_extra_001',count:1},now)).accepted,0);
  assert.equal((await tapSnapshot(db,'limit-test',now+86400000)).tapTodayCoins,0);
  const balanceBeforeSettings=(await api('/api/wallet',{init:auth})).value.balance;
  const settingsPair=(await api('/api/wallet',{method:'POST',init:auth,data:{action:'pair'}})).value.code;
  const settingsToken=(await api('/api/device/pair',{method:'POST',data:{code:settingsPair,platform:'android'}})).value.token;
  const config=(await admin('/api/admin/rewards')).value.settings;
  assert.equal(config.tapDailyLimit,1000);assert.equal(config.stepReward,0.4);
  assert.equal((await member('/api/admin/rewards')).status,403);
  assert.equal((await member('/api/admin/rewards',{...config,tapReward:99})).status,403);
  assert.equal((await admin('/api/admin/rewards',{...config,tapReward:NaN})).status,400);
  assert.equal((await admin('/api/admin/rewards',{...config,energyRegenSeconds:0})).status,400);
  const saved=(await admin('/api/admin/rewards',{...config,tapReward:0.2,stepReward:0.5,stepDailyLimit:5000}));
  assert.equal(saved.status,200);
  assert.equal((await admin('/api/admin/rewards',config)).status,409);
  assert.equal((await tapSnapshot(db,'fraction-test',now)).tapCoins,1.5);
  const changed=await earnTaps(db,'fraction-test',{requestId:'changed_reward_00001',count:15},now);
  assert.equal(changed.tapCoins,4.5);
  assert.equal((await earnTaps(db,'fraction-test',{requestId:'fifteen_taps_000001',count:15},now)).tapCoins,4.5);
  assert.equal((await api('/api/wallet',{init:auth})).value.balance,balanceBeforeSettings);
  const changedSteps=await api('/api/device/steps',{method:'POST',token:settingsToken,data:{day:dayOffset(0),steps:13000}});
  assert.equal(changedSteps.value.coins,4500);
  assert.equal((await api('/api/device/steps',{method:'POST',token:settingsToken,data:{day:dayOffset(0),steps:13000}})).value.coins,4500);
  assert.equal((await api('/api/device/steps',{method:'POST',token:settingsToken,data:{day:dayOffset(0),steps:15000}})).value.coins,5000);
  console.log('PASS: owner-only settings, validation, stale-edit conflict, saved rates, frozen old balances, replay after rate change, incremental step rewards and new caps.');
  console.log('PASS: tap authentication, atomic replay protection, Android/Telegram shared balance, energy cap, partial awards, fractional regeneration, account isolation and revocation.');
  console.log('PASS: developer-only access, signed identity, draft/future visibility, step eligibility, concurrent exactly-once rewards, partner review, frozen reward, URL validation, sponsor toggle and account isolation.');
  console.log('PASS: real local D1/Workers integration — Telegram signature and expiry, single-use pairing race, non-consuming pairing preflight, same-account history recovery, old-device rotation, different-account detection, deployment-owned Telegram configuration, hashed credentials, idempotent sync, daily cap, seven-day window, account isolation, revocation, CORS, webhook secret, bounded requests, JSON errors.');
} finally { await mf.dispose(); }
