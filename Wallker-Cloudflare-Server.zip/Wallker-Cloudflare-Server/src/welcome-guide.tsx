import {useEffect,useRef,useState} from 'react';
import {ArrowLeft,ChevronRight,Footprints,PawPrint,Wallet,UsersRound,ListChecks,TrendingUp,Check} from 'lucide-react';
import {getLanguage,LanguageSelect} from './language';
const completedHere=new Set<string>();
// This key belongs to the guide, not to an app release. Updates never reset it.
const guideKey=(account:string)=>'walker:welcome:v1:'+account;
function completed(account:string){
 if(completedHere.has(account))return true;
 try{if(localStorage.getItem(guideKey(account))==='done')return true}catch{}
 try{if(sessionStorage.getItem(guideKey(account))==='done')return true}catch{}
 return false;
}
function remember(account:string){
 completedHere.add(account);
 try{localStorage.setItem(guideKey(account),'done')}catch{}
 try{sessionStorage.setItem(guideKey(account),'done')}catch{}
}
export function WelcomeGuide({account,forceOpen=false,onDismiss}:{account:string,forceOpen?:boolean,onDismiss:()=>void}){
 const t=(ru:string,en:string)=>getLanguage()==='en'?en:ru;
 const [firstVisit,setFirstVisit]=useState(()=>!completed(account)),[step,setStep]=useState(0);
 const dialog=useRef<HTMLDialogElement>(null),heading=useRef<HTMLHeadingElement>(null);
 const open=firstVisit||forceOpen;
 useEffect(()=>{
  if(!open)return;
  setStep(0);
  const node=dialog.current;if(!node)return;
  const previous=document.body.style.overflow;document.body.style.overflow='hidden';
  if(!node.open)node.showModal();
  heading.current?.focus({preventScroll:true});
  return()=>{node.close();document.body.style.overflow=previous;};
 },[open]);
 useEffect(()=>{if(open)heading.current?.focus({preventScroll:true})},[step]);
 function finish(){remember(account);setFirstVisit(false);onDismiss()}
 if(!open)return null;
 const sections=[
  {name:'Earn',icon:PawPrint,text:t('Шаги и тапы','Walking and tapping')},
  {name:'Wallet',icon:Wallet,text:t('Баланс и подключение шагомера','Balance and pedometer setup')},
  {name:'Friends',icon:UsersRound,text:t('Друзья, кланы и бонус за приглашения','Friends, clans and invite boosts')},
  {name:'Quests',icon:ListChecks,text:t('Задания и награды','Tasks and rewards')},
  {name:'Listing',icon:TrendingUp,text:t('Новости о будущем листинге','Updates on listing plans')}
 ];
 return <dialog ref={dialog} className="welcome-guide" aria-labelledby="welcome-title" aria-describedby="welcome-description" onCancel={e=>{e.preventDefault();finish()}}>
  <header className="welcome-top"><span>{t('БЫСТРЫЙ СТАРТ','QUICK START')}</span><LanguageSelect/><button className="welcome-skip" onClick={finish}>{t('Пропустить','Skip')}</button></header>
  <div className="welcome-body">
   {step===0?<><div className="welcome-art"><img src="/wolf-level-1.png" alt={t('Волкер готов шагать с тобой','Walker is ready to walk with you')}/><span><Footprints size={22}/>WC</span></div>
    <h2 id="welcome-title" ref={heading} tabIndex={-1}>{t('Шагай и получай WC','Walk and earn WC')}</h2>
    <p id="welcome-description">{t('Подключи шагомер: Wallet → «Подключение». Гуляй — шаги принесут игровые WC.','Connect your pedometer in Wallet. Go for a walk to earn WC game points.')}</p>
    <div className="welcome-earning"><p><PawPrint size={18}/>{t('Тапай волка в Earn — получай бонус.','Tap the wolf in Earn for a bonus.')}</p><p><ListChecks size={18}/>{t('Выполняй задания в Quests — забирай награды.','Complete tasks in Quests for rewards.')}</p></div>
   </>:<><div className="welcome-section-icon"><Wallet size={30}/></div><h2 id="welcome-title" ref={heading} tabIndex={-1}>{t('Всё под рукой','Find your way around')}</h2><p id="welcome-description">{t('Пять вкладок внизу — вот и всё.','Five tabs at the bottom. That’s it.')}</p>
    <div className="welcome-sections">{sections.map(({name,icon:Icon,text})=><div key={name}><span><Icon size={21}/></span><div><strong>{name}</strong><p>{text}</p></div></div>)}</div>
   </>}
  </div>
  <footer className="welcome-footer"><div className="welcome-progress" aria-label={t('Шаг '+(step+1)+' из 2','Step '+(step+1)+' of 2')}><span className={step===0?'current':''}/><span className={step===1?'current':''}/><small>{step+1}/2</small></div><div className="welcome-actions">{step===1&&<button className="welcome-back" onClick={()=>setStep(0)} aria-label={t('Назад','Back')}><ArrowLeft size={19}/></button>}<button className="button primary" onClick={()=>step===0?setStep(1):finish()}>{step===0?t('Далее','Next'):t('Начать','Let’s go')}{step===0?<ChevronRight size={18}/>:<Check size={18}/>}</button></div></footer>
 </dialog>;
}
