import {CampaignError} from './campaigns.mjs';
import {clansAction} from './clans.mjs';
export async function deleteAccount(db,admin,data){
 const id=data.userId;if(!/^tg:[1-9]\d*$/.test(id||'')||data.confirm!==true||id===admin.id)throw new CampaignError('Подтверди удаление выбранного аккаунта');
 if(!await db.prepare("SELECT user_id FROM deletion_requests WHERE user_id=? AND state='pending'").bind(id).first())throw new CampaignError('Нет запроса пользователя на удаление',409);
 const unresolved=await db.prepare("SELECT COUNT(*) AS n FROM shop_orders WHERE user_id=? AND state IN ('paid','refund_pending')").bind(id).first();
 const extra=await db.prepare("SELECT COUNT(*) AS n FROM shop_extra_charges WHERE user_id=? AND state='pending'").bind(id).first();
 if(unresolved.n||extra.n)throw new CampaignError('Сначала урегулируй оплаченные заказы и возвраты в поддержке',409);
 if(await db.prepare('SELECT clan_id FROM clan_members WHERE user_id=?').bind(id).first())await clansAction(db,id,{action:'leave'});
 const stmts=[db.prepare('INSERT OR IGNORE INTO deleted_payment_audit(charge_id,stars,state,created) SELECT charge_id,stars,state,created FROM shop_orders WHERE user_id=? AND charge_id IS NOT NULL').bind(id)];
 for(const table of ['shop_invoice_links','shop_checkout_leases','shop_checkout','shop_order_bots'])stmts.push(db.prepare(`DELETE FROM ${table} WHERE order_id IN (SELECT id FROM shop_orders WHERE user_id=?)`).bind(id));
 for(const table of ['days','pairings','trusted_step_totals','step_reports','device_sessions','abuse_controls','client_errors','daily_claims','analytics_profiles','analytics_daily','tap_limit_state','tap_state','tap_paid','tap_daily_paid','tap_awards','tap_daily','tap_reward_baseline','tap_receipts','developer_levels','level_claims','admin_grants','grant_reversals','friend_codes','support_messages','support_chat','support_reads','shop_accounts','shop_orders','shop_purchases','shop_boosts','shop_game_awards','shop_extra_charges','campaign_claims','deletion_requests'])stmts.push(db.prepare(`DELETE FROM ${table} WHERE user_id=?`).bind(id));
 stmts.push(db.prepare('DELETE FROM friendships WHERE a=? OR b=?').bind(id,id),db.prepare('DELETE FROM referrals WHERE invitee=? OR inviter=?').bind(id,id),db.prepare('DELETE FROM referral_qualified WHERE invitee=? OR inviter=?').bind(id,id),db.prepare('DELETE FROM analytics_errors WHERE user_id=?').bind(id),db.prepare('DELETE FROM users WHERE id=?').bind(id));
 const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode('walker-bot-chat:'+id.slice(3))));const chatHash=Array.from(digest,x=>x.toString(16).padStart(2,'0')).join('');stmts.push(db.prepare('DELETE FROM bot_card_rotation WHERE chat_hash=?').bind(chatHash));
 await db.batch(stmts);return {ok:true,deleted:true};
}
