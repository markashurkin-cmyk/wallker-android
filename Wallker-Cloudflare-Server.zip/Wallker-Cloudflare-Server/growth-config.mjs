import {memo} from './runtime.mjs';
export class GrowthError extends Error{constructor(message,status=400){super(message);this.status=status}}
export const defaultMilestones=[
 [1,'Recruiter','recruiter'],[10,'Pack Builder','pack-frame'],[50,'Alpha','alpha-outfit'],[100,'Pack Leader','leader-badge'],[500,'Creator','creator-wolf'],[1000,'Pro Creator','pro-frame'],[5000,'Influencer','influencer-skin'],[10000,'Wolf Influencer','wolf-influencer'],[50000,'Walker Ambassador','ambassador-profile'],[100000,'Walker Legend','legend-badge']
].map(([count,title,asset])=>({count,title,asset}));
export const growthDefaults={activeDays:2,creatorTotal:500,creatorActive:100,curve:[[0,1000000],[100,2000000],[250,2150000],[500,2400000],[1000,2900000],[2500,3650000],[5000,4400000],[10000,5400000],[25000,6900000],[50000,8400000],[100000,10400000]],overflowMicros:40,milestones:defaultMilestones};
export const BOOST_SOURCES=Object.freeze(['steps','taps','levels','quest:steps','quest:telegram','quest:tiktok','quest:partner','quest:contest']);
export function multiplierMicros(n,config=growthDefaults){
 if(!Number.isSafeInteger(n)||n<0)throw new GrowthError('Invalid referral count');
 const points=config.curve,last=points.at(-1);
 if(n>last[0])return BigInt(last[1])+BigInt(n-last[0])*BigInt(config.overflowMicros);
 for(let i=1;i<points.length;i++)if(n<=points[i][0]){const [a,v]=points[i-1],[b,w]=points[i];return BigInt(v)+BigInt(n-a)*BigInt(w-v)/BigInt(b-a)}
 return 1000000n;
}
export const multiplier=(n,config)=>Number(multiplierMicros(n,config))/1e6;
export const boostSource=(source,n,config)=>BOOST_SOURCES.includes(source)?multiplier(n,config):1;
// Owner reports/export use the same stored points, rather than a second curve.
export const CURVE_SQL_CTE=`growth_curve AS (SELECT CAST(key AS INTEGER) AS i,json_extract(value,'$[0]') AS n,json_extract(value,'$[1]') AS micros FROM json_each((SELECT value FROM growth_settings WHERE id=1),'$.curve'))`;
export function multiplierSQL(count){return `(CASE WHEN ${count}>(SELECT MAX(n) FROM growth_curve) THEN (SELECT micros FROM growth_curve ORDER BY n DESC LIMIT 1)+(${count}-(SELECT MAX(n) FROM growth_curve))*json_extract((SELECT value FROM growth_settings WHERE id=1),'$.overflowMicros') ELSE (SELECT lo.micros+(${count}-lo.n)*(hi.micros-lo.micros)/(hi.n-lo.n) FROM growth_curve lo JOIN growth_curve hi ON hi.i=lo.i+1 WHERE ${count}>=lo.n AND ${count}<=hi.n LIMIT 1) END)/1000000.0`;}
export function validateGrowth(value){
 if(!value||typeof value!=='object')throw new GrowthError('Invalid growth settings');
 for(const [key,min,max] of [['activeDays',2,30],['creatorTotal',1,10000000],['creatorActive',1,10000000],['overflowMicros',0,10000]])if(!Number.isSafeInteger(value[key])||value[key]<min||value[key]>max)throw new GrowthError('Invalid '+key);
 if(value.creatorActive>value.creatorTotal)throw new GrowthError('Creator Active cannot exceed Total');
 const c=value.curve;if(!Array.isArray(c)||c.length<2||c.length>30||c[0]?.[0]!==0||c[0]?.[1]!==1000000)throw new GrowthError('Invalid curve');
 for(let i=0;i<c.length;i++){const p=c[i];if(!Array.isArray(p)||p.length!==2||p.some(n=>!Number.isSafeInteger(n)||n<0)||p[0]>1000000000||p[1]>1000000000)throw new GrowthError('Invalid curve point');if(i&&(p[0]<=c[i-1][0]||p[1]<c[i-1][1]||(p[1]-c[i-1][1])%(p[0]-c[i-1][0])!==0))throw new GrowthError('Curve requires monotonic exact integer slopes');}
 if(!Array.isArray(value.milestones)||value.milestones.length>30)throw new GrowthError('Invalid milestones');
 const seen=new Set();for(const m of value.milestones){if(!Number.isSafeInteger(m.count)||m.count<1||m.count>1e9||seen.has(m.count)||typeof m.title!=='string'||m.title.length<1||m.title.length>60||!/^[a-z0-9-]{1,60}$/.test(m.asset))throw new GrowthError('Invalid milestone');seen.add(m.count)}
 return {activeDays:value.activeDays,creatorTotal:value.creatorTotal,creatorActive:value.creatorActive,curve:c,overflowMicros:value.overflowMicros,milestones:[...value.milestones].sort((a,b)=>a.count-b.count)};
}
export async function growthSettings(db){return memo(db,'growth:settings',async()=>{
 const row=await db.prepare('SELECT value,revision FROM growth_settings WHERE id=1').first();
 return {...(row?JSON.parse(row.value):growthDefaults),revision:row?.revision||1};
});}
export async function totalInvited(db,id){
 // Avoid evaluating the legacy COUNT on every wallet/tap request.
 const existing=await db.prepare('SELECT total FROM growth_totals WHERE user_id=?').bind(id).first();
 if(existing)return existing.total;
 await db.prepare('INSERT OR IGNORE INTO growth_totals(user_id,total) SELECT ?,COUNT(*) FROM referral_qualified WHERE inviter=?').bind(id,id).run();
 return (await db.prepare('SELECT total FROM growth_totals WHERE user_id=?').bind(id).first()).total;
}
