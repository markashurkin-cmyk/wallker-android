import {CURVE_SQL_CTE,multiplierSQL} from './growth-config.mjs';
import {ensureReferrals} from './referrals.mjs';
import {ensureShop} from './shop.mjs';
import {ensureGrants} from './grants.mjs';
import {ensureLevels} from './levels.mjs';
import {CampaignError} from './campaigns.mjs';
import {ensureStepRewards} from './rewards.mjs';
import {ensureTaps} from './taps.mjs';
import {ensureCampaigns} from './campaigns.mjs';

const DAY=86400000;
const routes=new Set(['/api/admin/security','/api/device/state','/api/device/errors','/api/client/errors','/api/account/delete','/api/daily','/api/clans','/api/bot','/api/telegram/legacy-webhook','/api/support/chat','/api/admin/support/chat','/api/admin/support/chats','/api/admin/shop','/api/shop','/api/shop/buy','/api/shop/invoice','/api/admin/export','/api/support','/api/admin/support','/api/friends','/api/admin/grants','/api/admin/levels','/api/levels','/api/levels/claim','/api/health','/api/wallet','/api/tap','/api/device/tap','/api/device/pair','/api/device/steps','/api/device/revoke','/api/telegram/webhook','/api/campaigns','/api/campaigns/claim','/api/admin/rewards','/api/admin/campaigns','/api/admin/claims','/api/admin/mascot','/api/admin/stats','/api/admin/stats/users','/api/admin/stats/user','/api/admin/stats/errors']);
export async function ensureStatistics(db){if(db.schemaReady)return;
 await db.batch([
  db.prepare('CREATE TABLE IF NOT EXISTS analytics_meta(id INTEGER PRIMARY KEY,started INTEGER NOT NULL,cleaned INTEGER NOT NULL)'),
  db.prepare('CREATE TABLE IF NOT EXISTS analytics_profiles(user_id TEXT PRIMARY KEY,username TEXT NOT NULL DEFAULT \'\',last_seen INTEGER NOT NULL DEFAULT 0,last_wallet INTEGER NOT NULL DEFAULT 0,first_sync INTEGER)'),
  db.prepare('CREATE TABLE IF NOT EXISTS analytics_daily(user_id TEXT NOT NULL,day TEXT NOT NULL,opens INTEGER NOT NULL DEFAULT 0,syncs INTEGER NOT NULL DEFAULT 0,pairs INTEGER NOT NULL DEFAULT 0,last_seen INTEGER NOT NULL,PRIMARY KEY(user_id,day))'),
  db.prepare('CREATE INDEX IF NOT EXISTS analytics_daily_day ON analytics_daily(day,user_id)'),
  db.prepare('CREATE TABLE IF NOT EXISTS analytics_errors(hour INTEGER NOT NULL,path TEXT NOT NULL,status INTEGER NOT NULL,code TEXT NOT NULL,user_id TEXT NOT NULL,platform TEXT NOT NULL,count INTEGER NOT NULL,first_at INTEGER NOT NULL,last_at INTEGER NOT NULL,version TEXT NOT NULL,PRIMARY KEY(hour,path,status,code,user_id,platform))'),
  db.prepare('CREATE INDEX IF NOT EXISTS analytics_errors_last ON analytics_errors(last_at)'),
  db.prepare('INSERT OR IGNORE INTO analytics_meta(id,started,cleaned) VALUES(1,?,0)').bind(Date.now())
 ]);
}
export function errorCode(status,path,message=''){
 if(status>=500)return 'server_unavailable';
 if(status===401)return path==='/api/device/pair'?'pair_code_rejected':path.startsWith('/api/device/')?'device_not_linked':'telegram_login_required';
 if(status===403)return 'access_denied';
 if(status===423)return 'account_on_hold';
 if(status===404)return 'not_found';
 if(status===405)return 'method_not_allowed';
 if(status===413)return 'request_too_large';
 if(status===429)return 'too_many_requests';
 if(status===409)return 'conflict';
 if(path==='/api/device/steps')return message.includes('шесть предыдущих')?'step_date_invalid':'step_count_invalid';
 return 'invalid_request';
}
// Never persist headers, bodies, query strings, secrets or raw exception messages.
// Anonymous rejections use one fixed aggregate bucket, not caller-controlled IDs.
export async function recordStatistics(db,context,status,path,message='',now=Date.now()){
 const known=routes.has(path)?path:'/api/other';
 const error=status>=400;
 if(!error&&!context.event)return;
 await ensureStatistics(db);
 const statements=[];
 if(error){
  const platform=['telegram','android','ios','bot'].includes(context.platform)?context.platform:'unknown';
  statements.push(db.prepare(`INSERT INTO analytics_errors(hour,path,status,code,user_id,platform,count,first_at,last_at,version) VALUES(?,?,?,?,?,?,1,?,?,?) ON CONFLICT(hour,path,status,code,user_id,platform) DO UPDATE SET count=MIN(analytics_errors.count+1,1000000000),last_at=MAX(analytics_errors.last_at,excluded.last_at)`).bind(Math.floor(now/3600000),known,status,errorCode(status,known,message),context.user?.id||'',platform,now,now,'0.2.24'));
 }else if(context.user){
  const id=context.user.id,day=new Date(now).toISOString().slice(0,10);
  const hasName=typeof context.user.username==='string';
  const username=hasName?context.user.username:'';
  const wallet=context.event==='wallet'?now:0;
  const firstSync=context.event==='sync'&&context.positiveSteps?now:null;
  statements.push(db.prepare(`INSERT INTO analytics_profiles(user_id,username,last_seen,last_wallet,first_sync) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=CASE WHEN ? THEN excluded.username ELSE analytics_profiles.username END,last_seen=MAX(analytics_profiles.last_seen,excluded.last_seen),last_wallet=MAX(analytics_profiles.last_wallet,excluded.last_wallet),first_sync=COALESCE(analytics_profiles.first_sync,excluded.first_sync)`).bind(id,username,now,wallet,firstSync,hasName?1:0));
  statements.push(db.prepare(`INSERT INTO analytics_daily(user_id,day,opens,syncs,pairs,last_seen) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET opens=MIN(analytics_daily.opens+excluded.opens,1000000000),syncs=MIN(analytics_daily.syncs+excluded.syncs,1000000000),pairs=MIN(analytics_daily.pairs+excluded.pairs,1000000000),last_seen=MAX(analytics_daily.last_seen,excluded.last_seen)`).bind(id,day,context.event==='wallet'?1:0,context.event==='sync'?1:0,context.event==='pair'?1:0,now));
 }
 if(statements.length)await db.batch(statements);
 // One cleanup per UTC day; keep error aggregates 30 days and activity 90 days.
 const lease=await db.prepare('UPDATE analytics_meta SET cleaned=? WHERE id=1 AND cleaned<? RETURNING id').bind(now,Math.floor(now/DAY)*DAY).first();
 if(lease)await db.batch([db.prepare('DELETE FROM analytics_errors WHERE last_at<?').bind(now-30*DAY),db.prepare('DELETE FROM analytics_daily WHERE day<?').bind(new Date(now-90*DAY).toISOString().slice(0,10))]);
}
export async function balancesReady(db){
 await ensureStepRewards(db);await ensureTaps(db);await ensureCampaigns(db);await ensureLevels(db);await ensureGrants(db);await ensureShop(db);await ensureReferrals(db);
 if(db.schemaReady)return;
 // Same legacy conversion as tapSnapshot, without creating states for inactive users.
 await db.prepare('INSERT OR IGNORE INTO tap_reward_baseline(user_id,legacy_total) SELECT user_id,total FROM tap_state').run();
 await db.prepare('INSERT OR IGNORE INTO tap_paid(user_id,units) SELECT s.user_id,b.legacy_total*100+MAX(0,s.total-b.legacy_total)*10 FROM tap_state s JOIN tap_reward_baseline b ON b.user_id=s.user_id').run();
}
export const userQuery=`WITH ${CURVE_SQL_CTE},recruits AS (SELECT inviter AS user_id,COUNT(*) AS referralPercent FROM referral_qualified GROUP BY inviter),bought AS (SELECT user_id,SUM(units)/100.0 AS purchaseCoins FROM shop_game_awards WHERE NOT EXISTS(SELECT 1 FROM shop_accounts a WHERE a.user_id=shop_game_awards.user_id AND a.credits<0) GROUP BY user_id),grants AS (SELECT user_id,SUM(units)/100.0 AS grantCoins FROM admin_grants GROUP BY user_id),ranks AS (SELECT user_id,SUM(units)/100.0 AS levelCoins FROM level_claims GROUP BY user_id),walk AS (SELECT user_id,SUM(units)/100.0 AS walkCoins FROM step_rewards GROUP BY user_id),bonus AS (SELECT user_id,SUM(reward) AS bonusCoins FROM campaign_claims WHERE state='approved' GROUP BY user_id),walked AS (SELECT user_id,SUM(steps) AS steps,MAX(updated) AS lastSync FROM days GROUP BY user_id),devices AS (SELECT user_id,MAX(platform='ios') AS ios,MAX(platform='android') AS android FROM pairings WHERE device_hash IS NOT NULL GROUP BY user_id) SELECT u.id,u.name,u.created,u.timezone,(SELECT steps FROM trusted_step_totals WHERE user_id=u.id) AS rankSteps,ROUND(((${multiplierSQL('COALESCE(gt.total,r.referralPercent,0)')})-1)*100,4) AS referralPercent,${multiplierSQL('COALESCE(gt.total,r.referralPercent,0)')} AS referralMultiplier,COALESCE(p.username,'') AS username,COALESCE(w.walkCoins,0) AS walkCoins,COALESCE(t.units,COALESCE(tb.legacy_total,ts.total)*100+MAX(0,ts.total-COALESCE(tb.legacy_total,ts.total))*10,0)/100.0 AS tapCoins,COALESCE(b.bonusCoins,0) AS bonusCoins,COALESCE(l.levelCoins,0) AS levelCoins,COALESCE(g.grantCoins,0) AS grantCoins,COALESCE(k.purchaseCoins,0) AS purchaseCoins,COALESCE(w.walkCoins,0)+COALESCE(t.units,COALESCE(tb.legacy_total,ts.total)*100+MAX(0,ts.total-COALESCE(tb.legacy_total,ts.total))*10,0)/100.0+COALESCE(b.bonusCoins,0)+COALESCE(l.levelCoins,0)+COALESCE(g.grantCoins,0)+COALESCE(k.purchaseCoins,0) AS balance,COALESCE(d.steps,0) AS steps,d.lastSync,MAX(COALESCE(p.last_seen,0),COALESCE(d.lastSync,0)) AS lastSeen,p.first_sync AS firstSync,COALESCE(v.ios,0) AS ios,COALESCE(v.android,0) AS android FROM users u LEFT JOIN growth_totals gt ON gt.user_id=u.id LEFT JOIN recruits r ON r.user_id=u.id LEFT JOIN bought k ON k.user_id=u.id LEFT JOIN analytics_profiles p ON p.user_id=u.id LEFT JOIN grants g ON g.user_id=u.id LEFT JOIN ranks l ON l.user_id=u.id LEFT JOIN walk w ON w.user_id=u.id LEFT JOIN tap_paid t ON t.user_id=u.id LEFT JOIN tap_state ts ON ts.user_id=u.id LEFT JOIN tap_reward_baseline tb ON tb.user_id=u.id LEFT JOIN bonus b ON b.user_id=u.id LEFT JOIN walked d ON d.user_id=u.id LEFT JOIN devices v ON v.user_id=u.id`;
function search(url){const q=(url.searchParams.get('q')||'').trim().slice(0,60).replace(/^@/,'');return {q,like:`%${q.replace(/[\\%_]/g,'\\$&')}%`};}
function page(url){const n=Number(url.searchParams.get('page')||1);if(!Number.isSafeInteger(n)||n<1||n>100000)throw new CampaignError('Неверный номер страницы');return n;}
export async function statisticsRoute(db,url,snapshotUser){
 await ensureStatistics(db);await balancesReady(db);
 const path=url.pathname,now=Date.now(),today=new Date(now).toISOString().slice(0,10);
 const started=(await db.prepare('SELECT started FROM analytics_meta WHERE id=1').first()).started;
 if(path==='/api/admin/stats'){
  const totals=await db.prepare(`SELECT COUNT(*) AS users,COALESCE(SUM(balance),0) AS balance,COALESCE(SUM(walkCoins),0) AS walkCoins,COALESCE(SUM(tapCoins),0) AS tapCoins,COALESCE(SUM(bonusCoins),0) AS bonusCoins,COALESCE(SUM(levelCoins),0) AS levelCoins,COALESCE(SUM(grantCoins),0) AS grantCoins,COALESCE(SUM(purchaseCoins),0) AS purchaseCoins,COALESCE(SUM(ios),0) AS ios,COALESCE(SUM(android),0) AS android,COALESCE(SUM(ios OR android),0) AS linked,COALESCE(SUM(firstSync IS NOT NULL OR steps>0),0) AS walkers FROM (${userQuery})`).first();
  const active={};for(const n of [1,7,30])active[n]=(await db.prepare('SELECT COUNT(DISTINCT user_id) AS n FROM analytics_daily WHERE day>=?').bind(new Date(Date.parse(today)- (n-1)*DAY).toISOString().slice(0,10)).first()).n;
  const since=new Date(Date.parse(today)-29*DAY).toISOString().slice(0,10);
  const activity=(await db.prepare('SELECT day,COUNT(*) AS active,SUM(opens) AS opens,SUM(syncs) AS syncs FROM analytics_daily WHERE day>=? GROUP BY day ORDER BY day').bind(since).all()).results;
  const registrations=(await db.prepare("SELECT strftime('%Y-%m-%d',created/1000,'unixepoch') AS day,COUNT(*) AS newUsers FROM users WHERE created>=? GROUP BY day").bind(Date.parse(since)).all()).results;
  const daily=Array.from({length:30},(_,i)=>{const day=new Date(Date.parse(since)+i*DAY).toISOString().slice(0,10);return {day,...(activity.find(x=>x.day===day)||{active:0,opens:0,syncs:0}),newUsers:registrations.find(x=>x.day===day)?.newUsers||0,observed:Date.parse(day)+DAY>started};});
  const errors=await db.prepare('SELECT COALESCE(SUM(count),0) AS allErrors,COALESCE(SUM(CASE WHEN status>=500 THEN count ELSE 0 END),0) AS serverErrors FROM analytics_errors WHERE last_at>=?').bind(now-DAY).first();
  const retention={};for(const n of [1,7]){
   const cohort=new Date(Date.parse(today)-n*DAY).toISOString().slice(0,10),from=Date.parse(cohort);
   if(from<started){retention[n]=null;continue;}
   const r=await db.prepare('SELECT COUNT(*) AS eligible,SUM(EXISTS(SELECT 1 FROM analytics_daily a WHERE a.user_id=u.id AND a.day=?)) AS returned FROM users u WHERE created>=? AND created<?').bind(today,from,from+DAY).first();
   retention[n]={eligible:r.eligible,returned:r.returned||0,percent:r.eligible?Math.round((r.returned||0)/r.eligible*100):null};
  }
  return {started,timezone:'UTC',totals,active,errors,retention,daily};
 }
 if(path==='/api/admin/stats/users'){
  const {q,like}=search(url),p=page(url),size=25;
  const sort={balance:'balance DESC,id',steps:'steps DESC,id',recent:'lastSeen DESC,id',new:'created DESC,id'}[url.searchParams.get('sort')||'balance'];
  if(!sort)throw new CampaignError('Неверная сортировка');
  const where="WHERE (?='' OR name LIKE ? ESCAPE '\\' OR username LIKE ? ESCAPE '\\' OR id=? OR id=?)";
  const args=[q,like,like,q,`tg:${q}`];
  const total=(await db.prepare(`SELECT COUNT(*) AS n FROM (${userQuery}) ${where}`).bind(...args).first()).n;
  const users=(await db.prepare(`SELECT * FROM (${userQuery}) ${where} ORDER BY ${sort} LIMIT ? OFFSET ?`).bind(...args,size,(p-1)*size).all()).results;
  return {users,total,page:p,pageSize:size};
 }
 if(path==='/api/admin/stats/user'){
  const id=url.searchParams.get('id')||'';if(!/^tg:[1-9]\d*$/.test(id))throw new CampaignError('Неверный Telegram ID');
  const user=await db.prepare(`SELECT * FROM (${userQuery}) WHERE id=?`).bind(id).first();if(!user)throw new CampaignError('Пользователь не найден',404);
  const wallet=await snapshotUser(id);
  const tapDays=(await db.prepare('SELECT day,units/100.0 AS coins FROM tap_daily_paid WHERE user_id=? ORDER BY day DESC LIMIT 90').bind(id).all()).results;
  const claims=(await db.prepare('SELECT c.title,q.state,q.reward,q.created,q.reviewed FROM campaign_claims q LEFT JOIN campaigns c ON c.id=q.campaign_id WHERE q.user_id=? ORDER BY q.created DESC LIMIT 90').bind(id).all()).results;
  return {user,levels:wallet.levels,today:wallet.today,todaySteps:wallet.steps,todayCoins:wallet.todayCoins,tapTodayCoins:wallet.tapTodayCoins,history:wallet.history,tapDays,claims};
 }
 if(path==='/api/admin/stats/errors'){
  const p=page(url),size=25,days=Number(url.searchParams.get('days')||7);if(![1,7,30].includes(days))throw new CampaignError('Неверный период');
  const severity=url.searchParams.get('severity')||'all';if(!['all','server','client'].includes(severity))throw new CampaignError('Неверный фильтр');
  const status=severity==='server'?'status>=500':severity==='client'?'status<500':'1=1';
  const {q,like}=search(url);
  const where=`WHERE last_at>=? AND ${status} AND (?='' OR e.user_id=? OR e.user_id=? OR u.name LIKE ? ESCAPE '\\' OR p.username LIKE ? ESCAPE '\\')`;
  const args=[now-days*DAY,q,q,`tg:${q}`,like,like];
  const from='FROM analytics_errors e LEFT JOIN users u ON u.id=e.user_id LEFT JOIN analytics_profiles p ON p.user_id=e.user_id';
  const total=(await db.prepare(`SELECT COUNT(*) AS n ${from} ${where}`).bind(...args).first()).n;
  const errors=(await db.prepare(`SELECT e.*,u.name,p.username ${from} ${where} ORDER BY last_at DESC,e.hour DESC,e.path,e.user_id LIMIT ? OFFSET ?`).bind(...args,size,(p-1)*size).all()).results;
  return {errors,total,page:p,pageSize:size,started};
 }
 throw new CampaignError('Не найдено',404);
}
