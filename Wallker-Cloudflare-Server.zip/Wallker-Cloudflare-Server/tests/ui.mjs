import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {extname,join} from 'node:path';
import assert from 'node:assert/strict';
import {defaultMilestones} from '../growth-config.mjs';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {chromium,webkit}=require('playwright');
const root=fileURLToPath(new URL('../public',import.meta.url));
const server=createServer(async(req,res)=>{try{const file=join(root,req.url==='/'?'index.html':req.url.split('?')[0]);res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.webp':'image/webp'})[extname(file)]||'application/octet-stream');res.end(await readFile(file))}catch{res.statusCode=404;res.end()}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await (process.env.WALKER_UI_ENGINE==='webkit'?webkit:chromium).launch({headless:true});
const level={level:11,name:'Божественный Walker',totalSteps:0,nextSteps:null,remainingSteps:0,progress:1,coins:0,availableCoins:0,catalog:[{level:11,name:'Божественный Walker',steps:0,reward:0,description:'Особый уровень',tapReward:1,tapDailyLimit:70000,unlocked:true,claimed:true}]};
const state={serverNow:Date.now(),tapResetAt:Date.now()+3600000,pendingSteps:[],referralMultiplier:1,referralPercent:0,purchaseCoins:0,levels:level,levelCoins:0,grantCoins:0,earnings:[],rewardSettings:{stepReward:.4,stepDailyLimit:4000},tapReward:1,user:{name:'Тест',mode:'beta',timezone:'Europe/Moscow'},today:'2026-10-12',steps:0,balance:15731,todayCoins:0,history:[],devices:[],botConnected:true,isAdmin:true,telegramId:'1001',tapDailyLimit:70000,tapTodayCoins:15731,tapDailyRemaining:54269,tapCoins:15731,tapCount:15731,energy:100,capacity:100,regenMs:1000,bonusCoins:0,campaigns:[],mascot:null};
const questSamples=[
 {id:'sample-tg',title:'Подпишись на канал',title_en:'Follow our channel',description:'Новости стаи',description_en:'Pack news',kind:'telegram',partner:'Walker',url:'https://example.com',target:0,reward:200,starts:0,ends:Date.now()+86400000,status:'published'},
 {id:'sample-tt',title:'Подпишись на TikTok',title_en:'Follow our TikTok',description:'Подпишись и пришли подтверждение',description_en:'Follow and send proof',kind:'tiktok',partner:'Walker',url:'https://example.com',target:0,reward:200,starts:0,ends:Date.now()+86400000,status:'published'},
 {id:'sample-partner',title:'Предложение партнёра',title_en:'Partner offer',description:'Условия партнёра',description_en:'Partner requirements',kind:'partner',partner:'Demo',url:'https://example.com',target:0,reward:500,starts:0,ends:Date.now()+86400000,status:'published'},
 {id:'legacy-steps',title:'Разминка',description:'Пройди 5000 шагов',kind:'steps',target:5000,reward:50,starts:0,ends:Date.now()+86400000,status:'published'}
];
const rankFixture={rows:[{name:'Walker 12345678',score:5,rank:18421}],self:{score:5,rank:18421,weeklyChange:null},asOf:Date.now()};
const packFixture={catalog:defaultMilestones,total:147,active:93,multiplier:2.047,eligible:false,trust:'NORMAL',creatorCode:null,creatorThresholds:{total:500,active:100},link:'https://t.me/wallker_wallet_bot?start=ref_01234567890123456789',milestones:[{milestone:100,title:'Pack Leader',asset:'leader-badge',created:Date.now()}],next:{count:500,title:'Creator'},remaining:353,founder:{number:18421},seasons:[],history:[],rank:rankFixture};
try{
 for(const width of [320,375,393,430]){
  let accountId='1001';
  const page=await browser.newPage({viewport:{width,height:852},isMobile:true,hasTouch:true});
  await page.route('https://telegram.org/**',r=>r.fulfill({contentType:'text/javascript',body:'window.Telegram={WebApp:{initData:"fixture",ready(){},expand(){}}};'}));
  await page.route('**/api/**',r=>{const path=new URL(r.request().url()).pathname;const response=path==='/api/bot'?{username:'wallker_wallet_bot',link:'https://t.me/wallker_wallet_bot'}:path==='/api/growth'?{...packFixture,eligible:width===393}:path==='/api/growth/profile'?{pack:packFixture,profile:{steps:12000,walkingDays:2,activeDays:3,coverageStart:Date.now(),ageDays:8,quests:3,clan:null}}:path==='/api/growth/creator'?{conversion:.63,d7:{rate:.7,retained:7,eligible:10},d30:{rate:null,retained:0,eligible:0},asOf:Date.now()}:path==='/api/growth/leaderboard'?rankFixture:path==='/api/friends'?{code:'01234567890123456789',referrals:{link:packFixture.link,multiplier:2.047,percent:104.7,minSteps:0,invited:147,qualified:147},friends:[],incoming:[],outgoing:[]}:{...state,telegramId:accountId,campaigns:width===320?[]:questSamples};return r.fulfill({contentType:'application/json',body:JSON.stringify(response)});});
  await page.goto('http://127.0.0.1:'+server.address().port);await page.locator('.wolf-tap').waitFor();
  const guide=page.locator('.welcome-guide');await guide.waitFor({state:'visible'});
  await guide.locator('.language-select select').selectOption('ru');
  await guide.getByRole('heading',{name:'Шагай и получай WC',exact:true}).waitFor();
  assert.ok(await guide.evaluate(el=>el.open));
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.waitForFunction(()=>{const img=document.querySelector('.welcome-art img');return img?.complete&&img.naturalWidth>0});
  if(width===393)await page.screenshot({path:'onboarding-1-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  await guide.getByRole('button',{name:'Далее',exact:true}).click();
  await guide.getByRole('heading',{name:'Всё под рукой',exact:true}).waitFor();
  assert.deepEqual(await guide.locator('.welcome-sections strong').allTextContents(),['Earn','Wallet','Friends','Quests','Listing']);
  await guide.getByRole('button',{name:'Назад',exact:true}).click();
  await guide.getByRole('heading',{name:'Шагай и получай WC',exact:true}).waitFor();
  await guide.getByRole('button',{name:'Далее',exact:true}).click();
  await guide.getByRole('heading',{name:'Всё под рукой',exact:true}).waitFor();
  if(width===393)await page.screenshot({path:'onboarding-2-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  if(width===430)await guide.getByRole('button',{name:'Пропустить',exact:true}).click();
  else await guide.getByRole('button',{name:'Начать',exact:true}).click();
  await guide.waitFor({state:'detached'});
  assert.equal(await page.evaluate(()=>localStorage.getItem('walker:welcome:v1:1001')),'done');
  assert.notEqual(await page.evaluate(()=>document.body.style.overflow),'hidden');
  await page.reload();await page.locator('.wolf-tap').waitFor();assert.equal(await guide.count(),0);
  if(width===393){
   await page.locator('.mobile-nav button').filter({hasText:'Wallet'}).click();
   await page.getByRole('button',{name:'Как пользоваться Walker',exact:true}).click();
   await guide.getByRole('heading',{name:'Шагай и получай WC',exact:true}).waitFor();
   await guide.locator('.language-select select').selectOption('en');
   await guide.getByRole('heading',{name:'Walk and earn WC',exact:true}).waitFor();
   await guide.getByRole('button',{name:'Next',exact:true}).click();
   await guide.getByRole('heading',{name:'Find your way around',exact:true}).waitFor();
   assert.ok(!/[а-яё]/i.test(await guide.innerText()));
   await guide.locator('.language-select select').selectOption('ru');
   await guide.press('Escape');await guide.waitFor({state:'detached'});
   accountId='2002';await page.getByRole('button',{name:'Обновить',exact:true}).click();
   await guide.getByRole('heading',{name:'Шагай и получай WC',exact:true}).waitFor();
   await guide.getByRole('button',{name:'Пропустить',exact:true}).click();await guide.waitFor({state:'detached'});
   assert.equal(await page.evaluate(()=>localStorage.getItem('walker:welcome:v1:2002')),'done');
   accountId='1001';await page.getByRole('button',{name:'Обновить',exact:true}).click();
   await page.locator('.mobile-nav button').filter({hasText:'Earn'}).click();
   await page.locator('.wolf-tap').waitFor();assert.equal(await guide.count(),0);
  }
  console.log('Initial tap geometry',await page.locator('.wolf-tap').evaluate(el=>({buttonWidth:el.getBoundingClientRect().width,stageWidth:el.parentElement.getBoundingClientRect().width,grid:getComputedStyle(el.parentElement).gridTemplateColumns})));await page.screenshot({path:process.env.WALKER_UI_SCREENSHOT||'tap-fixed-393.png',fullPage:true});await page.waitForFunction(()=>document.querySelector('.wolf-tap').getBoundingClientRect().width>100);
  const geometry=await page.locator('.wolf-tap').evaluate(el=>{const r=el.getBoundingClientRect(),p=el.querySelector('.tap-rank-portrait'),s=getComputedStyle(p);return {width:r.width,height:r.height,left:r.left,right:r.right,portraitBorder:s.borderWidth,portraitShadow:s.boxShadow,clip:s.clipPath,overflow:getComputedStyle(el).overflow,scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth}});
  assert.ok(Math.abs(geometry.width-geometry.height)<1);assert.ok(geometry.left>=0&&geometry.right<=width);assert.equal(geometry.portraitBorder,'0px');assert.equal(geometry.portraitShadow,'none');assert.equal(geometry.overflow,'hidden');assert.ok(geometry.scrollWidth<=width);
  await page.locator('.language-select select').selectOption('en');
  assert.deepEqual(await page.locator('.mobile-nav button span').allTextContents(),['Earn','Wallet','Friends','Quests','Listing']);
  assert.equal(await page.locator('.mobile-nav button').count(),5);
  await page.locator('.mobile-nav button').filter({hasText:'Listing'}).click();await page.getByRole('heading',{name:'Next chapter: WC listing'}).waitFor();
  await page.locator('.language-select select').selectOption('ru');await page.getByRole('heading',{name:'Следующая глава — листинг WC'}).waitFor();
  await page.locator('.mobile-nav button').filter({hasText:'Quests'}).click();assert.equal(await page.locator('.daily-cards').count(),0);
  assert.equal(await page.locator('.goal').count(),0);
  assert.equal(await page.locator('.quest-categories button').count(),3);
  assert.ok(!(await page.locator('.quest-hub').innerText()).includes('Разминка'));
  await page.getByRole('button',{name:'Партнёры',exact:true}).click();
  if(width===320)await page.getByRole('heading',{name:'Готовим партнёрские квесты',exact:true}).waitFor();
  else{await page.locator('.quest-partner .quest-card-summary').click();assert.equal(await page.locator('.quest-card-details button').isEnabled(),false);await page.locator('.quest-card-details textarea').fill('Proof for the sample quest');assert.equal(await page.locator('.quest-card-details button').isEnabled(),true);}

  await page.getByRole('button',{name:'Выполнено',exact:true}).click();
  await page.getByRole('heading',{name:'Здесь будут твои победы',exact:true}).waitFor();
  await page.locator('.quest-categories button').filter({hasText:'Walker'}).click();
  if(width!==320){assert.equal(await page.locator('.quest-card').count(),2);await page.locator('.quest-telegram .quest-card-summary').click();await page.getByRole('button',{name:'Проверить подписку',exact:true}).waitFor();assert.ok(!(await page.locator('.quest-card-details').innerText()).includes('Подтверждение выполнения'));}
  await page.screenshot({path:'quests-'+width+'-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  await page.locator('.mobile-nav button').filter({hasText:'Friends'}).click();
  await page.getByRole('button',{name:'Пригласить друзей'}).waitFor();
  assert.ok((await page.locator('.growth-shell').textContent()).includes('147'));
  assert.equal(await page.locator('.growth-badge').count(),10);
  assert.equal(await page.locator('.growth-badge[data-unlocked=true]').count(),1);
  assert.equal(await page.locator('.growth-badge[data-unlocked=false]').count(),9);
  for(const portrait of await page.locator('.growth-art-well img').all()){
   await portrait.scrollIntoViewIfNeeded();await page.waitForFunction(src=>[...document.querySelectorAll('.growth-art-well img')].some(img=>img.getAttribute('src')===src&&img.complete&&img.naturalWidth>0),await portrait.getAttribute('src'));
   assert.equal(await portrait.evaluate(el=>getComputedStyle(el).objectFit),'contain');
   assert.ok(await portrait.evaluate(el=>el.naturalWidth>0));
  }
  assert.equal(new Set(await page.locator('.growth-art-well img').evaluateAll(els=>els.map(el=>el.getAttribute('src')))).size,10);
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'growth-pack-'+width+'-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  await page.locator('.language-select select').selectOption('en');
  assert.ok(!/[а-яё]/i.test(await page.locator('.growth-shell').innerText()));
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.getByRole('button',{name:'Leaderboards',exact:true}).click();
  await page.getByText('GLOBAL PACK',{exact:true}).waitFor();
  await page.getByRole('button',{name:'CREATOR TOP',exact:true}).click();await page.getByLabel('Top size').selectOption('10');await page.getByText(/TOP 10$/).waitFor();assert.ok(await page.locator('.growth-ranking li').count()<=10);
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  if(width===393){await page.getByRole('button',{name:'Creator',exact:true}).click();await page.getByText('D7 retention · 7 / 10',{exact:true}).waitFor();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));}
  await page.getByRole('button',{name:'Share cards',exact:true}).click();
  await page.getByRole('button',{name:'Download PNG',exact:true}).waitFor();if(width===393){const png=page.waitForEvent('download');await page.getByRole('button',{name:'Download PNG',exact:true}).click();await (await png).saveAs('growth-share-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png');}
  await page.screenshot({path:'growth-'+width+'-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  await page.locator('.language-select select').selectOption('ru');
  assert.ok((await page.locator('.growth-shell').innerText()).includes('Осталось'));
  await page.getByRole('button',{name:'Рейтинги',exact:true}).click();
  await page.getByLabel('Количество участников').selectOption('10');
  await page.locator('.board-self').waitFor();
  assert.ok(!(await page.locator('.growth-shell').innerText()).match(/Active|Total|Creator|MY PACK|INVITE|TOP/));
  assert.equal(await page.getByLabel('Период рейтинга').evaluate(el=>getComputedStyle(el).appearance),'none');
  await page.screenshot({path:'rankings-'+width+'-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  assert.equal(await page.locator('.mobile-nav button').count(),5);
  await page.locator('.mobile-nav button').filter({hasText:'Earn'}).click();
  if(width===393)await page.screenshot({path:process.env.WALKER_UI_SCREENSHOT||'tap-fixed-393.png',fullPage:true});
  console.log(JSON.stringify({width,...geometry}));await page.close();
  const moved=await browser.newPage({viewport:{width,height:852},isMobile:true,hasTouch:true});
  const destination={username:'WalkerWallet_bot',link:'https://t.me/WalkerWallet_bot'};
  await moved.route('https://telegram.org/**',r=>r.fulfill({contentType:'text/javascript',body:'window.Telegram={WebApp:{initData:"retired-fixture",ready(){},expand(){},openTelegramLink(url){window.__movedTo=url}}};'}));
  await moved.route('**/api/**',r=>r.fulfill({status:new URL(r.request().url()).pathname==='/api/bot'?200:409,contentType:'application/json',body:JSON.stringify(new URL(r.request().url()).pathname==='/api/bot'?destination:{error:'Walker переехал',code:'BOT_MOVED',migration:destination})}));
  await moved.goto('http://127.0.0.1:'+server.address().port);
  await moved.locator('.bot-moved').waitFor();
  await moved.locator('.language-select select').selectOption('ru');
  await moved.getByRole('heading',{name:'Walker переехал',exact:true}).waitFor();
  assert.equal(await moved.locator('.wolf-tap,.mobile-nav,.welcome-guide').count(),0);
  assert.equal(await moved.locator('.bot-moved-card>a').getAttribute('href'),destination.link);
  await moved.waitForFunction(()=>{const img=document.querySelector('.bot-moved-card>img');return img?.complete&&img.naturalWidth>0});
  assert.ok(await moved.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  if(width===393)await moved.screenshot({path:'growth-bot-moved-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  await moved.locator('.language-select select').selectOption('en');
  await moved.getByRole('heading',{name:'Walker has moved',exact:true}).waitFor();
  assert.ok(!/[а-яё]/i.test(await moved.locator('.bot-moved').innerText()));
  await moved.getByRole('link',{name:'Open the new Walker',exact:true}).click();
  assert.equal(await moved.evaluate(()=>window.__movedTo),destination.link);
  assert.ok(moved.url().startsWith('http://127.0.0.1:'));
  await moved.close();
 }
}finally{await browser.close();await new Promise(r=>server.close(r))}
