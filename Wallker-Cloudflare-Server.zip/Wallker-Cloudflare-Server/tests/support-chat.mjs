import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {Miniflare} from 'miniflare';
const root=fileURLToPath(new URL('../',import.meta.url)),token='123:LOCAL_CHAT_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:token,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id){const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'User '+id})});const secret=createHmac('sha256','WebAppData').update(token).digest();f.set('hash',createHmac('sha256',secret).update([...f].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return f.toString()}
async function api(path,id=1002,data){const r=await mf.dispatchFetch('http://localhost'+path,{method:data?'POST':'GET',headers:{'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id)}:{})},...(data?{body:JSON.stringify(data)}:{})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])await api('/api/wallet',id);
 const legacy={message:'Старое обращение не должно исчезнуть',requestId:'legacy_support_001'};await api('/api/support',1002,legacy);
 assert.equal((await api('/api/support/chat',null)).status,401);
 for(const p of ['/api/admin/support/chats','/api/admin/support/chat?user=tg:1002'])assert.equal((await api(p,1002)).status,403);
 assert.equal((await api('/api/support/chat',1002)).value.messages[0].message,legacy.message);
 assert.equal((await api('/api/support/chat?user=tg:1002',1003)).value.messages.length,0);
 await db.prepare('UPDATE support_chat SET created=?').bind(Date.now()-3000).run();
 const message={message:'Привет',requestId:'user_chat_message01'};
 const sent=await Promise.all(Array.from({length:4},()=>api('/api/support/chat',1002,message)));assert.ok(sent.every(r=>r.status===200));assert.equal(sent[0].value.messages.length,2);
 assert.equal((await api('/api/support/chat',1002,{...message,message:'Другой текст'})).status,409);
 assert.equal((await api('/api/support/chat',1002,{...message,requestId:'user_chat_too_fast1'})).status,429);
 let inbox=(await api('/api/admin/support/chats',1001)).value;assert.equal(inbox.threads[0].unread,2);
 await api('/api/admin/support/chat?user=tg:1002',1001);assert.equal((await api('/api/admin/support/chats',1001)).value.threads[0].unread,0);
 const reply={message:'Привет! Помогу разобраться.',userId:'tg:1002',requestId:'admin_chat_reply01'};
 assert.equal((await api('/api/admin/support/chat',1003,reply)).status,403);
 const replies=await Promise.all(Array.from({length:4},()=>api('/api/admin/support/chat',1001,reply)));assert.ok(replies.every(r=>r.status===200));
 const chat=(await api('/api/support/chat',1002)).value;assert.equal(chat.messages.length,3);assert.equal(chat.messages.at(-1).sender,'admin');assert.equal(chat.messages.at(-1).message,reply.message);
 assert.equal((await api('/api/support/chat',1003)).value.messages.length,0);
 assert.equal((await api('/api/admin/support/chat',1001,{...reply,userId:'tg:1003'})).status,409);
 assert.equal((await api('/api/admin/support/chat?user='+encodeURIComponent('tg:1002 OR 1=1'),1001)).status,400);
 for(let i=0;i<110;i++)await db.prepare("INSERT INTO support_chat(user_id,sender,author_id,request_id,message,created) VALUES('tg:1002','user','tg:1002',?,'История',?)").bind('history_'+i,Date.now()).run();
 const last=(await api('/api/support/chat',1002)).value;assert.equal(last.messages.length,100);assert.ok(last.before);const previous=(await api('/api/support/chat?before='+last.before,1002)).value;assert.equal(previous.messages.length,13);assert.ok(previous.messages.every(m=>m.id<last.before));
 console.log('PASS: persistent bidirectional support, legacy migration, private user threads, owner-only replies/inbox, replay/conflict/rate protections, unread counters and paginated history.');
}finally{await mf.dispose()}
