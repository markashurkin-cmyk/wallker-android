import {CampaignError} from './campaigns.mjs';
import {LEVELS,walkingLevel} from './level-catalog.mjs';
export async function ensureLevels(db){
 await db.prepare('CREATE TABLE IF NOT EXISTS level_claims(user_id TEXT NOT NULL,level INTEGER NOT NULL,units INTEGER NOT NULL,created INTEGER NOT NULL,PRIMARY KEY(user_id,level))').run();
}
export async function levelSnapshot(db,id){
 await ensureLevels(db);
 const totalSteps=(await db.prepare('SELECT COALESCE(SUM(steps),0) AS n FROM days WHERE user_id=?').bind(id).first()).n;
 const claims=(await db.prepare('SELECT level,units,created FROM level_claims WHERE user_id=?').bind(id).all()).results;
 const current=walkingLevel(totalSteps),next=LEVELS[current.level]||null;
 const catalog=LEVELS.map(x=>{const claim=claims.find(c=>c.level===x.level);return {...x,unlocked:totalSteps>=x.steps,claimed:x.reward===0||!!claim,claimedCoins:claim?claim.units/100:0,claimedAt:claim?.created||null};});
 return {level:current.level,name:current.name,totalSteps,nextSteps:next?.steps??null,remainingSteps:next?Math.max(0,next.steps-totalSteps):0,progress:next?Math.min(1,(totalSteps-current.steps)/(next.steps-current.steps)):1,coins:claims.reduce((sum,c)=>sum+c.units,0)/100,availableCoins:catalog.filter(c=>c.unlocked&&!c.claimed).reduce((sum,c)=>sum+c.reward,0),catalog};
}
export async function claimLevel(db,id,data){
 if(!Number.isSafeInteger(data.level)||data.level<2||data.level>LEVELS.length)throw new CampaignError('Выбери уровень от 2 до 10');
 const level=LEVELS[data.level-1];await ensureLevels(db);
 // Unique account/level and server-side step eligibility are evaluated in one write.
 // Concurrent/replayed claims cannot pay twice; claimed awards are frozen.
 await db.prepare(`INSERT OR IGNORE INTO level_claims(user_id,level,units,created) SELECT ?,?,?,? WHERE (SELECT COALESCE(SUM(steps),0) FROM days WHERE user_id=?)>=?`).bind(id,level.level,level.reward*100,Date.now(),id,level.steps).run();
 const receipt=await db.prepare('SELECT units FROM level_claims WHERE user_id=? AND level=?').bind(id,level.level).first();
 if(!receipt)throw new CampaignError('Сначала передай нужное количество шагов с телефона',409);
 return {ok:true,level:level.level,coins:receipt.units/100};
}
