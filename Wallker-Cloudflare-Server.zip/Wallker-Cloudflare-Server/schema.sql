-- Run only in the new wallker-wallet D1 database. Does not delete or reset data.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  timezone TEXT NOT NULL,
  mode TEXT NOT NULL,
  created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS days (
  user_id TEXT NOT NULL REFERENCES users(id),
  day TEXT NOT NULL,
  steps INTEGER NOT NULL DEFAULT 0 CHECK(steps >= 0 AND steps <= 100000),
  updated INTEGER NOT NULL,
  source TEXT NOT NULL,
  PRIMARY KEY(user_id, day)
);
CREATE TABLE IF NOT EXISTS pairings (
  code_hash TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  expires INTEGER NOT NULL,
  device_hash TEXT,
  platform TEXT
);
CREATE INDEX IF NOT EXISTS pairings_user ON pairings(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS pairings_device ON pairings(device_hash) WHERE device_hash IS NOT NULL;
