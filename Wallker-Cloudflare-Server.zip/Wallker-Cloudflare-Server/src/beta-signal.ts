export const BETA_EVENT='walker:beta-access-required';
export type BetaAccess={required:boolean,allowed:boolean,status:'none'|'pending'|'approved'|'rejected'|'revoked',telegramId:string,requestedAt:number|null,revision:number};
export function betaSignal(result:any){if(result?.code==='BETA_ACCESS_REQUIRED'&&result.access)window.dispatchEvent(new CustomEvent(BETA_EVENT,{detail:result.access}));}
