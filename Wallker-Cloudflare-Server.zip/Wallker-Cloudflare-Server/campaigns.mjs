import {canEarn} from './security.mjs';
import {referralBoost} from './referrals.mjs';
import {telegramMembership} from './subscriptions.mjs';
export class CampaignError extends Error{constructor(message,status=400){super(message);this.status=status}}
export function isAdmin(user,env){return String(env.ADMIN_TELEGRAM_ID||'').split(',').map(x=>x.trim()).filter(x=>/^[1-9]\d*$/.test(x)).some(x=>user.id===`tg:${x}`)}
export async function ensureCampaigns(db){if(db.schemaReady)return;
 await db.batch([
 db.prepare(`CREATE TABLE IF NOT EXISTS campaigns(id TEXT PRIMARY KEY,title TEXT NOT NULL,description TEXT NOT NULL,title_en TEXT NOT NULL DEFAULT '',description_en TEXT NOT NULL DEFAULT '',kind TEXT NOT NULL,partner TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',target INTEGER NOT NULL DEFAULT 0,reward INTEGER NOT NULL,starts INTEGER NOT NULL,ends INTEGER NOT NULL,status TEXT NOT NULL,created INTEGER NOT NULL,updated INTEGER NOT NULL)`),
 db.prepare(`CREATE TABLE IF NOT EXISTS campaign_claims(campaign_id TEXT NOT NULL,user_id TEXT NOT NULL,proof TEXT NOT NULL DEFAULT '',state TEXT NOT NULL,reward INTEGER NOT NULL,created INTEGER NOT NULL,reviewed INTEGER,PRIMARY KEY(campaign_id,user_id))`),
 db.prepare(`CREATE TABLE IF NOT EXISTS mascot_config(id TEXT PRIMARY KEY,partner TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 0)`)
 ]);
}
function text(v,max,required=false){if(typeof v!=='string'||v.length>max||(required&&!v.trim()))throw new CampaignError('Проверь текстовые поля задания');return v.trim()}
function safeURL(v){const t=text(v||'',1000);if(!t)return '';let u;try{u=new URL(t)}catch{throw new CampaignError('Укажи полную HTTPS-ссылку')};if(u.protocol!=='https:'||u.username||u.password)throw new CampaignError('Разрешены только HTTPS-ссылки без логина и пароля');return u.href}
function campaign(data){
 const title=text(data.title,100,true),description=text(data.description,1500,true),partner=text(data.partner||'',60),url=safeURL(data.url);
 if(!['steps','partner','contest','telegram','tiktok'].includes(data.kind))throw new CampaignError('Выбери тип задания');
 if(!['draft','published','archived'].includes(data.status))throw new CampaignError('Неверный статус');
 const reward=data.reward,target=['steps','contest'].includes(data.kind)?data.target:0;
 if(!Number.isSafeInteger(reward)||reward<0||reward>100000)throw new CampaignError('Награда: от 0 до 100 000 WC');
 if(data.kind==='steps'&&(!Number.isSafeInteger(target)||target<100||target>100000))throw new CampaignError('Цель: от 100 до 100 000 шагов');
 if(data.kind==='contest'&&(!Number.isSafeInteger(target)||target<1||target>100))throw new CampaignError('Количество победителей: от 1 до 100');
 if(data.kind==='telegram'&&(!/^@[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(partner)||url!==`https://t.me/${partner.slice(1)}`))throw new CampaignError('Канал: @username и ссылка https://t.me/username');
 if(data.kind==='tiktok'&&!/^https:\/\/www\.tiktok\.com\/@[a-zA-Z0-9_.]+\/?$/.test(url))throw new CampaignError('Укажи ссылку на профиль TikTok: https://www.tiktok.com/@имя');
 if(data.kind==='partner'&&(!partner||!url))throw new CampaignError('Добавь партнёра и HTTPS-ссылку');
 if(!Number.isSafeInteger(data.starts)||!Number.isSafeInteger(data.ends)||data.ends<=data.starts||data.ends-data.starts>366*86400000)throw new CampaignError('Проверь сроки: до 366 дней');
 if(data.status==='published'&&data.ends<=Date.now())throw new CampaignError('Нельзя опубликовать завершённое задание');
 return {title,description,title_en:text(data.title_en||'',100),description_en:text(data.description_en||'',1500),kind:data.kind,partner,url,target,reward,starts:data.starts,ends:data.ends,status:data.status};
}
export async function campaignSnapshot(db,user,env){
 await ensureCampaigns(db);
 const now=Date.now(),boost=await referralBoost(db,user.id);
 const tasks=(await db.prepare(`SELECT c.*,q.state AS claimState,q.reward AS claimedReward,(SELECT COUNT(*) FROM campaign_claims w WHERE w.campaign_id=c.id AND w.state='approved') AS winnerCount FROM campaigns c LEFT JOIN campaign_claims q ON q.campaign_id=c.id AND q.user_id=? WHERE c.status='published' AND c.starts<=? AND (c.ends>? OR c.kind='contest') ORDER BY c.created DESC LIMIT 100`).bind(user.id,now,now).all()).results;
 const mascot=await db.prepare("SELECT partner,url,active FROM mascot_config WHERE id='volker'").first();
 for(const t of tasks){t.baseReward=t.reward;t.reward=t.claimedReward??Math.round(t.reward*boost.multiplier*10000)/10000;}
 return {isAdmin:isAdmin(user,env),telegramId:user.id.slice(3),campaigns:tasks,mascot:mascot?.active?mascot:null};
}
export async function bonusBalance(db,id){await ensureCampaigns(db);return (await db.prepare("SELECT COALESCE(SUM(reward),0) AS amount FROM campaign_claims WHERE user_id=? AND state='approved'").bind(id).first()).amount}
export async function campaignRoute(path,method,data,db,user,env,steps){
 await ensureCampaigns(db);
 if(path.startsWith('/api/admin/')&&!isAdmin(user,env))throw new CampaignError('Меню разработчика доступно только владельцу',403);
 if(path==='/api/campaigns'&&method==='GET')return campaignSnapshot(db,user,env);
 if(path==='/api/campaigns/claim'&&method==='POST'){if(db.schemaReady)await canEarn(db,user.id);
  const id=text(data.id,64,true);const now=Date.now();
  const task=await db.prepare("SELECT * FROM campaigns WHERE id=? AND status='published' AND starts<=? AND ends>?").bind(id,now,now).first();
  if(!task)throw new CampaignError('Задание завершено или снято с публикации',409);
  const existing=await db.prepare('SELECT state FROM campaign_claims WHERE campaign_id=? AND user_id=?').bind(id,user.id).first();
  if(existing)return {ok:true,state:existing.state};
  if(task.kind==='steps'&&steps<task.target)throw new CampaignError('Сначала передай нужное количество шагов за сегодня');
  if(task.kind==='telegram'&&!await telegramMembership(env,task.partner,user.id))throw new CampaignError('Подпишись на канал и нажми «Проверить подписку»',409);
  const proof=['partner','contest','tiktok'].includes(task.kind)?text(data.proof,1000,true):'';
  if(task.kind==='contest'){const link=safeURL(proof);if(!/^https:\/\/(t\.me|www\.tiktok\.com|vk\.com|www\.youtube\.com|youtube\.com)\//.test(link))throw new CampaignError('Пришли ссылку на свою публикацию в Telegram, TikTok, VK или YouTube');}
  const boost=await referralBoost(db,user.id),award=Math.round(task.reward*boost.multiplier*10000)/10000;
  // Atomic insert reads current publication state again; reward is frozen at submission.
  await db.prepare(`INSERT OR IGNORE INTO campaign_claims(campaign_id,user_id,proof,state,reward,created) SELECT id,?,?,?,?,? FROM campaigns WHERE id=? AND status='published' AND starts<=? AND ends>? AND kind=? AND partner=? AND url=? AND reward=? AND target=? AND starts=? AND ends=?`).bind(user.id,proof,['steps','telegram'].includes(task.kind)?'approved':'pending',award,now,id,now,now,task.kind,task.partner,task.url,task.reward,task.target,task.starts,task.ends).run();
  const claim=await db.prepare('SELECT state FROM campaign_claims WHERE campaign_id=? AND user_id=?').bind(id,user.id).first();
  if(!claim)throw new CampaignError('Задание больше не доступно',409);
  return {ok:true,state:claim.state};
 }
 if(path==='/api/admin/campaigns'&&method==='GET'){
  const page=data.page??1;if(!Number.isSafeInteger(page)||page<1||page>10000)throw new CampaignError('Неверная страница');const offset=(page-1)*200;
  const tasks=(await db.prepare('SELECT * FROM campaigns ORDER BY created DESC LIMIT 200 OFFSET ?').bind(offset).all()).results;
  const claims=(await db.prepare(`SELECT q.*,c.title,u.name FROM campaign_claims q JOIN campaigns c ON c.id=q.campaign_id JOIN users u ON u.id=q.user_id WHERE q.state='pending' ORDER BY q.created LIMIT 200 OFFSET ?`).bind(offset).all()).results;
  const mascot=await db.prepare("SELECT partner,url,active FROM mascot_config WHERE id='volker'").first();
  return {campaigns:tasks,claims,mascot,page,hasNext:tasks.length===200||claims.length===200};
 }
 if(path==='/api/admin/campaigns'&&method==='POST'){
  const c=campaign(data);const id=data.id?text(data.id,64,true):crypto.randomUUID();const now=Date.now();
  if(c.kind==='telegram'&&c.status==='published')await telegramMembership(env,c.partner,null);
  if(data.id){
   const prior=await db.prepare('SELECT * FROM campaigns WHERE id=?').bind(id).first();
   const submitted=await db.prepare('SELECT 1 AS n FROM campaign_claims WHERE campaign_id=? LIMIT 1').bind(id).first();
   if(submitted&&prior&&['title','description','title_en','description_en','kind','reward','target','partner','url','starts','ends'].some(k=>prior[k]!==c[k]))throw new CampaignError('После первых заявок сроки, условия проверки и награды закреплены. Создай новое задание.',409);
   const result=await db.prepare(`UPDATE campaigns SET title=?,description=?,title_en=?,description_en=?,kind=?,partner=?,url=?,target=?,reward=?,starts=?,ends=?,status=?,updated=? WHERE id=? AND (NOT EXISTS(SELECT 1 FROM campaign_claims WHERE campaign_id=campaigns.id) OR (title=? AND description=? AND title_en=? AND description_en=? AND kind=? AND partner=? AND url=? AND target=? AND reward=? AND starts=? AND ends=?))`).bind(c.title,c.description,c.title_en,c.description_en,c.kind,c.partner,c.url,c.target,c.reward,c.starts,c.ends,c.status,now,id,c.title,c.description,c.title_en,c.description_en,c.kind,c.partner,c.url,c.target,c.reward,c.starts,c.ends).run();
   if(!result.meta.changes)throw new CampaignError('Задание не найдено',404);
  }else await db.prepare(`INSERT INTO campaigns(id,title,description,title_en,description_en,kind,partner,url,target,reward,starts,ends,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(id,c.title,c.description,c.title_en,c.description_en,c.kind,c.partner,c.url,c.target,c.reward,c.starts,c.ends,c.status,now,now).run();
  return {ok:true,id};
 }
 if(path==='/api/admin/claims'&&method==='POST'){
  if(!['approved','rejected'].includes(data.state))throw new CampaignError('Неверное решение');
  const id=text(data.id,64,true),uid=text(data.userId,100,true);
  const task=await db.prepare('SELECT * FROM campaigns WHERE id=?').bind(id).first();
  if(!task)throw new CampaignError('Задание не найдено',404);
  if(task.kind==='telegram'||task.kind==='steps')throw new CampaignError('Это задание проверяется автоматически',409);
  if(task.kind==='contest'&&data.state==='approved'&&Date.now()<task.ends)throw new CampaignError('Выбери победителей после окончания приёма работ',409);
  const result=await db.prepare("UPDATE campaign_claims SET state=?,reviewed=? WHERE campaign_id=? AND user_id=? AND state='pending' AND (?<>'approved' OR ?<>'contest' OR (SELECT COUNT(*) FROM campaign_claims WHERE campaign_id=? AND state='approved')<?)").bind(data.state,Date.now(),id,uid,data.state,task.kind,id,task.target).run();
  const current=await db.prepare('SELECT state FROM campaign_claims WHERE campaign_id=? AND user_id=?').bind(id,uid).first();
  if(!current)throw new CampaignError('Заявка не найдена',404);
  if(current.state!==data.state)throw new CampaignError('Заявка уже рассмотрена или все призовые места заняты',409);
  return {ok:true};
 }
 if(path==='/api/admin/mascot'&&method==='POST'){
  const partner=text(data.partner||'',30),url=safeURL(data.url);const active=data.active===true;
  if(active&&(!partner||!url))throw new CampaignError('Добавь название и ссылку партнёра');
  await db.prepare("INSERT INTO mascot_config(id,partner,url,active) VALUES('volker',?,?,?) ON CONFLICT(id) DO UPDATE SET partner=excluded.partner,url=excluded.url,active=excluded.active").bind(partner,url,active?1:0).run();return {ok:true};
 }
 throw new CampaignError('Метод не поддерживается',405);
}
