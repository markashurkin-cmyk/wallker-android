import {CampaignError} from './campaigns.mjs';
export async function telegramMembership(env,channel,id,request=fetch){
 if(!env.TELEGRAM_BOT_TOKEN||!/^@[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(channel))throw new CampaignError('Добавь канал и бота-администратора',409);
 const call=async(method,body)=>{let j;try{const r=await request(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(8000)});j=await r.json();if(!r.ok||!j.ok)throw Error()}catch{throw new CampaignError('Telegram не подтвердил проверку. Проверь канал и права бота, затем повтори.',503)}return j.result};
 const chat=await call('getChat',{chat_id:channel});
 if(chat.type!=='channel'||String(chat.username).toLowerCase()!==channel.slice(1).toLowerCase())throw new CampaignError('Укажи публичный Telegram-канал',409);
 const me=await call('getMe',{}),bot=await call('getChatMember',{chat_id:channel,user_id:me.id});
 if(!['creator','administrator'].includes(bot.status))throw new CampaignError('Сначала добавь нашего бота администратором канала',409);
 if(id==null)return true;
 const member=await call('getChatMember',{chat_id:channel,user_id:Number(id.slice(3))});
 return ['creator','administrator','member'].includes(member.status)||(member.status==='restricted'&&member.is_member===true);
}
