import {LanguageProvider,translate,getLocale} from '../src/language';
import Wallet from '../src/wallet';
import {Challenges} from '../src/campaigns';
import {Listing} from '../src/listing';
import {SimpleWallet} from '../src/wallet-simple';
import {renderToStaticMarkup} from 'react-dom/server';
import assert from 'node:assert/strict';
let selected='en';
(globalThis as any).window={Telegram:{WebApp:{ready(){},expand(){},initData:''}}};
(globalThis as any).document={documentElement:{lang:''}};
(globalThis as any).localStorage={getItem:(key:string)=>key==='walker-language'?selected:null,setItem(){}};
Object.defineProperty(globalThis,'navigator',{value:{language:'ru-RU'},configurable:true});
for(const language of ['en','ru']){
 selected=language;
 const html=renderToStaticMarkup(<LanguageProvider><Wallet/><Challenges tasks={[{id:'legacy',title:'НЕ ПОКАЗЫВАТЬ',description:'Старый квест',kind:'steps',partner:'',url:'',target:5000,reward:50,starts:0,ends:Date.now()+86400000,status:'published'},{id:'tg',title:'Подпишись на канал',description:'Новости проекта',title_en:'Follow our channel',description_en:'Project news',kind:'telegram',partner:'Walker',url:'https://example.com',target:0,reward:200,starts:0,ends:Date.now()+86400000,status:'published'}]} reload={async()=>{}}/><Listing/><SimpleWallet data={{balance:123.5,earnings:[],tapCoins:0,bonusCoins:0,levelCoins:0,grantCoins:0,purchaseCoins:0,history:[]}} connected={false} onLevels={()=>{}} onShop={()=>{}} onConnection={()=>{}}/></LanguageProvider>);
 assert.equal((globalThis as any).document.documentElement.lang,language);
 for(const label of ['Earn','Wallet','Friends','Quests','Listing'])assert.ok(html.includes('>'+label+'<'));
 assert.ok(!html.includes('НЕ ПОКАЗЫВАТЬ'));assert.ok(!html.includes('Ссылка ещё не добавлена'));
 assert.equal(getLocale(),language==='en'?'en-US':'ru-RU');
 if(language==='en'){assert.ok(!/[а-яё]/i.test(html),html.match(/[а-яё][^<]*/i)?.[0]);assert.ok(html.includes('Next chapter'));assert.equal(translate('Ещё 25,000 шагов до уровня 3'),'25,000 steps to level 3');assert.equal(translate('За тап +0.1 WC'),'Per tap +0.1 WC');assert.equal(translate('+25% WC за тап'),'+25% tap WC')}
 else {assert.ok(html.includes('Следующая глава'));assert.ok(html.includes('ТВОЯ АКТИВНОСТЬ / ДОХОД'));assert.ok(!html.includes('ТВОЯ АКТИВНОСТЬ / EARN'));assert.ok(html.includes('>Кошелёк</button>'));}
}
console.log('PASS: Russian/English app rendering, persisted preference, English-only navigation, localized banners, dynamic tap/level text and number locale.');
