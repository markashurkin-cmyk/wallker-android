import {access,cp,mkdir,readFile,rm,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
// Immutable, owned source snapshot. Download assets only; verify before extraction.
const URL='https://raw.githubusercontent.com/markashurkin-cmyk/wallker-android/b2e2529b481df3890807d7022ca0e41a6d75882c/Wallker-Cloudflare-Server.zip';
const SHA='7d752976389f477f36a7f83b63a8961a05f5d4e8a4f6d788441d90097b0630f5';
export async function ensureAssets({archivePath,destination='assets'}={}){
 try{await access(destination+'/wolf-level-11.png');return}catch{}
 const temp='.walker-asset-bootstrap';await mkdir(temp,{recursive:true});
 try{
  let bytes;if(archivePath)bytes=await readFile(archivePath);else{const r=await fetch(URL,{signal:AbortSignal.timeout(60000)});if(!r.ok)throw Error('Base assets unavailable');const n=Number(r.headers.get('content-length'));if(n>30_000_000)throw Error('Base assets too large');const chunks=[];let size=0;for await(const chunk of r.body){size+=chunk.length;if(size>30_000_000)throw Error('Base assets too large');chunks.push(Buffer.from(chunk))}bytes=Buffer.concat(chunks);}
  if(bytes.length>30_000_000||createHash('sha256').update(bytes).digest('hex')!==SHA)throw Error('Base assets integrity check failed');
  const path=temp+'/base.zip';await writeFile(path,bytes);await promisify(execFile)('unzip',['-q',path,'Wallker-Cloudflare-Server/assets/*','-d',temp]);
  await cp(temp+'/Wallker-Cloudflare-Server/assets',destination,{recursive:true});
 }finally{await rm(temp,{recursive:true,force:true})}
}
