// Reproducible LOCAL synthetic benchmark. Never connects to production D1.
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {Miniflare} from 'miniflare';
import worker from '../worker.js';
import {migrate,requestDB} from '../runtime.mjs';
import {refreshRanks,leaderboard,refreshCreatorAnalytics,creatorDashboard,backfillGrowth} from '../growth.mjs';
import {saveSeason,finalizeSeasons} from '../growth-seasons.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),DAY=86400000,now=Date.now(),token='123:LOCAL_SYNTHETIC_LOAD_ONLY';
const users=100000,hosts=10150,big=150,perBig=500,base=1000000,viewer='tg:1006000';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB']});
const report={kind:'local-synthetic-not-production-capacity',created:new Date(now).toISOString(),dataset:{users,hosts,creatorEligible:big,qualified:users-hosts},measurements:[],warnings:['Local workerd/SQLite latency is not Cloudflare edge latency.','D1 billing and simultaneous-device capacity require a separate remote staging test.','Reported row counters omit first() calls because that API does not return metadata.']};
let calls=0,read=0,written=0,metaSeen=false;
function track(r){if(r?.meta){metaSeen=true;read+=r.meta.rows_read||0;written+=r.meta.rows_written||0;}return r;}
function wrap(raw){function statement(s){return new Proxy(s,{get(t,k){if(k==='bind')return (...a)=>statement(t.bind(...a));if(['all','run','first','raw'].includes(k))return async(...a)=>{calls++;return track(await t[k](...a));};return Reflect.get(t,k)}});}return {prepare:q=>statement(raw.prepare(q)),batch:async ss=>{calls++;return (await raw.batch(ss)).map(track);}};}
async function measure(label,fn){calls=read=written=0;metaSeen=false;const at=performance.now(),value=await fn();const result={label,ms:Math.round((performance.now()-at)*10)/10,calls,reportedRowsRead:metaSeen?read:null,reportedRowsWritten:metaSeen?written:null};report.measurements.push(result);console.log(JSON.stringify(result));return value;}
function signed(){const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id:Number(viewer.slice(3)),first_name:'Synthetic'})});const key=createHmac('sha256','WebAppData').update(token).digest();f.set('hash',createHmac('sha256',key).update([...f].sort(([a],[b])=>a<b?-1:1).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return f.toString();}
try{
 const raw=await mf.getD1Database('DB');await migrate(raw);const measured=wrap(raw);
 const seq=n=>`WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM n WHERE x<${n})`;
 const seedStart=performance.now();
 await raw.prepare(`${seq(users)} INSERT INTO users(id,name,timezone,mode,created) SELECT 'tg:'||(${base}+x),'Load Walker','Europe/Moscow','beta',? FROM n`).bind(now-40*DAY).run();
 await raw.prepare(`${seq(users)} INSERT INTO friend_codes(user_id,code) SELECT 'tg:'||(${base}+x),printf('%020x',${base}+x) FROM n`).run();
 await raw.prepare(`${seq(users-hosts)} INSERT INTO referral_qualified(invitee,inviter,qualified) SELECT 'tg:'||(${base+hosts}+x),'tg:'||(${base+1}+CASE WHEN x<=${big*perBig} THEN CAST((x-1)/${perBig} AS INTEGER) ELSE ${big}+((x-${big*perBig}-1)%${hosts-big}) END),? FROM n`).bind(now-35*DAY).run();
 await raw.prepare('INSERT INTO referrals(invitee,inviter,created) SELECT invitee,inviter,qualified FROM referral_qualified').run();
 await raw.prepare("INSERT INTO pairings(code_hash,user_id,expires,device_hash,platform) SELECT 'load-'||invitee,invitee,?,printf('%064x',CAST(substr(invitee,4) AS INTEGER)),'android' FROM referral_qualified").bind(now-DAY).run();
 for(const offset of [5,6])await raw.prepare("INSERT INTO days(user_id,day,steps,updated,source) SELECT invitee,date(?/1000,'unixepoch'),5000,?,'sensor' FROM referral_qualified").bind(now-offset*DAY,now-offset*DAY).run();
 await raw.prepare('UPDATE growth_meta SET started=?,backfill_done=1 WHERE id=1').bind(now-50*DAY).run();
 await raw.prepare('INSERT INTO growth_totals(user_id,total) SELECT inviter,COUNT(*) FROM referral_qualified GROUP BY inviter').run();
 await raw.prepare('INSERT INTO growth_activations(invitee,inviter,activated,legacy,criteria_revision) SELECT invitee,inviter,?-((CAST(substr(invitee,4) AS INTEGER)%6)+1)*86400000,0,1 FROM referral_qualified').bind(now).run();
 for(const age of [7,30])await raw.prepare("INSERT INTO growth_activity(user_id,day,first_seen,last_seen) SELECT id,date((created+?)/1000,'unixepoch'),created+?,created+? FROM users WHERE CAST(substr(id,4) AS INTEGER)%?=0").bind(age*DAY,age*DAY,age*DAY,age===7?2:4).run();
 await raw.prepare(`${seq(100)} INSERT INTO clans(id,name,name_key,description,owner,created) SELECT 'load-clan-'||x,'Load Clan '||x,'load-clan-'||x,'Synthetic fixture','tg:'||(${base+1}+(x-1)*100),? FROM n`).bind(now-20*DAY).run();
 await raw.prepare(`${seq(10000)} INSERT INTO clan_members(user_id,clan_id,joined) SELECT 'tg:'||(${base}+x),'load-clan-'||(1+CAST((x-1)/100 AS INTEGER)),? FROM n`).bind(now-10*DAY).run();
 const db=()=>requestDB(measured);
 await saveSeason(db(),'tg:1000001',{id:'load_referral_season',kind:'referral',title_ru:'Тест нагрузки',title_en:'Synthetic load',status:'active',starts:now-7*DAY,ends:now+DAY},now);
 report.seedMs=Math.round(performance.now()-seedStart);console.log(JSON.stringify({seedMs:report.seedMs}));
 assert.equal((await raw.prepare('SELECT COUNT(*) AS n FROM users').first()).n,users);
 assert.equal((await raw.prepare('SELECT SUM(total) AS n FROM growth_active_totals').first()).n,users-hosts);
 await measure('rank-refresh-100k-with-active-creator-season',()=>refreshRanks(db(),now));assert.ok(report.measurements.at(-1).reportedRowsRead<3000000,'Season rank must not rescan entire packs per invitee');
 for(const metric of ['global','fastest','creator','clan']){
  const board=await measure('read-'+metric,()=>leaderboard(db(),viewer,metric,null,1,now));assert.ok(board.rows.length>0);if(metric==='global')assert.ok(board.self.rank>1000);
 }
 const season=await measure('read-season-own-position',()=>leaderboard(db(),viewer,'global','load_referral_season',1,now));assert.ok(season.self.rank>1000);
 await measure('creator-analytics-batch',()=>refreshCreatorAnalytics(db(),now));assert.ok(report.measurements.at(-1).calls<=6,'Creator cache must use bounded aggregate requests');assert.equal((await raw.prepare('SELECT COUNT(*) AS n FROM growth_creator_cache').first()).n,20);
 const creator=await creatorDashboard(db(),'tg:1000001',now);assert.equal(creator.d7.rate,.5);assert.equal(creator.d30.rate,.25);
 const auth=signed();async function api(path,data){const pending=[];const r=await worker.fetch(new Request('http://localhost'+path,{method:data?'POST':'GET',headers:{'X-Telegram-Init-Data':auth,'Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})}),{DB:measured,TELEGRAM_BOT_TOKEN:token},{waitUntil:p=>pending.push(p)});const v=await r.json();await Promise.all(pending);assert.equal(r.status,200,JSON.stringify(v));return v;}
 await api('/api/wallet');
 for(let i=0;i<5;i++)await measure('warm-wallet-'+i,()=>api('/api/wallet'));
 for(let i=0;i<5;i++)await measure('tap-'+i,()=>api('/api/tap',{count:5,requestId:'load_tap_receipt_0000'+i}));
 for(let i=0;i<5;i++)await measure('my-pack-'+i,()=>api('/api/growth'));
 await raw.prepare('UPDATE growth_meta SET backfill_cursor=?,backfill_done=0 WHERE id=1').bind('').run();await measure('backfill-batch-80',()=>backfillGrowth(db(),now));assert.ok(report.measurements.at(-1).reportedRowsRead<2000,'Already-initialized totals must skip recount');
 await measure('season-finalization-100k',()=>finalizeSeasons(db(),now+DAY));assert.ok(report.measurements.at(-1).reportedRowsRead<2000000,'Finalization must use grouped eligibility');
 await measure('season-finalization-retry',()=>finalizeSeasons(db(),now+DAY+1));
 const counts=(await raw.prepare('SELECT metric,COUNT(*) AS n FROM growth_ranks GROUP BY metric').all()).results;report.rankRows=counts;report.rankRowsPerSnapshot=counts.reduce((n,r)=>n+r.n,0);report.projectedRankInsertsPerDay=report.rankRowsPerSnapshot*96;
 for(const [prefix,max] of [['warm-wallet',50],['tap',50],['my-pack',30]])assert.ok(report.measurements.filter(r=>r.label.startsWith(prefix)).every(r=>r.calls<=max),'Bounded request count '+prefix);
 for(const prefix of ['warm-wallet','tap','my-pack']){const ms=report.measurements.filter(r=>r.label.startsWith(prefix)).map(r=>r.ms).sort((a,b)=>a-b);report[prefix]={samples:ms.length,p50:ms[Math.floor(ms.length/2)],max:ms.at(-1)};}
 await writeFile(root+'growth-load-results.json',JSON.stringify(report,null,2)+'\n');console.log('PASS: 100,000 synthetic users; exact ranking/retention, own rank beyond TOP, bounded warm paths, bulk backfill and season retry.');
}catch(error){report.error=String(error);await writeFile(root+'growth-load-results.json',JSON.stringify(report,null,2)+'\n');throw error;}finally{await mf.dispose();}
