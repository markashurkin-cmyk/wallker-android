import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {deliverSupport,flushSupport,ensureSupport} from '../support.mjs';
import {Miniflare} from 'miniflare';
const root=fileURLToPath(new URL('../',import.meta.url)),token='123:LOCAL_SUPPORT_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:token,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id){const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'User '+id})});const secret=createHmac('sha256','WebAppData').update(token).digest();f.set('hash',createHmac('sha256',secret).update([...f].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return f.toString()}
async function api(path,id=1002,data){const r=await mf.dispatchFetch('http://localhost'+path,{method:data?'POST':'GET',headers:{'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id)}:{})},...(data?{body:JSON.stringify(data)}:{})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])assert.equal((await api('/api/wallet',id)).status,200);
 assert.equal((await api('/api/support',null)).status,401);assert.equal((await api('/api/admin/support',1002)).status,403);
 const payload={message:'Проверка шагов на тестовом аккаунте',requestId:'support_request_0001'};
 const requests=await Promise.all(Array.from({length:5},()=>api('/api/support',1002,payload)));assert.ok(requests.every(r=>r.status===200));
 const own=(await api('/api/support',1002)).value;assert.equal(own.messages.length,1);assert.equal(own.messages[0].state,'pending');assert.equal(own.botConnected,false);assert.equal((await api('/api/support',1003)).value.messages.length,0);
 assert.equal((await api('/api/support',1002,{...payload,message:'Другой текст этого же обращения'})).status,409);
 assert.equal((await api('/api/support',1002,{...payload,requestId:'support_request_0002'})).status,429);
 for(const message of ['abc','a'.repeat(2001),'bad\u0000message'])assert.equal((await api('/api/support',1003,{message,requestId:'invalid_support_test1'})).status,400);
 const ticket=own.messages[0];let sent=0;const env={SUPPORT_BOT_TOKEN:'456:LOCAL_SECOND_BOT',SUPPORT_CHAT_ID:'1001'};
 const send=async(url,request)=>{sent++;assert.ok(url.includes('456:LOCAL_SECOND_BOT'));assert.ok(!url.includes(token));const body=JSON.parse(request.body);assert.equal(body.chat_id,'1001');assert.ok(body.text.includes('Telegram ID: 1002'));assert.ok(body.text.includes(payload.message));await new Promise(r=>setTimeout(r,20));return new Response(JSON.stringify({ok:true}),{status:200})};
 await Promise.all(Array.from({length:4},()=>deliverSupport(db,env,ticket.id,send)));assert.equal(sent,1);await deliverSupport(db,env,ticket.id,send);assert.equal(sent,1);
 assert.equal((await api('/api/admin/support',1001)).value.messages[0].state,'delivered');
 await db.prepare('UPDATE support_messages SET created=?').bind(Date.now()-120000).run();
 await api('/api/support',1002,{...payload,requestId:'support_request_0002'});const id=(await api('/api/support',1002)).value.messages[0].id;
 const fail=async()=>new Response(JSON.stringify({ok:false,description:'PRIVATE TOKEN ERROR'}),{status:403});assert.equal(await deliverSupport(db,env,id,fail),false);
 const failed=await db.prepare('SELECT * FROM support_messages WHERE id=?').bind(id).first();assert.equal(failed.state,'pending');assert.ok(failed.next_try>Date.now());assert.ok(!JSON.stringify((await api('/api/admin/support',1001)).value).includes('PRIVATE TOKEN'));
 await db.prepare('UPDATE support_messages SET next_try=0,state=?,lease_until=? WHERE id=?').bind('sending',Date.now()-1,id).run();await deliverSupport(db,env,id,send);assert.equal(sent,2);
 await db.prepare('UPDATE support_messages SET created=?').bind(Date.now()-120000).run();await api('/api/support',1002,{...payload,requestId:'support_request_0003'});await db.prepare('UPDATE support_messages SET created=?').bind(Date.now()-120000).run();assert.equal((await api('/api/support',1002,{...payload,requestId:'support_request_0004'})).status,429);
 console.log('PASS: signed support, owner-only inbox, account isolation, validation, atomic deduplication/cooldown/quota, separate bot routing, lease-protected delivery, retry and expired lease recovery, no secret/error disclosure.');
}finally{await mf.dispose()}
