import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {LEVELS,walkingLevel} from '../level-catalog.mjs';
const {Miniflare}=await import(process.env.WALLKER_MINIFLARE_MODULE||'miniflare');
const root=fileURLToPath(new URL('../',import.meta.url)),botToken='123:LOCAL_LEVEL_TEST';
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:botToken,ADMIN_TELEGRAM_ID:'1001'}});
function auth(id){const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Волкер'})});const secret=createHmac('sha256','WebAppData').update(botToken).digest();const check=[...f].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');f.set('hash',createHmac('sha256',secret).update(check).digest('hex'));return f.toString()}
async function api(path,id=1002,data,token){const method=data===undefined?'GET':'POST';const headers={'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id)}:{}),...(token?{Authorization:'Bearer '+token}:{})};const r=await mf.dispatchFetch('http://localhost'+path,{method,headers,...(data!==undefined?{body:JSON.stringify(data)}:{})});return {status:r.status,value:await r.json()}}
try{
 const db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])assert.equal((await api('/api/wallet',id)).status,200);
 assert.equal((await api('/api/friends',null)).status,401);
 const a=(await api('/api/friends',1002)).value,b=(await api('/api/friends',1003)).value;
 assert.match(a.code,/^[a-f0-9]{20}$/);assert.equal(a.friends.length,0);assert.equal((await api('/api/friends',1002)).value.code,a.code);
 assert.equal((await api('/api/friends',1002,{action:'request',code:a.code})).status,400);
 assert.equal((await api('/api/friends',1002,{action:'request',code:'0'.repeat(20)})).status,404);
 assert.equal((await api('/api/friends',1002,{action:'request',code:b.code,userId:'tg:1001'})).status,200);
 assert.equal((await api('/api/friends',1002,{action:'accept',userId:'tg:1003'})).status,403);
 assert.equal((await api('/api/friends',1001,{action:'accept',userId:'tg:1002'})).status,403);
 const pending=(await api('/api/friends',1003)).value;assert.equal(pending.friends.length,0);assert.equal(pending.incoming[0].id,'tg:1002');assert.equal(pending.incoming[0].balance,undefined);
 await api('/api/friends',1003,{action:'request',code:a.code});assert.equal((await api('/api/friends',1003)).value.friends.length,0);
 await api('/api/friends',1003,{action:'accept',userId:'tg:1002'});await api('/api/friends',1003,{action:'accept',userId:'tg:1002'});
 assert.equal((await api('/api/friends',1002)).value.friends.length,1);assert.equal((await api('/api/friends',1001)).value.friends.length,0);
 assert.equal((await api('/api/admin/grants',1002,{userId:'tg:1003',amount:100,requestId:'invalid_admin_grant_1'})).status,403);
 for(const amount of [0,-1,0.001,1000001,'5'])assert.equal((await api('/api/admin/grants',1001,{userId:'tg:1002',amount,requestId:'invalid_amount_grant1'})).status,400);
 assert.equal((await api('/api/admin/grants',1001,{userId:'tg:999999',amount:10,requestId:'unknown_user_grant_01'})).status,404);
 const payload={userId:'tg:1002',amount:250.25,requestId:'concurrent_grant_0001'};
 const grants=await Promise.all(Array.from({length:5},()=>api('/api/admin/grants',1001,payload)));assert.ok(grants.every(r=>r.status===200));
 assert.equal((await api('/api/wallet',1002)).value.grantCoins,250.25);assert.equal((await api('/api/wallet',1003)).value.grantCoins,0);
 assert.equal((await api('/api/admin/grants',1001,{...payload,amount:1})).status,409);
 assert.equal((await api('/api/admin/grants',1001,{...payload,userId:'tg:1003'})).status,409);
 assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM admin_grants').first()).n,1);
 const day=(await api('/api/wallet',1002)).value.today;
 await db.prepare('INSERT INTO days(user_id,day,steps,updated,source) VALUES(?,?,?,?,?)').bind('tg:1002',day,45000,Date.now(),'ios:unverified').run();
 const wallet=(await api('/api/wallet',1002)).value,friend=(await api('/api/friends',1003)).value.friends[0];assert.equal(friend.balance,wallet.balance);assert.equal(friend.level,2);assert.equal(friend.levelName,wallet.levels.name);
 const stats=(await api('/api/admin/stats/user?id=tg:1002',1001)).value;assert.equal(stats.user.grantCoins,250.25);assert.equal(stats.user.balance,wallet.balance);assert.equal((await api('/api/admin/stats',1001)).value.totals.grantCoins,250.25);
 await api('/api/friends',1001,{action:'request',code:a.code});await api('/api/friends',1002,{action:'accept',userId:'tg:1001'});await api('/api/admin/levels',1001,{level:11});assert.equal((await api('/api/friends',1002)).value.friends.find(f=>f.id==='tg:1001').levelName,'Божественный Walker');
 await api('/api/friends',1003,{action:'remove',userId:'tg:1002'});assert.equal((await api('/api/friends',1003)).value.friends.length,0);assert.equal((await api('/api/friends',1002)).value.friends.some(f=>f.id==='tg:1003'),false);
 // Concurrent requests cannot exceed the per-account friend/request bound.
 for(let i=0;i<55;i++){const id='tg:'+String(2000+i),code=i.toString(16).padStart(20,'0');await db.prepare('INSERT INTO users(id,name,created,timezone,mode) VALUES(?,?,?,?,?)').bind(id,'Friend '+i,Date.now(),'UTC','telegram').run();await db.prepare('INSERT INTO friend_codes(user_id,code) VALUES(?,?)').bind(id,code).run()}
 await Promise.all(Array.from({length:55},(_,i)=>api('/api/friends',1003,{action:'request',code:i.toString(16).padStart(20,'0')})));
 assert.equal((await api('/api/friends',1003)).value.outgoing.length,50);
 console.log('PASS: friend invite stability, mutual consent before balances, account isolation, removal and concurrent bounds; owner-only manual grants, validation, exact-once concurrent/replayed awards and wallet/friends/statistics reconciliation.');
}finally{await mf.dispose()}
