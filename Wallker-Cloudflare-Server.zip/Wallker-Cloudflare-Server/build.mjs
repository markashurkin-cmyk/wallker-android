import {build} from 'esbuild';
import {mkdir, copyFile} from 'node:fs/promises';
await mkdir('public', {recursive:true});
await build({entryPoints:['src/main.tsx'], outdir:'public', entryNames:'app', bundle:true, minify:true, format:'esm', target:'es2022', jsx:'automatic', legalComments:'eof'});
await copyFile('src/index.html', 'public/index.html');
