import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {extname,join} from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {chromium,webkit}=require('playwright');
const root=fileURLToPath(new URL('../public',import.meta.url));
const server=createServer(async(req,res)=>{try{const file=join(root,req.url==='/'?'index.html':req.url.split('?')[0]);res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'})[extname(file)]||'application/octet-stream');res.end(await readFile(file))}catch{res.statusCode=404;res.end()}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await (process.env.WALKER_UI_ENGINE==='webkit'?webkit:chromium).launch({headless:true});
const level={level:11,name:'Божественный Walker',totalSteps:0,nextSteps:null,remainingSteps:0,progress:1,coins:0,availableCoins:0,catalog:[{level:11,name:'Божественный Walker',steps:0,reward:0,description:'Особый уровень',tapReward:1,tapDailyLimit:70000,unlocked:true,claimed:true}]};
const state={serverNow:Date.now(),tapResetAt:Date.now()+3600000,pendingSteps:[],referralMultiplier:1,referralPercent:0,purchaseCoins:0,levels:level,levelCoins:0,grantCoins:0,earnings:[],rewardSettings:{stepReward:.4,stepDailyLimit:4000},tapReward:1,user:{name:'Тест',mode:'beta',timezone:'Europe/Moscow'},today:'2026-10-12',steps:0,balance:15731,todayCoins:0,history:[],devices:[],botConnected:true,isAdmin:true,telegramId:'1001',tapDailyLimit:70000,tapTodayCoins:15731,tapDailyRemaining:54269,tapCoins:15731,tapCount:15731,energy:100,capacity:100,regenMs:1000,bonusCoins:0,campaigns:[],mascot:null};
try{
 for(const width of [320,375,393,430]){
  const page=await browser.newPage({viewport:{width,height:852},isMobile:true,hasTouch:true});
  await page.route('https://telegram.org/**',r=>r.fulfill({contentType:'text/javascript',body:'window.Telegram={WebApp:{initData:"fixture",ready(){},expand(){}}};'}));
  await page.route('**/api/**',r=>r.fulfill({contentType:'application/json',body:JSON.stringify(new URL(r.request().url()).pathname==='/api/bot'?{username:'wallker_wallet_bot',link:'https://t.me/wallker_wallet_bot'}:state)}));
  await page.goto('http://127.0.0.1:'+server.address().port);await page.locator('.wolf-tap').waitFor();console.log('Initial tap geometry',await page.locator('.wolf-tap').evaluate(el=>({buttonWidth:el.getBoundingClientRect().width,stageWidth:el.parentElement.getBoundingClientRect().width,grid:getComputedStyle(el.parentElement).gridTemplateColumns})));await page.screenshot({path:process.env.WALKER_UI_SCREENSHOT||'tap-fixed-393.png',fullPage:true});await page.waitForFunction(()=>document.querySelector('.wolf-tap').getBoundingClientRect().width>100);
  const geometry=await page.locator('.wolf-tap').evaluate(el=>{const r=el.getBoundingClientRect(),p=el.querySelector('.tap-rank-portrait'),s=getComputedStyle(p);return {width:r.width,height:r.height,left:r.left,right:r.right,portraitBorder:s.borderWidth,portraitShadow:s.boxShadow,clip:s.clipPath,overflow:getComputedStyle(el).overflow,scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth}});
  assert.ok(Math.abs(geometry.width-geometry.height)<1);assert.ok(geometry.left>=0&&geometry.right<=width);assert.equal(geometry.portraitBorder,'0px');assert.equal(geometry.portraitShadow,'none');assert.equal(geometry.overflow,'hidden');assert.ok(geometry.scrollWidth<=width);
  await page.locator('.language-select select').selectOption('en');
  assert.deepEqual(await page.locator('.mobile-nav button span').allTextContents(),['Earn','Wallet','Friends','Quests','Listing']);
  assert.equal(await page.locator('.mobile-nav button').count(),5);
  await page.locator('.mobile-nav button').filter({hasText:'Listing'}).click();await page.getByRole('heading',{name:'Next chapter: WC listing'}).waitFor();
  await page.locator('.language-select select').selectOption('ru');await page.getByRole('heading',{name:'Следующая глава — листинг WC'}).waitFor();
  await page.locator('.mobile-nav button').filter({hasText:'Quests'}).click();assert.equal(await page.locator('.daily-cards').count(),0);
  await page.locator('.mobile-nav button').filter({hasText:'Earn'}).click();
  if(width===393)await page.screenshot({path:process.env.WALKER_UI_SCREENSHOT||'tap-fixed-393.png',fullPage:true});
  console.log(JSON.stringify({width,...geometry}));await page.close();
 }
}finally{await browser.close();await new Promise(r=>server.close(r))}
