// Backend foundation for a future independent web store, not a Telegram payment
// bypass. No public route calls this adapter in 0.2.15. Secrets stay server-side.
import {CampaignError} from './campaigns.mjs';
async function call(env,path,data,key,fetcher=fetch){
 if(!env.YOOKASSA_SHOP_ID||!env.YOOKASSA_SECRET_KEY)throw new CampaignError('ЮKassa не подключена',409);
 const r=await fetcher('https://api.yookassa.ru/v3/'+path,{method:data?'POST':'GET',headers:{Authorization:'Basic '+btoa(env.YOOKASSA_SHOP_ID+':'+env.YOOKASSA_SECRET_KEY),...(data?{'Content-Type':'application/json','Idempotence-Key':key}:{})},...(data?{body:JSON.stringify(data)}:{}),signal:AbortSignal.timeout(10000)});
 if(!r.ok)throw new CampaignError('Платёжный сервис временно недоступен',503);return r.json();
}
export async function createCardOrSBP(env,order,fetcher){
 if(!Number.isSafeInteger(order.credits)||order.credits<100||order.credits>10000||!['bank_card','sbp'].includes(order.method)||!/^[a-zA-Z0-9_-]{16,64}$/.test(order.id))throw new CampaignError('Неверный заказ');
 const returnURL=new URL(env.YOOKASSA_RETURN_URL||'');if(returnURL.protocol!=='https:'||returnURL.username||returnURL.password)throw new CampaignError('Настрой адрес самостоятельного магазина',409);
 // The server owns amount and method. No card numbers enter Walker.
 const request={amount:{value:order.credits.toFixed(2),currency:'RUB'},capture:true,payment_method_data:{type:order.method},confirmation:{type:'redirect',return_url:returnURL.href},description:`Walker: ${order.credits} WC-Донатов`,metadata:{order_id:order.id},...(order.receipt?{receipt:order.receipt}:{})};
 return call(env,'payments',request,order.id,fetcher);
}
export async function verifyCardOrSBP(env,paymentID,order,fetcher){
 if(!/^[a-f0-9-]{36}$/.test(paymentID))throw new CampaignError('Неверный платёж');
 // Callback JSON and the return page cannot confirm a payment. Re-read it from
 // the authenticated provider API, then let the store's atomic ledger credit it.
 const p=await call(env,'payments/'+paymentID,null,null,fetcher);
 return p.id===paymentID&&p.status==='succeeded'&&p.paid===true&&p.test===false&&p.amount?.currency==='RUB'&&p.amount.value===order.credits.toFixed(2)&&p.metadata?.order_id===order.id;
}
