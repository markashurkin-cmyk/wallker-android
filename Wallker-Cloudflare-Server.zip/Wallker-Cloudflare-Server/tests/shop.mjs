import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {ensureShop,creditPayment,paymentPrecheck,refundedPayment,createInvoice,activeBoosts,buyProduct} from '../shop.mjs';
import {createCardOrSBP,verifyCardOrSBP} from '../yookassa-adapter.mjs';
import {rewardSettings,saveRewardSettings} from '../rewards.mjs';
const {Miniflare}=await import('miniflare');
const root=fileURLToPath(new URL('../',import.meta.url)),botToken='123:LOCAL_SHOP_TEST';
const persistent=await mkdtemp(root+'tests/shop-state-');
const options={modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:{DB:'shop-tests'},d1Persist:persistent,bindings:{TELEGRAM_BOT_TOKEN:botToken,ADMIN_TELEGRAM_ID:'1001',TELEGRAM_WEBHOOK_SECRET:'test-secret'}};
let mf=new Miniflare(options);
function auth(id){const f=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Волкер'})});const secret=createHmac('sha256','WebAppData').update(botToken).digest();const check=[...f].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');f.set('hash',createHmac('sha256',secret).update(check).digest('hex'));return f.toString()}
async function api(path,id=1002,data,secret){const r=await mf.dispatchFetch('http://localhost'+path,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id)}:{}),...(secret?{'X-Telegram-Bot-Api-Secret-Token':secret}:{})},...(data!==undefined?{body:JSON.stringify(data)}:{})});return {status:r.status,value:await r.json()}}
try{
 let db=await mf.getD1Database('DB');for(const s of (await readFile(root+'schema.sql','utf8')).replace(/^--.*$/gm,'').split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 for(const id of [1001,1002,1003])assert.equal((await api('/api/wallet',id)).status,200);
 assert.equal((await api('/api/shop',null)).status,401);
 assert.equal((await api('/api/shop/invoice',1002,{credits:100,requestId:'topup_disabled_test'})).status,409);
 assert.equal((await api('/api/shop/buy',1002,{product:'tap-7',requestId:'purchase_empty_test'})).status,409);
 await ensureShop(db);
 const settings=await rewardSettings(db),custom={...settings,tapReward:.23,tapDailyLimit:1357,energyCapacity:120,stepDailyLimit:4312};
 await saveRewardSettings(db,custom);
 assert.equal((await rewardSettings(db)).tapDailyLimit,1357);
 let called=0;
 await assert.rejects(()=>createInvoice(db,'tg:1002',{credits:100,requestId:'topup_terms_test'}, {STARS_PAYMENTS_ENABLED:'true',TELEGRAM_BOT_TOKEN:botToken},async()=>{called++}));assert.equal(called,0);
 const invoice=await createInvoice(db,'tg:1002',{credits:300,requestId:'topup_valid_test01',termsAccepted:true},{STARS_PAYMENTS_ENABLED:'true',TELEGRAM_BOT_TOKEN:botToken},async(env,method,payload)=>{assert.equal(method,'createInvoiceLink');assert.equal(payload.currency,'XTR');assert.equal(payload.prices[0].amount,300);called++;return 'https://t.me/invoice/test'});assert.ok(invoice.invoice);
 const order=await db.prepare('SELECT * FROM shop_orders WHERE user_id=?').bind('tg:1002').first();
 const payment={invoice_payload:order.id,currency:'XTR',total_amount:300,telegram_payment_charge_id:'LOCAL_CHARGE_1'};
 assert.equal(await paymentPrecheck(db,{invoice_payload:order.id,currency:'XTR',total_amount:300,from:{id:1003}},{STARS_PAYMENTS_ENABLED:'true',TELEGRAM_BOT_TOKEN:botToken}),false);
 assert.equal(await paymentPrecheck(db,{invoice_payload:order.id,currency:'RUB',total_amount:300,from:{id:1002}},{STARS_PAYMENTS_ENABLED:'true',TELEGRAM_BOT_TOKEN:botToken}),false);
 assert.equal(await paymentPrecheck(db,{...payment,id:'precheck-1',from:{id:1002}},{STARS_PAYMENTS_ENABLED:'true',TELEGRAM_BOT_TOKEN:botToken}),true);
 assert.equal(await paymentPrecheck(db,{...payment,id:'precheck-2',from:{id:1002}},{STARS_PAYMENTS_ENABLED:'true',TELEGRAM_BOT_TOKEN:botToken}),false);
 await assert.rejects(()=>creditPayment(db,1003,payment));
 await assert.rejects(()=>creditPayment(db,1002,{...payment,total_amount:1}));
 // Signed server receipt, never a client callback or pre-check, credits money.
 assert.equal((await api('/api/telegram/webhook',null,{message:{chat:{id:1002,type:'private'},from:{id:1002},successful_payment:payment}},'wrong')).status,401);
 assert.equal((await api('/api/telegram/webhook',null,{message:{chat:{id:1002,type:'private'},from:{id:1002},successful_payment:payment}},'test-secret')).status,200);
 await Promise.all(Array.from({length:5},()=>creditPayment(db,1002,payment)));
 assert.equal((await api('/api/shop')).value.credits,300);
 const payload={product:'tap-7',requestId:'buy_tap_once_test_1'};
 const buys=await Promise.all(Array.from({length:5},()=>api('/api/shop/buy',1002,payload)));
 assert.ok(buys.every(r=>r.status===200));assert.equal((await api('/api/shop')).value.credits,201);
 let boost=(await activeBoosts(db,'tg:1002'))[0],expires=boost.expires;
 assert.equal((await api('/api/wallet')).value.tapReward,.2875);
 assert.equal((await api('/api/shop/buy',1002,{...payload,product:'cap-7'})).status,409);
 assert.equal((await api('/api/shop')).value.credits,201);
 await api('/api/shop/buy',1002,{product:'tap-7',requestId:'buy_tap_extend_test'});assert.equal((await activeBoosts(db,'tg:1002'))[0].expires,expires+7*86400000);
 assert.equal((await activeBoosts(db,'tg:1002',expires+30*86400000)).length,0);
 const coins=await api('/api/shop/buy',1002,{product:'coins-1000',requestId:'buy_coins_once_test'});assert.equal(coins.status,200);assert.equal(coins.value.credits,3);
 const wallet=(await api('/api/wallet')).value;assert.equal(wallet.purchaseCoins,1000);assert.equal(wallet.balance,1000);assert.equal(wallet.earnings.reduce((n,d)=>n+d.coins,0),1000);
 assert.equal((await api('/api/admin/stats',1001)).value.totals.purchaseCoins,1000);
 assert.equal((await api('/api/admin/stats/users',1001)).value.users.find(x=>x.id==='tg:1002').balance,1000);
 assert.equal((await api('/api/admin/export?dataset=users',1003)).status,403);
 assert.equal((await api('/api/admin/export?dataset=users',null)).status,401);
 for(const type of ['users','errors','activity','steps','tapDays','levelAwards','grants','purchases','orders','donations','quests']){const r=await api('/api/admin/export?dataset='+type,1001);assert.equal(r.status,200,type);assert.ok(!JSON.stringify(r.value).includes('device_hash'));}
 await refundedPayment(db,1002,payment);await refundedPayment(db,1002,payment);assert.equal((await api('/api/shop')).value.credits,-297);
 assert.equal((await api('/api/shop/buy',1002,{product:'cap-7',requestId:'buy_after_refund_1'})).status,409);
 // New runtime, same database: deployment must not reset global/rank settings,
 // paid coins, credits, boost expiry or award receipts.
 await mf.dispose();mf=new Miniflare(options);db=await mf.getD1Database('DB');
 const persisted=await rewardSettings(db);assert.equal(persisted.tapDailyLimit,1357);assert.equal(persisted.stepDailyLimit,4312);assert.equal(persisted.tapReward,.23);
 assert.equal((await api('/api/wallet')).value.purchaseCoins,0);assert.equal((await api('/api/shop')).value.credits,-297);
 await db.prepare('DELETE FROM reward_settings').run();assert.equal((await rewardSettings(db)).tapDailyLimit,1357);
 const history=(await api('/api/admin/rewards',1001)).value.history;assert.equal(history.length,2);
 const restored=await api('/api/admin/rewards',1001,{action:'restore',targetRevision:1,revision:persisted.revision});assert.equal(restored.status,200);assert.equal(restored.value.settings.tapDailyLimit,1000);
 const merchant={YOOKASSA_SHOP_ID:'fake-shop',YOOKASSA_SECRET_KEY:'fake-local-secret',YOOKASSA_RETURN_URL:'https://store.example/return'},external={id:'local_external_order_01',credits:100,method:'sbp'},paymentID='01234567-1234-1234-1234-012345678901';
 for(const method of ['bank_card','sbp'])await createCardOrSBP(merchant,{...external,method},async(url,req)=>{const b=JSON.parse(req.body);assert.equal(b.amount.value,'100.00');assert.equal(b.amount.currency,'RUB');assert.equal(b.payment_method_data.type,method);assert.equal(req.headers['Idempotence-Key'],external.id);return Response.json({id:paymentID,status:'pending'})});
 const confirmed={id:paymentID,status:'succeeded',paid:true,test:false,amount:{value:'100.00',currency:'RUB'},metadata:{order_id:external.id}};
 assert.equal(await verifyCardOrSBP(merchant,paymentID,external,async()=>Response.json(confirmed)),true);
 for(const bad of [{...confirmed,test:true},{...confirmed,status:'pending'},{...confirmed,amount:{value:'1.00',currency:'RUB'}},{...confirmed,metadata:{order_id:'wrong'}}])assert.equal(await verifyCardOrSBP(merchant,paymentID,external,async()=>Response.json(bad)),false);
 console.log('PASS: permanent settings across runtime restart, version recovery; owner-only exports; signed payment receipts, exact amount and owner checks, replay and refund protection; concurrent purchases, expiry extension, rounded boosts, gameplay ledger and analytics.');
}finally{await mf.dispose();await rm(persistent,{recursive:true,force:true})}
