import {build} from 'esbuild';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
export async function checkBetaAdmin(browser,base){
 const root=fileURLToPath(new URL('../',import.meta.url));
 const result=await build({stdin:{contents:`import {createRoot} from 'react-dom/client';import {BetaAdmin} from './src/beta-admin';import {LanguageProvider,LanguageSelect} from './src/language';createRoot(document.getElementById('root')).render(<LanguageProvider><LanguageSelect/><BetaAdmin/></LanguageProvider>);`,resolveDir:root,loader:'tsx'},bundle:true,write:false,format:'esm',jsx:'automatic',jsxImportSource:'./localized',plugins:[{name:'beta-test-jsx',setup(b){b.onResolve({filter:/^\.\/localized\/jsx-runtime$/},()=>({path:root+'src/localized/jsx-runtime.tsx'}))}}]});
 for(const width of [320,393]){
  const page=await browser.newPage({viewport:{width,height:852},isMobile:true,hasTouch:true});let rows=[{user_id:'tg:2002',name:'Beta Tester',username:'beta_tester',status:'pending',requested:Date.now(),updated:Date.now(),revision:1}],writes=[];
  await page.route('**/beta-owner-fixture',r=>r.fulfill({contentType:'text/html',body:'<html><head><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="/app.css"></head><body><div id="root" style="max-width:600px;margin:auto;padding:12px"></div><script type="module" src="/beta-owner-fixture.js"></script></body></html>'}));
  await page.route('**/beta-owner-fixture.js',r=>r.fulfill({contentType:'text/javascript',body:result.outputFiles[0].text}));
  await page.route('**/api/admin/beta**',r=>{
   const url=new URL(r.request().url());if(r.request().method()==='POST'){const data=r.request().postDataJSON();writes.push(data);let row=rows.find(v=>v.user_id==='tg:'+data.userId.replace(/^tg:/,''));if(!row){row={user_id:'tg:'+data.userId,name:'Manual Tester',username:'',status:'none',requested:null,updated:Date.now(),revision:0};rows.push(row)}assert.equal(data.revision,row.revision);row.status={approve:'approved',reject:'rejected',revoke:'revoked'}[data.action];row.revision++;return r.fulfill({contentType:'application/json',body:'{"ok":true}'})}
   const status=url.searchParams.get('status')||'pending',q=url.searchParams.get('q')||'',lookup=q?rows.filter(v=>v.user_id==='tg:'+q.replace(/^tg:/,'')||v.username===q.replace(/^@/,'')):[];
   return r.fulfill({contentType:'application/json',body:JSON.stringify({closed:true,counts:Object.fromEntries(['pending','approved','rejected','revoked'].map(s=>[s,rows.filter(v=>v.status===s).length])),rows:rows.filter(v=>(status==='all'||v.status===status)&&(!q||lookup.includes(v))),hasNext:false,page:1,lookup})});
  });
  await page.goto(base+'/beta-owner-fixture');await page.locator('.language-select select').selectOption('ru');await page.locator('.beta-admin summary').click();await page.getByRole('button',{name:'Одобрить',exact:true}).click();await page.getByText('Бета-доступ выдан. Пользователь может открыть приложение.',{exact:true}).waitFor();assert.equal(writes[0].userId,'tg:2002');
  await page.getByPlaceholder('Telegram ID или @username заявителя',{exact:true}).fill('3003');await page.getByRole('button',{name:'Выдать бета-доступ',exact:true}).click();await page.getByPlaceholder('Telegram ID или @username заявителя',{exact:true}).waitFor();await page.waitForFunction(()=>document.querySelector('.beta-admin input')?.value==='');assert.equal(writes.at(-1).userId,'3003');
  await page.getByLabel('Статус заявок',{exact:true}).selectOption('approved');await page.locator('.beta-admin-person').filter({hasText:'3003'}).getByRole('button',{name:'Отозвать доступ',exact:true}).click();await page.getByText('Бета-доступ отозван.',{exact:true}).waitFor();assert.equal(writes.at(-1).action,'revoke');
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.screenshot({path:'beta-developer-'+width+'-'+(process.env.WALKER_UI_ENGINE||'chromium')+'.png',fullPage:true});
  await page.locator('.language-select select').selectOption('en');assert.ok(!/[а-яё]/i.test(await page.locator('.beta-admin').innerText()));await page.getByRole('button',{name:'Grant beta access',exact:true}).waitFor();await page.close();
 }
 console.log('PASS: beta owner UI at 320/393px, RU/EN, approval, manual grant, revision forwarding, revocation and no horizontal overflow.');
}
