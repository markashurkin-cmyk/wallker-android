// Fixtures model previously reviewed/legacy activity, never a production bypass.
import {requestDB} from '../runtime.mjs';
import {settleReferrals} from '../referrals.mjs';
export async function qualifiedFixture(db,id,today){
 const now=Date.now();await db.prepare('UPDATE referrals SET created=? WHERE invitee=?').bind(now-4*86400000,id).run();
 await db.prepare('UPDATE users SET created=? WHERE id=?').bind(now-5*86400000,id).run();
 for(let i=0;i<3;i++){const day=new Date(Date.parse(today+'T12:00:00Z')-i*86400000).toISOString().slice(0,10);await db.prepare("INSERT OR REPLACE INTO step_reports(user_id,day,steps,approved_steps,state,reason,received,reviewed) VALUES(?,?,5000,5000,'approved','test-reviewed',?,?)").bind(id,day,now,now).run();}
 await settleReferrals(requestDB(db),id);
}
export async function trustedFixture(db,id,steps){await db.prepare('INSERT INTO trusted_step_totals(user_id,steps) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET steps=excluded.steps').bind(id,steps).run()}
