# Walker Wallet — Growth Engine 0.2.27

Version 0.2.27 refreshes the pack leaderboard, Russian interface copy and quest hub. The previous 0.2.25 update is deployed; this candidate follows the same GitHub and Cloudflare deployment path after regression checks.

Quests now show published social, contest and partner campaigns only, grouped into Walker, Partners and Completed. The built-in walking checklist is removed. Legacy step campaign rows and earned rewards remain stored; step campaigns are hidden from players, new publication and new claims are rejected. Walking reward rates, rank progression, settings and ledgers are unchanged.

Russian labels include pack achievements, creator analytics, seasonal state, owner controls and generated share cards. Brand names, account content, codes and WC remain intact. Bottom navigation remains Earn, Wallet, Friends, Quests and Listing.

## Decisions and economy

New-account first open qualifies the immutable inviter. No 3 × 5,000-step condition and no fixed 500 WC referral award. Self-referrals, later attribution of existing accounts, inviter reassignment and competing first-open requests are rejected/deduplicated at the database boundary.

Total Invited drives the permanent multiplier; Active Pack drives quality rankings and Creator eligibility. Initial Active criteria: a linked device plus positive server-accepted step totals on two distinct profile calendar dates. Those dates may arrive in one upload. This is evidence of accepted synchronization, not hardware attestation. Old inactive invitees do not remove the Total bonus. Explicit owner restrictions affect quality results without rewriting WC history.

The curve is linear between these points, computed in integer millionths:

| Total | Multiplier |
| ---: | ---: |
| 0 | 1.00 |
| 100 | 2.00 |
| 250 | 2.15 |
| 500 | 2.40 |
| 1,000 | 2.90 |
| 2,500 | 3.65 |
| 5,000 | 4.40 |
| 10,000 | 5.40 |
| 25,000 | 6.90 |
| 50,000 | 8.40 |
| 100,000 | 10.40 |

Above 100,000, the approved final slope continues: M(n)=10.4+(n−100000)×0.00004. Thus 1,000,000 → ×46.4. For adjacent points (a,A),(b,B), M(n)=A+(n−a)×(B−A)/(b−a). Default intervals all have exact integer-millionth slopes. Example 147 → ×2.047.

On 4,000 eligible base WC per day: 0 referrals → 4,000; 100 → 8,000; 1,000 → 11,600; 10,000 → 21,600; 100,000 → 41,600; 1M → 185,600. This illustrates emission, not money or token allocation. Existing step/tap daily WC caps also follow the multiplier, so the higher rate is not silently neutralized by the old cap. Energy and natural level progress do not multiply.

Server whitelist: steps, taps, levels and approved quest kinds steps/telegram/tiktok/partner/contest. Bought WC, Shop WC, payment receipts, refunds, grants/corrections and disabled daily-game rewards receive ×1. No old entries are recomputed. Settings and SQL owner exports use one stored curve. Owner changes require a revision and reason, with immutable settings history.

## Migration and preserved data

Migration 22 is additive. Version 0.2.25 makes the legacy bilingual column upgrade safe when independent cold isolates race; only a verified duplicate-column race is tolerated, while storage failures still propagate and can be retried. See ROLLOUT_0.2.25.md for the synthetic preservation/export/restore rehearsal and the remaining real-snapshot prerequisite. See growth-schema.mjs and runtime.mjs. It creates Growth-only counters, onboarding receipts, distinct activity dates, first-active receipts, milestone entitlements, Creator codes/cache, trust/audit history, seasons/results/claims, Founder sequence, ranking versions/results and campaign events. Existing balances, ledgers, devices, clans, quests, reward_settings and payment identifiers are preserved. No production database is recreated.

Legacy counters are initialized lazily once, or through resumable batches of up to 80 accounts. Old accepted activity is marked legacy and excluded from new seasonal/7-day growth when no new accepted synchronization exists. First-active events and milestone/season claims have unique keys. Founder numbers use a database sequence, granted at wallet open during the one-time Founder season [start,end); gaps are valid and numbers are never reused. Published season titles/dates and criteria are frozen; draft criteria are snapshotted when published. Finished Creator and ordinary race results are immutable on retries.

Initial Creator requirement: 500 Total + 100 Active (owner configurable). A readable 5–24-character code is normalized, unique, immutable and blocks reserved values/prefixes. Creator code and stable friend code share the attribution path. D7/D30 are exact UTC cohort-day retention on mature, post-instrumentation accounts; immature denominators display unavailable, not zero retention. Cache coverage and timestamps are exposed.

## UI and boundaries

MY PACK lives in Friends; Pre-Launch Profile lives in Listing. Bottom navigation remains Earn / Wallet / Friends / Quests / Listing. New screens support RU/EN, milestones, personal invite/copy/Telegram sharing, five locally generated share PNG variants, four rankings, TOP 10/100/1000, own position, Creator progress/code/retention, season history and Founder status. The achievement gallery shows the server-configured catalog, earned dates and remaining invitations for locked milestones. Recruiter and Pack Builder retain the original full-body mascot; eight new transparent full-body outfits progress from Alpha to Walker Legend. Stable asset keys preserve existing earned entitlements and owner custom keys have a safe local fallback. Share cards use the highest earned outfit, contained without stretching. Art is language-neutral; interface copy supports RU/EN, with reduced-motion support for the Pro frame. See assets/growth/ART_SOURCES.md.

Owner controls are folded into the existing developer screen: versioned criteria/curve/milestones, seasons, one-time Founder Season, diagnostics, review states and audit. The server enforces ADMIN_TELEGRAM_ID. Preview owner forms use sample data and cannot persist changes.

## Quality review and security

NORMAL / PENDING_REVIEW / VERIFIED / RESTRICTED are separate from Total attribution. A burst of >=100 registrations/minute creates an audited review marker, never an automatic ban or WC debit. Owner diagnostics show account age, device presence/rotation, accepted step days, Active conversion, cohort retention and registration velocity. Scores are review signals, not proof of fraud. Shared phones, emulators, rooted devices and physical walking are not attested by this implementation. Production still needs adversarial device testing before public scale.

Campaign analytics has a foundation endpoint and owner readout. Client impression/open/start events are explicitly unverified and limited to one per account/type/UTC day; server-approved completions are separate. Automatic real-money Creator payouts and a cash ledger are intentionally not enabled. Full campaign instrumentation/advertiser attribution and payout accounting are future work.

## D1 execution and capacity

Tap/wallet paths use indexed counters and request-local memoization. They do not rank all users or scan all of an inviter's historical referrals after counter initialization. Backfill is a bounded bulk batch, not hundreds of network queries. Ranking snapshots run at most every 15 minutes in cron/owner maintenance; reads paginate 50 rows and do one independent indexed own-position lookup, including positions beyond TOP 1000. Clan score is summed Active Pack of current members, never a shared spendable balance.

Snapshots retain two recent versions plus UTC daily anchors for 14 days, reducing roughly 1,344 full snapshots to ~16. Creator analytics refreshes up to 20 stale creators per tick using one aggregate query and one write batch; pending/as-of state is visible and this has a finite queue capacity.

Measured local warm D1 request counts, including telemetry: wallet 33, positive tap 25, exhausted tap 20. A synthetic 1,005+ participant ranking test covers paging and own position beyond TOP 1000. A separate 100,000-account synthetic local test now covers 89,850 qualified/active invitees, 150 eligible Creators, 100 clans and an active Creator season; see LOAD_TEST_0.2.23.md. This does not measure 100,000 simultaneous connections or remote D1 throughput. For R positive rows across all metrics, each refresh writes roughly R rank rows plus indexes; 96 refreshes/day means ~96R row inserts/day, plus pruning. At R=100,000 that is ~9.6M inserts/day before index amplification. Production needs a measured D1 plan/budget, lower refresh cadence or incremental/partitioned ranking work before that scale. No claim of unlimited D1 capacity is made.

## Validation and rollout

`npm test` runs legacy regressions, Growth server tests and concurrent signed HTTP waves on disposable local D1. See CONCURRENCY_0.2.24.md; this verifies accounting races, not remote capacity. `node tests/performance.mjs` enforces warm request budgets. `npm run test:load` reproduces the 100,000-account local benchmark, with row-read guards against per-invitee season eligibility rescans. The default `npm test` includes this benchmark and 42 independent seasonal boundary/quality cases. `npm run build` restores integrity-checked existing assets. `node tests/ui.mjs` checks RU/EN, 320/375/393/430 widths, circle geometry, five navigation items, no horizontal overflow, Creator view and share PNG download in Chromium and WebKit CI.

Preview config uses only walker-wallet-preview D1. BOT_AUTO_SETUP and STARS_PAYMENTS_ENABLED are false; GROWTH_PREVIEW blocks real API calls except health and disables cron bot/payment work even if a remote binding is mistakenly present. `/growth-preview.html` is a static, clearly marked sample-data UI; it has no real-account API bypass and no production credentials. Backend integration tests use disposable local D1 and fake signatures/receipts.

Before production: final-commit CI green; inspect mobile screenshots and preview; backup production D1/settings, verify migration on an authorized sanitized snapshot and cost limits; then separate explicit production deploy and live `/api/health` version verification. This branch does not merge or publish production.
