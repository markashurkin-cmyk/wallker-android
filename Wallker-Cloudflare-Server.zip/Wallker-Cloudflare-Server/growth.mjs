import {seasonScoreSource,finalizeSeasons} from './growth-seasons.mjs';
import {GrowthError,growthDefaults,growthSettings,totalInvited,multiplier,validateGrowth} from './growth-config.mjs';
import {botUsername} from './bot-config.mjs';
import {invalidate} from './runtime.mjs';
const DAY=86400000,uid=x=>typeof x==='string'&&/^tg:[1-9]\d*$/.test(x);
export const utcDay=t=>new Date(t).toISOString().slice(0,10);
export const seasonState=(s,now)=>s.status==='scheduled'&&now>=s.ends?'finished':s.status==='scheduled'&&now>=s.starts?'active':s.status==='active'&&now>=s.ends?'finished':s.status;
export async function qualifyActive(db,id,now=Date.now()){
 const config=await growthSettings(db),ids=Array.isArray(id)?id:[id];if(!ids.length)return;
 await db.prepare(`INSERT OR IGNORE INTO growth_activations(invitee,inviter,activated,legacy,criteria_revision)
 SELECT q.invitee,q.inviter,?,CASE WHEN (SELECT MAX(updated) FROM days WHERE user_id=q.invitee AND steps>0)<(SELECT started FROM growth_meta WHERE id=1) THEN 1 ELSE 0 END,?
 FROM referral_qualified q WHERE q.invitee IN (${ids.map(()=>'?').join(',')})
 AND EXISTS(SELECT 1 FROM pairings p WHERE p.user_id=q.invitee AND p.device_hash IS NOT NULL)
 AND (SELECT COUNT(*) FROM days d WHERE d.user_id=q.invitee AND d.steps>0)>=?
 AND NOT EXISTS(SELECT 1 FROM abuse_controls a WHERE a.user_id=q.invitee AND a.frozen=1) AND NOT EXISTS(SELECT 1 FROM growth_trust t WHERE t.user_id=q.invitee AND t.state='RESTRICTED')`)
 .bind(now,config.revision,...ids,config.activeDays).run();
}
export async function growthOpen(db,id,now=Date.now()){
 await db.prepare('INSERT INTO growth_activity(user_id,day,first_seen,last_seen) VALUES(?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET last_seen=MAX(last_seen,excluded.last_seen)').bind(id,utcDay(now),now,now).run();
 await db.prepare(`INSERT OR IGNORE INTO growth_founders(user_id,season_id,created) SELECT ?,id,? FROM growth_seasons WHERE kind='founder' AND status IN ('active','scheduled') AND starts<=? AND ends>?`).bind(id,now,now,now).run();
}
export async function milestones(db,id,total,now=Date.now()){
 const config=await growthSettings(db);
 const eligible=config.milestones.filter(m=>total>=m.count);
 if(eligible.length)await db.batch(eligible.map(m=>db.prepare('INSERT OR IGNORE INTO growth_milestones(user_id,milestone,title,asset,created) VALUES(?,?,?,?,?)').bind(id,m.count,m.title,m.asset,now)));
 return (await db.prepare('SELECT milestone,title,asset,created FROM growth_milestones WHERE user_id=? ORDER BY milestone').bind(id).all()).results;
}
export async function creatorEligibility(db,id,config){
 const total=await totalInvited(db,id),active=(await db.prepare('SELECT total FROM growth_active_totals WHERE user_id=?').bind(id).first())?.total||0;
 const trust=(await db.prepare('SELECT state FROM growth_trust WHERE user_id=?').bind(id).first())?.state||'NORMAL';
 return {eligible:total>=config.creatorTotal&&active>=config.creatorActive&&trust!=='RESTRICTED',total,active,trust};
}
export async function creatorCode(db,id,value,now=Date.now()){
 if(typeof value!=='string')throw new GrowthError('Invalid Creator Code');
 const code=value.trim().toUpperCase();
 if(!/^[A-Z][A-Z0-9_]{4,23}$/.test(code)||/^(ADMIN|SUPPORT|OFFICIAL|WALKER|TELEGRAM|REF_|C_|API|BOT|NULL|OWNER)$/.test(code)||/^(REF_|C_|ADMIN_|OFFICIAL_|SUPPORT_|OWNER_|TELEGRAM_)/.test(code))throw new GrowthError('Choose a different Creator Code');
 const config=await growthSettings(db);if(!(await creatorEligibility(db,id,config)).eligible)throw new GrowthError('Creator requirements are not met',403);
 const old=await db.prepare('SELECT code FROM growth_creator_codes WHERE user_id=?').bind(id).first();
 if(old){if(old.code===code)return {code};throw new GrowthError('Your Creator Code is permanent',409)}
 await db.prepare(`INSERT OR IGNORE INTO growth_creator_codes(user_id,code,created) VALUES(?,?,?)`).bind(id,code,now).run();
 const saved=await db.prepare('SELECT code FROM growth_creator_codes WHERE user_id=?').bind(id).first();
 if(saved?.code!==code)throw new GrowthError('Creator Code is already taken',409);
 await audit(db,id,'creator-code',id,'',code,'Creator selected code',now);return {code};
}
export async function packSnapshot(db,id,env,now=Date.now()){
 const config=await growthSettings(db),eligibility=await creatorEligibility(db,id,config);
 const code=await db.prepare('SELECT code FROM friend_codes WHERE user_id=?').bind(id).first();
 const creator=await db.prepare('SELECT code FROM growth_creator_codes WHERE user_id=?').bind(id).first();
 const badges=await milestones(db,id,eligibility.total,now),next=config.milestones.find(m=>m.count>eligibility.total)||null;
 const founder=await db.prepare('SELECT number,season_id,created FROM growth_founders WHERE user_id=?').bind(id).first();
 const seasons=(await db.prepare("SELECT id,kind,title_ru,title_en,status,starts,ends FROM growth_seasons WHERE status!='draft' ORDER BY starts DESC LIMIT 20").all()).results.map(s=>({...s,status:seasonState(s,now)}));
 const history=(await db.prepare('SELECT r.*,s.title_ru,s.title_en,c.badge FROM growth_season_results r JOIN growth_seasons s ON s.id=r.season_id LEFT JOIN growth_season_claims c ON c.season_id=r.season_id AND c.user_id=r.user_id WHERE r.user_id=? ORDER BY s.ends DESC LIMIT 30').bind(id).all()).results;
 const username=botUsername(env);
 return {...eligibility,multiplier:multiplier(eligibility.total,config),milestones:badges,catalog:config.milestones,next,remaining:next?next.count-eligibility.total:0,
 activeCriteria:{days:config.activeDays},creatorCode:creator?.code||null,creatorThresholds:{total:config.creatorTotal,active:config.creatorActive},
 link:`https://t.me/${username}?start=${creator?'c_'+creator.code:'ref_'+code?.code}`,founder,seasons,history,
 rank:await leaderboard(db,id,'global',null,1,now),asOf:now,activityMeaning:'server-accepted-not-attested'};
}
export async function creatorDashboard(db,id,now=Date.now()){
 const config=await growthSettings(db),eligible=await creatorEligibility(db,id,config);if(!eligible.eligible)throw new GrowthError('Creator requirements are not met',403);
 const cached=await db.prepare('SELECT value,updated FROM growth_creator_cache WHERE user_id=?').bind(id).first();
 if(!cached)return {...eligible,pending:true,asOf:null};
 return {...eligible,...JSON.parse(cached.value),asOf:cached.updated};
}
export async function refreshCreatorAnalytics(db,now=Date.now()){
 const config=await growthSettings(db);
 const accounts=(await db.prepare('SELECT g.user_id AS id,g.total,a.total AS active FROM growth_totals g JOIN growth_active_totals a ON a.user_id=g.user_id LEFT JOIN growth_creator_cache c ON c.user_id=g.user_id WHERE g.total>=? AND a.total>=? AND (c.updated IS NULL OR c.updated<?) ORDER BY COALESCE(c.updated,0),g.user_id LIMIT 20').bind(config.creatorTotal,config.creatorActive,now-3600000).all()).results;
 if(!accounts.length)return;
 const coverage=(await db.prepare('SELECT started FROM growth_meta WHERE id=1').first()).started;
 // One bounded aggregate for up to 20 creators. No per-creator round trips.
 const rows=(await db.prepare(`SELECT q.inviter,
 SUM(CASE WHEN u.created<=? THEN 1 ELSE 0 END) AS d7eligible,
 SUM(CASE WHEN u.created<=? AND a7.user_id IS NOT NULL THEN 1 ELSE 0 END) AS d7retained,
 SUM(CASE WHEN u.created<=? THEN 1 ELSE 0 END) AS d30eligible,
 SUM(CASE WHEN u.created<=? AND a30.user_id IS NOT NULL THEN 1 ELSE 0 END) AS d30retained
 FROM referral_qualified q JOIN users u ON u.id=q.invitee
 LEFT JOIN growth_activity a7 ON a7.user_id=q.invitee AND a7.day=date(u.created/1000,'unixepoch','+7 days')
 LEFT JOIN growth_activity a30 ON a30.user_id=q.invitee AND a30.day=date(u.created/1000,'unixepoch','+30 days')
 WHERE q.inviter IN (${accounts.map(()=>'?').join(',')}) AND u.created>=? GROUP BY q.inviter`)
 .bind(now-7*DAY,now-7*DAY,now-30*DAY,now-30*DAY,...accounts.map(a=>a.id),coverage).all()).results;
 const stats=new Map(rows.map(r=>[r.inviter,r]));
 await db.batch(accounts.map(account=>{
  const r=stats.get(account.id),cohort=age=>{const eligible=r?.['d'+age+'eligible']||0,retained=r?.['d'+age+'retained']||0;return {eligible,retained,rate:eligible?retained/eligible:null};};
  const value={d7:cohort(7),d30:cohort(30),conversion:account.total?account.active/account.total:null,coverageStart:coverage,cohortTimezone:'UTC'};
  return db.prepare('INSERT INTO growth_creator_cache(user_id,value,updated) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET value=excluded.value,updated=excluded.updated').bind(account.id,JSON.stringify(value),now);
 }));
}
export async function profileSnapshot(db,id,now=Date.now()){
 const row=await db.prepare(`SELECT u.created,COALESCE((SELECT SUM(steps) FROM days WHERE user_id=u.id),0) AS steps,(SELECT COUNT(*) FROM days WHERE user_id=u.id AND steps>0) AS walkingDays,(SELECT COUNT(*) FROM growth_activity WHERE user_id=u.id) AS activeDays,(SELECT COUNT(*) FROM campaign_claims WHERE user_id=u.id AND state='approved' AND campaign_id NOT LIKE 'referral:%') AS quests,(SELECT c.name FROM clan_members m JOIN clans c ON c.id=m.clan_id WHERE m.user_id=u.id AND c.archived=0) AS clan FROM users u WHERE u.id=?`).bind(id).first();
 return {...row,ageDays:Math.max(0,Math.floor((now-row.created)/DAY)),coverageStart:(await db.prepare('SELECT started FROM growth_meta WHERE id=1').first()).started};
}
function rankingSource(metric,now,config){
 const allowed=`NOT EXISTS(SELECT 1 FROM growth_trust t WHERE t.user_id=p.user_id AND t.state='RESTRICTED') AND NOT EXISTS(SELECT 1 FROM abuse_controls b WHERE b.user_id=p.user_id AND b.frozen=1)`;
 if(metric==='global')return {sql:`SELECT p.user_id AS subject,p.total AS score FROM growth_active_totals p WHERE ${allowed}`,args:[]};
 if(metric==='fastest')return {sql:`SELECT a.inviter AS subject,COUNT(*) AS score FROM growth_activations a WHERE a.legacy=0 AND a.activated>=? AND a.activated<=? AND NOT EXISTS(SELECT 1 FROM growth_trust t WHERE t.user_id=a.inviter AND t.state='RESTRICTED') AND NOT EXISTS(SELECT 1 FROM growth_trust t WHERE t.user_id=a.invitee AND t.state='RESTRICTED') AND NOT EXISTS(SELECT 1 FROM abuse_controls b WHERE b.user_id IN (a.inviter,a.invitee) AND b.frozen=1) GROUP BY a.inviter`,args:[now-7*DAY,now]};
 if(metric==='creator')return {sql:`SELECT p.user_id AS subject,p.total AS score FROM growth_active_totals p JOIN growth_totals g ON g.user_id=p.user_id WHERE p.total>=? AND g.total>=? AND ${allowed}`,args:[config.creatorActive,config.creatorTotal]};
 if(metric==='clan')return {sql:`SELECT m.clan_id AS subject,SUM(p.total) AS score FROM growth_active_totals p JOIN clan_members m ON m.user_id=p.user_id JOIN clans c ON c.id=m.clan_id WHERE c.archived=0 AND ${allowed} GROUP BY m.clan_id`,args:[]};
 throw new GrowthError('Unknown leaderboard');
}
export async function refreshRanks(db,now=Date.now()){
 const lease=await db.prepare('UPDATE growth_meta SET lease=? WHERE id=1 AND lease<=? AND ranked_at<=? RETURNING id').bind(now+120000,now,now-15*60000).first();if(!lease)return;
 const config=await growthSettings(db),version=crypto.randomUUID(),statements=[db.prepare('INSERT INTO growth_rank_versions(id,created) VALUES(?,?)').bind(version,now)];
 for(const metric of ['global','fastest','creator','clan']){
  const source=rankingSource(metric,now,config);
  statements.push(db.prepare(`INSERT INTO growth_ranks(version,metric,subject,score,rank) SELECT ?,?,subject,score,RANK() OVER(ORDER BY score DESC) FROM (${source.sql}) WHERE score>0`).bind(version,metric,...source.args));
 }
 const seasons=(await db.prepare("SELECT * FROM growth_seasons WHERE status IN ('scheduled','active') AND starts<=? AND ends>? LIMIT 10").bind(now,now).all()).results;
 for(const season of seasons)for(const creator of [false,true]){const source=seasonScoreSource(season,now,config,creator);statements.push(db.prepare(`INSERT INTO growth_ranks(version,metric,subject,score,rank) SELECT ?,?,subject,score,RANK() OVER(ORDER BY score DESC) FROM (${source.sql})`).bind(version,'season:'+season.id+(creator?':creator':''),...source.args));}
 statements.push(db.prepare('UPDATE growth_rank_versions SET ready=1 WHERE id=?').bind(version),db.prepare('UPDATE growth_meta SET ranked_at=?,lease=0 WHERE id=1').bind(now));
 // D1 batch is transactional; all four views switch together after the writes.
 await db.batch(statements);
 // Keep two recent snapshots plus one UTC daily anchor, rather than 1,344
 // full versions over 14 days. Own positions still cover every participant.
 const stale=`SELECT id FROM growth_rank_versions WHERE id NOT IN (SELECT id FROM growth_rank_versions WHERE ready=1 ORDER BY created DESC LIMIT 2) AND (created<? OR id NOT IN (SELECT id FROM (SELECT id,ROW_NUMBER() OVER(PARTITION BY CAST(created/86400000 AS INTEGER) ORDER BY created DESC,id) AS n FROM growth_rank_versions WHERE ready=1) WHERE n=1))`;
 await db.batch([db.prepare('DELETE FROM growth_ranks WHERE version IN ('+stale+')').bind(now-14*DAY),db.prepare('DELETE FROM growth_rank_versions WHERE id IN ('+stale+')').bind(now-14*DAY)]);
}
export async function leaderboard(db,id,metric,seasonId=null,page=1,now=Date.now()){
 if(!Number.isSafeInteger(page)||page<1||page>20)throw new GrowthError('Invalid leaderboard page');
 const config=await growthSettings(db);
 let subject=id;if(metric==='clan')subject=(await db.prepare('SELECT clan_id FROM clan_members WHERE user_id=?').bind(id).first())?.clan_id||'';
 if(seasonId){
  const season=await db.prepare('SELECT * FROM growth_seasons WHERE id=? AND status NOT IN (\'draft\',\'archived\')').bind(seasonId).first();if(!season)throw new GrowthError('Season not found',404);
  const finished=['finished','archived'].includes(seasonState(season,now));
  if(finished){const self=await db.prepare(`SELECT score,rank FROM ${metric==='creator'?'growth_creator_results':'growth_season_results'} WHERE season_id=? AND user_id=?`).bind(seasonId,id).first();const rows=(await db.prepare(`SELECT user_id AS subject,score,rank FROM ${metric==='creator'?'growth_creator_results':'growth_season_results'} WHERE season_id=? ORDER BY rank,user_id LIMIT 50 OFFSET ?`).bind(seasonId,(page-1)*50).all()).results;return {rows:await publicRows(db,rows),self,asOf:season.ends,finalized:!!await db.prepare('SELECT 1 AS n FROM growth_season_finalized WHERE season_id=? LIMIT 1').bind(seasonId).first()};}
  // Active season rank reads use the periodically generated snapshot.
  metric='season:'+seasonId+(metric==='creator'?':creator':'');
 }else if(!['global','fastest','creator','clan'].includes(metric))throw new GrowthError('Unknown leaderboard');
 const version=await db.prepare('SELECT id,created FROM growth_rank_versions WHERE ready=1 ORDER BY created DESC LIMIT 1').first();
 if(!version)return {rows:[],self:null,asOf:null,pending:true};
 const rows=(await db.prepare('SELECT subject,score,rank FROM growth_ranks WHERE version=? AND metric=? ORDER BY rank,subject LIMIT 50 OFFSET ?').bind(version.id,metric,(page-1)*50).all()).results;
 let self=await db.prepare('SELECT score,rank FROM growth_ranks WHERE version=? AND metric=? AND subject=?').bind(version.id,metric,subject).first();
 const restricted=await db.prepare("SELECT 1 AS n FROM growth_trust WHERE user_id=? AND state='RESTRICTED' UNION SELECT 1 FROM abuse_controls WHERE user_id=? AND frozen=1").bind(id,id).first();
 if(!self&&!restricted&&subject&&(metric==='global'||metric==='fastest'||metric==='clan'||metric.startsWith('season:')&&!metric.endsWith(':creator'))){const n=(await db.prepare('SELECT COUNT(*) AS n FROM growth_ranks WHERE version=? AND metric=?').bind(version.id,metric).first()).n;self={score:0,rank:n+1};}
 const old=await db.prepare('SELECT id FROM growth_rank_versions WHERE ready=1 AND created<=? ORDER BY created DESC LIMIT 1').bind(version.created-7*DAY).first();
 const previous=old?await db.prepare('SELECT rank FROM growth_ranks WHERE version=? AND metric=? AND subject=?').bind(old.id,metric,subject).first():null;
 return {rows:await publicRows(db,rows,metric==='clan'),self:self?{...self,weeklyChange:previous?previous.rank-self.rank:null}:null,asOf:version.created,pending:false};
}
async function publicRows(db,rows,clans=false){
 if(!rows.length)return [];
 const keys=rows.map(r=>r.subject);
 if(clans){const names=(await db.prepare(`SELECT id,name FROM clans WHERE id IN (${keys.map(()=>'?').join(',')})`).bind(...keys).all()).results;return rows.map(r=>({name:names.find(c=>c.id===r.subject)?.name||'Clan',score:r.score,rank:r.rank}));}
 const codes=(await db.prepare(`SELECT user_id,code FROM friend_codes WHERE user_id IN (${keys.map(()=>'?').join(',')})`).bind(...keys).all()).results;
 return rows.map(r=>({name:'Walker '+(codes.find(c=>c.user_id===r.subject)?.code.slice(0,8)||'—'),score:r.score,rank:r.rank}));
}
export async function audit(db,actor,action,target,before,after,reason,now=Date.now()){
 await db.prepare('INSERT INTO growth_audit(actor,action,target,before_value,after_value,reason,created) VALUES(?,?,?,?,?,?,?)').bind(actor,action,target,typeof before==='string'?before:JSON.stringify(before),typeof after==='string'?after:JSON.stringify(after),reason,now).run();
}
export async function saveGrowthSettings(db,actor,data,now=Date.now()){
 const current=await growthSettings(db);if(data.revision!==current.revision)throw new GrowthError('Growth settings changed. Refresh.',409);
 const value=validateGrowth(data.settings);if(typeof data.reason!=='string'||data.reason.trim().length<3||data.reason.length>300)throw new GrowthError('A reason is required');
 const result=await db.batch([db.prepare('UPDATE growth_settings SET value=?,revision=revision+1 WHERE id=1 AND revision=? RETURNING revision').bind(JSON.stringify(value),current.revision),db.prepare('INSERT OR IGNORE INTO growth_settings_history(revision,value,created,actor,reason) SELECT revision,value,?,?,? FROM growth_settings WHERE id=1').bind(now,actor,data.reason)]);
 if(!result[0].results.length)throw new GrowthError('Growth settings changed. Refresh.',409);
 invalidate(db,'growth:settings');return growthSettings(db);
}
export async function recountAffectedActive(db,id){
 const host=await db.prepare('SELECT inviter FROM growth_activations WHERE invitee=?').bind(id).first();
 if(host)await db.prepare(`UPDATE growth_active_totals SET total=(SELECT COUNT(*) FROM growth_activations a WHERE a.inviter=? AND NOT EXISTS(SELECT 1 FROM growth_trust t WHERE t.user_id=a.invitee AND t.state='RESTRICTED') AND NOT EXISTS(SELECT 1 FROM abuse_controls b WHERE b.user_id=a.invitee AND b.frozen=1)) WHERE user_id=?`).bind(host.inviter,host.inviter).run();
}
export async function reviewTrust(db,actor,data,now=Date.now()){
 if(!uid(data.userId)||!['NORMAL','PENDING_REVIEW','VERIFIED','RESTRICTED'].includes(data.state)||typeof data.reason!=='string'||data.reason.trim().length<3||data.reason.length>300)throw new GrowthError('Invalid review');
 if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(data.userId).first())throw new GrowthError('Account not found',404);
 const before=await db.prepare('SELECT * FROM growth_trust WHERE user_id=?').bind(data.userId).first();
 await db.batch([db.prepare('INSERT INTO growth_trust(user_id,state,reason,score,updated,actor) VALUES(?,?,?,0,?,?) ON CONFLICT(user_id) DO UPDATE SET state=excluded.state,reason=excluded.reason,updated=excluded.updated,actor=excluded.actor').bind(data.userId,data.state,data.reason,now,actor),db.prepare('INSERT INTO growth_audit(actor,action,target,before_value,after_value,reason,created) VALUES(?,\'trust-review\',?,?,?,?,?)').bind(actor,data.userId,JSON.stringify(before),data.state,data.reason,now)]);await recountAffectedActive(db,data.userId);return {ok:true};
}
export async function trustSignals(db,id,now=Date.now()){
 if(!uid(id))throw new GrowthError('Invalid account');
 const user=await db.prepare('SELECT created FROM users WHERE id=?').bind(id).first();if(!user)throw new GrowthError('Account not found',404);
 const total=await totalInvited(db,id),active=(await db.prepare('SELECT total FROM growth_active_totals WHERE user_id=?').bind(id).first())?.total||0;
 const devices=(await db.prepare('SELECT COUNT(*) AS n FROM pairings WHERE user_id=? AND device_hash IS NOT NULL').bind(id).first()).n;
 const days=(await db.prepare('SELECT COUNT(*) AS n FROM days WHERE user_id=? AND steps>0').bind(id).first()).n;
 const burst=(await db.prepare('SELECT COUNT(*) AS n FROM referrals WHERE inviter=? AND created>=?').bind(id,now-60000).first()).n;
 const rotations=(await db.prepare('SELECT COUNT(*) AS n FROM device_sessions WHERE user_id=? AND started>=?').bind(id,now-DAY).first()).n;
 const ageDays=Math.max(0,Math.floor((now-user.created)/DAY)),conversion=total?active/total:null;
 const signals=[];let score=0;
 if(ageDays<1&&total>=50){signals.push('young-large-pack');score+=25;}
 if(devices===0&&total>=100){signals.push('inviter-no-linked-device');score+=15;}
 if(total>=100&&conversion<.02){signals.push('low-active-conversion');score+=20;}
 if(burst>=100){signals.push('registration-burst-not-proof');score+=20;}
 if(rotations>5){signals.push('device-rotation');score+=20;}
 const retention=await db.prepare('SELECT value,updated FROM growth_creator_cache WHERE user_id=?').bind(id).first();
 return {ageDays,total,active,devices,acceptedStepDays:days,conversion,registrationsLastMinute:burst,deviceRotationsLastDay:rotations,score,signals,retention:retention?JSON.parse(retention.value):null,asOf:now,attestedSteps:false,automaticBan:false};
}
export async function backfillGrowth(db,now=Date.now()){
 const meta=await db.prepare('SELECT * FROM growth_meta WHERE id=1').first();if(meta.backfill_done)return;
 const ids=(await db.prepare('SELECT id FROM users WHERE id>? ORDER BY id LIMIT 80').bind(meta.backfill_cursor).all()).results;
 // One bounded page of users per scheduled invocation; safe to resume/replay.
 if(ids.length){const keys=ids.map(r=>r.id);await db.prepare(`INSERT OR IGNORE INTO growth_totals(user_id,total) SELECT u.id,(SELECT COUNT(*) FROM referral_qualified q WHERE q.inviter=u.id) FROM users u WHERE u.id IN (${keys.map(()=>'?').join(',')}) AND NOT EXISTS(SELECT 1 FROM growth_totals g WHERE g.user_id=u.id)`).bind(...keys).run();await qualifyActive(db,keys,now);}
 await db.prepare('UPDATE growth_meta SET backfill_cursor=?,backfill_done=? WHERE id=1 AND backfill_cursor=?').bind(ids.at(-1)?.id||meta.backfill_cursor,ids.length<80?1:0,meta.backfill_cursor).run();
}
export async function detectBursts(db,now=Date.now()){
 const rows=(await db.prepare('SELECT inviter,COUNT(*) AS n FROM referrals WHERE created>=? GROUP BY inviter HAVING COUNT(*)>=100 LIMIT 100').bind(now-60000).all()).results;
 if(rows.length)await db.batch(rows.flatMap(r=>[
 db.prepare("INSERT OR IGNORE INTO growth_trust(user_id,state,reason,score,updated,actor) VALUES(?,'PENDING_REVIEW','Registration burst; review quality, not growth alone',20,?,'system:burst')").bind(r.inviter,now),
 db.prepare("INSERT INTO growth_audit(actor,action,target,before_value,after_value,reason,created) SELECT 'system:burst','burst-review',user_id,'NORMAL',state,reason,? FROM growth_trust t WHERE user_id=? AND actor='system:burst' AND updated=? AND NOT EXISTS(SELECT 1 FROM growth_audit a WHERE a.action='burst-review' AND a.target=t.user_id)").bind(now,r.inviter,now)
 ]));
 // No automatic restrictions, bans, award removal or Total changes.
}
export async function growthTick(db,now=Date.now()){await backfillGrowth(db,now);await detectBursts(db,now);await finalizeSeasons(db,now);await refreshCreatorAnalytics(db,now);await refreshRanks(db,now);}
