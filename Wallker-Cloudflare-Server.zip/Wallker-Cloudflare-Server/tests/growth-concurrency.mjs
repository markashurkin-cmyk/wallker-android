// Local concurrent HTTP waves against real workerd + disposable D1. No live bot.
import assert from 'node:assert/strict';
import {createHmac,createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {Miniflare} from 'miniflare';
import {requestDB} from '../runtime.mjs';
import {rewardSettings,saveRewardSettings} from '../rewards.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),token='123:CONCURRENT_TEST_ONLY',started=Date.now(),players=Array.from({length:100},(_,i)=>2000001+i);
const mf=new Miniflare({modules:true,scriptPath:root+'worker.js',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{TELEGRAM_BOT_TOKEN:token,ADMIN_TELEGRAM_ID:'1001'}});
const report={type:'local-concurrency-not-remote-capacity',created:new Date(started).toISOString(),players:players.length,waves:[],invariants:[],limits:'Driver launches each wave together; workerd/D1 may queue requests. These timings do not establish Cloudflare production concurrency or p95.'};
function auth(id,start=''){const p=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Concurrent Fixture'}),...(start?{start_param:start}:{})});const key=createHmac('sha256','WebAppData').update(token).digest();p.set('hash',createHmac('sha256',key).update([...p].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex'));return p.toString();}
async function api(path,id,data,extra={}){const {start='',device}=extra;const r=await mf.dispatchFetch('http://localhost'+path,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(id?{'X-Telegram-Init-Data':auth(id,start)}:{}),...(device?{Authorization:'Bearer '+device}:{})},...(data===undefined?{}:{body:JSON.stringify(data)})});const body=await r.json();return {status:r.status,body};}
async function wave(name,jobs,expected=200){const at=performance.now(),times=[];let active=0,maxActive=0;const values=await Promise.all(jobs.map(async job=>{active++;maxActive=Math.max(active,maxActive);const t=performance.now();try{const value=await job();times.push(performance.now()-t);assert.equal(value.status,expected,JSON.stringify({name,value}));return value.body;}finally{active--;}}));times.sort((a,b)=>a-b);const entry={name,requests:jobs.length,driverInFlight:maxActive,ms:Math.round(performance.now()-at),p50:Math.round(times[Math.floor(times.length*.5)]),p95:Math.round(times[Math.min(times.length-1,Math.floor(times.length*.95))]),status:expected};report.waves.push(entry);console.log(JSON.stringify(entry));return values;}
const uid=id=>'tg:'+id;
try{
 assert.equal((await api('/api/wallet',1001)).status,200);const raw=await mf.getD1Database('DB');
 const cfg=await rewardSettings(requestDB(raw));await saveRewardSettings(requestDB(raw),{...cfg,tapDailyLimit:3,energyRegenSeconds:3600});
 await raw.prepare("WITH RECURSIVE n(x) AS(SELECT 1 UNION ALL SELECT x+1 FROM n WHERE x<100) INSERT INTO users(id,name,timezone,mode,created) SELECT 'tg:'||(2000000+x),'Concurrent Fixture','Europe/Moscow','beta',? FROM n").bind(started-60*86400000).run();
 // Warm fixtures in bounded batches; measured waves below are concurrent.
 for(let i=0;i<players.length;i+=10)await Promise.all(players.slice(i,i+10).map(async id=>assert.equal((await api('/api/wallet',id)).status,200)));
 const receipt=id=>'parallel_first_tap_'+id;
 const first=await wave('100-players-tap',players.map(id=>()=>api('/api/tap',id,{count:5,requestId:receipt(id)})));
 assert.ok(first.every(v=>v.accepted===5&&v.tapCoins===.5));
 const replay=await wave('24-identical-retries-one-account',Array.from({length:24},()=>()=>api('/api/tap',players[0],{count:5,requestId:receipt(players[0])})));
 assert.ok(replay.every(v=>v.accepted===5));assert.equal((await raw.prepare('SELECT units FROM tap_paid WHERE user_id=?').bind(uid(players[0])).first()).units,50);
 await wave('24-competing-cap-claims-one-account',Array.from({length:24},(_,i)=>()=>api('/api/tap',players[0],{count:50,requestId:'parallel_cap_request_'+i})));
 const capped=await raw.prepare('SELECT p.units,s.total,s.energy FROM tap_paid p JOIN tap_state s ON s.user_id=p.user_id WHERE p.user_id=?').bind(uid(players[0])).first();assert.equal(capped.units,300);assert.equal(capped.total,30);assert.equal(capped.energy,70);
 assert.equal((await raw.prepare('SELECT SUM(units) AS n FROM tap_awards WHERE user_id=?').bind(uid(players[0])).first()).n,300);
 assert.equal((await raw.prepare('SELECT units FROM tap_paid WHERE user_id=?').bind(uid(players[1])).first()).units,50);
 assert.equal((await api('/api/tap',players[0],{count:6,requestId:receipt(players[0])})).status,409);
 report.invariants.push('Replay exactly once; competing requests stop at exact 3 WC cap; energy deducted once; other accounts unchanged');
 const device='d'.repeat(48),hash=createHash('sha256').update(device).digest('hex'),stepUser=players[49],day=new Date(started+3*3600000).toISOString().slice(0,10);
 await raw.prepare("INSERT INTO pairings(code_hash,user_id,expires,device_hash,platform) VALUES('concurrency-step-device',?,?,?,'android')").bind(uid(stepUser),started+86400000,hash).run();
 const counts=Array.from({length:24},(_,i)=>((i*7)%12+1)*1000);
 await wave('24-overlapping-step-reports',counts.map(steps=>()=>api('/api/device/steps',null,{day,steps},{device})));
 assert.equal((await raw.prepare('SELECT steps FROM days WHERE user_id=? AND day=?').bind(uid(stepUser),day).first()).steps,12000);
 assert.equal((await raw.prepare('SELECT units FROM step_rewards WHERE user_id=? AND day=?').bind(uid(stepUser),day).first()).units,400000);
 assert.equal((await raw.prepare('SELECT steps FROM trusted_step_totals WHERE user_id=?').bind(uid(stepUser)).first()).steps,10000);
 assert.equal((await api('/api/wallet',stepUser)).body.balance,4000.5);report.invariants.push('Out-of-order repeated step reports converge to max 12000 steps and exactly 4000 WC, with rank progress capped at 10000/day and without double credit');
 const code=(await api('/api/friends',players[0])).body.code,ownerCode=(await api('/api/friends',1001)).body.code;
 await wave('50-first-open-referrals',Array.from({length:50},(_,i)=>()=>api('/api/wallet',3000001+i,undefined,{start:'ref_'+code})));
 await wave('20-competing-inviters-one-new-account',Array.from({length:20},(_,i)=>()=>api('/api/wallet',3500000,undefined,{start:'ref_'+(i%2?ownerCode:code)})));
 assert.equal((await raw.prepare("SELECT COUNT(*) AS n FROM referral_qualified WHERE invitee='tg:3500000'").first()).n,1);
 const totals=await raw.prepare('SELECT SUM(total) AS n FROM growth_totals WHERE user_id IN (?,?)').bind(uid(players[0]),'tg:1001').first();assert.equal(totals.n,51);
 assert.equal((await api('/api/wallet',players[0])).body.balance,3);report.invariants.push('51 distinct new accounts counted once; competing inviters cannot duplicate attribution; no fixed invite coin awards or retroactive tap changes');
 const packs=await wave('100-players-read-my-pack',players.map(id=>()=>api('/api/growth',id)));
 assert.ok(packs.every(p=>p.catalog.length===10));
 assert.equal((await raw.prepare('SELECT COUNT(*) AS n FROM growth_milestones WHERE user_id=? AND milestone=1').bind(uid(players[0])).first()).n,1);
 await wave('20-unauthenticated-tap-requests',Array.from({length:20},()=>()=>api('/api/tap',null,{count:50,requestId:'invalid_auth_request_01'})),401);
 assert.equal((await raw.prepare('SELECT units FROM tap_paid WHERE user_id=?').bind(uid(players[0])).first()).units,300);
 report.invariants.push('Achievement deduplicated under read waves; unauthenticated traffic creates no rewards');
 await writeFile(root+'growth-concurrency-results.json',JSON.stringify(report,null,2)+'\n');console.log('PASS: concurrent signed user/device HTTP waves, exactly-once rewards, cap/energy, isolation, step convergence and immutable referral attribution.');
}catch(error){report.error=String(error);await writeFile(root+'growth-concurrency-results.json',JSON.stringify(report,null,2)+'\n');throw error;}finally{await mf.dispose();}
