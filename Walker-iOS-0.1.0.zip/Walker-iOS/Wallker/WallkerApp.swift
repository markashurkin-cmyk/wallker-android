import SwiftUI
import CoreMotion
import Combine
import Security

@main struct WallkerApp: App {
    var body: some Scene { WindowGroup { WallkerView() } }
}
struct APIProblem: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}
enum TokenStore {
    static let service = "com.wallker.device"
    static func get() -> String? {
        var result: CFTypeRef?
        let q: [String: Any] = [kSecClass as String:kSecClassGenericPassword, kSecAttrService as String:service, kSecAttrAccount as String:"token", kSecReturnData as String:true, kSecMatchLimit as String:kSecMatchLimitOne]
        guard SecItemCopyMatching(q as CFDictionary,&result)==errSecSuccess, let d=result as? Data else{return nil}
        return String(data:d,encoding:.utf8)
    }
    static func save(_ token:String) throws {
        let q:[String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,kSecAttrAccount as String:"token"]
        let attributes:[String:Any] = [kSecValueData as String:Data(token.utf8), kSecAttrAccessible as String:kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        let status = SecItemUpdate(q as CFDictionary,attributes as CFDictionary)
        if status == errSecItemNotFound {
            var item=q; attributes.forEach { item[$0.key]=$0.value }
            guard SecItemAdd(item as CFDictionary,nil)==errSecSuccess else { throw APIProblem(message:"Не удалось сохранить привязку") }
        } else if status != errSecSuccess { throw APIProblem(message:"Не удалось сохранить привязку") }
    }
    static func clear() {SecItemDelete([kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,kSecAttrAccount as String:"token"] as CFDictionary)}
}
// One persisted ledger: daily totals and the baseline for the current tracking segment.
// Querying the same segment again replaces its contribution rather than adding it twice.
struct StepLedger: Codable {
    var accountId: String?
    var started: Date?
    var enabled = false
    var totals: [String:Int] = [:]
    var baseline: [String:Int] = [:]
    var sent: [String:Int] = [:]
}
@MainActor final class WallkerModel: ObservableObject {
    @Published var code = ""
    @Published var message = "Включи шагомер. Подключение к Apple Health не требуется."
    @Published var busy = false
    @Published var paired = TokenStore.get() != nil
    @Published var steps = 0
    @Published var tracking = false
    @Published var pending = 0
    @Published var confirmAccountChange = false
    private var checkedAccountId: String?
    private let pedometer = CMPedometer()
    private var ledger: StepLedger
    private let origin = URL(string:"https://wallker-wallet.markashurkin.workers.dev")!
    private var timezone: String { UserDefaults.standard.string(forKey:"wallkerTimezone") ?? "Europe/Moscow" }
    private var calendar: Calendar {
        var c = Calendar(identifier:.gregorian); c.timeZone = TimeZone(identifier:timezone) ?? .current; return c
    }
    init() {
        ledger = UserDefaults.standard.data(forKey:"stepLedger").flatMap { try? JSONDecoder().decode(StepLedger.self,from:$0) } ?? StepLedger()
        tracking = ledger.enabled
        updateDisplay()
    }
    private func day(_ date:Date) -> String {
        let f = DateFormatter(); f.calendar = calendar; f.locale = Locale(identifier:"en_US_POSIX"); f.timeZone = calendar.timeZone; f.dateFormat = "yyyy-MM-dd"; return f.string(from:date)
    }
    private func updateDisplay() {
        steps = ledger.totals[day(Date())] ?? 0
        pending = ledger.totals.filter { $0.value > (ledger.sent[$0.key] ?? 0) }.count
    }
    private func save() {
        if let data = try? JSONEncoder().encode(ledger) { UserDefaults.standard.set(data,forKey:"stepLedger") }
        updateDisplay()
    }
    private func query(_ start:Date,_ end:Date) async throws -> Int {
        try await withCheckedThrowingContinuation { continuation in
            pedometer.queryPedometerData(from:start,to:end) { data,error in
                if let error { continuation.resume(throwing:error) }
                else { continuation.resume(returning:data?.numberOfSteps.intValue ?? 0) }
            }
        }
    }
    func request(_ path:String,body:[String:Any],token:String? = nil) async throws -> [String:Any] {
        var req = URLRequest(url:origin.appendingPathComponent(path)); req.httpMethod = "POST"; req.timeoutInterval = 15
        req.setValue("application/json",forHTTPHeaderField:"Content-Type")
        if let token { req.setValue("Bearer \(token)",forHTTPHeaderField:"Authorization") }
        req.httpBody = try JSONSerialization.data(withJSONObject:body)
        let (data,response) = try await URLSession.shared.data(for:req)
        guard let result = try? JSONSerialization.jsonObject(with:data) as? [String:Any] else { throw APIProblem(message:"Сервер временно недоступен") }
        guard let http = response as? HTTPURLResponse,(200..<300).contains(http.statusCode) else { throw APIProblem(message:result["error"] as? String ?? "Ошибка сервера") }
        return result
    }
    func pair(allowAccountChange: Bool = false) async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do {
            let value=code.trimmingCharacters(in:.whitespacesAndNewlines)
            guard value.range(of:"^[a-f0-9]{48}$",options:.regularExpression) != nil else { throw APIProblem(message:"Вставь полный код из Telegram: 48 символов") }
            let previousToken=TokenStore.get()
            let check=try await request("api/device/pair",body:["code":value,"platform":"ios","checkOnly":true],token:previousToken)
            guard let accountId=check["accountId"] as? String else { throw APIProblem(message:"Не удалось проверить аккаунт") }
            let first=previousToken == nil && ledger.accountId == nil
            let same=ledger.accountId.map { $0 == accountId } ?? (check["sameAccount"] as? Bool ?? false)
            if !first && !same && (!allowAccountChange || checkedAccountId != accountId) {
                checkedAccountId=accountId; confirmAccountChange=true; return
            }
            let r=try await request("api/device/pair",body:["code":value,"platform":"ios","expectedAccountId":accountId],token:previousToken)
            guard let token=r["token"] as? String, let tz=r["timezone"] as? String,
                  r["accountId"] as? String == accountId else { throw APIProblem(message:"Неверный ответ сервера") }
            try TokenStore.save(token)
            if !first && !same { pedometer.stopUpdates(); ledger=StepLedger(); tracking=false }
            ledger.accountId=accountId
            UserDefaults.standard.set(tz,forKey:"wallkerTimezone")
            // Server totals are acknowledgements, not additional steps on this phone.
            for row in r["history"] as? [[String:Any]] ?? [] {
                if let day=row["day"] as? String,let count=row["steps"] as? Int {
                    ledger.sent[day]=max(ledger.sent[day] ?? 0,count)
                }
            }
            paired=true; code=""; checkedAccountId=nil; save()
            message=same ? "Привязка обновлена. Шаги на телефоне сохранены." : "Телефон привязан. Включи шагомер и передай шаги."
        } catch { message=error.localizedDescription }
    }
    func start() async {
        guard !busy else { return }
        guard CMPedometer.isStepCountingAvailable() else { message = "На этом устройстве нет доступного шагомера"; return }
        busy = true; defer { busy = false }
        do {
            let now = Date()
            _ = try await query(now.addingTimeInterval(-1),now) // System motion permission prompt.
            if !ledger.enabled { ledger.started = now; ledger.baseline = ledger.totals; ledger.enabled = true }
            tracking = true; save(); message = "Шагомер включён. Носи iPhone с собой."
        } catch { message = "Разреши Walker доступ к движению в настройках iPhone. \(error.localizedDescription)" }
    }
    private func readSteps() async throws {
        let now = Date(), today = calendar.startOfDay(for:now)
        let oldest = calendar.date(byAdding:.day,value:-6,to:today)!
        let oldestKey = day(oldest)
        ledger.totals = ledger.totals.filter { $0.key >= oldestKey }
        ledger.sent = ledger.sent.filter { $0.key >= oldestKey }
        ledger.baseline = ledger.baseline.filter { $0.key >= oldestKey }
        save()
        guard ledger.enabled, let segmentStart = ledger.started else { return }
        for offset in 0...6 {
            let start = calendar.date(byAdding:.day,value:-offset,to:today)!
            let end = min(calendar.date(byAdding:.day,value:1,to:start)!,now)
            let from = max(start,segmentStart)
            guard from < end else { continue }
            let value = try await query(from,end), key = day(start)
            ledger.totals[key] = min(100000,max(ledger.totals[key] ?? 0,(ledger.baseline[key] ?? 0)+value))
            save() // Persist each successful query even if the next one fails.
        }
    }
    func refresh() async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do {
            try await readSteps()
            guard let token = TokenStore.get() else { message = "Шаги сохраняются на телефоне. Привяжи Telegram для начисления монет."; return }
            for key in ledger.totals.keys.sorted() {
                let value = ledger.totals[key] ?? 0
                guard value > (ledger.sent[key] ?? 0) else { continue }
                _ = try await request("api/device/steps",body:["day":key,"steps":value],token:token)
                ledger.sent[key] = value; save()
            }
            message = "Шаги сохранены и переданы. Обнови баланс в Telegram."
        } catch { message = "Шаги остаются на телефоне. Повторим передачу при следующем открытии. \(error.localizedDescription)" }
    }
    func stop() async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do { try await readSteps() } catch { /* Preserve existing totals even when motion permission was revoked. */ }
        pedometer.stopUpdates(); ledger.enabled = false; tracking = false; save(); message = "Шагомер приостановлен. Сохранённые шаги доступны для передачи."
    }
    func unlink() {
        pedometer.stopUpdates(); TokenStore.clear(); ledger = StepLedger(); tracking = false; paired = false; save()
        message = "Привязка и местные шаги удалены. Для отзыва доступа отключи телефон в Telegram."
    }
}
struct WallkerView: View {
    @StateObject private var model = WallkerModel()
    @Environment(\.scenePhase) private var scenePhase
    @State private var confirmClear=false
    private let timer = Timer.publish(every:60,on:.main,in:.common).autoconnect()
    var body: some View {
        NavigationStack { Form {
            Section {
                Text("Шаги — здесь. Кошелёк — в Telegram.").font(.headline)
                Link("Открыть кошелёк в Telegram",destination:URL(string:"https://t.me/wallker_wallet_bot")!)
            }
            Section("Шаги сегодня") {
                Text(model.steps.formatted()).font(.system(size:48,weight:.bold,design:.rounded))
                Text(model.tracking ? "Шагомер включён" : "Шагомер приостановлен")
                Button(model.tracking ? "Приостановить шагомер" : "Включить шагомер") { Task { if model.tracking { await model.stop() } else { await model.start(); await model.refresh() } } }.disabled(model.busy)
                Text("Шаги учитываются с момента включения. Носи телефон с собой. При открытии Walker восстановит доступную историю за последние семь дней.")
            }
            Section(model.paired ? "Обновить привязку Telegram" : "Подключить Telegram") {
                Text(model.paired ? "Telegram подключён" : "В Telegram открой раздел «Телефон» и получи код привязки.")
                TextField("Одноразовый код из Walker",text:$model.code).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Привязать телефон") { Task { await model.pair() } }.disabled(model.busy || model.code.count != 48)
            }
            Section("Передача шагов") {
                Text("Дней ожидают передачи: \(model.pending)")
                Button("Обновить шаги и передать") { Task { await model.refresh() } }.disabled(model.busy || !model.paired)
                Button("Отключить и очистить местные шаги",role:.destructive) { confirmClear=true }.disabled(model.busy)
            }
            Section("Статус") { if model.busy { ProgressView() }; Text(model.message) }
            Section("О данных") { Text("Передаются только дата и число шагов. Apple Health, маршруты и пульс не используются. Передача выполняется при открытом Walker; без интернета шаги сохраняются. WC — игровые монеты бета-версии без вывода.") }
        }.navigationTitle("Walker Wallet") }.preferredColorScheme(.dark).tint(Color(red:0.76,green:0.95,blue:0.30))
        .alert("Другой аккаунт Telegram",isPresented:$model.confirmAccountChange) {
            Button("Сменить аккаунт",role:.destructive) { Task { await model.pair(allowAccountChange:true) } }
            Button("Отмена",role:.cancel) {}
        } message: { Text("При продолжении местные шаги прежнего аккаунта будут очищены. Серверная история останется в его Telegram-кошельке.") }
        .alert("Очистить данные телефона?",isPresented:$confirmClear) {
            Button("Очистить",role:.destructive) { model.unlink() }
            Button("Отмена",role:.cancel) {}
        } message: { Text("Привязка и ещё не переданные шаги будут удалены. Уже переданная история останется в Telegram.") }
        .task { await model.refresh() }
        .onChange(of:scenePhase) { _,phase in if phase == .active { Task { await model.refresh() } } }
        .onReceive(timer) { _ in if scenePhase == .active { Task { await model.refresh() } } }
    }
}
